/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = 3000;

app.use(express.json());

const dbPath = path.join(process.cwd(), 'src', 'data', 'db.json');

// Helper to read database
function readDB() {
  try {
    if (!fs.existsSync(dbPath)) {
      return { users: [], menu: [], orders: [] };
    }
    const data = fs.readFileSync(dbPath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Failed to read DB:', error);
    return { users: [], menu: [], orders: [] };
  }
}

// Helper to write database
function writeDB(data: any) {
  try {
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(dbPath, JSON.stringify(data, null, 2), 'utf8');
  } catch (error) {
    console.error('Failed to write DB:', error);
  }
}

// Helper to extract user from token
function getAuthenticatedUser(req: express.Request) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.split(' ')[1];
  // Format of mock token: mock-jwt-token-for-${userId}-${role}
  if (!token.startsWith('mock-jwt-token-for-')) {
    return null;
  }
  const tokenStr = token.replace('mock-jwt-token-for-', '');
  const lastDashIdx = tokenStr.lastIndexOf('-');
  const userId = lastDashIdx !== -1 ? tokenStr.substring(0, lastDashIdx) : tokenStr;
  
  const db = readDB();
  return db.users.find((u: any) => u.id === userId) || null;
}

// Dynamic Notifications Store
let notifications: any[] = [];

// Seed some initial system notifications if empty
if (notifications.length === 0) {
  notifications = [
    {
      id: 'notif-1',
      message: 'Bistro Guru Kitchen Console initialized. System is online.',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      read: false,
      recipientRole: 'all'
    },
    {
      id: 'notif-2',
      message: 'New order ticket #B-1005 received for delivery.',
      timestamp: new Date(Date.now() - 1800000).toISOString(),
      read: false,
      recipientRole: 'staff'
    }
  ];
}

// API ROUTES

// 1. Auth - Register (Customer Profile Creation)
app.post('/api/auth/register', (req, res) => {
  const { username, password, name, email, phone, address } = req.body;
  if (!username || !password || !name || !email) {
    return res.status(400).json({ error: 'All fields (username, password, name, email) are required' });
  }

  const db = readDB();
  const existingUser = db.users.find((u: any) => u.username.toLowerCase() === username.toLowerCase());
  if (existingUser) {
    return res.status(400).json({ error: 'Username already exists. Choose another one.' });
  }

  const newUser = {
    id: `u-${Date.now()}`,
    username,
    password,
    name,
    role: 'customer',
    email,
    phone: phone || '',
    address: address || '',
    loyaltyPoints: 50 // Signup bonus points
  };

  db.users.push(newUser);
  writeDB(db);

  // Generate mock JWT token
  const token = `mock-jwt-token-for-${newUser.id}-customer`;
  const { password: _, ...safeUser } = newUser;

  // Add welcome notification
  notifications.unshift({
    id: `notif-${Date.now()}`,
    message: `Welcome to Bistro Guru, ${name}! You earned 50 loyalty points as a signup bonus.`,
    timestamp: new Date().toISOString(),
    read: false,
    recipientRole: 'customer',
    recipientId: newUser.id
  });

  res.status(201).json({
    token,
    user: safeUser
  });
});

// 2. Auth - Login
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  const db = readDB();
  const user = db.users.find(
    (u: any) => u.username.toLowerCase() === username.toLowerCase() && u.password === password
  );

  if (!user) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }

  const token = `mock-jwt-token-for-${user.id}-${user.role}`;
  const { password: _, ...safeUser } = user;
  res.json({
    token,
    user: safeUser
  });
});

// 3. Auth - Bypass login for quick test testing
app.post('/api/auth/bypass-login', (req, res) => {
  const { username } = req.body;
  if (!username) {
    return res.status(400).json({ error: 'Username is required' });
  }

  const db = readDB();
  const user = db.users.find(
    (u: any) => u.username.toLowerCase() === username.toLowerCase()
  );

  if (!user) {
    return res.status(404).json({ error: 'User profile not found' });
  }

  const token = `mock-jwt-token-for-${user.id}-${user.role}`;
  const { password: _, ...safeUser } = user;
  res.json({
    token,
    user: safeUser,
    password: user.password
  });
});

// 4. Auth - Me
app.get('/api/auth/me', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  const { password: _, ...safeUser } = user;
  res.json(safeUser);
});

// 5. Auth - Update profile/address/phone
app.put('/api/auth/profile', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const db = readDB();
  const idx = db.users.findIndex((u: any) => u.id === user.id);
  if (idx === -1) return res.status(404).json({ error: 'User profile not found' });

  const { name, email, phone, address, password } = req.body;
  db.users[idx] = {
    ...db.users[idx],
    name: name || db.users[idx].name,
    email: email || db.users[idx].email,
    phone: phone !== undefined ? phone : db.users[idx].phone,
    address: address !== undefined ? address : db.users[idx].address,
    password: password || db.users[idx].password,
  };

  writeDB(db);
  const { password: _, ...safeUser } = db.users[idx];
  res.json(safeUser);
});

// 6. Menu Management (Products CRUD)
app.get('/api/menu', (req, res) => {
  const db = readDB();
  const normalizedMenu = (db.menu || []).map((item: any) => ({
    ...item,
    stock: item.stock !== undefined ? Number(item.stock) : 10,
    threshold: item.threshold !== undefined ? Number(item.threshold) : 3
  }));
  res.json(normalizedMenu);
});

app.post('/api/menu', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. Administrator privileges required.' });
  }

  const db = readDB();
  const { name, description, price, category, isAvailable, image, prepTime, stock, threshold } = req.body;
  if (!name || !price || !category) {
    return res.status(400).json({ error: 'Name, price, and category are required' });
  }

  const newMenuItem = {
    id: `m-${Date.now()}`,
    name,
    description: description || '',
    price: Number(price) || 0,
    category,
    isAvailable: isAvailable !== undefined ? isAvailable : true,
    image: image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3',
    prepTime: Number(prepTime) || 15,
    stock: stock !== undefined ? Number(stock) : 10,
    threshold: threshold !== undefined ? Number(threshold) : 3
  };

  db.menu = db.menu || [];
  db.menu.push(newMenuItem);
  writeDB(db);

  notifications.unshift({
    id: `notif-${Date.now()}`,
    message: `Chef Sarah added a new dish: "${name}" under ${category}.`,
    timestamp: new Date().toISOString(),
    read: false,
    recipientRole: 'all'
  });

  res.status(201).json(newMenuItem);
});

app.put('/api/menu/:id', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user || (user.role !== 'admin' && user.role !== 'staff')) {
    return res.status(403).json({ error: 'Access denied' });
  }

  const db = readDB();
  const idx = db.menu.findIndex((m: any) => m.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Menu item not found' });

  const { name, description, price, category, isAvailable, image, prepTime, stock, threshold } = req.body;
  
  db.menu[idx] = {
    ...db.menu[idx],
    name: name !== undefined ? name : db.menu[idx].name,
    description: description !== undefined ? description : db.menu[idx].description,
    price: price !== undefined ? Number(price) : db.menu[idx].price,
    category: category !== undefined ? category : db.menu[idx].category,
    isAvailable: isAvailable !== undefined ? isAvailable : db.menu[idx].isAvailable,
    image: image !== undefined ? image : db.menu[idx].image,
    prepTime: prepTime !== undefined ? Number(prepTime) : db.menu[idx].prepTime,
    stock: stock !== undefined ? Number(stock) : (db.menu[idx].stock !== undefined ? Number(db.menu[idx].stock) : 10),
    threshold: threshold !== undefined ? Number(threshold) : (db.menu[idx].threshold !== undefined ? Number(db.menu[idx].threshold) : 3)
  };

  writeDB(db);
  res.json(db.menu[idx]);
});

app.delete('/api/menu/:id', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied' });
  }

  const db = readDB();
  const item = db.menu.find((m: any) => m.id === req.params.id);
  if (!item) return res.status(404).json({ error: 'Menu item not found' });

  db.menu = db.menu.filter((m: any) => m.id !== req.params.id);
  writeDB(db);

  res.json({ success: true, message: `Dish "${item.name}" deleted successfully` });
});

// 7. Ordering Processes
app.get('/api/orders', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const db = readDB();
  const orders = db.orders || [];

  if (user.role === 'customer') {
    // Customers only see their own order history
    const customerOrders = orders.filter((o: any) => o.customerId === user.id);
    return res.json(customerOrders);
  }

  // Admin and Staff can see all orders
  res.json(orders);
});

app.post('/api/orders', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const { items, type, tableNumber, deliveryAddress, discountCode, paymentMethod, notes } = req.body;

  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'An order must contain at least one item' });
  }

  const db = readDB();
  let subtotal = 0;
  const processedItems = [];

  // Check and process menu items
  for (const item of items) {
    const menuItem = db.menu.find((m: any) => m.id === item.menuItemId);
    if (!menuItem) {
      return res.status(404).json({ error: `Dish item ${item.menuItemId} does not exist in our catalog` });
    }
    if (!menuItem.isAvailable) {
      return res.status(400).json({ error: `"${menuItem.name}" is currently out of stock.` });
    }

    const currentStock = menuItem.stock !== undefined ? Number(menuItem.stock) : 10;
    if (currentStock < item.quantity) {
      return res.status(400).json({ error: `Only ${currentStock} portion(s) of "${menuItem.name}" are available in stock.` });
    }

    // Decrement stock
    menuItem.stock = Math.max(0, currentStock - item.quantity);
    if (menuItem.stock === 0) {
      menuItem.isAvailable = false;
    }

    const itemSubtotal = menuItem.price * item.quantity;
    subtotal += itemSubtotal;

    processedItems.push({
      menuItemId: menuItem.id,
      name: menuItem.name,
      price: menuItem.price,
      quantity: item.quantity,
      subtotal: itemSubtotal
    });

    // Check low stock threshold
    const currentThreshold = menuItem.threshold !== undefined ? Number(menuItem.threshold) : 3;
    if (menuItem.stock <= currentThreshold) {
      notifications.unshift({
        id: `notif-${Date.now()}-${menuItem.id}`,
        message: `Low stock alert: "${menuItem.name}" has dropped to ${menuItem.stock} item(s) (threshold: ${currentThreshold}).`,
        timestamp: new Date().toISOString(),
        read: false,
        recipientRole: 'staff'
      });
    }
  }

  // Validate discount codes
  let discountAmount = 0;
  const dCode = (discountCode || '').trim().toUpperCase();
  if (dCode === 'WELCOME10') {
    discountAmount = Math.round((subtotal * 0.1) * 100) / 100;
  } else if (dCode === 'BISTROLIFE') {
    discountAmount = Math.round((subtotal * 0.2) * 100) / 100;
  }

  // Calculate taxes (e.g. 8%) and total
  const taxable = Math.max(0, subtotal - discountAmount);
  const taxAmount = Math.round((taxable * 0.08) * 100) / 100;
  const total = Math.round((taxable + taxAmount) * 100) / 100;

  // sequential ticket generation
  const today = new Date();
  const ticketCount = ordersTodayCount(db.orders || [], today) + 1;
  const orderNumber = `B-${1000 + ticketCount}`;

  // Calculate Loyalty points (1 point per dollar spent on total)
  const earnedPoints = Math.floor(total);

  // Determine Customer details
  let customerId = user.id;
  let customerName = user.name;
  
  // Staff taking orders for walks-in customers
  if (user.role === 'staff' && req.body.walkInCustomerName) {
    customerId = 'walk-in';
    customerName = req.body.walkInCustomerName;
  }

  const newOrder = {
    id: `ord-${Date.now()}`,
    orderNumber,
    date: today.toISOString(),
    customerId,
    customerName,
    items: processedItems,
    subtotal,
    discountCode: dCode,
    discountAmount,
    taxAmount,
    total,
    type: type || 'dine-in',
    tableNumber: type === 'dine-in' ? (Number(tableNumber) || 1) : undefined,
    deliveryAddress: type === 'delivery' ? (deliveryAddress || user.address || '') : undefined,
    status: 'pending',
    paymentMethod: paymentMethod || 'cash',
    paymentStatus: paymentMethod === 'cash' ? 'pending' : 'paid', // Cash is paid at pickup/table
    earnedPoints,
    notes: notes || ''
  };

  db.orders = db.orders || [];
  db.orders.push(newOrder);

  // Award points to the customer if registered
  if (user.role === 'customer') {
    const userIdx = db.users.findIndex((u: any) => u.id === user.id);
    if (userIdx !== -1) {
      db.users[userIdx].loyaltyPoints = (db.users[userIdx].loyaltyPoints || 0) + earnedPoints;
    }
  }

  writeDB(db);

  // Notify Staff & Admin
  notifications.unshift({
    id: `notif-${Date.now()}`,
    message: `New Order ${orderNumber} placed for ${type} (${processedItems.length} items, total $${total.toFixed(2)})`,
    timestamp: today.toISOString(),
    read: false,
    recipientRole: 'staff'
  });

  res.status(201).json(newOrder);
});

// Helper for sales ticker counts
function ordersTodayCount(orders: any[], targetDate: Date) {
  const targetStr = targetDate.toISOString().split('T')[0];
  return orders.filter((o: any) => o.date.startsWith(targetStr)).length;
}

// 8. Order Tracking & Status Updates
app.put('/api/orders/:id/status', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user || user.role === 'customer') {
    return res.status(403).json({ error: 'Access denied. Restaurant staff credentials required.' });
  }

  const { status } = req.body;
  if (!status) return res.status(400).json({ error: 'Status is required' });

  const db = readDB();
  const idx = db.orders.findIndex((o: any) => o.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Order not found' });

  const previousStatus = db.orders[idx].status;
  db.orders[idx].status = status;

  // Automatically mark cash orders as paid when delivered
  if (status === 'delivered' && db.orders[idx].paymentMethod === 'cash') {
    db.orders[idx].paymentStatus = 'paid';
  }

  writeDB(db);

  // Add Notification for customer
  const orderNum = db.orders[idx].orderNumber;
  let statusMessage = `Your order ${orderNum} status is now: ${status.toUpperCase()}.`;
  if (status === 'preparing') {
    statusMessage = `Chef is preparing your order ${orderNum}!`;
  } else if (status === 'ready') {
    statusMessage = `Your order ${orderNum} is ready! ${db.orders[idx].type === 'dine-in' ? 'Preparing to serve at Table ' + db.orders[idx].tableNumber : 'Ready for pickup!'}`;
  } else if (status === 'delivered') {
    statusMessage = `Your order ${orderNum} has been successfully ${db.orders[idx].type === 'delivery' ? 'delivered! Enjoy your meal!' : 'served!'}`;
  }

  notifications.unshift({
    id: `notif-${Date.now()}`,
    message: statusMessage,
    timestamp: new Date().toISOString(),
    read: false,
    recipientRole: 'customer',
    recipientId: db.orders[idx].customerId
  });

  res.json(db.orders[idx]);
});

// 9. Payment Settlement Gateway Simulation
app.put('/api/orders/:id/payment', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });

  const { paymentMethod } = req.body;

  const db = readDB();
  const idx = db.orders.findIndex((o: any) => o.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Order ticket not found' });

  db.orders[idx].paymentStatus = 'paid';
  if (paymentMethod) {
    db.orders[idx].paymentMethod = paymentMethod;
  }

  writeDB(db);

  notifications.unshift({
    id: `notif-${Date.now()}`,
    message: `Payment successful for order ${db.orders[idx].orderNumber} ($${db.orders[idx].total.toFixed(2)}) via ${db.orders[idx].paymentMethod.toUpperCase()}`,
    timestamp: new Date().toISOString(),
    read: false,
    recipientRole: 'staff'
  });

  res.json(db.orders[idx]);
});

// 10. Staff Management API (Optional but brilliant for full Admin control)
app.get('/api/staff', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied' });
  }

  const db = readDB();
  const staffMembers = db.users.filter((u: any) => u.role === 'staff' || u.role === 'admin');
  res.json(staffMembers.map((s: any) => {
    const { password: _, ...safe } = s;
    return safe;
  }));
});

app.post('/api/staff', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied' });
  }

  const { username, password, name, email } = req.body;
  if (!username || !password || !name || !email) {
    return res.status(400).json({ error: 'All fields (username, password, name, email) are required' });
  }

  const db = readDB();
  const exists = db.users.some((u: any) => u.username.toLowerCase() === username.toLowerCase());
  if (exists) return res.status(400).json({ error: 'Username already in use' });

  const newStaff = {
    id: `u-${Date.now()}`,
    username,
    password,
    name,
    role: 'staff',
    email
  };

  db.users.push(newStaff);
  writeDB(db);

  res.status(201).json(newStaff);
});

// 11. Notifications Fetching
app.get('/api/notifications', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user) {
    // Fallback for public or boot checks
    return res.json(notifications);
  }

  // Filter alerts based on role and recipient ID
  const filtered = notifications.filter((n: any) => {
    if (n.recipientRole === 'all') return true;
    if (user.role === 'admin' || user.role === 'staff') {
      return n.recipientRole === 'staff';
    } else {
      // Customer
      return n.recipientRole === 'customer' && n.recipientId === user.id;
    }
  });

  res.json(filtered);
});

app.post('/api/notifications/clear-all', (req, res) => {
  notifications = [];
  res.json({ success: true });
});

app.post('/api/notifications/:id/read', (req, res) => {
  const note = notifications.find(n => n.id === req.params.id);
  if (note) {
    note.read = true;
  }
  res.json({ success: true });
});

// 12. Dashboard Reporting & Analytics API
app.get('/api/reports/dashboard', (req, res) => {
  const user = getAuthenticatedUser(req);
  if (!user || user.role === 'customer') {
    return res.status(403).json({ error: 'Access denied' });
  }

  const db = readDB();
  const orders = db.orders || [];

  // General Totals
  let totalSales = 0;
  let completedOrdersCount = 0;
  let activeOrdersCount = 0;

  // Popular Dishes map
  const dishQuantities: Record<string, { qty: number; revenue: number }> = {};

  orders.forEach((o: any) => {
    if (o.status !== 'cancelled') {
      totalSales += o.total;
      
      if (o.status === 'delivered') {
        completedOrdersCount++;
      } else {
        activeOrdersCount++;
      }

      o.items.forEach((item: any) => {
        if (!dishQuantities[item.name]) {
          dishQuantities[item.name] = { qty: 0, revenue: 0 };
        }
        dishQuantities[item.name].qty += item.quantity;
        dishQuantities[item.name].revenue += item.subtotal;
      });
    }
  });

  const averageOrderValue = orders.length > 0 ? Math.round((totalSales / orders.length) * 100) / 100 : 0;

  // Formatting Popular Dishes (sort and top 5)
  const popularDishes = Object.keys(dishQuantities)
    .map(name => ({
      name,
      quantity: dishQuantities[name].qty,
      revenue: Math.round(dishQuantities[name].revenue * 100) / 100
    }))
    .sort((a, b) => b.quantity - a.quantity)
    .slice(0, 5);

  // Group by Date (last 7 days)
  const dateMap: Record<string, { amount: number; count: number }> = {};
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dayStr = d.toISOString().split('T')[0];
    dateMap[dayStr] = { amount: 0, count: 0 };
  }

  orders.forEach((o: any) => {
    const dayStr = o.date.split('T')[0];
    if (dateMap[dayStr] !== undefined && o.status !== 'cancelled') {
      dateMap[dayStr].amount += o.total;
      dateMap[dayStr].count += 1;
    }
  });

  const salesByDate = Object.keys(dateMap).sort().map(date => ({
    date,
    amount: Math.round(dateMap[date].amount * 100) / 100,
    count: dateMap[date].count
  }));

  // Type ratio
  const typeMap: Record<string, number> = { 'dine-in': 0, takeaway: 0, delivery: 0 };
  orders.forEach((o: any) => {
    if (o.status !== 'cancelled') {
      typeMap[o.type] = (typeMap[o.type] || 0) + o.total;
    }
  });
  const ordersByType = Object.keys(typeMap).map(type => ({
    type: type.toUpperCase(),
    value: Math.round(typeMap[type] * 100) / 100
  }));

  // Status ratio
  const statusMap: Record<string, number> = { pending: 0, preparing: 0, ready: 0, delivered: 0, cancelled: 0 };
  orders.forEach((o: any) => {
    statusMap[o.status] = (statusMap[o.status] || 0) + 1;
  });
  const ordersByStatus = Object.keys(statusMap).map(status => ({
    status: status.toUpperCase(),
    value: statusMap[status]
  }));

  res.json({
    totalSales: Math.round(totalSales * 100) / 100,
    totalOrders: orders.length,
    completedOrdersCount,
    activeOrdersCount,
    averageOrderValue,
    popularDishes,
    salesByDate,
    ordersByType,
    ordersByStatus
  });
});

// CSV Export route
app.get('/api/reports/export/:type', (req, res) => {
  const type = req.params.type;
  const db = readDB();

  if (type === 'sales') {
    let csv = 'Order Number,Date,Customer,Type,Items Count,Subtotal,Discount,Tax,Total,Status,Payment\n';
    db.orders.forEach((o: any) => {
      const itemsCount = o.items.reduce((acc: number, cur: any) => acc + cur.quantity, 0);
      csv += `"${o.orderNumber}","${o.date.split('T')[0]}","${o.customerName}","${o.type}","${itemsCount}","${o.subtotal.toFixed(2)}","${o.discountAmount.toFixed(2)}","${o.taxAmount.toFixed(2)}","${o.total.toFixed(2)}","${o.status}","${o.paymentStatus}"\n`;
    });
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=restaurant_sales_report.csv');
    return res.status(200).send(csv);
  } else if (type === 'menu') {
    let csv = 'Dish ID,Name,Category,Price,Prep Time (mins),Available\n';
    db.menu.forEach((m: any) => {
      csv += `"${m.id}","${m.name}","${m.category}","${m.price.toFixed(2)}","${m.prepTime}","${m.isAvailable}"\n`;
    });
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=restaurant_menu_report.csv');
    return res.status(200).send(csv);
  }

  res.status(400).json({ error: 'Invalid export type. Supported: sales, menu' });
});

// Start express server
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
