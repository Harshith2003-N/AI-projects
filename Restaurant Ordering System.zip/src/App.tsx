/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  X, 
  Trash2, 
  AlertTriangle, 
  Store, 
  TrendingUp, 
  Users, 
  Package, 
  DollarSign, 
  CheckCircle,
  FileText,
  User as UserIcon,
  Sparkles,
  Lock,
  ArrowRight,
  ArrowLeft,
  KeyRound,
  Utensils,
  LogOut,
  Clock,
  Briefcase,
  ShoppingBag,
  Phone,
  Mail,
  MapPin,
  Calendar
} from 'lucide-react';

import Sidebar from './components/Sidebar';
import POSBilling from './components/POSBilling';
import Inventory from './components/Inventory';
import Customers from './components/Customers';
import Reports from './components/Reports';
import InvoiceModal from './components/InvoiceModal';
import ProductFormModal from './components/ProductFormModal';
import CustomerFormModal from './components/CustomerFormModal';

import { User, MenuItem, Order, Notification, DashboardStats } from './types';

export default function App() {
  // Auth state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Password Recovery state
  const [showRecovery, setShowRecovery] = useState(false);
  const [recoveryUsername, setRecoveryUsername] = useState('');
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoveryNewPassword, setRecoveryNewPassword] = useState('');
  const [recoveryStep, setRecoveryStep] = useState<'verify_username' | 'verify_email' | 'reset_password' | 'completed'>('verify_username');
  const [recoveryError, setRecoveryError] = useState('');
  const [recoveryEmailHint, setRecoveryEmailHint] = useState('');
  const [isRecovering, setIsRecovering] = useState(false);

  // Active view tab
  const [activeTab, setActiveTab] = useState('dashboard');

  // Profile fields state
  const [profileName, setProfileName] = useState('');
  const [profileEmail, setProfileEmail] = useState('');
  const [profilePhone, setProfilePhone] = useState('');
  const [profileAddress, setProfileAddress] = useState('');
  const [profileNewPassword, setProfileNewPassword] = useState('');
  const [profileConfirmPassword, setProfileConfirmPassword] = useState('');
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  // Database lists
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [dashboardStats, setDashboardStats] = useState<any>(null);

  // Layout drawers / modal triggers
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [activeInvoice, setActiveInvoice] = useState<Order | null>(null);
  const [activeDishEdit, setActiveDishEdit] = useState<MenuItem | null>(null);
  const [isDishFormOpen, setIsDishFormOpen] = useState(false);
  const [isCustomerFormOpen, setIsCustomerFormOpen] = useState(false);

  // Toast notifications
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
  };

  // Sync profile state with currentUser loaded from backend
  useEffect(() => {
    if (currentUser) {
      setProfileName(currentUser.name || '');
      setProfileEmail(currentUser.email || '');
      setProfilePhone(currentUser.phone || '');
      setProfileAddress(currentUser.address || '');
      setProfileNewPassword('');
      setProfileConfirmPassword('');
    }
  }, [currentUser]);

  // Auto-clear toast after 4s
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Check auth and fetch user info on load
  useEffect(() => {
    if (token) {
      fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      })
      .then(res => {
        if (res.ok) return res.json();
        throw new Error('Session expired');
      })
      .then(user => {
        setCurrentUser(user);
        
        // Define appropriate starting tab based on role
        if (user.role === 'customer') {
          setActiveTab('menu'); // Browse & Order Menu
        } else if (user.role === 'staff') {
          setActiveTab('orders'); // Live Kitchen Console
        } else {
          setActiveTab('dashboard'); // Performance Analysis
        }
      })
      .catch(() => {
        handleLogout();
      });
    }
  }, [token]);

  // Fetch lists from Server APIs (Run this once when authenticated, then poll periodically)
  const fetchCoreData = () => {
    if (!token) return;
    const authHeaders = { 'Authorization': `Bearer ${token}` };

    Promise.all([
      fetch('/api/menu', { headers: authHeaders }).then(res => res.ok ? res.json() : []),
      fetch('/api/orders', { headers: authHeaders }).then(res => res.ok ? res.json() : []),
      fetch('/api/notifications', { headers: authHeaders }).then(res => res.ok ? res.json() : []),
      fetch('/api/reports/dashboard', { headers: authHeaders }).then(res => res.ok ? res.json() : null)
    ])
    .then(([menu, ords, notes, stats]) => {
      setMenuItems(menu);
      setOrders(ords);
      setNotifications(notes);
      setDashboardStats(stats);
    })
    .catch(err => {
      console.error('Failed to sync gastronomy data:', err);
    });
  };

  // Sync data whenever authenticated user state settles
  useEffect(() => {
    if (currentUser && token) {
      fetchCoreData();

      // Establish a lightweight, reliable real-time polling channel (every 5 seconds)
      const pollTimer = setInterval(() => {
        fetchCoreData();
      }, 5000);

      return () => clearInterval(pollTimer);
    }
  }, [currentUser?.id, token]);

  // Handle Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsLoggingIn(true);

    fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    })
    .then(async res => {
      if (res.ok) return res.json();
      const err = await res.json();
      throw new Error(err.error || 'Authentication failed');
    })
    .then(data => {
      localStorage.setItem('token', data.token);
      setToken(data.token);
      setCurrentUser(data.user);
      setUsername('');
      setPassword('');
      showToast(`Welcome back, ${data.user.name}!`, 'success');
    })
    .catch(err => {
      setLoginError(err.message);
    })
    .finally(() => {
      setIsLoggingIn(false);
    });
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setCurrentUser(null);
    setMenuItems([]);
    setOrders([]);
    setNotifications([]);
    setDashboardStats(null);
  };

  // Pre-fill fields and automatically login for simple login testing!
  const handlePrefillLogin = (user: string) => {
    setLoginError('');
    setIsLoggingIn(true);

    fetch('/api/auth/bypass-login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: user })
    })
    .then(async res => {
      if (res.ok) return res.json();
      const err = await res.json();
      throw new Error(err.error || 'Authentication failed');
    })
    .then(data => {
      setUsername(data.user.username);
      setPassword(data.password || 'password');

      localStorage.setItem('token', data.token);
      setToken(data.token);
      setCurrentUser(data.user);
      showToast(`Logged in as ${data.user.name} (${data.user.role.toUpperCase()})`, 'success');
    })
    .catch(err => {
      setLoginError(err.message);
      showToast(err.message, 'error');
    })
    .finally(() => {
      setIsLoggingIn(false);
    });
  };

  // Handle forgot password submit
  const handleForgotPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRecoveryError('');
    setIsRecovering(true);

    const body: any = { username: recoveryUsername };
    if (recoveryStep === 'verify_email' || recoveryStep === 'reset_password') {
      body.email = recoveryEmail;
    }
    if (recoveryStep === 'reset_password') {
      body.newPassword = recoveryNewPassword;
    }

    fetch('/api/auth/forgot-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    })
    .then(async res => {
      if (res.ok) return res.json();
      const err = await res.json();
      throw new Error(err.error || 'Identity check failed');
    })
    .then(data => {
      if (data.step === 'verify_email') {
        setRecoveryStep('verify_email');
        setRecoveryEmailHint(data.emailHint || '');
      } else if (data.step === 'reset_password') {
        setRecoveryStep('reset_password');
      } else if (data.step === 'completed') {
        setRecoveryStep('completed');
        showToast('PIN updated successfully. Please log in.', 'success');
        handleBackToLogin();
      }
    })
    .catch(err => {
      setRecoveryError(err.message);
      showToast(err.message, 'error');
    })
    .finally(() => {
      setIsRecovering(false);
    });
  };

  const handleBackToLogin = () => {
    setShowRecovery(false);
    setRecoveryUsername('');
    setRecoveryEmail('');
    setRecoveryNewPassword('');
    setRecoveryStep('verify_username');
    setRecoveryError('');
    setRecoveryEmailHint('');
  };

  // Create or Update Menu Item
  const handleSaveMenuItem = (dishData: Omit<MenuItem, 'id'> & { id?: string }) => {
    const isEdit = !!dishData.id;
    const url = isEdit ? `/api/menu/${dishData.id}` : '/api/menu';
    const method = isEdit ? 'PUT' : 'POST';

    fetch(url, {
      method,
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(dishData)
    })
    .then(async res => {
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to persist menu dish');
      }
      return res.json();
    })
    .then(() => {
      setIsDishFormOpen(false);
      setActiveDishEdit(null);
      showToast(isEdit ? 'Culinary dish updated successfully' : 'Culinary dish registered on menu', 'success');
      fetchCoreData();
    })
    .catch(err => showToast(err.message, 'error'));
  };

  // Delete Menu Item
  const handleDeleteMenuItem = (itemId: string) => {
    fetch(`/api/menu/${itemId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(async res => {
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to remove menu dish');
      }
      return res.json();
    })
    .then(() => {
      showToast('Culinary dish removed from menu', 'success');
      fetchCoreData();
    })
    .catch(err => showToast(err.message, 'error'));
  };

  // Register Customer / Loyalty Profile
  const handleSaveCustomer = (customerData: any) => {
    fetch('/api/users', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(customerData)
    })
    .then(async res => {
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || 'Failed to register loyalty profile');
      }
      return res.json();
    })
    .then(() => {
      setIsCustomerFormOpen(false);
      showToast('Loyalty patron registered successfully', 'success');
      fetchCoreData();
    })
    .catch(err => showToast(err.message, 'error'));
  };

  // Process Restaurant Ordering Checkout (Customer Menu Cart or Walk-In POS)
  const handleCheckout = async (orderData: {
    items: { menuItemId: string; quantity: number }[];
    type: 'dine-in' | 'takeaway' | 'delivery';
    tableNumber?: number;
    deliveryAddress?: string;
    couponCode?: string;
    paymentMethod: 'cash' | 'card' | 'wallet';
    notes?: string;
  }): Promise<Order | null> => {
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(orderData)
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to place kitchen order');
      }

      const generatedOrder = await res.json();
      
      // Sync immediately
      fetchCoreData();
      
      // Open digital bill receipt popup
      setActiveInvoice(generatedOrder);
      showToast('Order confirmed! Sending ticket to kitchen.', 'success');
      return generatedOrder;
    } catch (err: any) {
      showToast(err.message, 'error');
      return null;
    }
  };

  // Notifications controls
  const handleMarkAsRead = (id: string) => {
    fetch(`/api/notifications/${id}/read`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(() => {
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    });
  };

  const handleClearAllNotifications = () => {
    fetch('/api/notifications/clear-all', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(() => {
      setNotifications([]);
    });
  };

  const unreadNotesCount = notifications.filter(n => !n.read).length;

  // View routing renderer
  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return renderOverview();
      case 'orders':
      case 'billing':
        // Represents the Kitchen & Orders Console
        return (
          <POSBilling
            products={menuItems}
            onCheckout={handleCheckout}
          />
        );
      case 'menu':
      case 'inventory':
        // Represents Menu Management & Browser ordering system
        return (
          <Inventory
            products={menuItems}
            currentUser={currentUser!}
            onAddProductClick={() => {
              setActiveDishEdit(null);
              setIsDishFormOpen(true);
            }}
            onEditProductClick={(dish) => {
              setActiveDishEdit(dish);
              setIsDishFormOpen(true);
            }}
            onDeleteProduct={handleDeleteMenuItem}
            onCheckout={handleCheckout}
            onRefreshMenu={fetchCoreData}
          />
        );
      case 'staff':
      case 'customers':
        // Handles staff roster and customer loyalty register
        return (
          <Customers
            onAddCustomerClick={() => setIsCustomerFormOpen(true)}
          />
        );
      case 'customer-orders':
        return renderCustomerOrders();
      case 'profile':
        return renderProfile();
      case 'reports':
        // Analytics sheets & SVG charts
        return <Reports sales={orders} products={menuItems} />;
      default:
        return renderOverview();
    }
  };

  // Save user profile details
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;

    // Check if password change is requested
    if (profileNewPassword) {
      if (profileNewPassword !== profileConfirmPassword) {
        showToast('New passwords do not match', 'error');
        return;
      }
    }

    setIsSavingProfile(true);

    const payload: any = {
      name: profileName,
      email: profileEmail,
      phone: profilePhone,
      address: profileAddress
    };

    if (profileNewPassword) {
      payload.password = profileNewPassword;
    }

    fetch('/api/auth/profile', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    })
    .then(async res => {
      if (res.ok) return res.json();
      const err = await res.json();
      throw new Error(err.error || 'Failed to update profile settings');
    })
    .then(updatedUser => {
      setCurrentUser(updatedUser);
      showToast('Profile and security settings saved successfully', 'success');
      setProfileNewPassword('');
      setProfileConfirmPassword('');
    })
    .catch(err => {
      showToast(err.message, 'error');
    })
    .finally(() => {
      setIsSavingProfile(false);
    });
  };

  // Render Customer Orders history and live tracker
  const renderCustomerOrders = () => {
    if (orders.length === 0) {
      return (
        <div className="h-96 flex flex-col items-center justify-center text-center p-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl shadow-sm">
          <div className="w-16 h-16 bg-amber-100 dark:bg-amber-950/30 rounded-full flex items-center justify-center text-amber-500 mb-4">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-black text-slate-800 dark:text-white uppercase tracking-wider mb-2">No Orders Found</h3>
          <p className="text-slate-500 dark:text-slate-400 text-xs max-w-sm mb-6 leading-relaxed">
            You haven't placed any culinary orders yet. Explore our delicious gourmet menu and order your first meal!
          </p>
          <button
            onClick={() => setActiveTab('menu')}
            className="px-6 py-3 bg-amber-500 text-slate-950 hover:bg-amber-400 rounded-2xl text-xs font-black uppercase tracking-wider shadow-md shadow-amber-500/10 transition-all flex items-center gap-2"
          >
            <Utensils className="w-4 h-4" />
            <span>Order Delicious Dishes</span>
          </button>
        </div>
      );
    }

    // Sort orders by date descending
    const sortedOrders = [...orders].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    // Helper for status classes
    const getStatusStyles = (status: string) => {
      switch (status) {
        case 'pending':
          return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
        case 'preparing':
          return 'bg-blue-500/10 text-blue-500 border-blue-500/20 animate-pulse';
        case 'ready':
          return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
        case 'delivered':
          return 'bg-slate-500/10 text-slate-400 border-slate-800';
        case 'cancelled':
          return 'bg-rose-500/10 text-rose-500 border-rose-500/20';
        default:
          return 'bg-slate-500/10 text-slate-400 border-slate-800';
      }
    };

    return (
      <div className="space-y-6 overflow-y-auto max-h-[85vh] pr-1 pb-10">
        <div className="flex justify-between items-center select-none">
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-wider">My Culinary Orders</h2>
            <p className="text-xs text-slate-400">Track current preparation status and view your full gourmet history.</p>
          </div>
          <button
            onClick={fetchCoreData}
            className="px-4 py-2 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl text-xs font-black uppercase tracking-wider text-slate-600 dark:text-slate-300 transition-colors"
          >
            Refresh Status
          </button>
        </div>

        <div className="grid grid-cols-1 gap-6">
          {sortedOrders.map((order) => {
            const isFinished = order.status === 'delivered' || order.status === 'cancelled';
            const statusSteps = ['pending', 'preparing', 'ready', 'delivered'];
            const activeStepIndex = statusSteps.indexOf(order.status);
            
            return (
              <div 
                key={order.id} 
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-6 shadow-sm space-y-6"
              >
                {/* Header Information block */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-dashed border-slate-100 dark:border-slate-850">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-amber-500/10 text-amber-500 rounded-xl flex items-center justify-center font-mono font-black text-sm">
                      #{order.orderNumber.replace('B-', '')}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-sm text-slate-900 dark:text-white">Order {order.orderNumber}</span>
                        <span className={`text-[9px] font-mono font-black px-2 py-0.5 rounded-lg border uppercase tracking-wider ${getStatusStyles(order.status)}`}>
                          {order.status}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(order.date).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })} at{' '}
                        {new Date(order.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Service Type</span>
                      <span className="font-extrabold text-slate-800 dark:text-slate-200 uppercase">
                        {order.type === 'dine-in' ? `Dine-in (Table ${order.tableNumber})` : order.type}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block uppercase font-bold tracking-wider">Amount Paid</span>
                      <span className="font-black text-amber-500 text-sm">${order.total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                {/* Live Tracking Timeline Stepper */}
                {!isFinished && (
                  <div className="bg-slate-50 dark:bg-slate-950/50 rounded-2xl p-5 border border-slate-100 dark:border-slate-850/40 select-none">
                    <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-4">Live Order Progress</p>
                    <div className="flex flex-col sm:flex-row justify-between items-center gap-6 relative">
                      
                      {/* Stepper background connector line */}
                      <div className="absolute top-1/2 left-4 right-4 h-0.5 bg-slate-200 dark:bg-slate-800 -translate-y-1/2 hidden sm:block z-0" />
                      
                      {/* Active green progress filler */}
                      {activeStepIndex > 0 && (
                        <div 
                          className="absolute top-1/2 left-4 h-0.5 bg-emerald-500 -translate-y-1/2 hidden sm:block z-0 transition-all duration-500" 
                          style={{ width: `${(activeStepIndex / 3) * 90}%` }}
                        />
                      )}

                      {statusSteps.map((step, index) => {
                        const stepLabels: Record<string, string> = {
                          pending: 'Received',
                          preparing: 'Preparing',
                          ready: 'Ready',
                          delivered: order.type === 'delivery' ? 'Dispatched' : 'Completed'
                        };
                        const stepDescriptions: Record<string, string> = {
                          pending: 'Ticket sent to kitchen',
                          preparing: 'Chef culinary work',
                          ready: 'Fresh & hot at counter',
                          delivered: order.type === 'delivery' ? 'Driver en route' : 'Order complete'
                        };

                        const isDone = index < activeStepIndex;
                        const isCurrent = index === activeStepIndex;

                        return (
                          <div key={step} className="flex sm:flex-col items-center text-center gap-3 relative z-10 w-full sm:w-1/4">
                            <div className={`w-9 h-9 rounded-full flex items-center justify-center font-bold text-xs border-2 transition-all ${
                              isDone ? 'bg-emerald-500 border-emerald-500 text-white' :
                              isCurrent ? 'bg-amber-500 border-amber-500 text-slate-950 shadow-lg shadow-amber-500/20' :
                              'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-400'
                            }`}>
                              {isDone ? '✓' : index + 1}
                            </div>
                            <div className="text-left sm:text-center">
                              <span className={`text-xs font-black block leading-none uppercase tracking-wider ${isCurrent ? 'text-amber-500' : isDone ? 'text-emerald-500' : 'text-slate-400'}`}>
                                {stepLabels[step]}
                              </span>
                              <span className="text-[10px] text-slate-400 mt-1 block max-w-[120px] mx-auto leading-tight">{stepDescriptions[step]}</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Items and Details list */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                  
                  {/* Order Items List */}
                  <div className="space-y-3">
                    <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Dishes & Quantities</p>
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex items-center justify-between text-xs bg-slate-50 dark:bg-slate-950 p-2.5 rounded-xl border border-slate-100 dark:border-slate-850/40">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-500 font-mono">x{item.quantity}</span>
                            <span className="font-extrabold text-slate-800 dark:text-slate-200">{item.name}</span>
                          </div>
                          <span className="font-mono font-bold text-slate-500">${item.subtotal.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Order summary cards */}
                  <div className="bg-slate-50 dark:bg-slate-950/40 border border-slate-150 dark:border-slate-850 p-4 rounded-2xl flex flex-col justify-between">
                    <div>
                      <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-2">Order Details</p>
                      
                      <div className="space-y-1.5 text-xs">
                        {order.type === 'delivery' && order.deliveryAddress && (
                          <div className="flex items-start gap-1.5 text-slate-600 dark:text-slate-400">
                            <MapPin className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                            <span className="line-clamp-2">Delivery to: {order.deliveryAddress}</span>
                          </div>
                        )}
                        {order.notes && (
                          <p className="text-slate-500 italic pr-2 leading-relaxed">
                            "{order.notes}"
                          </p>
                        )}
                        <p className="text-slate-400 text-[10px]">
                          Payment Status:{' '}
                          <span className={`font-bold ${order.paymentStatus === 'paid' ? 'text-emerald-500' : 'text-amber-500'}`}>
                            {order.paymentStatus === 'paid' ? 'Paid Securely via Card' : 'Pending Counter Cash'}
                          </span>
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-dashed border-slate-200 dark:border-slate-800 flex justify-between items-center text-xs">
                      <div className="flex items-center gap-1 text-slate-500">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        <span>Earned Bistro Points:</span>
                      </div>
                      <span className="font-mono font-black text-amber-500 bg-amber-500/10 px-2.5 py-0.5 rounded-md">
                        +{order.earnedPoints || Math.floor(order.total)} pts
                      </span>
                    </div>
                  </div>

                </div>

              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Render Profile & Loyalty Settings View
  const renderProfile = () => {
    if (!currentUser) return null;

    // Loyalty Tier classification helper
    const getLoyaltyTier = (points: number) => {
      if (points >= 1000) return { name: 'Platinum VIP', color: 'text-purple-500 bg-purple-500/10 border-purple-500/20', desc: 'Complimentary chef dining and priority culinary slots.' };
      if (points >= 300) return { name: 'Gold Club', color: 'text-amber-500 bg-amber-500/10 border-amber-500/20', desc: 'Free home delivery and exclusive seasonal menu tasting.' };
      if (points >= 100) return { name: 'Silver Member', color: 'text-blue-500 bg-blue-500/10 border-blue-500/20', desc: 'Priority serving counter and 10% discount on BISTROLIFE.' };
      return { name: 'Bronze Member', color: 'text-amber-600 bg-amber-600/10 border-amber-600/20', desc: 'Earn 1 reward point for every dollar spent at checkouts.' };
    };

    const isCustomer = currentUser.role === 'customer';
    const tier = getLoyaltyTier(currentUser.loyaltyPoints || 0);

    return (
      <div className="space-y-6 overflow-y-auto max-h-[85vh] pr-1 pb-10 select-none">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-wider">
            {isCustomer ? 'My Loyalty Profile' : 'My Staff Profile'}
          </h2>
          <p className="text-xs text-slate-400">
            {isCustomer 
              ? 'Manage your gourmet delivery locations, secure credentials, and view rewards tier.' 
              : 'Update your display identity, phone, address and secure credentials.'
            }
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Left Column - Loyalty Stats */}
          <div className="space-y-6 lg:col-span-1">
            <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 shadow-xl relative overflow-hidden flex flex-col justify-between h-72">
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
              
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-widest">
                    {isCustomer ? 'Bistro Loyalty Pass' : 'Restaurant Staff Pass'}
                  </span>
                  <Sparkles className="w-5 h-5 text-amber-500" />
                </div>
                <h3 className="text-xl font-black text-white mt-4 tracking-tight">{currentUser.name}</h3>
                <span className="text-[10px] text-slate-400 font-mono">User ID: {currentUser.id}</span>
              </div>

              <div>
                {isCustomer ? (
                  <>
                    <div className="flex items-baseline justify-between mt-6">
                      <div>
                        <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider block">Reward Balance</span>
                        <span className="text-4xl font-black font-mono text-amber-500">{currentUser.loyaltyPoints || 0}</span>
                        <span className="text-xs font-mono text-slate-400 ml-1">PTS</span>
                      </div>
                      <span className={`text-[10px] font-mono font-black px-2.5 py-1 rounded-xl border uppercase ${tier.color}`}>
                        {tier.name}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 leading-tight mt-3 italic">
                      "{tier.desc}"
                    </p>
                  </>
                ) : (
                  <>
                    <div className="flex items-baseline justify-between mt-6">
                      <div>
                        <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider block">System Status</span>
                        <span className="text-2xl font-black text-emerald-500">ACTIVE</span>
                      </div>
                      <span className="text-[10px] font-mono font-black px-2.5 py-1 rounded-xl border border-amber-500/20 bg-amber-500/10 text-amber-500 uppercase">
                        {currentUser.role}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 leading-tight mt-3 italic">
                      "Access verified for kitchen console, staff rosters, and report logs."
                    </p>
                  </>
                )}
              </div>
            </div>

            {/* Profile Brief Info Box */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-6 shadow-sm space-y-4">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-350">Quick Reference</h4>
              
              <div className="space-y-3.5 text-xs text-slate-600 dark:text-slate-400">
                <div className="flex items-center gap-2">
                  <UserIcon className="w-4 h-4 text-slate-400" />
                  <div>
                    <span className="text-[9px] text-slate-400 block uppercase font-bold tracking-wider">Username ID</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">@{currentUser.username}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-slate-400" />
                  <div>
                    <span className="text-[9px] text-slate-400 block uppercase font-bold tracking-wider">Registered Email</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[200px] block">{currentUser.email}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-slate-400" />
                  <div>
                    <span className="text-[9px] text-slate-400 block uppercase font-bold tracking-wider">System Role</span>
                    <span className="font-mono font-bold text-amber-500 uppercase">{currentUser.role}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Columns - Form Fields */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSaveProfile} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-6 shadow-sm space-y-6">
              
              {/* Account Details Group */}
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-slate-800 dark:text-white border-b border-dashed border-slate-100 dark:border-slate-800 pb-2 mb-4">Gourmet Account Settings</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Full Display Name</label>
                    <input 
                      type="text" 
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      required
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Registered Email</label>
                    <input 
                      type="email" 
                      value={profileEmail}
                      onChange={(e) => setProfileEmail(e.target.value)}
                      required
                      className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Contact Phone Number</label>
                    <div className="relative">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        value={profilePhone}
                        onChange={(e) => setProfilePhone(e.target.value)}
                        placeholder="e.g. +1 555-123-4567"
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pl-11 pr-4 py-2.5 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Primary Delivery Address</label>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-3.5 w-4 h-4 text-slate-400" />
                      <textarea 
                        value={profileAddress}
                        onChange={(e) => setProfileAddress(e.target.value)}
                        placeholder="Please enter your full street name, apartment or suite details, and postal code."
                        rows={3}
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pl-11 pr-4 py-2.5 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Password credentials update */}
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-slate-800 dark:text-white border-b border-dashed border-slate-100 dark:border-slate-800 pb-2 mb-4">Security Credentials</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">New Password</label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="password" 
                        value={profileNewPassword}
                        onChange={(e) => setProfileNewPassword(e.target.value)}
                        placeholder="Leave blank to keep current"
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pl-11 pr-4 py-2.5 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Confirm New Password</label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="password" 
                        value={profileConfirmPassword}
                        onChange={(e) => setProfileConfirmPassword(e.target.value)}
                        placeholder="Leave blank to keep current"
                        className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pl-11 pr-4 py-2.5 text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-amber-500"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Action save buttons */}
              <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="submit"
                  disabled={isSavingProfile}
                  className="px-6 py-3 bg-amber-500 text-slate-950 hover:bg-amber-400 disabled:opacity-50 rounded-2xl text-xs font-black uppercase tracking-wider shadow-md shadow-amber-500/10 transition-all flex items-center gap-2"
                >
                  {isSavingProfile ? (
                    <>
                      <Sparkles className="w-4 h-4 animate-spin" />
                      <span>Saving settings...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      <span>Save Settings</span>
                    </>
                  )}
                </button>
              </div>

            </form>
          </div>

        </div>
      </div>
    );
  };

  // Render Admin Performance Overview
  const renderOverview = () => {
    if (!dashboardStats) return (
      <div className="h-64 flex flex-col items-center justify-center text-slate-400">
        <Sparkles className="w-8 h-8 text-amber-500 animate-spin mb-2" />
        <p className="text-xs font-bold">Syncing performance metrics stream...</p>
      </div>
    );

    const outOfStockDishes = menuItems.filter(item => !item.isAvailable);

    return (
      <div className="space-y-6 overflow-y-auto max-h-full pr-1 pb-10">
        
        {/* Dynamic Alerts notification header */}
        {outOfStockDishes.length > 0 && (
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-3xl p-5 flex items-start space-x-3 text-xs text-amber-800 select-none">
            <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <span className="font-extrabold block text-slate-900 text-sm">Out-of-Stock Menu Items Flagged!</span>
              <span className="text-slate-500">
                There are <strong className="font-bold text-amber-500">{outOfStockDishes.length}</strong> dishes currently marked as out-of-stock. 
                Please restock ingredients or toggle availability in the <strong>Menu Management</strong> tab to enable guest checkout.
              </span>
            </div>
          </div>
        )}

        {/* Core KPI cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          
          {/* Daily Revenue */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col justify-between h-36">
            <p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Gross Sales Yield</p>
            <h2 className="text-3xl font-black text-slate-900 dark:text-white font-mono leading-none">
              ${(dashboardStats.totalSales || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </h2>
            <p className="text-emerald-500 text-[10px] font-bold uppercase tracking-widest">↑ Stable Profit Margin</p>
          </div>

          {/* Average Billing Ticket */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col justify-between h-36">
            <p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Avg. Ticket Size</p>
            <h2 className="text-3xl font-black text-amber-500 font-mono leading-none">
              ${(dashboardStats.averageOrderValue || 0).toFixed(2)}
            </h2>
            <p className="text-slate-400 text-[10px]">Average per guest checkout</p>
          </div>

          {/* Orders count */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col justify-between h-36">
            <p className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Completed Tickets</p>
            <h2 className="text-3xl font-black text-slate-900 dark:text-white font-mono leading-none">
              {dashboardStats.completedOrdersCount || 0}
            </h2>
            <p className="text-slate-400 text-[10px]">Orders successfully dispatched</p>
          </div>

          {/* Active cooking slots */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col justify-between h-36 border-l-4 border-l-amber-500">
            <p className="text-amber-500 text-[10px] font-bold uppercase tracking-wider">Active Kitchen Tickets</p>
            <h2 className="text-3xl font-black text-slate-900 dark:text-white font-mono leading-none">
              {dashboardStats.activeOrdersCount || 0}
            </h2>
            <p className="text-slate-400 text-[10px]">Tickets in preparation phase</p>
          </div>

        </div>

        {/* Visual Trend Chart area */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            
            {/* Sales Trends Curve widget */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-6 shadow-sm">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-4 flex items-center gap-1">
                <TrendingUp className="w-4 h-4 text-amber-500" />
                <span>Culinary Sales Performance Wave</span>
              </h4>
              
              {/* Responsive SVG curve */}
              <div className="h-44 flex items-end justify-between px-2 gap-2 pt-2">
                {(dashboardStats.salesByDate || []).slice(-7).map((day: any, idx: number) => (
                  <div key={idx} className="flex-1 flex flex-col items-center justify-end h-full gap-2 group">
                    <span className="text-[9px] font-mono font-bold text-amber-500 opacity-0 group-hover:opacity-100 transition-all">
                      ${day.amount}
                    </span>
                    <div 
                      className="w-full bg-slate-100 dark:bg-slate-800 group-hover:bg-amber-500 rounded-lg transition-all"
                      style={{ height: `${Math.max(10, Math.min(100, (day.amount / (dashboardStats.totalSales || 100)) * 250))}%` }}
                    ></div>
                    <span className="text-[10px] font-bold text-slate-400 font-sans uppercase">
                      {day.date.split('-').slice(1).join('/')}
                    </span>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Menu Category Share Distribution list */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-6 shadow-sm flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-4">Culinary Sales Breakdown</h4>
              
              <div className="space-y-4 max-h-56 overflow-y-auto pr-1">
                {(dashboardStats.ordersByType || []).map((type: any, idx: number) => {
                  const totalOrders = (dashboardStats.ordersByType || []).reduce((acc: number, c: any) => acc + c.value, 0);
                  const percentage = totalOrders > 0 ? (type.value / totalOrders) * 100 : 0;
                  
                  return (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between items-center text-xs font-semibold">
                        <span className="text-slate-700 dark:text-slate-300 capitalize">{type.type} services</span>
                        <span className="font-mono text-slate-400">{type.value} tickets ({percentage.toFixed(0)}%)</span>
                      </div>
                      <div className="w-full bg-slate-100 dark:bg-slate-950 rounded-full h-1.5 overflow-hidden">
                        <div 
                          className="bg-amber-500 h-1.5 rounded-full transition-all duration-500" 
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="border-t border-slate-100 dark:border-slate-800 pt-3 mt-4 text-[10px] text-slate-400 font-bold uppercase tracking-wider text-center select-none">
              Valued across {menuItems.length} active menu slots
            </div>
          </div>
        </div>

        {/* Live Food Logs & Out-of-Stock menu indicators */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Recent Orders log */}
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-6 shadow-sm flex flex-col">
            <div className="flex items-center justify-between mb-5">
              <h4 className="text-sm font-extrabold text-slate-800 dark:text-white uppercase tracking-wider">Gastronomy Service Log</h4>
              <button 
                onClick={() => setActiveTab('billing')}
                className="text-xs font-bold text-amber-500 hover:text-amber-400 uppercase tracking-wider flex items-center gap-1"
              >
                <span>Kitchen Console</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-4 max-h-72 overflow-y-auto pr-1">
              {orders.slice(0, 5).map((order) => {
                const name = order.customerName || 'Anonymous Guest';
                const initials = name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
                
                const bgGradients = [
                  'bg-amber-500/10 text-amber-500',
                  'bg-blue-500/10 text-blue-500',
                  'bg-rose-500/10 text-rose-500',
                  'bg-indigo-500/10 text-indigo-500'
                ];
                const gradientIndex = initials.charCodeAt(0) % bgGradients.length;
                
                return (
                  <div key={order.id} className="flex items-center justify-between pb-3 border-b border-slate-50 dark:border-slate-800/60 last:border-0 last:pb-0">
                    <div className="flex gap-3 items-center">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-xs shrink-0 ${bgGradients[gradientIndex]}`}>
                        {initials}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-extrabold text-slate-800 dark:text-white truncate">{name}</p>
                        <p className="text-[10px] text-slate-400 uppercase font-mono font-bold tracking-tight">
                          {order.orderNumber} • {new Date(order.createdAt || order.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <span className="text-sm font-black text-slate-900 dark:text-white font-mono block">${order.total.toFixed(2)}</span>
                      <span className={`text-[9px] font-black uppercase tracking-wider ${
                        order.status === 'delivered' ? 'text-emerald-500' : 'text-amber-500'
                      }`}>{order.status}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Out-of-Stock menu card widget */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-6 shadow-sm flex flex-col justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-800 dark:text-white mb-4 flex items-center gap-2">
                <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
                Out-of-Stock Items
              </h3>
              
              <div className="space-y-3.5 max-h-56 overflow-y-auto pr-1">
                {outOfStockDishes.length === 0 ? (
                  <div className="text-center py-8 text-slate-400 text-xs font-semibold">
                    <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                    All dishes fully stocked!
                  </div>
                ) : (
                  outOfStockDishes.slice(0, 4).map((dish) => (
                    <div key={dish.id} className="p-3 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800">
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider font-mono">DISH ID: {dish.id.slice(0, 8)}</p>
                      <p className="font-extrabold text-xs truncate text-slate-800 dark:text-slate-200">{dish.name}</p>
                      <div className="flex justify-between items-end mt-1.5">
                        <span className="text-[10px] text-red-500 font-bold">OUT OF STOCK</span>
                        <span className="text-[10px] text-slate-400 font-mono">${dish.price.toFixed(2)}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <button 
              onClick={() => setActiveTab('inventory')}
              className="w-full mt-4 py-2.5 bg-slate-950 hover:bg-slate-850 text-white rounded-xl font-black text-xs uppercase tracking-wider transition-all"
            >
              Update Menu Catalog
            </button>
          </div>

        </div>

      </div>
    );
  };

  // Rendering login portals if not authenticated
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-center items-center p-4 font-sans relative overflow-hidden">
        
        {/* Subtle decorative glowing culinary mesh */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl -z-10 animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl -z-10"></div>

        {/* Recovery Container card */}
        {showRecovery ? (
          <div className="w-full max-w-md bg-slate-900 border border-slate-850 rounded-3xl p-6 md:p-8 shadow-2xl relative">
            
            <button
              onClick={handleBackToLogin}
              className="absolute top-6 left-6 text-slate-400 hover:text-white transition-colors flex items-center space-x-1.5 text-[10px] font-black uppercase tracking-wider"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Login</span>
            </button>

            <div className="text-center space-y-2 mb-8 mt-6">
              <div className="w-12 h-12 bg-amber-500/10 text-amber-500 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-amber-500/5">
                <KeyRound className="w-5 h-5" />
              </div>
              <h2 className="text-sm font-black tracking-wider text-white uppercase mt-4">Recover Credentials</h2>
              <p className="text-xs text-slate-400">
                Step {recoveryStep === 'verify_username' ? '1 of 3' : recoveryStep === 'verify_email' ? '2 of 3' : '3 of 3'}: Reset Merchant PIN
              </p>
            </div>

            {recoveryError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-semibold rounded-xl mb-6">
                {recoveryError}
              </div>
            )}

            <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
              
              {recoveryStep === 'verify_username' && (
                <div className="space-y-1.5 text-xs font-semibold">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Username ID</label>
                  <input
                    type="text"
                    required
                    value={recoveryUsername}
                    onChange={e => setRecoveryUsername(e.target.value)}
                    placeholder="e.g. admin or staff or customer..."
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-none focus:border-amber-500 placeholder-slate-600 text-white"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">Please enter your unique username credentials to recover your account.</p>
                </div>
              )}

              {recoveryStep === 'verify_email' && (
                <div className="space-y-1.5 text-xs font-semibold">
                  <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded-xl mb-3 text-xs text-slate-300">
                    <p className="font-extrabold text-amber-500 mb-1">Verify Security Contact</p>
                    <p>We found an active gastronomy profile registered to: <strong className="font-mono text-white">{recoveryEmailHint}</strong></p>
                  </div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Confirm Registered Email</label>
                  <input
                    type="email"
                    required
                    value={recoveryEmail}
                    onChange={e => setRecoveryEmail(e.target.value)}
                    placeholder="Enter full registered email address..."
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-none focus:border-amber-500 placeholder-slate-600 text-white"
                  />
                </div>
              )}

              {recoveryStep === 'reset_password' && (
                <div className="space-y-1.5 text-xs font-semibold">
                  <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded-xl mb-3 text-xs text-slate-300">
                    <p className="font-extrabold text-amber-500 mb-1">Security Match Confirmed</p>
                    <p>Email verification succeeded for <strong className="text-white font-mono">{recoveryUsername}</strong>. You may now overwrite your security PIN.</p>
                  </div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">New Password PIN</label>
                  <input
                    type="password"
                    required
                    value={recoveryNewPassword}
                    onChange={e => setRecoveryNewPassword(e.target.value)}
                    placeholder="Enter at least 4 characters..."
                    className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-none focus:border-amber-500 placeholder-slate-600 text-white"
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={isRecovering}
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black uppercase tracking-wider rounded-xl shadow-md transition-all flex items-center justify-center"
              >
                {isRecovering ? (
                  <span>AUTHENTICATING KEYS...</span>
                ) : (
                  <span>
                    {recoveryStep === 'verify_username' ? 'Locate Account' : recoveryStep === 'verify_email' ? 'Confirm Email' : 'Update Credentials PIN'}
                  </span>
                )}
              </button>

            </form>

          </div>
        ) : (
          /* Login Container card */
          <div className="w-full max-w-md bg-slate-900 border border-slate-850 rounded-3xl p-6 md:p-8 shadow-2xl relative">
            
            <div className="text-center space-y-2 mb-8">
              <div className="w-12 h-12 bg-amber-500 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-amber-500/20">
                <Utensils className="w-6 h-6 text-slate-950" />
              </div>
              <h2 className="text-lg font-black tracking-wider text-white uppercase mt-4">Bistro Guru Gastronomy</h2>
              <p className="text-xs text-slate-400">Secure Restaurant POS & Order-Entry Terminal</p>
            </div>

            {loginError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-semibold rounded-xl mb-6">
                {loginError}
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              
              {/* Username */}
              <div className="space-y-1.5 text-xs font-semibold">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Username ID</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="admin / staff / customer"
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-none focus:border-amber-500 placeholder-slate-600 text-white"
                />
              </div>

              {/* Password */}
              <div className="space-y-1.5 text-xs font-semibold">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">PIN / Password</label>
                  <button
                    type="button"
                    onClick={() => {
                      setRecoveryStep('verify_username');
                      setShowRecovery(true);
                    }}
                    className="text-[10px] text-amber-500 hover:text-amber-400 transition-all font-black uppercase tracking-wider"
                  >
                    Forgot password?
                  </button>
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-sm focus:outline-none focus:border-amber-500 placeholder-slate-600 text-white"
                />
              </div>

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800 text-slate-950 text-xs font-black uppercase tracking-wider rounded-xl shadow-md transition-all flex items-center justify-center space-x-1.5"
              >
                {isLoggingIn ? (
                  <span>AUTHENTICATING KEYS...</span>
                ) : (
                  <>
                    <Lock className="w-4 h-4 text-slate-950 shrink-0" />
                    <span>Authenticate Session</span>
                  </>
                )}
              </button>

            </form>

            {/* Click-to-login Test shortcuts */}
            <div className="border-t border-slate-800 mt-6 pt-5 space-y-2 text-[11px] font-semibold">
              <span className="text-slate-400 font-bold block mb-1 uppercase text-[10px] tracking-wider">Test Account Quick Logins:</span>
              
              <div className="grid grid-cols-1 gap-2">
                
                <button
                  onClick={() => handlePrefillLogin('admin')}
                  className="p-2 bg-slate-950/40 border border-slate-800 rounded-xl text-left hover:bg-slate-950 hover:border-amber-500/20 transition-colors flex items-center justify-between group"
                >
                  <div>
                    <span className="font-extrabold text-white block text-xs">Sarah Jenkins</span>
                    <span className="text-[9px] text-rose-400 font-bold uppercase tracking-wide">System Admin (Full Roster & Menu)</span>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-500 transition-colors" />
                </button>

                <button
                  onClick={() => handlePrefillLogin('staff')}
                  className="p-2 bg-slate-950/40 border border-slate-800 rounded-xl text-left hover:bg-slate-950 hover:border-amber-500/20 transition-colors flex items-center justify-between group"
                >
                  <div>
                    <span className="font-extrabold text-white block text-xs">Chef Robert</span>
                    <span className="text-[9px] text-blue-400 font-bold uppercase tracking-wide">Kitchen Staff (Live Order Queue)</span>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-500 transition-colors" />
                </button>

                <button
                  onClick={() => handlePrefillLogin('customer')}
                  className="p-2 bg-slate-950/40 border border-slate-800 rounded-xl text-left hover:bg-slate-950 hover:border-amber-500/20 transition-colors flex items-center justify-between group"
                >
                  <div>
                    <span className="font-extrabold text-white block text-xs">Sarah Connor</span>
                    <span className="text-[9px] text-amber-500 font-bold uppercase tracking-wide">VIP Customer (Browse, Cart & Track)</span>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-500 transition-colors" />
                </button>

              </div>

            </div>

          </div>
        )}

        <div className="mt-8 text-center text-[10px] text-slate-600 select-none font-bold uppercase tracking-widest">
          SECURED VIA LOCAL Gastronomy JWT EMULATOR • PORT 3000
        </div>

      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 overflow-hidden font-sans">
      
      {/* SIDEBAR NAVIGATION PANEL */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        user={currentUser}
        onLogout={handleLogout}
        unreadCount={unreadNotesCount}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
      />

      {/* MAIN VIEW CONTENT CONTAINER */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        
        {/* Upper Header strip */}
        <header className="h-20 bg-white dark:bg-slate-900 border-b border-slate-250 dark:border-slate-850 flex items-center justify-between px-8 shrink-0">
          <div className="flex items-center gap-3">
            <h1 className="text-lg font-black uppercase tracking-wider text-slate-900 dark:text-white">
              {activeTab === 'dashboard' && 'Executive Performance Overview'}
              {(activeTab === 'orders' || activeTab === 'billing') && 'Kitchen Orders Console'}
              {(activeTab === 'menu' || activeTab === 'inventory') && 'Bistro Gastronomy Menu'}
              {(activeTab === 'staff' || activeTab === 'customers') && 'Roster & Patron Directory'}
              {activeTab === 'customer-orders' && 'My Order History & Live Tracker'}
              {activeTab === 'profile' && 'My Loyalty Profile & Settings'}
              {activeTab === 'reports' && 'Financial Performance sheets'}
            </h1>
          </div>
          
          <div className="flex items-center gap-4">
            
            {/* Loyalty points helper box for Customers */}
            {currentUser.role === 'customer' && (
              <div className="hidden sm:flex items-center gap-1.5 bg-amber-500/10 text-amber-500 px-4 py-1.5 rounded-full border border-amber-500/20 text-xs font-black font-mono">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{currentUser.loyaltyPoints || 0} REWARD PTS</span>
              </div>
            )}

            <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-950 px-3 py-1.5 rounded-full select-none text-[10px] font-bold uppercase tracking-wider text-slate-500">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span>Port 3000 secure</span>
            </div>

            {/* Quick alert badge indicator */}
            <button
              onClick={() => setIsNotificationsOpen(true)}
              className="p-2.5 border border-slate-200 dark:border-slate-800 rounded-full hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors relative shrink-0"
              title="Notifications"
            >
              <Bell className="w-4 h-4 text-slate-500 dark:text-slate-400" />
              {unreadNotesCount > 0 && (
                <span className="absolute top-0 right-0 w-2.5 h-2.5 rounded-full bg-rose-500 border-2 border-white dark:border-slate-900"></span>
              )}
            </button>
          </div>
        </header>

        {/* Scrollable View body viewport */}
        <div className="flex-1 p-6 md:p-8 overflow-hidden bg-slate-50/50 dark:bg-slate-950/20">
          {renderActiveView()}
        </div>

      </main>

      {/* SLIDE-OUT NOTIFICATIONS TRAY DRAWER */}
      {isNotificationsOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/40 backdrop-blur-xs">
          <div className="flex-1" onClick={() => setIsNotificationsOpen(false)}></div>
          
          <div className="w-96 bg-white dark:bg-slate-900 h-full shadow-2xl border-l border-slate-200 dark:border-slate-850 flex flex-col justify-between">
            <div>
              
              {/* Drawer Header */}
              <div className="p-6 border-b border-slate-150 dark:border-slate-850 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Bell className="w-4 h-4 text-amber-500" />
                  <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-250">Bistro Alerts Hub</h3>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={handleClearAllNotifications}
                    className="p-1 text-slate-400 hover:text-rose-500 rounded-full transition-all flex items-center"
                    title="Clear All"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setIsNotificationsOpen(false)}
                    className="p-1 text-slate-400 hover:text-slate-600 dark:hover:bg-slate-800 rounded-full transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Drawer Notifications List content */}
              <div className="p-6 space-y-4 overflow-y-auto max-h-[80vh]">
                {notifications.length === 0 ? (
                  <div className="h-48 flex flex-col items-center justify-center text-slate-400 text-center text-xs">
                    <CheckCircle className="w-10 h-10 text-amber-100 dark:text-amber-900/20 mb-2" />
                    <p className="font-semibold text-slate-600">Zero System Alerts</p>
                    <p className="text-[10px]">Your gastronomy system logs and terminals are fully synced.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {notifications.map(note => (
                      <div 
                        key={note.id}
                        onClick={() => handleMarkAsRead(note.id)}
                        className={`p-3.5 border rounded-2xl transition-all cursor-pointer select-none space-y-1.5 relative ${
                          note.read 
                            ? 'bg-slate-50/50 dark:bg-slate-950/20 border-slate-100 dark:border-slate-850 opacity-60' 
                            : 'bg-amber-500/[0.02] border-amber-100 dark:border-amber-900/30 hover:border-amber-500/20 shadow-sm'
                        }`}
                      >
                        {!note.read && (
                          <span className="absolute top-3.5 right-3.5 w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                        )}

                        <div className="flex items-center space-x-1.5 text-[9px] font-black uppercase font-mono text-slate-400">
                          <Clock className="w-3.5 h-3.5 text-amber-500" />
                          <span>Notification Alert</span>
                        </div>

                        <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 pr-4 leading-normal">
                          {note.message}
                        </p>

                        <span className="text-[9px] text-slate-400 font-mono block">
                          {new Date(note.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </div>

            <div className="p-4 border-t border-slate-150 dark:border-slate-850 bg-slate-50 dark:bg-slate-950 text-center text-[10px] text-slate-400 font-mono select-none">
              Auto Sync Refresher Live
            </div>

          </div>
        </div>
      )}

      {/* POPUP MODAL COMPONENT ROUTING */}
      
      {/* 1. DISH FORM MODAL */}
      {isDishFormOpen && (
        <ProductFormModal
          product={activeDishEdit}
          onClose={() => {
            setIsDishFormOpen(false);
            setActiveDishEdit(null);
          }}
          onSave={handleSaveMenuItem}
        />
      )}

      {/* 2. CUSTOMER FORM MODAL */}
      {isCustomerFormOpen && (
        <CustomerFormModal
          onClose={() => setIsCustomerFormOpen(false)}
          onSave={handleSaveCustomer}
        />
      )}

      {/* 3. DIGITAL RECEIPT BILL POPUP */}
      {activeInvoice && (
        <InvoiceModal
          sale={activeInvoice}
          onClose={() => setActiveInvoice(null)}
        />
      )}

      {/* 4. TOAST NOTIFICATION OVERLAY */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center space-x-3 px-4 py-3 rounded-2xl shadow-2xl border animate-fade-in transition-all duration-300 bg-slate-950 border-slate-850 text-white">
          <span className={`w-2 h-2 rounded-full ${toast.type === 'success' ? 'bg-amber-500 shadow-sm' : 'bg-rose-500 shadow-sm'}`} />
          <span className="text-[10px] font-black uppercase tracking-wider">{toast.message}</span>
        </div>
      )}

    </div>
  );
}
