/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Search, 
  UserPlus, 
  Phone, 
  Mail, 
  Award, 
  Calendar, 
  ChevronRight, 
  Users, 
  ShieldCheck, 
  DollarSign, 
  Clock, 
  XCircle,
  Briefcase,
  Star,
  CheckCircle,
  Plus
} from 'lucide-react';
import { User, Order } from '../types';

interface CustomersProps {
  onAddCustomerClick: () => void; // Trigger standard Modal
  onAddStaffClick?: () => void; // Shortcut/Modal action
}

export default function Customers({ onAddCustomerClick, onAddStaffClick }: CustomersProps) {
  const [activeTab, setActiveTab] = useState<'patrons' | 'staff'>('patrons');
  const [searchTerm, setSearchTerm] = useState('');
  
  const [patrons, setPatrons] = useState<any[]>([]);
  const [staff, setStaff] = useState<any[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Create Staff Form modal state
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);
  const [staffName, setStaffName] = useState('');
  const [staffEmail, setStaffEmail] = useState('');
  const [staffPhone, setStaffPhone] = useState('');
  const [staffRole, setStaffRole] = useState<'admin' | 'staff'>('staff');
  const [staffSalary, setStaffSalary] = useState('2800');
  const [staffShift, setStaffShift] = useState('Morning (08:00 - 16:00)');
  const [staffNotes, setStaffNotes] = useState('');

  // Fetch patrons, staff, and orders from APIs
  const loadData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const headers = { 'Authorization': `Bearer ${token}` };

      // Get users list (which contains both staff and customers)
      const resUsers = await fetch('/api/users', { headers });
      const usersData = await resUsers.json();
      
      if (Array.isArray(usersData)) {
        // patrons are customers
        setPatrons(usersData.filter(u => u.role === 'customer'));
        // staff are admins or staff
        setStaff(usersData.filter(u => u.role === 'admin' || u.role === 'staff'));
      }

      // Get orders for history count
      const resOrders = await fetch('/api/orders', { headers });
      const ordersData = await resOrders.json();
      if (Array.isArray(ordersData)) {
        setOrders(ordersData);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Submit adding new Staff
  const handleCreateStaff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffName || !staffEmail) return;

    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          name: staffName,
          email: staffEmail,
          phone: staffPhone,
          role: staffRole,
          salary: Number(staffSalary),
          shift: staffShift,
          notes: staffNotes
        })
      });

      if (res.ok) {
        setIsStaffModalOpen(false);
        // Reset form
        setStaffName('');
        setStaffEmail('');
        setStaffPhone('');
        setStaffSalary('2800');
        setStaffNotes('');
        loadData();
      } else {
        const err = await res.json();
        alert(err.message || 'Failed to create staff record.');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Filter lists based on search
  const filteredPatrons = patrons.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.phone?.includes(searchTerm)
  );

  const filteredStaff = staff.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.shift?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full space-y-6">
      
      {/* Tab control headers */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-5 bg-white dark:bg-slate-900 border border-slate-250 dark:border-slate-850 rounded-3xl shadow-sm shrink-0">
        <div className="flex gap-2">
          <button
            onClick={() => { setActiveTab('patrons'); setSearchTerm(''); }}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
              activeTab === 'patrons'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-500 hover:text-slate-850 dark:hover:text-white'
            }`}
          >
            <Star className="w-4 h-4" />
            <span>Loyalty Patrons ({patrons.length})</span>
          </button>
          
          <button
            onClick={() => { setActiveTab('staff'); setSearchTerm(''); }}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all flex items-center gap-1.5 ${
              activeTab === 'staff'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-500 hover:text-slate-850 dark:hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Staff Directory ({staff.length})</span>
          </button>
        </div>

        {/* Action Button */}
        {activeTab === 'patrons' ? (
          <button
            onClick={onAddCustomerClick}
            className="py-2.5 px-4 bg-slate-950 hover:bg-slate-850 text-white text-xs font-black rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 shrink-0"
          >
            <UserPlus className="w-4 h-4 text-amber-500" />
            <span>Register New Patron</span>
          </button>
        ) : (
          <button
            onClick={() => setIsStaffModalOpen(true)}
            className="py-2.5 px-4 bg-slate-950 hover:bg-slate-850 text-white text-xs font-black rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 shrink-0"
          >
            <Plus className="w-4 h-4 text-amber-500" />
            <span>Hire Staff Member</span>
          </button>
        )}
      </div>

      {/* Searching row */}
      <div className="relative shrink-0">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
        <input
          type="text"
          placeholder={activeTab === 'patrons' ? "Search patrons by name, email, phone number..." : "Search staff by name, email, shift..."}
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-xs focus:outline-none"
        />
      </div>

      {/* Interactive Main directory table */}
      <div className="flex-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl flex flex-col min-h-0 shadow-xs">
        
        <div className="flex-1 overflow-y-auto min-h-0">
          
          {activeTab === 'patrons' ? (
            // Patrons view
            filteredPatrons.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-slate-400">
                <Star className="w-12 h-12 text-slate-200 dark:text-slate-850 mb-2" />
                <p className="text-sm font-semibold">No loyalty patrons found</p>
                <p className="text-xs">Add a new customer to track rewards and points.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-950 border-b border-slate-150 dark:border-slate-850 text-[10px] font-bold text-slate-400 uppercase tracking-wider select-none">
                      <th className="px-6 py-4">Patron Name</th>
                      <th className="px-6 py-4">Contact Details</th>
                      <th className="px-6 py-4 text-center">Bistro Reward Points</th>
                      <th className="px-6 py-4 text-center">Registered Date</th>
                      <th className="px-6 py-4 text-center">Invoices count</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
                    {filteredPatrons.map(c => {
                      const patronOrders = orders.filter(o => o.customerName === c.name || o.email === c.email);
                      return (
                        <tr key={c.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/20 transition-colors">
                          <td className="px-6 py-4 font-extrabold text-slate-900 dark:text-white">
                            {c.name}
                          </td>
                          <td className="px-6 py-4">
                            <div className="space-y-1 text-slate-500">
                              <span className="flex items-center">
                                <Phone className="w-3.5 h-3.5 mr-1 text-slate-300 inline shrink-0" />
                                {c.phone || 'N/A'}
                              </span>
                              {c.email && (
                                <span className="flex items-center text-[10px]">
                                  <Mail className="w-3.5 h-3.5 mr-1 text-slate-300 inline shrink-0" />
                                  {c.email}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 text-center">
                            <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-xl bg-amber-500/10 text-amber-500 font-mono font-black border border-amber-500/20">
                              <Award className="w-3.5 h-3.5" />
                              <span>{c.loyaltyPoints || 0} pts</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-center text-slate-400 font-mono font-bold">
                            {new Date(c.createdAt || Date.now()).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center justify-center text-slate-500 text-[11px] font-mono font-black">
                              <span>{patronOrders.length} tickets</span>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )
          ) : (
            // Staff view
            filteredStaff.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-slate-400">
                <Users className="w-12 h-12 text-slate-200 dark:text-slate-850 mb-2" />
                <p className="text-sm font-semibold">No staff records found</p>
                <p className="text-xs">Register new staff members using the Hire action.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-950 border-b border-slate-150 dark:border-slate-850 text-[10px] font-bold text-slate-400 uppercase tracking-wider select-none">
                      <th className="px-6 py-4">Staff Member</th>
                      <th className="px-6 py-4">Security Role</th>
                      <th className="px-6 py-4">Contact Info</th>
                      <th className="px-6 py-4 text-center">Monthly Payroll</th>
                      <th className="px-6 py-4">Active Shift Plan</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
                    {filteredStaff.map(s => (
                      <tr key={s.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-950/20 transition-colors">
                        <td className="px-6 py-4">
                          <div>
                            <span className="font-extrabold text-slate-900 dark:text-white block">
                              {s.name}
                            </span>
                            <span className="text-[10px] text-slate-400">{s.notes || 'No special remarks'}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-2.5 py-1 rounded-xl text-[9px] font-black uppercase font-mono tracking-wider ${
                            s.role === 'admin'
                              ? 'bg-rose-500/10 border border-rose-500/15 text-rose-500'
                              : 'bg-blue-500/10 border border-blue-500/15 text-blue-500'
                          }`}>
                            {s.role}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="space-y-0.5 text-slate-500 font-medium">
                            <span className="block">{s.email}</span>
                            <span className="block text-[10px] text-slate-400">{s.phone || 'No phone'}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-center font-mono font-black text-slate-800 dark:text-slate-100">
                          ${(s.salary || 2500).toLocaleString()}/mo
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400 font-medium">
                            <Clock className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                            <span>{s.shift || 'Flexible Shift'}</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )
          )}

        </div>

        {/* Info footer banner */}
        <div className="px-6 py-4 border-t border-slate-150 dark:border-slate-850 flex justify-between text-[11px] text-slate-400 select-none bg-slate-50/50 dark:bg-slate-950/20">
          <span>Active Operations Registry Directory</span>
          <span>Security & GDPR Compliant</span>
        </div>

      </div>

      {/* Hire Staff Modal Form */}
      {isStaffModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 text-slate-950 dark:text-white rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4">
            
            <div className="flex justify-between items-start pb-2 border-b border-slate-100 dark:border-slate-850">
              <h4 className="text-sm font-black uppercase tracking-wider flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-amber-500" />
                <span>Register New Staff Record</span>
              </h4>
              <button 
                onClick={() => setIsStaffModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateStaff} className="space-y-4 text-xs">
              
              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Full Name</label>
                <input 
                  type="text"
                  required
                  value={staffName}
                  onChange={e => setStaffName(e.target.value)}
                  placeholder="e.g. Chef Robert"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Email Address</label>
                <input 
                  type="email"
                  required
                  value={staffEmail}
                  onChange={e => setStaffEmail(e.target.value)}
                  placeholder="robert@bistroguru.com"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Phone Number</label>
                <input 
                  type="text"
                  value={staffPhone}
                  onChange={e => setStaffPhone(e.target.value)}
                  placeholder="+1 (555) 489-0291"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Operational Role</label>
                  <select
                    value={staffRole}
                    onChange={e => setStaffRole(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none"
                  >
                    <option value="staff">Kitchen/Staff</option>
                    <option value="admin">System Admin</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Monthly Salary ($)</label>
                  <input 
                    type="number"
                    value={staffSalary}
                    onChange={e => setStaffSalary(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Assigned Shift Plan</label>
                <select
                  value={staffShift}
                  onChange={e => setStaffShift(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none"
                >
                  <option value="Morning (08:00 - 16:00)">Morning (08:00 - 16:00)</option>
                  <option value="Evening (16:00 - 00:00)">Evening (16:00 - 00:00)</option>
                  <option value="Night (00:00 - 08:00)">Night (00:00 - 08:00)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">Special Contract Notes</label>
                <textarea 
                  value={staffNotes}
                  onChange={e => setStaffNotes(e.target.value)}
                  placeholder="Allergies, emergency contacts..."
                  rows={2}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-md transition-all flex items-center justify-center gap-1"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Save Contract Record</span>
              </button>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
