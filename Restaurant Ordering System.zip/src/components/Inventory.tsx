/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Plus, 
  Edit, 
  Trash2, 
  Clock, 
  CheckCircle, 
  XCircle, 
  ShoppingBag, 
  Minus, 
  PlusCircle, 
  Sparkles,
  Utensils,
  CreditCard,
  MapPin,
  HelpCircle,
  TrendingUp,
  Percent
} from 'lucide-react';
import { MenuItem, User, OrderItem, OrderType, PaymentMethod } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface MenuModuleProps {
  products: any[]; // Represents menu items (dishes)
  currentUser: User;
  onAddProductClick: () => void; // Admin action
  onEditProductClick: (item: MenuItem) => void; // Admin action
  onDeleteProduct: (id: string) => void; // Admin action
  onCheckout: (orderData: any) => Promise<any>; // Placed order action
  onRefreshMenu?: () => void; // Optional sync
}

export default function Inventory({ 
  products: menuItems, 
  currentUser, 
  onAddProductClick, 
  onEditProductClick, 
  onDeleteProduct,
  onCheckout,
  onRefreshMenu
}: MenuModuleProps) {
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'starters' | 'mains' | 'desserts' | 'drinks'>('All');
  
  // Customer Cart state
  const [cart, setCart] = useState<{ [id: string]: { item: MenuItem; quantity: number } }>({});
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [orderType, setOrderType] = useState<OrderType>('dine-in');
  const [tableNumber, setTableNumber] = useState('4');
  const [deliveryAddress, setDeliveryAddress] = useState(currentUser.address || '');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; rate: number } | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  const [orderNotes, setOrderNotes] = useState('');
  const [isSubmittingOrder, setIsSubmittingOrder] = useState(false);
  
  // Payment Gateway simulation state
  const [isPaying, setIsPaying] = useState(false);
  const [paymentCardNum, setPaymentCardNum] = useState('4111 2222 3333 4444');
  const [paymentCardName, setPaymentCardName] = useState(currentUser.name);
  const [paymentCardExpiry, setPaymentCardExpiry] = useState('12/28');
  const [paymentCardCVC, setPaymentCardCVC] = useState('123');

  // Filter categories
  const categories: { id: 'All' | 'starters' | 'mains' | 'desserts' | 'drinks'; name: string }[] = [
    { id: 'All', name: 'All Dishes' },
    { id: 'starters', name: 'Starters' },
    { id: 'mains', name: 'Mains' },
    { id: 'desserts', name: 'Desserts' },
    { id: 'drinks', name: 'Drinks' },
  ];

  // Filter dishes
  const filteredDishes = menuItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          item.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Handle stock availability toggling (Staff and Admin)
  const handleToggleAvailability = (dish: MenuItem) => {
    fetch(`/api/menu/${dish.id}`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ isAvailable: !dish.isAvailable })
    })
    .then(res => {
      if (res.ok) {
        // Trigger page refresh or list reload indirectly via App.tsx syncing
        if (onRefreshMenu) {
          onRefreshMenu();
        } else {
          window.location.reload();
        }
      }
    });
  };

  const handleDeleteConfirm = (dish: MenuItem) => {
    if (confirm(`Are you sure you want to delete "${dish.name}" from the menu?`)) {
      onDeleteProduct(dish.id);
    }
  };

  // Cart operations
  const addToCart = (item: MenuItem) => {
    if (!item.isAvailable) return;
    const stock = item.stock !== undefined ? item.stock : 10;
    
    setCart(prev => {
      const existing = prev[item.id];
      const currentQty = existing ? existing.quantity : 0;
      if (currentQty >= stock) {
        alert(`Cannot add more "${item.name}". Only ${stock} portions are available in stock.`);
        return prev;
      }
      return {
        ...prev,
        [item.id]: {
          item,
          quantity: currentQty + 1
        }
      };
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => {
      const copy = { ...prev };
      if (!copy[itemId]) return prev;
      if (copy[itemId].quantity <= 1) {
        delete copy[itemId];
      } else {
        copy[itemId].quantity -= 1;
      }
      return copy;
    });
  };

  const updateCartQty = (itemId: string, qty: number) => {
    setCart(prev => {
      if (qty <= 0) {
        const copy = { ...prev };
        delete copy[itemId];
        return copy;
      }
      const item = prev[itemId]?.item;
      if (!item) return prev;
      const stock = item.stock !== undefined ? item.stock : 10;
      if (qty > stock) {
        alert(`Only ${stock} portions of "${item.name}" are available in stock.`);
        return prev;
      }
      return {
        ...prev,
        [itemId]: {
          ...prev[itemId],
          quantity: qty
        }
      };
    });
  };

  // Calculations
  const cartItemsArray = Object.values(cart) as { item: MenuItem; quantity: number }[];
  const subtotal = cartItemsArray.reduce((acc, current) => acc + (current.item.price * current.quantity), 0);
  const discountRate = appliedCoupon ? appliedCoupon.rate : 0;
  const discountAmount = Math.round((subtotal * discountRate) * 100) / 100;
  const taxableAmount = Math.max(0, subtotal - discountAmount);
  const taxAmount = Math.round((taxableAmount * 0.08) * 100) / 100; // 8% sales tax
  const total = Math.round((taxableAmount + taxAmount) * 100) / 100;

  // Coupon Verification
  const verifyCoupon = () => {
    const cleanCode = couponCode.trim().toUpperCase();
    if (cleanCode === 'WELCOME10') {
      setAppliedCoupon({ code: 'WELCOME10', rate: 0.1 }); // 10%
    } else if (cleanCode === 'BISTROLIFE') {
      setAppliedCoupon({ code: 'BISTROLIFE', rate: 0.2 }); // 20%
    } else {
      alert('Invalid or expired coupon code!');
    }
  };

  // Checkout submission
  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cartItemsArray.length === 0) return;

    setIsSubmittingOrder(true);

    const orderData = {
      items: cartItemsArray.map(c => ({
        menuItemId: c.item.id,
        quantity: c.quantity
      })),
      type: orderType,
      tableNumber: orderType === 'dine-in' ? tableNumber : undefined,
      deliveryAddress: orderType === 'delivery' ? deliveryAddress : undefined,
      discountCode: appliedCoupon ? appliedCoupon.code : undefined,
      paymentMethod,
      notes: orderNotes
    };

    if (paymentMethod !== 'cash') {
      // Show card processor simulation
      setIsPaying(true);
      setTimeout(async () => {
        const result = await onCheckout(orderData);
        if (result) {
          setCart({});
          setAppliedCoupon(null);
          setCouponCode('');
          setOrderNotes('');
          setIsCartOpen(false);
        }
        setIsPaying(false);
        setIsSubmittingOrder(false);
      }, 2000);
    } else {
      // Cash payment
      const result = await onCheckout(orderData);
      if (result) {
        setCart({});
        setAppliedCoupon(null);
        setCouponCode('');
        setOrderNotes('');
        setIsCartOpen(false);
      }
      setIsSubmittingOrder(false);
    }
  };

  return (
    <div className="flex h-full overflow-hidden gap-6 relative">
      
      {/* Main Menu Feed (Left Side) */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        
        {/* Banner with metrics */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-white shrink-0 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none"></div>
          <div>
            <h2 className="text-xl font-extrabold flex items-center gap-2">
              <Utensils className="w-5 h-5 text-amber-500" />
              <span>Menu Catalog</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              {currentUser.role === 'customer' 
                ? 'Welcome! Browse gourmet dishes, add them to your cart, and redeem reward points.' 
                : 'Manage culinary listings, adjust recipe availabilities, or update pricing details.'
              }
            </p>
          </div>

          <div className="flex gap-3 shrink-0">
            {currentUser.role === 'admin' && (
              <button
                onClick={onAddProductClick}
                className="py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-xl shadow-md transition-all flex items-center justify-center space-x-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Create Dish</span>
              </button>
            )}

            {currentUser.role === 'customer' && (
              <button
                onClick={() => setIsCartOpen(true)}
                className="py-2.5 px-4 bg-slate-850 hover:bg-slate-800 border border-slate-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 relative transition-all"
              >
                <ShoppingBag className="w-4 h-4 text-amber-500" />
                <span>My Cart ({cartItemsArray.reduce((acc, c) => acc + c.quantity, 0)})</span>
                {cartItemsArray.length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-amber-500 text-slate-950 font-black font-mono rounded-full flex items-center justify-center text-[10px]">
                    {cartItemsArray.reduce((acc, c) => acc + c.quantity, 0)}
                  </span>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Filters and Search row */}
        <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center mb-6 shrink-0">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search by dish name or ingredients..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-xs focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
            />
          </div>

          <div className="flex gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none shrink-0">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 border ${
                  selectedCategory === cat.id
                    ? 'bg-amber-500 border-amber-500 text-slate-950 shadow-sm shadow-amber-500/10'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-850 text-slate-500 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Dishes Grid */}
        <div className="flex-1 overflow-y-auto pr-1">
          {filteredDishes.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-slate-400">
              <Utensils className="w-12 h-12 text-slate-200 dark:text-slate-850 mb-2" />
              <p className="text-sm font-semibold">No dishes found matching filters</p>
              <p className="text-xs">Try adjusting your search criteria or categories.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-12">
              {filteredDishes.map(dish => {
                const cartQty = cart[dish.id]?.quantity || 0;
                const isLowStock = dish.stock !== undefined && dish.threshold !== undefined && dish.stock <= dish.threshold;
                
                return (
                  <div 
                    key={dish.id}
                    className={`bg-white dark:bg-slate-900 border overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col justify-between h-[400px] relative group ${
                      isLowStock 
                        ? 'border-rose-500 dark:border-rose-900 ring-1 ring-rose-500/10 shadow-rose-100/30 dark:shadow-rose-950/10' 
                        : 'border-slate-200 dark:border-slate-850'
                    } rounded-3xl`}
                  >
                    {/* Badge for Out of Stock or Low Stock */}
                    {!dish.isAvailable ? (
                      <div className="absolute top-4 left-4 z-10 bg-rose-600 text-white font-mono text-[9px] font-black uppercase px-2.5 py-1 rounded-lg shadow-md">
                        Out of stock
                      </div>
                    ) : isLowStock ? (
                      <div className="absolute top-4 left-4 z-10 bg-rose-500 text-white font-mono text-[9px] font-black uppercase px-2.5 py-1 rounded-lg shadow-md animate-pulse">
                        Low stock
                      </div>
                    ) : null}

                    {/* Dish image container */}
                    <div className="h-44 overflow-hidden relative bg-slate-100">
                      <img 
                        src={dish.image} 
                        alt={dish.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-all duration-550"
                      />
                      <div className="absolute top-4 right-4 bg-slate-950/60 backdrop-blur-md text-white font-mono text-[10px] font-black px-2.5 py-1.5 rounded-xl flex items-center gap-1 shadow-sm">
                        <Clock className="w-3.5 h-3.5 text-amber-400" />
                        <span>{dish.prepTime} min</span>
                      </div>
                    </div>

                    {/* Dish Info */}
                    <div className="p-5 flex-1 flex flex-col justify-between">
                      <div className="space-y-1.5">
                        <div className="flex justify-between items-start gap-2">
                          <h3 className="font-extrabold text-sm text-slate-900 dark:text-white line-clamp-1">
                            {dish.name}
                          </h3>
                          <span className="text-sm font-black text-amber-500 font-mono">
                            ${dish.price.toFixed(2)}
                          </span>
                        </div>
                        <p className="text-slate-500 dark:text-slate-400 text-xs line-clamp-2 leading-relaxed">
                          {dish.description}
                        </p>
                        
                        {/* Stock & Threshold Display */}
                        <div className="flex items-center justify-between pt-2 border-t border-dashed border-slate-100 dark:border-slate-800">
                          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Stock status</span>
                          <span className={`text-[10px] font-mono font-black px-2 py-0.5 rounded-lg border ${
                            isLowStock 
                              ? 'bg-rose-500/10 text-rose-500 border-rose-500/20' 
                              : 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                          }`}>
                            {dish.stock !== undefined ? dish.stock : 10} portions left {isLowStock && `(Min: ${dish.threshold !== undefined ? dish.threshold : 3})`}
                          </span>
                        </div>
                      </div>

                      {/* Role Specific Actions */}
                      <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-850 flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold uppercase text-slate-400 tracking-wider">
                          {dish.category}
                        </span>

                        {/* Customer controls */}
                        {currentUser.role === 'customer' && (
                          <div className="flex items-center gap-2">
                            {cartQty > 0 ? (
                              <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 rounded-xl p-1">
                                <button
                                  onClick={() => removeFromCart(dish.id)}
                                  className="w-7 h-7 bg-amber-500 text-slate-950 hover:bg-amber-400 rounded-lg flex items-center justify-center font-bold"
                                >
                                  <Minus className="w-3.5 h-3.5" />
                                </button>
                                <span className="font-mono font-black text-xs text-amber-500 px-1">
                                  {cartQty}
                                </span>
                                <button
                                  onClick={() => addToCart(dish)}
                                  className="w-7 h-7 bg-amber-500 text-slate-950 hover:bg-amber-400 rounded-lg flex items-center justify-center font-bold"
                                >
                                  <Plus className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => addToCart(dish)}
                                disabled={!dish.isAvailable}
                                className={`py-2 px-3.5 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 ${
                                  dish.isAvailable
                                    ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-sm shadow-amber-500/10'
                                    : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                                }`}
                              >
                                <ShoppingBag className="w-3.5 h-3.5" />
                                <span>Add to Cart</span>
                              </button>
                            )}
                          </div>
                        )}

                        {/* Staff toggle controls */}
                        {currentUser.role === 'staff' && (
                          <button
                            onClick={() => handleToggleAvailability(dish)}
                            className={`py-1.5 px-3 rounded-lg text-[10px] font-extrabold uppercase tracking-wider transition-all flex items-center gap-1 ${
                              dish.isAvailable
                                ? 'bg-emerald-500/10 border border-emerald-500/25 text-emerald-500 hover:bg-emerald-500/20'
                                : 'bg-rose-500/10 border border-rose-500/25 text-rose-500 hover:bg-rose-500/20'
                            }`}
                          >
                            {dish.isAvailable ? <CheckCircle className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                            <span>{dish.isAvailable ? 'In Stock' : 'Out of Stock'}</span>
                          </button>
                        )}

                        {/* Admin Action Menu */}
                        {currentUser.role === 'admin' && (
                          <div className="flex gap-1.5">
                            <button
                              onClick={() => onEditProductClick(dish)}
                              className="p-1.5 text-slate-500 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all"
                              title="Edit item"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteConfirm(dish)}
                              className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-all"
                              title="Delete item"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

      </div>

      {/* Floating/Slide-out Cart Panel (Right Side for Customers only) */}
      <AnimatePresence>
        {currentUser.role === 'customer' && isCartOpen && (
          <motion.div
            initial={{ opacity: 0, x: 200 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 200 }}
            className="w-96 bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 h-full flex flex-col justify-between shadow-xl z-30 shrink-0"
          >
            {/* Cart Header */}
            <div className="p-6 border-b border-slate-100 dark:border-slate-850 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-amber-500" />
                <h3 className="font-extrabold text-sm uppercase tracking-wider text-slate-700 dark:text-slate-200">
                  Your Cart
                </h3>
              </div>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 rounded-full transition-colors"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            {/* Cart list content */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {cartItemsArray.length === 0 ? (
                <div className="h-64 flex flex-col items-center justify-center text-slate-400 text-center">
                  <ShoppingBag className="w-12 h-12 text-slate-100 dark:text-slate-800 mb-2" />
                  <p className="text-sm font-semibold">Your cart is empty</p>
                  <p className="text-[10px] text-slate-500 px-6">Select delicious dishes from the menu to start building your meal order!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cartItemsArray.map(c => (
                    <div key={c.item.id} className="flex gap-3 items-center pb-3 border-b border-slate-100 dark:border-slate-850">
                      <img 
                        src={c.item.image} 
                        alt={c.item.name}
                        referrerPolicy="no-referrer"
                        className="w-12 h-12 rounded-xl object-cover bg-slate-50 shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">{c.item.name}</h4>
                        <span className="text-[10px] font-mono text-slate-400 block">${c.item.price.toFixed(2)} each</span>
                      </div>
                      
                      {/* Quantity adjusting widgets */}
                      <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-950 p-1 rounded-lg shrink-0">
                        <button
                          onClick={() => removeFromCart(c.item.id)}
                          className="p-1 text-slate-500 hover:text-amber-500 hover:bg-white rounded-md transition-all"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="font-mono font-bold text-xs w-4 text-center">{c.quantity}</span>
                        <button
                          onClick={() => addToCart(c.item)}
                          className="p-1 text-slate-500 hover:text-amber-500 hover:bg-white rounded-md transition-all"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Order Type & Details Form */}
                  <form onSubmit={handlePlaceOrder} className="pt-4 space-y-4 border-t border-slate-100 dark:border-slate-850">
                    
                    {/* Dine-in/takeaway/delivery selector */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Service Type</label>
                      <div className="grid grid-cols-3 gap-1 bg-slate-50 dark:bg-slate-950 p-1 rounded-xl border border-slate-100 dark:border-slate-850">
                        {(['dine-in', 'takeaway', 'delivery'] as OrderType[]).map(type => (
                          <button
                            key={type}
                            type="button"
                            onClick={() => setOrderType(type)}
                            className={`py-1.5 text-[10px] font-extrabold uppercase rounded-lg transition-all ${
                              orderType === type
                                ? 'bg-amber-500 text-slate-950 shadow-xs'
                                : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
                            }`}
                          >
                            {type}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Conditional inputs */}
                    {orderType === 'dine-in' && (
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Table Number</label>
                        <select
                          value={tableNumber}
                          onChange={e => setTableNumber(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-250 dark:border-slate-850 rounded-xl text-xs focus:outline-none"
                        >
                          {[1,2,3,4,5,6,7,8,9,10,12].map(num => (
                            <option key={num} value={num}>Table #{num}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    {orderType === 'delivery' && (
                      <div className="space-y-1">
                        <div className="flex justify-between">
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Delivery Address</label>
                          <span className="text-[9px] text-amber-500 font-bold flex items-center gap-0.5">
                            <MapPin className="w-3 h-3" /> Safe Location
                          </span>
                        </div>
                        <input
                          type="text"
                          required
                          value={deliveryAddress}
                          onChange={e => setDeliveryAddress(e.target.value)}
                          placeholder="Enter complete shipping address..."
                          className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none"
                        />
                      </div>
                    )}

                    {/* Coupons and Discounts */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Coupon Discount Code</label>
                      <div className="flex gap-1.5">
                        <input
                          type="text"
                          value={couponCode}
                          onChange={e => setCouponCode(e.target.value)}
                          placeholder="WELCOME10 (10%) or BISTROLIFE (20%)"
                          className="flex-1 px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none"
                        />
                        <button
                          type="button"
                          onClick={verifyCoupon}
                          className="py-2 px-3 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-amber-500 rounded-xl text-xs font-bold shrink-0"
                        >
                          Apply
                        </button>
                      </div>
                      {appliedCoupon && (
                        <p className="text-[10px] text-emerald-500 font-bold flex items-center gap-0.5 mt-1 animate-pulse">
                          <Percent className="w-3.5 h-3.5" /> Coupon Applied: "{appliedCoupon.code}" ({(appliedCoupon.rate * 100)}% Discount)
                        </p>
                      )}
                    </div>

                    {/* Payment Mode */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Payment Method</label>
                      <div className="grid grid-cols-2 gap-1.5">
                        <button
                          type="button"
                          onClick={() => setPaymentMethod('card')}
                          className={`p-2 rounded-xl text-left border flex flex-col justify-between h-14 transition-all ${
                            paymentMethod === 'card'
                              ? 'bg-amber-500/5 border-amber-500 text-amber-500'
                              : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-850 text-slate-500 hover:bg-slate-50'
                          }`}
                        >
                          <CreditCard className="w-4 h-4" />
                          <span className="text-[10px] font-bold block">Credit/Debit Card</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setPaymentMethod('cash')}
                          className={`p-2 rounded-xl text-left border flex flex-col justify-between h-14 transition-all ${
                            paymentMethod === 'cash'
                              ? 'bg-amber-500/5 border-amber-500 text-amber-500'
                              : 'bg-white dark:bg-slate-950 border-slate-200 dark:border-slate-850 text-slate-500 hover:bg-slate-50'
                          }`}
                        >
                          <Utensils className="w-4 h-4" />
                          <span className="text-[10px] font-bold block">Cash on Delivery / Pickup</span>
                        </button>
                      </div>
                    </div>

                    {/* Notes */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Kitchen Instruction Notes</label>
                      <textarea
                        value={orderNotes}
                        onChange={e => setOrderNotes(e.target.value)}
                        placeholder="e.g. Allergy details, spicy level, leave package..."
                        rows={2}
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none"
                      />
                    </div>
                    
                    {/* Submit Order */}
                    <button
                      type="submit"
                      disabled={isSubmittingOrder}
                      className="w-full py-3.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 mt-2"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>{isSubmittingOrder ? 'Placing Order...' : `Checkout & Place Order`}</span>
                    </button>

                  </form>
                </div>
              )}
            </div>

            {/* Price Calculations Footer block */}
            {cartItemsArray.length > 0 && (
              <div className="p-6 border-t border-slate-100 dark:border-slate-850 bg-slate-50/50 dark:bg-slate-950/20 space-y-2 shrink-0">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-500">Subtotal</span>
                  <span className="font-mono text-slate-700 dark:text-slate-300">${subtotal.toFixed(2)}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-xs text-emerald-500 font-bold">
                    <span>Discount</span>
                    <span className="font-mono">-${discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-xs">
                  <span className="text-slate-500">VAT / Sales Tax (8%)</span>
                  <span className="font-mono text-slate-700 dark:text-slate-300">${taxAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm pt-2 border-t border-slate-200 dark:border-slate-800 font-bold">
                  <span className="text-slate-950 dark:text-white">Order Total</span>
                  <span className="font-mono text-amber-500 text-base">${total.toFixed(2)}</span>
                </div>
                <p className="text-[9px] text-slate-400 italic text-center mt-1">
                  You will earn <strong className="font-bold text-amber-500">{Math.floor(total)} Bistro Points</strong> with this order!
                </p>
              </div>
            )}

          </motion.div>
        )}
      </AnimatePresence>

      {/* Simulated Secure Payment Gateway Checkout Modal Overlay */}
      <AnimatePresence>
        {isPaying && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border border-slate-800 text-white rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl relative"
            >
              <div className="text-center space-y-2 mb-6">
                <div className="w-12 h-12 bg-amber-500 rounded-xl flex items-center justify-center mx-auto shadow-lg shadow-amber-500/20">
                  <CreditCard className="w-5 h-5 text-slate-950" />
                </div>
                <h3 className="text-base font-extrabold uppercase tracking-wider text-white">
                  Securing Payment Gateway
                </h3>
                <p className="text-xs text-slate-400">
                  Processing transaction for <strong className="text-amber-500 font-mono">${total.toFixed(2)}</strong> via encrypted protocol.
                </p>
              </div>

              {/* Animated visual Credit Card mockup */}
              <div className="bg-gradient-to-tr from-amber-500 to-amber-600 rounded-2xl p-5 shadow-lg shadow-amber-500/5 relative overflow-hidden mb-6 h-40 flex flex-col justify-between">
                <div className="absolute top-0 right-0 w-36 h-36 bg-white/5 rounded-full blur-2xl pointer-events-none"></div>
                
                <div className="flex justify-between items-start">
                  <span className="text-xs font-black uppercase italic text-slate-950 tracking-wider">GuruPay Security</span>
                  <Sparkles className="w-5 h-5 text-slate-950 animate-pulse" />
                </div>

                <div className="space-y-4">
                  <span className="text-lg font-mono tracking-widest text-slate-950 font-black block">
                    {paymentCardNum}
                  </span>
                  <div className="flex justify-between items-end text-[9px] font-extrabold uppercase text-slate-900">
                    <div>
                      <span className="text-slate-900/60 block text-[7px] font-bold">Cardholder</span>
                      <span>{paymentCardName || 'Bistro Patron'}</span>
                    </div>
                    <div>
                      <span className="text-slate-900/60 block text-[7px] font-bold">Expires</span>
                      <span>{paymentCardExpiry}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Processor Log lines */}
              <div className="space-y-2 mb-6">
                <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                  <span>SSL Handshake Protocol...</span>
                  <span className="text-emerald-500 font-bold">CONFIRMED</span>
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                  <span>Merchant account check...</span>
                  <span className="text-emerald-500 font-bold">OK (BISTRO-GURU)</span>
                </div>
                <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                  <span>Settling token clearance...</span>
                  <span className="text-amber-400 font-bold animate-pulse">PENDING CLR...</span>
                </div>
              </div>

              {/* Loading spinner */}
              <div className="flex justify-center items-center py-4">
                <div className="w-8 h-8 border-4 border-amber-500 border-t-transparent rounded-full animate-spin"></div>
              </div>

              <div className="text-[10px] text-slate-500 font-semibold text-center select-none">
                ENCRYPTED AES-256 • REAL-TIME PAYMENT PROCESSING
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
