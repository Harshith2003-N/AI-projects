/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { X, Printer, Download, Sparkles, Receipt } from 'lucide-react';
import { Order } from '../types';

interface InvoiceModalProps {
  sale: Order | null;
  onClose: () => void;
}

export default function InvoiceModal({ sale: order, onClose }: InvoiceModalProps) {
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  const formattedDate = new Date(order.date || Date.now()).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const discountRate = order.subtotal > 0 ? Math.round((order.discountAmount / order.subtotal) * 100) : 0;
  const taxRate = order.subtotal > 0 ? Math.round((order.taxAmount / (order.subtotal - order.discountAmount)) * 100) : 8;

  // Calculate points earned for loyalty (1 point per dollar spent)
  const pointsEarned = Math.floor(order.total);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-md bg-white text-slate-800 rounded-3xl shadow-2xl border border-slate-150 overflow-hidden my-8">
        
        {/* Header Controls */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
            <span className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1">
              <Receipt className="w-4 h-4 text-amber-500" />
              <span>Digital Bill Receipt</span>
            </span>
          </div>
          <div className="flex space-x-1">
            <button
              onClick={handlePrint}
              className="p-2 text-slate-500 hover:text-amber-500 hover:bg-slate-100 rounded-full transition-colors"
              title="Print Receipt"
            >
              <Printer className="w-4.5 h-4.5" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-rose-500 hover:bg-slate-100 rounded-full transition-colors"
            >
              <X className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>

        {/* Printable Invoice Area */}
        <div id="printable-invoice" className="p-6 md:p-8 space-y-5 max-h-[75vh] overflow-y-auto font-sans">
          
          {/* Shop Header */}
          <div className="text-center space-y-1">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-amber-500/10 text-amber-500 mb-2 font-mono text-xl font-bold">
              BG
            </div>
            <h3 className="text-base font-black tracking-tight text-slate-900 uppercase">Bistro Guru Gastronomy</h3>
            <p className="text-xs text-slate-400">Authentic Taste, Premium Gastronomy</p>
            <p className="text-[10px] text-slate-400">Port 3000 Ingress • Realtime Secure Payment Gateway</p>
          </div>

          <div className="border-t border-dashed border-slate-200 my-3"></div>

          {/* Metadata Grid */}
          <div className="grid grid-cols-2 gap-y-2.5 text-xs font-semibold">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Ticket ID</span>
              <span className="font-mono font-bold text-slate-800">{order.orderNumber}</span>
            </div>
            <div className="text-right">
              <span className="text-slate-400 block text-[10px] uppercase">Service Mode</span>
              <span className="font-black text-amber-500 uppercase bg-amber-500/10 px-2 py-0.5 rounded-lg inline-block text-[10px] tracking-wide">
                {order.type}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Patron Guest</span>
              <span className="font-bold text-slate-800">{order.customerName || 'Anonymous Guest'}</span>
            </div>
            <div className="text-right">
              <span className="text-slate-400 block text-[10px] uppercase">Payment Mode</span>
              <span className="font-bold uppercase font-mono text-slate-800">{order.paymentMethod}</span>
            </div>
            <div className="col-span-2">
              <span className="text-slate-400 block text-[10px] uppercase">Date & Time</span>
              <span className="font-medium text-slate-800">{formattedDate}</span>
            </div>
          </div>

          <div className="border-t border-dashed border-slate-200 my-3"></div>

          {/* Items Table */}
          <div className="space-y-2">
            <div className="flex justify-between text-[10px] font-black uppercase tracking-wider text-slate-400 pb-1 border-b border-slate-100">
              <span>Culinary Dish & Qty</span>
              <span className="text-right">Amount</span>
            </div>
            
            <div className="space-y-3 max-h-48 overflow-y-auto">
              {order.items.map((item, idx) => (
                <div key={idx} className="flex justify-between items-start text-xs font-semibold">
                  <div className="space-y-0.5">
                    <p className="font-extrabold text-slate-800">{item.name}</p>
                    <p className="text-[10px] text-slate-400 font-mono">
                      {item.quantity} × ${item.price.toFixed(2)}
                    </p>
                  </div>
                  <span className="font-mono text-slate-800">${item.subtotal.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-dashed border-slate-200 my-3"></div>

          {/* Pricing Breakdown */}
          <div className="space-y-1.5 text-xs font-semibold">
            <div className="flex justify-between text-slate-500">
              <span>Subtotal</span>
              <span className="font-mono">${order.subtotal.toFixed(2)}</span>
            </div>
            
            {order.discountAmount > 0 && (
              <div className="flex justify-between text-rose-500 font-bold">
                <span>Discount Applied ({discountRate}%)</span>
                <span className="font-mono">-${order.discountAmount.toFixed(2)}</span>
              </div>
            )}

            <div className="flex justify-between text-slate-500">
              <span>Taxes ({taxRate}%)</span>
              <span className="font-mono">+${order.taxAmount.toFixed(2)}</span>
            </div>

            <div className="border-t border-slate-100 pt-2 flex justify-between text-sm font-black text-slate-900">
              <span>Final Total Paid</span>
              <span className="font-mono text-amber-500">${order.total.toFixed(2)}</span>
            </div>
          </div>

          {/* Loyalty & Rewards Alerts */}
          {pointsEarned > 0 && (
            <div className="mt-3 bg-amber-500/10 border border-amber-500/20 rounded-2xl p-3.5 flex items-start space-x-2 text-xs text-amber-800 font-semibold">
              <Sparkles className="w-4.5 h-4.5 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-black block text-slate-900">Bistro Loyalty Account Boosted!</span>
                <span className="text-slate-500 text-[11px]">This purchase credited <strong className="font-mono text-amber-500">+{pointsEarned}</strong> reward points directly into your customer profile.</span>
              </div>
            </div>
          )}

          {/* Footer Barcode placeholder / Thank you */}
          <div className="pt-4 text-center space-y-2">
            <p className="text-[11px] text-slate-400 italic">"Thank you for dining with Bistro Guru!"</p>
            <div className="inline-block px-4 py-1.5 border border-slate-200 rounded-xl bg-slate-50 text-[9px] font-mono font-bold text-slate-400 tracking-widest uppercase">
              *{order.id.slice(0, 10).toUpperCase()}*
            </div>
          </div>

        </div>

        {/* Bottom controls */}
        <div className="px-6 py-4 border-t border-slate-100 bg-slate-50/50 text-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 px-4 bg-slate-950 hover:bg-slate-850 text-white text-xs font-black uppercase tracking-wider rounded-xl shadow-md transition-all"
          >
            Done & Return
          </button>
        </div>

      </div>
    </div>
  );
}
