/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';

interface ChartDataPoint {
  date: string;
  amount: number;
  profit: number;
}

interface LineChartProps {
  data: ChartDataPoint[];
}

export default function LineChart({ data }: LineChartProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-slate-400 font-sans text-sm">
        No chart data available
      </div>
    );
  }

  // Find max value to scale the chart
  const maxVal = Math.max(...data.map(d => Math.max(d.amount, d.profit, 100))) * 1.15;

  const width = 600;
  const height = 240;
  const paddingLeft = 50;
  const paddingRight = 20;
  const paddingTop = 20;
  const paddingBottom = 40;

  const chartWidth = width - paddingLeft - paddingRight;
  const chartHeight = height - paddingTop - paddingBottom;

  // Generate points for SVG Polyline/Paths
  const getCoordinates = (index: number, value: number) => {
    const x = paddingLeft + (index / (data.length - 1)) * chartWidth;
    const y = height - paddingBottom - (value / maxVal) * chartHeight;
    return { x, y };
  };

  const revenuePointsStr = data.map((d, i) => {
    const { x, y } = getCoordinates(i, d.amount);
    return `${x},${y}`;
  }).join(' ');

  const profitPointsStr = data.map((d, i) => {
    const { x, y } = getCoordinates(i, d.profit);
    return `${x},${y}`;
  }).join(' ');

  // SVG Area path for fill gradient
  const getAreaPath = (points: { x: number; y: number }[]) => {
    if (points.length === 0) return '';
    const first = points[0];
    const last = points[points.length - 1];
    let path = `M ${first.x} ${first.y} `;
    for (let i = 1; i < points.length; i++) {
      path += `L ${points[i].x} ${points[i].y} `;
    }
    path += `L ${last.x} ${height - paddingBottom} L ${first.x} ${height - paddingBottom} Z`;
    return path;
  };

  const revenueCoords = data.map((d, i) => getCoordinates(i, d.amount));
  const profitCoords = data.map((d, i) => getCoordinates(i, d.profit));

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  const formatDateLabel = (dateStr: string) => {
    const [_, month, day] = dateStr.split('-');
    if (!month || !day) return dateStr;
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[parseInt(month) - 1]} ${day}`;
  };

  return (
    <div className="relative w-full">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-200">Revenue & Profit Trend (Last 7 Days)</h4>
        <div className="flex space-x-4 text-xs font-medium">
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-3 rounded-full bg-blue-500 inline-block"></span>
            <span className="text-slate-600 dark:text-slate-300">Revenue</span>
          </div>
          <div className="flex items-center space-x-1.5">
            <span className="w-3 h-3 rounded-full bg-indigo-500 inline-block"></span>
            <span className="text-slate-600 dark:text-slate-300">Profit</span>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible">
          <defs>
            <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.0" />
            </linearGradient>
            <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#6366f1" stopOpacity="0.2" />
              <stop offset="100%" stopColor="#6366f1" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines & Y axis labels */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio, idx) => {
            const y = paddingTop + (1 - ratio) * chartHeight;
            const val = ratio * maxVal;
            return (
              <g key={idx} className="opacity-40">
                <line
                  x1={paddingLeft}
                  y1={y}
                  x2={width - paddingRight}
                  y2={y}
                  stroke="#e2e8f0"
                  strokeWidth="1"
                  strokeDasharray="4 4"
                />
                <text
                  x={paddingLeft - 8}
                  y={y + 4}
                  textAnchor="end"
                  className="fill-slate-400 font-mono text-[10px]"
                >
                  {formatCurrency(val)}
                </text>
              </g>
            );
          })}

          {/* X Axis line */}
          <line
            x1={paddingLeft}
            y1={height - paddingBottom}
            x2={width - paddingRight}
            y2={height - paddingBottom}
            stroke="#cbd5e1"
            strokeWidth="1.5"
          />

          {/* X axis labels */}
          {data.map((d, i) => {
            const { x } = getCoordinates(i, 0);
            return (
              <text
                key={i}
                x={x}
                y={height - paddingBottom + 20}
                textAnchor="middle"
                className="fill-slate-400 font-sans text-[10px]"
              >
                {formatDateLabel(d.date)}
              </text>
            );
          })}

          {/* Area under lines */}
          <path d={getAreaPath(revenueCoords)} fill="url(#revGrad)" />
          <path d={getAreaPath(profitCoords)} fill="url(#profitGrad)" />

          {/* Line paths */}
          <polyline
            fill="none"
            stroke="#3b82f6"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            points={revenuePointsStr}
          />
          <polyline
            fill="none"
            stroke="#6366f1"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            points={profitPointsStr}
          />

          {/* Interactive vertical hover lines and points */}
          {data.map((d, i) => {
            const rCoord = getCoordinates(i, d.amount);
            const pCoord = getCoordinates(i, d.profit);

            const isHovered = hoveredIndex === i;

            return (
              <g key={i} className="cursor-pointer">
                {/* Large transparent touch bar */}
                <rect
                  x={rCoord.x - (chartWidth / (data.length - 1)) / 2}
                  y={paddingTop}
                  width={chartWidth / (data.length - 1)}
                  height={chartHeight}
                  fill="transparent"
                  onMouseEnter={() => setHoveredIndex(i)}
                  onMouseLeave={() => setHoveredIndex(null)}
                />

                {isHovered && (
                  <>
                    <line
                      x1={rCoord.x}
                      y1={paddingTop}
                      x2={rCoord.x}
                      y2={height - paddingBottom}
                      stroke="#94a3b8"
                      strokeWidth="1.5"
                      strokeDasharray="2 2"
                    />
                    {/* Revenue dot */}
                    <circle cx={rCoord.x} cy={rCoord.y} r="6" fill="#3b82f6" stroke="#fff" strokeWidth="2" />
                    {/* Profit dot */}
                    <circle cx={pCoord.x} cy={pCoord.y} r="6" fill="#6366f1" stroke="#fff" strokeWidth="2" />
                  </>
                )}

                {/* Constant tiny markers */}
                {!isHovered && (
                  <>
                    <circle cx={rCoord.x} cy={rCoord.y} r="3" fill="#3b82f6" />
                    <circle cx={pCoord.x} cy={pCoord.y} r="3" fill="#6366f1" />
                  </>
                )}
              </g>
            );
          })}
        </svg>

        {/* Dynamic Tooltip rendering below chart for responsive reliability */}
        <div className="mt-2 min-h-12 border-t border-slate-50 dark:border-slate-800 pt-2 flex items-center justify-between text-xs text-slate-500">
          {hoveredIndex !== null ? (
            <>
              <div className="font-semibold text-slate-700 dark:text-slate-300">
                Date: {new Date(data[hoveredIndex].date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
              </div>
              <div className="flex space-x-4">
                <div>
                  Revenue:{' '}
                  <span className="font-semibold text-blue-600 dark:text-blue-400 font-mono">
                    {formatCurrency(data[hoveredIndex].amount)}
                  </span>
                </div>
                <div>
                  Net Profit:{' '}
                  <span className="font-semibold text-indigo-600 dark:text-indigo-400 font-mono">
                    {formatCurrency(data[hoveredIndex].profit)}
                  </span>
                </div>
              </div>
            </>
          ) : (
            <div className="italic text-slate-400 text-center w-full">
              Hover over the chart nodes to view exact values
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
