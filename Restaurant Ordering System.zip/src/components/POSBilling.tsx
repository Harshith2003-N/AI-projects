/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Plus, 
  CheckCircle, 
  Clock, 
  Trash2, 
  ClipboardList, 
  MapPin, 
  Utensils, 
  ShoppingBag, 
  CreditCard,
  ChefHat,
  Bell,
  XCircle,
  TrendingUp,
  PlusCircle,
  MinusCircle,
  UserPlus
} from 'lucide-react';
import { Order, OrderStatus, OrderType, MenuItem, User, PaymentMethod } from '../types';

interface KitchenOrdersProps {
  products: MenuItem[]; // Actually represents the Menu catalog
  onCheckout: (orderData: any) => Promise<any>; // Handler to place walk-in orders
}

// In App.tsx, the component is imported as POSBilling, but it acts as our Kitchen & Orders dashboard!
export default function POSBilling({ 
  products: menuItems, 
  onCheckout 
}: KitchenOrdersProps) {
  
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState<'ALL' | OrderStatus>('ALL');
  const [typeFilter, setTypeFilter] = useState<'ALL' | OrderType>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Walk-In Ordering state
  const [isNewOrderOpen, setIsNewOrderOpen] = useState(false);
  const [walkInName, setWalkInName] = useState('Walk-In Customer');
  const [walkInType, setWalkInType] = useState<OrderType>('dine-in');
  const [walkInTable, setWalkInTable] = useState('3');
  const [walkInCart, setWalkInCart] = useState<{ [id: string]: number }>({});
  const [walkInNotes, setWalkInNotes] = useState('');
  const [walkInPayment, setWalkInPayment] = useState<PaymentMethod>('cash');
  const [couponCode, setCouponCode] = useState('');

  // Fetch orders
  const fetchOrders = () => {
    setLoading(true);
    fetch('/api/orders', {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
    })
    .then(res => res.json())
    .then(data => {
      setOrders(Array.isArray(data) ? data : []);
    })
    .catch(err => console.error(err))
    .finally(() => setLoading(false));
  };

  // Initial fetch on load
  useEffect(() => {
    fetchOrders();
    // Poll every 6 seconds to simulate real-time updates!
    const timer = setInterval(fetchOrders, 6000);
    return () => clearInterval(timer);
  }, []);

  // Handle status transitions
  const handleUpdateStatus = (orderId: string, nextStatus: OrderStatus) => {
    fetch(`/api/orders/${orderId}/status`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ status: nextStatus })
    })
    .then(res => {
      if (res.ok) {
        fetchOrders();
      }
    });
  };

  // Mark payment as settled
  const handleSettlePayment = (orderId: string) => {
    fetch(`/api/orders/${orderId}/payment`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ paymentStatus: 'paid' })
    })
    .then(res => {
      if (res.ok) {
        fetchOrders();
      }
    });
  };

  // Walk-In Cart operations
  const addToWalkInCart = (itemId: string) => {
    const dish = menuItems.find(m => m.id === itemId);
    const stock = dish && dish.stock !== undefined ? dish.stock : 10;
    const currentQtyInCart = walkInCart[itemId] || 0;
    
    if (currentQtyInCart >= stock) {
      alert(`Cannot add more "${dish?.name}". Only ${stock} portions are available in stock.`);
      return;
    }

    setWalkInCart(prev => ({
      ...prev,
      [itemId]: currentQtyInCart + 1
    }));
  };

  const removeFromWalkInCart = (itemId: string) => {
    setWalkInCart(prev => {
      const copy = { ...prev };
      if (!copy[itemId]) return prev;
      if (copy[itemId] <= 1) {
        delete copy[itemId];
      } else {
        copy[itemId] -= 1;
      }
      return copy;
    });
  };

  // Calculations for Walk-In order
  const walkInCartArray = Object.entries(walkInCart).map(([id, qty]) => {
    const menuItem = menuItems.find(m => m.id === id);
    return { menuItem, quantity: qty };
  }).filter(c => c.menuItem !== undefined) as { menuItem: MenuItem; quantity: number }[];

  const subtotal = walkInCartArray.reduce((acc, c) => acc + (c.menuItem.price * c.quantity), 0);
  let discountAmount = 0;
  const cleanCoupon = couponCode.trim().toUpperCase();
  if (cleanCoupon === 'WELCOME10') {
    discountAmount = Math.round((subtotal * 0.1) * 100) / 100;
  } else if (cleanCoupon === 'BISTROLIFE') {
    discountAmount = Math.round((subtotal * 0.2) * 100) / 100;
  }
  const taxable = Math.max(0, subtotal - discountAmount);
  const taxAmount = Math.round((taxable * 0.08) * 100) / 100;
  const total = Math.round((taxable + taxAmount) * 100) / 100;

  // Submit Walk-In order
  const handlePlaceWalkInOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (walkInCartArray.length === 0) return;

    const orderData = {
      items: walkInCartArray.map(c => ({
        menuItemId: c.menuItem.id,
        quantity: c.quantity
      })),
      type: walkInType,
      tableNumber: walkInType === 'dine-in' ? Number(walkInTable) : undefined,
      discountCode: cleanCoupon || undefined,
      paymentMethod: walkInPayment,
      notes: walkInNotes,
      walkInCustomerName: walkInName
    };

    const res = await onCheckout(orderData);
    if (res) {
      setIsNewOrderOpen(false);
      setWalkInCart({});
      setWalkInNotes('');
      setCouponCode('');
      setWalkInName('Walk-In Customer');
      fetchOrders();
    }
  };

  // Filter orders lists
  const filteredOrders = orders.filter(o => {
    const matchesStatus = statusFilter === 'ALL' || o.status === statusFilter;
    const matchesType = typeFilter === 'ALL' || o.type === typeFilter;
    const matchesSearch = o.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          o.customerName.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesType && matchesSearch;
  });

  return (
    <div className="flex flex-col h-full overflow-hidden space-y-6">
      
      {/* Upper Action Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 p-5 rounded-3xl flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 shrink-0 shadow-xs">
        
        {/* Status filtering Tabs */}
        <div className="flex overflow-x-auto pb-1 md:pb-0 gap-1.5 scrollbar-none">
          {([
            { id: 'ALL', name: 'All Tickets' },
            { id: 'pending', name: 'Pending' },
            { id: 'preparing', name: 'Preparing' },
            { id: 'ready', name: 'Ready' },
            { id: 'delivered', name: 'Delivered' },
            { id: 'cancelled', name: 'Cancelled' },
          ] as { id: 'ALL' | OrderStatus; name: string }[]).map(tab => (
            <button
              key={tab.id}
              onClick={() => setStatusFilter(tab.id)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 border ${
                statusFilter === tab.id
                  ? 'bg-amber-500 border-amber-500 text-slate-950 shadow-sm'
                  : 'bg-slate-50 dark:bg-slate-950 border-slate-150 dark:border-slate-850 text-slate-500 dark:text-slate-400 hover:text-slate-850'
              }`}
            >
              {tab.name}
              {tab.id !== 'ALL' && (
                <span className="ml-1.5 px-1.5 py-0.5 rounded-md font-mono text-[9px] font-black bg-slate-950/10 dark:bg-white/10">
                  {orders.filter(o => o.status === tab.id).length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Order Taker button for staff */}
        <button
          onClick={() => setIsNewOrderOpen(true)}
          className="py-2.5 px-4 bg-slate-950 hover:bg-slate-850 dark:bg-amber-500 dark:hover:bg-amber-400 text-white dark:text-slate-950 text-xs font-black rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>New Walk-In Order</span>
        </button>

      </div>

      {/* Search and Service Type filter */}
      <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center shrink-0">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
          <input
            type="text"
            placeholder="Search live order tickets by number or customer..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-xs focus:outline-none"
          />
        </div>

        <select
          value={typeFilter}
          onChange={e => setTypeFilter(e.target.value as any)}
          className="px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-xs font-semibold focus:outline-none shrink-0"
        >
          <option value="ALL">All Service Types</option>
          <option value="dine-in">Dine-In Only</option>
          <option value="takeaway">Takeaway Only</option>
          <option value="delivery">Delivery Only</option>
        </select>
      </div>

      {/* Orders Board */}
      <div className="flex-1 overflow-y-auto pr-1">
        {filteredOrders.length === 0 ? (
          <div className="h-64 flex flex-col items-center justify-center text-slate-400">
            <ClipboardList className="w-12 h-12 text-slate-200 dark:text-slate-850 mb-2" />
            <p className="text-sm font-semibold">No active order tickets</p>
            <p className="text-xs">Adjust search filters or wait for new customer orders.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-12">
            {filteredOrders.map(order => {
              
              const isPending = order.status === 'pending';
              const isPreparing = order.status === 'preparing';
              const isReady = order.status === 'ready';
              const isDelivered = order.status === 'delivered';
              const isCancelled = order.status === 'cancelled';
              const isUnpaid = order.paymentStatus === 'pending';

              return (
                <div 
                  key={order.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-5 shadow-sm hover:shadow-md transition-all flex flex-col justify-between min-h-[340px]"
                >
                  {/* Ticket Header */}
                  <div>
                    <div className="flex justify-between items-start pb-3 border-b border-slate-100 dark:border-slate-850">
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 font-mono block">Order ID</span>
                        <span className="font-mono text-sm font-black text-slate-900 dark:text-white">
                          {order.orderNumber}
                        </span>
                      </div>
                      
                      {/* Ticket Status Badge */}
                      <span className={`px-2.5 py-0.5 rounded-lg text-[9px] font-black uppercase font-mono tracking-wider ${
                        isPending ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400' :
                        isPreparing ? 'bg-blue-100 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400' :
                        isReady ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400' :
                        isDelivered ? 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300' :
                        'bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-400'
                      }`}>
                        {order.status}
                      </span>
                    </div>

                    {/* Customer & Details */}
                    <div className="py-3.5 space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Customer</span>
                        <span className="font-bold text-slate-950 dark:text-white truncate max-w-[150px]">{order.customerName}</span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-slate-400">Service Type</span>
                        <span className="font-extrabold text-amber-500 uppercase flex items-center gap-1 text-[10px]">
                          {order.type === 'dine-in' && <Utensils className="w-3.5 h-3.5" />}
                          {order.type === 'takeaway' && <ShoppingBag className="w-3.5 h-3.5" />}
                          {order.type === 'delivery' && <MapPin className="w-3.5 h-3.5" />}
                          <span>
                            {order.type} {order.type === 'dine-in' ? `(Table ${order.tableNumber})` : ''}
                          </span>
                        </span>
                      </div>

                      {order.type === 'delivery' && order.deliveryAddress && (
                        <div className="bg-slate-50 dark:bg-slate-950 p-2 rounded-xl text-[10px] text-slate-500 flex gap-1 items-start leading-relaxed">
                          <MapPin className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                          <span className="line-clamp-2">{order.deliveryAddress}</span>
                        </div>
                      )}

                      {order.notes && (
                        <div className="p-2 bg-amber-500/5 border border-amber-500/10 rounded-xl text-[10px] text-slate-500 leading-relaxed italic">
                          "{order.notes}"
                        </div>
                      )}

                      {/* Items Ordered */}
                      <div className="pt-2">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Dishes ({order.items.length})</span>
                        <div className="space-y-1.5 max-h-24 overflow-y-auto pr-1">
                          {order.items.map((item, idx) => (
                            <div key={idx} className="flex justify-between text-xs pb-1 border-b border-slate-50 dark:border-slate-850 last:border-0 last:pb-0">
                              <span className="font-medium text-slate-700 dark:text-slate-300">
                                {item.quantity}x <strong className="font-bold text-slate-900 dark:text-white">{item.name}</strong>
                              </span>
                              <span className="font-mono text-slate-400">${item.subtotal.toFixed(2)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Pricing and Action buttons */}
                  <div className="pt-4 border-t border-slate-100 dark:border-slate-850">
                    <div className="flex justify-between items-center mb-4">
                      <div>
                        <span className="text-[9px] text-slate-400 uppercase tracking-wider font-bold block leading-none">Total Sales Bill</span>
                        <span className="font-mono font-black text-sm text-slate-950 dark:text-white">${order.total.toFixed(2)}</span>
                      </div>
                      
                      {/* Payment Status */}
                      <span className={`px-2 py-0.5 rounded-md font-mono text-[9px] font-black uppercase ${
                        order.paymentStatus === 'paid'
                          ? 'bg-emerald-500/15 text-emerald-500'
                          : 'bg-amber-500/15 text-amber-500'
                      }`}>
                        {order.paymentStatus} via {order.paymentMethod.toUpperCase()}
                      </span>
                    </div>

                    {/* Operational Action Controls */}
                    <div className="grid grid-cols-2 gap-2">
                      {isPending && (
                        <>
                          <button
                            onClick={() => handleUpdateStatus(order.id, 'preparing')}
                            className="py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-xl transition-all flex items-center justify-center gap-1"
                          >
                            <ChefHat className="w-3.5 h-3.5" />
                            <span>Start Cooking</span>
                          </button>
                          <button
                            onClick={() => handleUpdateStatus(order.id, 'cancelled')}
                            className="py-2.5 border border-slate-200 dark:border-slate-850 text-slate-400 hover:text-rose-500 hover:bg-rose-500/5 text-xs font-bold rounded-xl transition-all"
                          >
                            Cancel Ticket
                          </button>
                        </>
                      )}

                      {isPreparing && (
                        <>
                          <button
                            onClick={() => handleUpdateStatus(order.id, 'ready')}
                            className="py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-black rounded-xl transition-all flex items-center justify-center gap-1 col-span-2"
                          >
                            <CheckCircle className="w-3.5 h-3.5" />
                            <span>Ready for pickup/serve</span>
                          </button>
                        </>
                      )}

                      {isReady && (
                        <>
                          <button
                            onClick={() => handleUpdateStatus(order.id, 'delivered')}
                            className="py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black rounded-xl transition-all flex items-center justify-center gap-1"
                          >
                            <CheckCircle className="w-3.5 h-3.5" />
                            <span>Serve / Deliver</span>
                          </button>
                          {isUnpaid ? (
                            <button
                              onClick={() => handleSettlePayment(order.id)}
                              className="py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-xl transition-all"
                            >
                              Settle Cash
                            </button>
                          ) : (
                            <div className="flex items-center justify-center text-[10px] text-emerald-500 font-extrabold uppercase border border-emerald-500/10 rounded-xl">
                              Paid in Full
                            </div>
                          )}
                        </>
                      )}

                      {isDelivered && (
                        <div className="col-span-2 py-2 border border-slate-100 dark:border-slate-850 text-slate-400 text-center font-bold text-[10px] rounded-xl bg-slate-50/50 dark:bg-slate-950/20">
                          Completed Ticket Logged
                        </div>
                      )}

                      {isCancelled && (
                        <div className="col-span-2 py-2 border border-rose-500/15 text-rose-500 text-center font-bold text-[10px] rounded-xl bg-rose-500/[0.02]">
                          Ticket Cancelled
                        </div>
                      )}
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* New Walk-In Order Slide-out form for Staff/Admin */}
      {isNewOrderOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex justify-end z-50">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col justify-between">
            
            {/* Header */}
            <div className="p-6 border-b border-slate-100 dark:border-slate-850 flex items-center justify-between shrink-0">
              <h3 className="text-sm font-black uppercase tracking-wider text-slate-800 dark:text-white flex items-center gap-2">
                <Utensils className="w-5 h-5 text-amber-500" />
                <span>Create Walk-In / Phone Order</span>
              </h3>
              <button 
                onClick={() => setIsNewOrderOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-full transition-colors"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            {/* Content split */}
            <div className="flex-1 overflow-hidden flex">
              
              {/* Left Column: Menu Items Select list */}
              <div className="flex-1 overflow-y-auto p-6 border-r border-slate-100 dark:border-slate-850">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-3">Dishes Catalog</span>
                <div className="space-y-3">
                  {menuItems.filter(m => m.isAvailable).map(dish => {
                    const count = walkInCart[dish.id] || 0;
                    return (
                      <div key={dish.id} className="p-3 border border-slate-100 dark:border-slate-850 rounded-2xl flex gap-3 items-center hover:bg-slate-50 dark:hover:bg-slate-950/40">
                        <img 
                          src={dish.image} 
                          alt={dish.name}
                          referrerPolicy="no-referrer"
                          className="w-10 h-10 rounded-xl object-cover bg-slate-100 shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{dish.name}</p>
                          <div className="flex gap-2 items-center text-[10px] font-bold">
                            <span className="text-amber-500 font-mono">${dish.price.toFixed(2)}</span>
                            <span className="text-slate-400 font-mono">• {dish.stock !== undefined ? dish.stock : 10} in stock</span>
                          </div>
                        </div>

                        {count > 0 ? (
                          <div className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/15 p-0.5 rounded-lg">
                            <button 
                              onClick={() => removeFromWalkInCart(dish.id)}
                              className="w-6 h-6 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-md flex items-center justify-center text-xs"
                            >
                              -
                            </button>
                            <span className="font-mono text-xs w-5 text-center text-amber-500 font-black">{count}</span>
                            <button 
                              onClick={() => addToWalkInCart(dish.id)}
                              className="w-6 h-6 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-md flex items-center justify-center text-xs"
                            >
                              +
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => addToWalkInCart(dish.id)}
                            className="p-1.5 bg-slate-950 hover:bg-slate-850 dark:bg-slate-800 dark:hover:bg-slate-700 text-white rounded-lg"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Right Column: Ticket details checkout */}
              <div className="w-72 overflow-y-auto p-6 space-y-4">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Ticket Setup</span>
                
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 block font-bold">Customer Name</label>
                  <input 
                    type="text"
                    value={walkInName}
                    onChange={e => setWalkInName(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 block font-bold">Service Type</label>
                  <select 
                    value={walkInType}
                    onChange={e => setWalkInType(e.target.value as any)}
                    className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none"
                  >
                    <option value="dine-in">Dine-In (Table Service)</option>
                    <option value="takeaway">Takeaway (Pickup)</option>
                  </select>
                </div>

                {walkInType === 'dine-in' && (
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-400 block font-bold">Table Number</label>
                    <select 
                      value={walkInTable}
                      onChange={e => setWalkInTable(e.target.value)}
                      className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none"
                    >
                      {[1,2,3,4,5,6,7,8,9,10,12].map(num => (
                        <option key={num} value={num}>Table #{num}</option>
                      ))}
                    </select>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 block font-bold">Coupon Code</label>
                  <input 
                    type="text"
                    value={couponCode}
                    onChange={e => setCouponCode(e.target.value)}
                    placeholder="WELCOME10 (10%) or BISTROLIFE (20%)"
                    className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-[10px] focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 block font-bold">Payment Mode</label>
                  <select 
                    value={walkInPayment}
                    onChange={e => setWalkInPayment(e.target.value as any)}
                    className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none"
                  >
                    <option value="cash">Cash (Collect at end)</option>
                    <option value="card">Credit / Debit Card</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-400 block font-bold">Kitchen Instructions</label>
                  <textarea 
                    value={walkInNotes}
                    onChange={e => setWalkInNotes(e.target.value)}
                    placeholder="Extra spicy, no salt etc..."
                    rows={2}
                    className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:outline-none"
                  />
                </div>

              </div>

            </div>

            {/* Checkout Pricing footer */}
            <div className="p-6 border-t border-slate-100 dark:border-slate-850 bg-slate-50/50 dark:bg-slate-950/30 flex flex-col gap-3 shrink-0">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400 font-medium">Subtotal:</span>
                <span className="font-mono text-slate-700 dark:text-slate-300 font-bold">${subtotal.toFixed(2)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-xs text-emerald-500 font-bold">
                  <span>Discount:</span>
                  <span className="font-mono">-${discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-xs">
                <span className="text-slate-400 font-medium">Taxes (8%):</span>
                <span className="font-mono text-slate-700 dark:text-slate-300 font-bold">${taxAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm font-black pt-1 border-t border-slate-200 dark:border-slate-800">
                <span className="text-slate-950 dark:text-white uppercase tracking-wider text-xs">Grand Total:</span>
                <span className="font-mono text-amber-500 text-base font-black">${total.toFixed(2)}</span>
              </div>

              <button
                type="button"
                onClick={handlePlaceWalkInOrder}
                disabled={walkInCartArray.length === 0}
                className="w-full py-3.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 mt-2"
              >
                <ClipboardList className="w-4 h-4" />
                <span>Place Ticket Order</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
