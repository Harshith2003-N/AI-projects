/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { X, Sparkles, Utensils, Image as ImageIcon } from 'lucide-react';
import { MenuItem } from '../types';

interface MenuItemFormModalProps {
  product: any | null; // Represents the MenuItem to edit
  onClose: () => void;
  onSave: (dishData: any) => void;
}

const CATEGORIES = ['starters', 'mains', 'desserts', 'drinks'];

// Some elegant default stock food pictures for easy creation
const PRESET_IMAGES = [
  { label: 'Burger & Fries', url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80' },
  { label: 'Gourmet Pizza', url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80' },
  { label: 'Fresh Green Salad', url: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=600&q=80' },
  { label: 'Pasta Carbonara', url: 'https://images.unsplash.com/photo-1612874742237-6526221588e3?auto=format&fit=crop&w=600&q=80' },
  { label: 'Chocolate Lava Cake', url: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=600&q=80' },
  { label: 'Cool Iced Tea', url: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=600&q=80' }
];

export default function ProductFormModal({ product: menuItem, onClose, onSave }: MenuItemFormModalProps) {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('12.99');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('mains');
  const [prepTime, setPrepTime] = useState('15');
  const [image, setImage] = useState(PRESET_IMAGES[0].url);
  const [isAvailable, setIsAvailable] = useState(true);
  const [stock, setStock] = useState('10');
  const [threshold, setThreshold] = useState('3');
  const [error, setError] = useState('');

  useEffect(() => {
    if (menuItem) {
      setName(menuItem.name);
      setPrice(String(menuItem.price));
      setDescription(menuItem.description || '');
      setCategory(menuItem.category);
      setPrepTime(String(menuItem.prepTime || 15));
      setImage(menuItem.image || PRESET_IMAGES[0].url);
      setIsAvailable(menuItem.isAvailable !== false);
      setStock(String(menuItem.stock !== undefined ? menuItem.stock : 10));
      setThreshold(String(menuItem.threshold !== undefined ? menuItem.threshold : 3));
    }
  }, [menuItem]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) return setError('Dish name is required');
    if (isNaN(Number(price)) || Number(price) <= 0) return setError('Price must be a valid positive number');
    if (isNaN(Number(prepTime)) || Number(prepTime) < 1) return setError('Preparation time must be at least 1 minute');
    if (isNaN(Number(stock)) || Number(stock) < 0) return setError('Stock must be a non-negative number');
    if (isNaN(Number(threshold)) || Number(threshold) < 0) return setError('Threshold must be a non-negative number');
    if (!image.trim()) return setError('Image URL is required');

    onSave({
      id: menuItem?.id,
      name: name.trim(),
      price: Number(price),
      description: description.trim(),
      category,
      prepTime: Number(prepTime),
      image: image.trim(),
      isAvailable,
      stock: Number(stock),
      threshold: Number(threshold)
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-100 rounded-3xl shadow-2xl border border-slate-150 dark:border-slate-850 overflow-hidden my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50">
          <h3 className="text-sm font-extrabold uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-2">
            <Utensils className="w-5 h-5 text-amber-500" />
            <span>{menuItem ? 'Edit Culinary Dish' : 'Add New Menu Dish'}</span>
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 md:p-8 space-y-5 max-h-[75vh] overflow-y-auto text-xs font-semibold">
          {error && (
            <div className="p-2.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-100 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs font-semibold rounded-xl">
              {error}
            </div>
          )}

          <div className="space-y-4">
            
            {/* Name */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Dish Name</label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Traditional Margherita Pizza"
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* Category */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Menu Category</label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none uppercase text-[10px]"
                >
                  {CATEGORIES.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              {/* Price */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Price ($)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.1"
                  value={price}
                  onChange={e => setPrice(e.target.value)}
                  placeholder="12.99"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none font-mono"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* Preparation time */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Preparation Time (minutes)</label>
                <input
                  type="number"
                  min="1"
                  value={prepTime}
                  onChange={e => setPrepTime(e.target.value)}
                  placeholder="15"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none"
                  required
                />
              </div>

              {/* Availability Status */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Availability Status</label>
                <div className="flex items-center gap-2 h-9">
                  <input
                    type="checkbox"
                    id="isAvailable"
                    checked={isAvailable}
                    onChange={e => setIsAvailable(e.target.checked)}
                    className="w-4 h-4 text-amber-500 accent-amber-500 rounded cursor-pointer"
                  />
                  <label htmlFor="isAvailable" className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer select-none">
                    In Stock (Available)
                  </label>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* Stock Quantity */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Current Stock Quantity</label>
                <input
                  type="number"
                  min="0"
                  value={stock}
                  onChange={e => setStock(e.target.value)}
                  placeholder="10"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none font-mono"
                  required
                />
              </div>

              {/* Low Stock Threshold */}
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Low Stock Threshold</label>
                <input
                  type="number"
                  min="0"
                  value={threshold}
                  onChange={e => setThreshold(e.target.value)}
                  placeholder="3"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none font-mono"
                  required
                />
              </div>
            </div>

            {/* Image URL with preset helper chips */}
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Dish Image (URL)</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={image}
                  onChange={e => setImage(e.target.value)}
                  placeholder="Enter complete HTTP Unsplash/Image link..."
                  className="flex-1 px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none text-[10px]"
                  required
                />
              </div>
              
              {/* Preset recommendations */}
              <div>
                <span className="text-[9px] text-slate-400 font-bold block mb-1">Preset Food Stock Links:</span>
                <div className="flex flex-wrap gap-1">
                  {PRESET_IMAGES.map((preset, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setImage(preset.url)}
                      className={`px-2 py-1 rounded text-[9px] font-bold border transition-all ${
                        image === preset.url
                          ? 'bg-amber-500 border-amber-500 text-slate-950'
                          : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-1">
              <label className="text-[10px] uppercase tracking-wider text-slate-400 font-bold block">Dish Ingredients / Description</label>
              <textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="List ingredients, allergies, and rich description (e.g. Fresh basil, buffalo mozzarella, hand-stretched sourdough)"
                rows={3}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none"
              />
            </div>

          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-slate-700 dark:text-slate-450 text-xs font-black uppercase rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black uppercase rounded-xl shadow-md transition-all"
            >
              {menuItem ? 'Save Updates' : 'Add Dish'}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
