/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from 'react';
import { 
  Download, 
  TrendingUp, 
  DollarSign, 
  ShoppingBag, 
  Calendar,
  Layers,
  ArrowUpRight,
  FileSpreadsheet,
  Utensils,
  Sparkles,
  PieChart,
  Award
} from 'lucide-react';
import { MenuItem, Order } from '../types';

interface ReportsProps {
  sales: Order[]; // We pass in completed orders to analyze
  products: MenuItem[]; // Menu dishes
}

export default function Reports({ sales: orders, products: dishes }: ReportsProps) {
  const [timeFilter, setTimeFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');

  // 1. Filter orders based on selected timeframe
  const filteredOrders = orders.filter(o => {
    if (o.status === 'cancelled') return false; // Ignore cancelled tickets in financial calculations
    
    const orderDate = new Date(o.date || Date.now());
    const now = new Date();
    
    if (timeFilter === 'today') {
      return orderDate.toDateString() === now.toDateString();
    } else if (timeFilter === 'week') {
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(now.getDate() - 7);
      return orderDate >= oneWeekAgo;
    } else if (timeFilter === 'month') {
      const oneMonthAgo = new Date();
      oneMonthAgo.setMonth(now.getMonth() - 1);
      return orderDate >= oneMonthAgo;
    }
    return true; // All
  });

  // Calculate Metrics
  const totalRevenue = filteredOrders.reduce((sum, o) => sum + o.total, 0);
  const transactionsCount = filteredOrders.length;
  const avgTicketSize = transactionsCount > 0 ? totalRevenue / transactionsCount : 0;
  
  // Simulated Ingredient and Food/Beverage COGS (approx 32% of retail price)
  const estimatedCOGS = totalRevenue * 0.32;
  const grossProfit = totalRevenue - estimatedCOGS;
  const grossMarginPercentage = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;

  // Breakdown by Service Type (dine-in, takeaway, delivery)
  const typeBreakdown = filteredOrders.reduce((acc, o) => {
    acc[o.type] = (acc[o.type] || 0) + o.total;
    return acc;
  }, { 'dine-in': 0, 'takeaway': 0, 'delivery': 0 } as Record<string, number>);

  // Compute popular dishes analytics
  const popularDishes = useMemo(() => {
    const dishStats: Record<string, { name: string; category: string; qty: number; rev: number }> = {};
    
    filteredOrders.forEach(o => {
      o.items.forEach(it => {
        const itemKey = it.name;
        if (!dishStats[itemKey]) {
          dishStats[itemKey] = {
            name: it.name,
            category: dishes.find(d => d.name === it.name)?.category || 'mains',
            qty: 0,
            rev: 0
          };
        }
        dishStats[itemKey].qty += it.quantity;
        dishStats[itemKey].rev += it.subtotal;
      });
    });

    const sorted = Object.values(dishStats)
      .sort((a, b) => b.qty - a.qty)
      .slice(0, 6); // Top 6 popular dishes

    return sorted.map(s => ({
      name: s.name,
      category: s.category,
      quantity: s.qty,
      revenue: s.rev
    }));
  }, [filteredOrders, dishes]);

  // Export spreadsheet files from the server
  const handleExport = (type: 'sales' | 'menu') => {
    const link = document.createElement('a');
    link.href = `/api/reports/export/${type}`;
    link.setAttribute('download', `${type}_bistro_report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Simulated Weekly chart points for nice visual SVG curve
  const chartPoints = [
    { label: 'Mon', sales: Math.round(totalRevenue * 0.12) },
    { label: 'Tue', sales: Math.round(totalRevenue * 0.08) },
    { label: 'Wed', sales: Math.round(totalRevenue * 0.11) },
    { label: 'Thu', sales: Math.round(totalRevenue * 0.15) },
    { label: 'Fri', sales: Math.round(totalRevenue * 0.22) },
    { label: 'Sat', sales: Math.round(totalRevenue * 0.20) },
    { label: 'Sun', sales: Math.round(totalRevenue * 0.12) },
  ];
  const maxVal = Math.max(...chartPoints.map(p => p.sales), 100);

  return (
    <div className="space-y-6 flex flex-col h-full overflow-hidden">
      
      {/* Exporters and control panel */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 p-5 bg-white dark:bg-slate-900 border border-slate-250 dark:border-slate-850 rounded-3xl shadow-sm shrink-0">
        <div className="space-y-0.5">
          <h3 className="text-sm font-extrabold text-slate-800 dark:text-slate-100 uppercase tracking-wider flex items-center gap-2">
            <PieChart className="w-5 h-5 text-amber-500" />
            <span>Restaurant Performance Ledger</span>
          </h3>
          <p className="text-xs text-slate-400">Review business metrics, popular culinary analysis, and download audit sheets.</p>
        </div>

        {/* Date Filters */}
        <div className="flex border border-slate-200 dark:border-slate-800 rounded-xl p-0.5 bg-slate-50 dark:bg-slate-950 self-start sm:self-auto">
          {(['all', 'today', 'week', 'month'] as const).map(f => (
            <button
              key={f}
              onClick={() => setTimeFilter(f)}
              className={`px-3.5 py-1.5 rounded-lg text-[10px] uppercase tracking-wider font-extrabold transition-all ${
                timeFilter === f
                  ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                  : 'text-slate-500 hover:text-slate-800 dark:hover:text-white'
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        
        {/* CSV Export buttons */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={() => handleExport('sales')}
            className="px-3.5 py-2 border border-slate-200 dark:border-slate-800 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-950 text-[11px] font-bold text-slate-700 dark:text-slate-300 transition-all flex items-center gap-1.5"
          >
            <Download className="w-4 h-4 text-amber-500" />
            <span>Sales CSV</span>
          </button>

          <button
            onClick={() => handleExport('menu')}
            className="px-3.5 py-2 border border-slate-200 dark:border-slate-800 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-950 text-[11px] font-bold text-slate-700 dark:text-slate-300 transition-all flex items-center gap-1.5"
          >
            <FileSpreadsheet className="w-4 h-4 text-amber-500" />
            <span>Menu CSV</span>
          </button>
        </div>
      </div>

      {/* Financial Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 shrink-0">
        
        {/* Total Revenues */}
        <div className="bg-slate-950 text-white rounded-3xl p-5 relative overflow-hidden border border-slate-850 shadow-md">
          <div className="absolute -bottom-6 -right-6 opacity-5 pointer-events-none">
            <DollarSign className="w-32 h-32 text-amber-500" />
          </div>
          <span className="text-[10px] font-bold text-amber-500 uppercase tracking-widest block mb-1">Gross Billing Yield</span>
          <span className="text-2xl font-black font-mono leading-none text-white">
            ${totalRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
          <div className="mt-4 flex justify-between text-[10px] text-slate-400">
            <span>Orders served</span>
            <span className="font-mono font-black text-amber-500">{transactionsCount} bills</span>
          </div>
        </div>

        {/* Food & Beverage COGS */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-5 shadow-xs">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Est. Recipe COGS (32%)</span>
              <span className="text-xl font-bold font-mono text-slate-800 dark:text-slate-100">
                ${estimatedCOGS.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4 text-[10px] text-slate-400 flex justify-between">
            <span>COGS Margin Ratio</span>
            <span className="font-mono text-rose-500">Industry Standard</span>
          </div>
        </div>

        {/* Net Profit Margin */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-5 shadow-xs">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Net Operating Margin</span>
              <span className="text-xl font-bold font-mono text-emerald-500">
                ${grossProfit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-500">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4 flex justify-between text-[10px] text-slate-400">
            <span>Profit Margin Ratio</span>
            <span className="font-mono font-bold text-emerald-500">
              {grossMarginPercentage.toFixed(1)}% <ArrowUpRight className="w-3 h-3 inline" />
            </span>
          </div>
        </div>

        {/* Avg Ticket size */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-5 shadow-xs">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Avg. Ticket Ticket Size</span>
              <span className="text-xl font-bold font-mono text-amber-500">
                ${avgTicketSize.toFixed(2)}
              </span>
            </div>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-500">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4 flex justify-between text-[10px] text-slate-400">
            <span>Per Walk-In / Delivery</span>
            <span className="font-mono font-bold text-slate-500">Average billing</span>
          </div>
        </div>

      </div>

      {/* Analytical Layout: Left Popular Dishes, Right Sales Trends & Delivery breakdown */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 overflow-hidden min-h-0">
        
        {/* LEFT: Top popular dishes list (2 cols width on large screen) */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl flex flex-col min-h-0 shadow-xs">
          <div className="p-5 border-b border-slate-100 dark:border-slate-850 flex items-center justify-between shrink-0 bg-slate-50/50 dark:bg-slate-950/20">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-amber-500" />
              <span>Popular Dishes Analytical Ranking</span>
            </h4>
            <span className="text-[10px] font-bold text-slate-400">Sort by Order Vol.</span>
          </div>

          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {popularDishes.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center">
                <Utensils className="w-10 h-10 text-slate-200 mb-2" />
                <p className="text-xs font-semibold">No food sales tracked yet</p>
                <p className="text-[10px] text-slate-500">Complete customer order billing to start logging trends.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {popularDishes.map((dish, idx) => (
                  <div key={idx} className="p-4 border border-slate-100 dark:border-slate-850 rounded-2xl flex items-center justify-between hover:bg-slate-50/50 dark:hover:bg-slate-950/20 transition-all">
                    <div className="flex items-center gap-3 min-w-0">
                      {/* Rank Indicator */}
                      <span className="w-6 h-6 rounded-lg bg-amber-500/10 text-amber-500 font-mono font-black text-xs flex items-center justify-center shrink-0">
                        #{idx + 1}
                      </span>
                      <div className="min-w-0">
                        <span className="font-extrabold text-sm text-slate-900 dark:text-white block truncate">
                          {dish.name}
                        </span>
                        <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-slate-400 bg-slate-100 dark:bg-slate-950 px-2 py-0.5 rounded">
                          {dish.category}
                        </span>
                      </div>
                    </div>

                    <div className="flex gap-6 items-center font-mono shrink-0 text-right">
                      <div>
                        <span className="text-[9px] text-slate-400 block font-bold">QTY SOLD</span>
                        <span className="text-xs font-extrabold text-slate-800 dark:text-slate-200">{dish.quantity} units</span>
                      </div>
                      <div>
                        <span className="text-[9px] text-slate-400 block font-bold">REVENUE</span>
                        <span className="text-xs font-black text-amber-500">${dish.revenue.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* RIGHT: Trends and Mode Breakdown */}
        <div className="space-y-6 flex flex-col min-h-0">
          
          {/* Service Mode Breakdown ratios */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-5 shadow-xs flex flex-col justify-between shrink-0">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-4 flex items-center gap-1">
              <Utensils className="w-4 h-4 text-amber-500" />
              <span>Service Mode Volumes</span>
            </h4>
            
            <div className="space-y-4">
              {/* Dine-In ratio */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-500">Dine-In Table Services</span>
                  <span className="font-mono text-slate-800 dark:text-slate-300">${typeBreakdown['dine-in'].toFixed(2)}</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-amber-500 h-full rounded-full transition-all duration-500" 
                    style={{ width: `${totalRevenue > 0 ? (typeBreakdown['dine-in'] / totalRevenue) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>

              {/* Delivery ratio */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-500">Delivery Orders</span>
                  <span className="font-mono text-slate-800 dark:text-slate-300">${typeBreakdown['delivery'].toFixed(2)}</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-sky-500 h-full rounded-full transition-all duration-500" 
                    style={{ width: `${totalRevenue > 0 ? (typeBreakdown['delivery'] / totalRevenue) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>

              {/* Takeaway ratio */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span className="text-slate-500">Takeaway Pickups</span>
                  <span className="font-mono text-slate-800 dark:text-slate-300">${typeBreakdown['takeaway'].toFixed(2)}</span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div 
                    className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                    style={{ width: `${totalRevenue > 0 ? (typeBreakdown['takeaway'] / totalRevenue) * 100 : 0}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>

          {/* Graphical vector curve for trend aesthetics */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-3xl p-5 shadow-xs flex-1 flex flex-col justify-between">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1">
              <TrendingUp className="w-4 h-4 text-amber-500" />
              <span>Weekly Yield Analytics</span>
            </h4>
            
            {/* SVG Visual Graphic */}
            <div className="flex-1 flex items-end justify-between h-24 pt-4 px-2 gap-2">
              {chartPoints.map((pt, idx) => {
                const barHeightPct = Math.max(10, Math.min(100, (pt.sales / maxVal) * 100));
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group cursor-pointer">
                    <div className="text-[8px] font-mono font-bold text-amber-500 opacity-0 group-hover:opacity-100 transition-opacity">
                      ${pt.sales}
                    </div>
                    <div 
                      className="w-full bg-slate-100 dark:bg-slate-800 group-hover:bg-amber-500 transition-all rounded-md"
                      style={{ height: `${barHeightPct}%` }}
                    ></div>
                    <span className="text-[10px] font-bold text-slate-400 font-sans uppercase">
                      {pt.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
