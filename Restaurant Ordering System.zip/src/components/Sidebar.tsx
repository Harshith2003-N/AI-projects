/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  Utensils, 
  ClipboardList, 
  Users, 
  TrendingUp, 
  LogOut, 
  User as UserIcon,
  Bell,
  Sparkles,
  ShoppingBag
} from 'lucide-react';
import { User } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  user: User;
  onLogout: () => void;
  unreadCount: number;
  onOpenNotifications: () => void;
}

export default function Sidebar({ 
  activeTab, 
  setActiveTab, 
  user, 
  onLogout, 
  unreadCount,
  onOpenNotifications 
}: SidebarProps) {
  
  // Define tabs for each role
  const navItems = [
    // Admin tabs
    { id: 'dashboard', name: 'Dashboard', icon: TrendingUp, roles: ['admin'] },
    { id: 'menu', name: 'Menu Management', icon: Utensils, roles: ['admin', 'staff', 'customer'] },
    { id: 'orders', name: 'Kitchen & Orders', icon: ClipboardList, roles: ['admin', 'staff'] },
    { id: 'staff', name: 'Staff Management', icon: Users, roles: ['admin'] },
    
    // Customer tabs
    { id: 'customer-orders', name: 'My Orders', icon: ShoppingBag, roles: ['customer'] },
    { id: 'profile', name: 'My Profile', icon: UserIcon, roles: ['customer', 'admin', 'staff'] },
  ];

  const filteredNavItems = navItems.filter(item => item.roles.includes(user.role));

  return (
    <aside className="w-64 bg-slate-900 text-slate-100 flex flex-col h-screen border-r border-slate-800 shrink-0">
      
      {/* Brand logo */}
      <div className="p-8 flex items-center gap-3 select-none">
        <div className="w-9 h-9 bg-amber-500 rounded-xl flex items-center justify-center shadow-lg shadow-amber-500/20">
          <Utensils className="w-5 h-5 text-slate-950" />
        </div>
        <div>
          <span className="font-black text-white tracking-tight text-lg block leading-none">Bistro Guru</span>
          <span className="text-[10px] text-amber-500 uppercase tracking-widest font-mono font-bold">Smart Ordering</span>
        </div>
      </div>

      {/* Navigation list */}
      <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
        {filteredNavItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-item-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                isActive 
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/10' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-slate-950' : 'text-slate-400'}`} />
              <span>{item.name}</span>
            </button>
          );
        })}

        {/* Notifications Shortcut Trigger */}
        <button
          onClick={onOpenNotifications}
          className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm font-semibold text-slate-400 hover:text-white hover:bg-slate-800/50 transition-colors text-left"
        >
          <div className="flex items-center space-x-3">
            <Bell className="w-4 h-4 text-slate-400" />
            <span>Alerts & Logs</span>
          </div>
          {unreadCount > 0 && (
            <span className="bg-rose-500 text-white font-mono text-[10px] font-bold px-2 py-0.5 rounded-full leading-none">
              {unreadCount}
            </span>
          )}
        </button>
      </nav>

      {/* User profile brief card */}
      <div className="p-6 border-t border-slate-800 flex flex-col space-y-4">
        
        {/* Loyalty points card for customers */}
        {user.role === 'customer' && (
          <div className="bg-slate-950/50 border border-slate-800 p-3.5 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-slate-300">Bistro Points</span>
            </div>
            <span className="text-sm font-mono font-black text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg">
              {user.loyaltyPoints || 0}
            </span>
          </div>
        )}

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-500/10 text-amber-500 rounded-xl border border-amber-500/20 flex items-center justify-center font-bold text-sm uppercase shrink-0">
            {user.name.slice(0, 2)}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-bold text-white truncate">{user.name}</p>
            <span className="text-[9px] px-2 py-0.5 rounded-md font-mono font-extrabold uppercase tracking-widest bg-slate-800 text-slate-300">
              {user.role}
            </span>
          </div>
        </div>

        <button
          onClick={onLogout}
          className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-bold text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-all border border-transparent hover:border-rose-500/20"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </button>
      </div>

    </aside>
  );
}
