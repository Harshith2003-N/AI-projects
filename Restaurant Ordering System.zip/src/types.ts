/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'admin' | 'staff' | 'customer';

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  email: string;
  phone?: string;
  address?: string;
  loyaltyPoints?: number;
}

export type MenuCategory = 'starters' | 'mains' | 'desserts' | 'drinks';

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: MenuCategory;
  isAvailable: boolean;
  image: string;
  prepTime: number; // in minutes
  stock: number;
  threshold: number;
}

export type OrderType = 'dine-in' | 'takeaway' | 'delivery';
export type OrderStatus = 'pending' | 'preparing' | 'ready' | 'delivered' | 'cancelled';
export type PaymentMethod = 'cash' | 'card' | 'wallet';
export type PaymentStatus = 'pending' | 'paid';

export interface OrderItem {
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
  subtotal: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  date: string;
  customerId: string;
  customerName: string;
  items: OrderItem[];
  subtotal: number;
  discountCode?: string;
  discountAmount: number;
  taxAmount: number;
  total: number;
  type: OrderType;
  tableNumber?: number; // only for dine-in
  deliveryAddress?: string; // only for delivery
  status: OrderStatus;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  earnedPoints: number;
  notes?: string;
}

export interface Notification {
  id: string;
  message: string;
  timestamp: string;
  read: boolean;
  recipientRole?: UserRole | 'all';
}

export interface DashboardStats {
  totalSales: number;
  totalOrders: number;
  completedOrdersCount: number;
  activeOrdersCount: number;
  averageOrderValue: number;
  popularDishes: { name: string; quantity: number; revenue: number }[];
  salesByDate: { date: string; amount: number; count: number }[];
  ordersByType: { type: string; value: number }[];
  ordersByStatus: { status: string; value: number }[];
}
