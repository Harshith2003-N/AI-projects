# Enterprise AI-Powered Code Review Assistant

Welcome to the **AI-Powered Code Review Assistant**—a production-grade, enterprise static code analysis, security auditing, and design refactoring microservice. 

This platform connects directly to your software repositories, parses AST structures, and leverages high-performance AI engines (**Gemini 3.5 Flash**) with guaranteed JSON schema structures to flag security breaches (OWASP Top 10), performance leaks, overbroad locks, resource leaks, and violations of clean code.

---

## 🏗️ Clean Architectural Design (Microservice Layout)

The backend is built following **Clean Architecture** patterns in **Java 21** and **Spring Boot 3.2.4**, enforcing strict separation of concerns, high scalability, stateless REST transactions, and distributed caching.

```text
com.codereview.assistant
 │
 ├── config                 # Security Filters, Redis configurations, and Cryptography
 │    ├── SecurityConfig.java         # Stateful JWT security filters
 │    ├── JwtAuthenticationFilter.java# Intercepts Bearer header keys
 │    └── JwtTokenProvider.java       # HS256 JWT claim encryption provider
 │
 ├── model                  # Domain Layer Database Entities
 │    ├── User.java                   # User registration roles (USER, ADMIN)
 │    ├── Repository.java             # Connected source control indicators
 │    └── CodeReview.java             # Saved static report JSONB states
 │
 ├── repository             # Relational Database Access Layer (Spring Data JPA)
 │    ├── UserRepository.java
 │    ├── RepositoryRepository.java
 │    └── CodeReviewRepository.java
 │
 ├── service                # Business Logic Core Orchestration Layer
 │    ├── AiReviewService.java        # Gemini API orchestrator with forced JSON Schemas
 │    └── GithubService.java          # Source tree pull integration service
 │
 └── controller             # Interface Presentation REST API Controllers
      ├── AuthController.java        # Registers & Authenticates JWT sessions
      ├── RepositoryController.java  # Maps branches and connected repos
      └── ReviewController.java      # Triggers static audit analyze requests
```

---

## 🗄️ Relational Database Schema (PostgreSQL)

Our database architecture uses optimized Postgres tables with high-speed indexes and `JSONB` structures to record static analysis findings.

```sql
-- Create Repositories Indexer
CREATE TABLE repositories (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    owner VARCHAR(255) NOT NULL,
    description TEXT,
    language VARCHAR(100),
    score INT DEFAULT 100,
    connected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_owner_repo UNIQUE (owner, name)
);

-- Indexing connected repos
CREATE INDEX idx_repositories_owner_name ON repositories(owner, name);

-- Create Code Reviews Table (Leverages JSONB for fast indexing)
CREATE TABLE code_reviews (
    id UUID PRIMARY KEY,
    repository_id UUID REFERENCES repositories(id) ON DELETE CASCADE,
    file_path VARCHAR(512) NOT NULL,
    branch VARCHAR(100) NOT NULL,
    score INT NOT NULL,
    summary TEXT,
    vulnerabilities JSONB,
    performance JSONB,
    code_smells JSONB,
    best_practices JSONB,
    reviewed_by VARCHAR(255),
    reviewed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_code_reviews_repo_id ON code_reviews(repository_id);
CREATE INDEX idx_code_reviews_score ON code_reviews(score);
-- GIN Index for rapid scanning inside JSON array blocks
CREATE INDEX idx_code_reviews_vulnerabilities ON code_reviews USING gin (vulnerabilities);
```

---

## 🔌 API Documentation (REST Specs)

All API request and response bodies utilize raw application JSON types. Authorization is enforced using the HTTP `Authorization: Bearer <JWT_TOKEN>` header.

### 1. Identity Provisioning (`POST /api/auth/register`)
- **Payload**:
  ```json
  {
    "email": "developer@company.com",
    "password": "S3cr3tPassword!",
    "name": "Alex Codecraft"
  }
  ```
- **Response** (Status `201 Created`):
  ```json
  {
    "token": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJkZXZlbG9wZX...",
    "user": {
      "id": 1,
      "email": "developer@company.com",
      "name": "Alex Codecraft",
      "role": "USER"
    }
  }
  ```

### 2. Static Code Analysis (`POST /api/reviews/analyze`)
- **Payload**:
  ```json
  {
    "code": "public class db { String pass = 'root'; }",
    "filePath": "src/main/java/com/payment/Db.java",
    "branch": "feature/security-audit"
  }
  ```
- **Response** (Status `200 OK`):
  ```json
  {
    "reviewId": "f784e883-fa4c-47fc-b514-69db3fa1a942",
    "score": 68,
    "summary": "Direct hardcoded credential constants detected. Structural code smells exist.",
    "vulnerabilities": [
      {
        "severity": "HIGH",
        "title": "Hardcoded Credentials",
        "line": 1,
        "description": "Sensitive credentials leaked in raw constants.",
        "fix": "Extract to secure properties: @Value(\"${database.password}\")"
      }
    ],
    "performance": [],
    "codeSmells": [],
    "bestPractices": []
  }
  ```

---

## 🧠 AI Static Analysis & Gemini Prompt Mapping

To secure typed output bounds, the platform coordinates with **Gemini 3.5 Flash** using advanced JSON Schema enforcement parameters.

### Systems Context Map
The AI static analysis core injects specialized prompts:
```text
SYSTEM INSTRUCTION:
You are an elite Staff Software Engineer, SecOps Lead, and Static Analysis Architect.
Perform an extremely rigorous code quality, security vulnerability, performance optimization, best practices, and code smell review.
Analyze the provided code and output a valid JSON report following the requested schema.
Be extremely objective. Only find real issues.
```

### Response Scheme Schema Configurations
```json
{
  "type": "OBJECT",
  "properties": {
    "score": { "type": "INTEGER", "description": "0 to 100 quality indicator" },
    "summary": { "type": "STRING" },
    "vulnerabilities": {
      "type": "ARRAY",
      "items": {
        "type": "OBJECT",
        "properties": {
          "severity": { "type": "STRING", "description": "HIGH, MEDIUM, or LOW" },
          "title": { "type": "STRING" },
          "line": { "type": "INTEGER" },
          "description": { "type": "STRING" },
          "fix": { "type": "STRING" }
        }
      }
    }
  }
}
```

---

## 🐳 Containerized Production Deployments (Docker)

To deploy the entire, isolated database, cache cluster, and Spring Boot application stack in a single command, execute the container orchestrations.

### 1. Build and Run Local Stack
Ensure your workspace includes the Docker runtime and run:
```bash
# Navigate to the backend folder
cd backend

# Boot PostgreSQL, Redis cache, and compile Java container from source
docker-compose up -d --build
```

### 2. Verify Container Health status
```bash
# Show container lists
docker-compose ps

# Monitor microservice logs
docker-compose logs -f backend-service
```

---

## 🧪 Spring Unit Verification Tests (Mockito / JUnit 5)

All code review engines are covered under test assertions verifying graceful timeouts and fallback rules mappings:

```bash
# Execute local unit tests inside Maven container
mvn test
```

---

## 🚀 CI/CD Pipeline (GitHub Actions Workflows)

The continuous integration pipeline is pre-configured inside `/.github/workflows/ci-cd.yml` supporting:
- Multi-tier Java 21 compilation and unit verification.
- TypeScript compilation and React static bundle verification.
- Automated security audits of Maven dependencies.
- Production multi-stage Docker image builds with publishing triggers to GitHub Container Registry (`ghcr.io`).
