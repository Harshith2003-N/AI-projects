package com.codereview.assistant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * AI Code Review Assistant Spring Boot Microservice Application Entry Point.
 * Enables high-performance asynchronous AI reviews and Redis distributed caching.
 */
@SpringBootApplication
@EnableAsync
@EnableCaching
public class CodeReviewAssistantApplication {

    public static void main(String[] args) {
        SpringApplication.run(CodeReviewAssistantApplication.class, args);
    }
}
