package com.codereview.assistant.controller;

import com.codereview.assistant.model.CodeReview;
import com.codereview.assistant.model.Repository;
import com.codereview.assistant.service.AiReviewService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    private final AiReviewService aiReviewService;

    public ReviewController(AiReviewService aiReviewService) {
        this.aiReviewService = aiReviewService;
    }

    @PostMapping("/analyze")
    public ResponseEntity<Map<String, Object>> analyzeCode(@RequestBody Map<String, String> request) {
        String code = request.get("code");
        String filePath = request.getOrDefault("filePath", "custom-upload.java");
        String branch = request.getOrDefault("branch", "main");

        if (code == null || code.trim().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Source code is empty or missing."));
        }

        // Mock repo setup for inline review requests
        Repository repo = Repository.builder()
                .name("inline-pasted-repo")
                .owner("developer")
                .description("Direct code snippet analysis")
                .language("Java")
                .score(100)
                .build();

        CodeReview review = aiReviewService.executeAnalysis(code, filePath, branch, repo);

        Map<String, Object> response = new HashMap<>();
        response.put("reviewId", review.getId());
        response.put("score", review.getScore());
        response.put("summary", review.getSummary());
        response.put("vulnerabilities", review.getVulnerabilities());
        response.put("performance", review.getPerformance());
        response.put("codeSmells", review.getCodeSmells());
        response.put("bestPractices", review.getBestPractices());
        response.put("reviewedBy", review.getReviewedBy());

        return ResponseEntity.ok(response);
    }
}
