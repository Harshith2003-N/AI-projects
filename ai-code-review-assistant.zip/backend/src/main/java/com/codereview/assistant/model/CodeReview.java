package com.codereview.assistant.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "code_reviews")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CodeReview {

    @Id
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "repository_id")
    private Repository repository;

    @Column(name = "file_path", nullable = false)
    private String filePath;

    @Column(nullable = false)
    private String branch;

    @Column(nullable = false)
    private Integer score;

    @Column(columnDefinition = "TEXT")
    private String summary;

    @Column(columnDefinition = "JSONB")
    private String vulnerabilities;

    @Column(columnDefinition = "JSONB")
    private String performance;

    @Column(name = "code_smells", columnDefinition = "JSONB")
    private String codeSmells;

    @Column(name = "best_practices", columnDefinition = "JSONB")
    private String bestPractices;

    @Column(name = "reviewed_by")
    private String reviewedBy;

    @Column(name = "reviewed_at")
    private LocalDateTime reviewedAt;

    @PrePersist
    protected void onReview() {
        id = UUID.randomUUID();
        reviewedAt = LocalDateTime.now();
    }
}
