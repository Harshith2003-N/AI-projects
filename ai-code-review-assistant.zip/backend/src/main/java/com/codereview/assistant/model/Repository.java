package com.codereview.assistant.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "repositories")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Repository {

    @Id
    private UUID id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String owner;

    private String description;

    private String language;

    @Column(name = "default_branch")
    private String defaultBranch;

    private Integer score;

    @Column(name = "connected_at")
    private LocalDateTime connectedAt;

    @PrePersist
    protected void onConnect() {
        id = UUID.randomUUID();
        connectedAt = LocalDateTime.now();
        if (score == null) score = 100;
    }
}
