package com.codereview.assistant.service;

import com.codereview.assistant.model.CodeReview;
import com.codereview.assistant.model.Repository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class AiReviewService {

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    @Value("${app.ai.gemini.api-key}")
    private String apiKey;

    @Value("${app.ai.gemini.endpoint-url}")
    private String endpointUrl;

    @Value("${app.ai.gemini.model}")
    private String modelName;

    public AiReviewService(RestTemplateBuilder restTemplateBuilder, ObjectMapper objectMapper) {
        this.restTemplate = restTemplateBuilder
                .setConnectTimeout(Duration.ofSeconds(15))
                .setReadTimeout(Duration.ofSeconds(60))
                .build();
        this.objectMapper = objectMapper;
    }

    public CodeReview executeAnalysis(String sourceCode, String filePath, String branch, Repository repository) {
        String prompt = buildPrompt(sourceCode, filePath, branch);
        
        try {
            // Real API invocation flow to Gemini v1beta REST endpoints
            String requestUrl = String.format("%s/%s:generateContent?key=%s", endpointUrl, modelName, apiKey);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            // Constructing request payload matching @google/genai structured outputs
            Map<String, Object> textPart = new HashMap<>();
            textPart.put("text", prompt);

            Map<String, Object> parts = new HashMap<>();
            parts.put("parts", List.of(textPart));

            Map<String, Object> contents = new HashMap<>();
            contents.put("contents", List.of(parts));

            // Request json schemas for guaranteed outputs
            Map<String, Object> responseSchema = buildJsonSchemaConfig();
            
            Map<String, Object> config = new HashMap<>();
            config.put("responseMimeType", "application/json");
            config.put("responseSchema", responseSchema);
            
            contents.put("config", config);

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(contents, headers);
            ResponseEntity<String> responseEntity = restTemplate.postForEntity(requestUrl, request, String.class);

            if (responseEntity.getStatusCode() == HttpStatus.OK && responseEntity.getBody() != null) {
                return parseAiResponse(responseEntity.getBody(), repository, filePath, branch);
            }
        } catch (Exception e) {
            // Fallback to static fallback simulator in case of API outages or unconfigured environment keys
            return executeFallbackAnalysis(sourceCode, filePath, branch, repository);
        }

        return executeFallbackAnalysis(sourceCode, filePath, branch, repository);
    }

    private String buildPrompt(String code, String path, String branch) {
        return """
                Perform static code quality, performance optimization, best practices, and security vulnerability review for the provided code.
                File Name: %s
                Branch Context: %s
                Code:
                %s
                """.formatted(path, branch, code);
    }

    private Map<String, Object> buildJsonSchemaConfig() {
        // Construct schema to force Gemini structured JSON reports
        Map<String, Object> schema = new HashMap<>();
        schema.put("type", "OBJECT");
        
        Map<String, Object> props = new HashMap<>();
        props.put("score", Map.of("type", "INTEGER", "description", "0 to 100"));
        props.put("summary", Map.of("type", "STRING"));
        props.put("vulnerabilities", Map.of("type", "ARRAY", "items", Map.of("type", "OBJECT", "properties", Map.of(
                "severity", Map.of("type", "STRING"),
                "title", Map.of("type", "STRING"),
                "line", Map.of("type", "INTEGER"),
                "description", Map.of("type", "STRING"),
                "fix", Map.of("type", "STRING")
        ))));
        props.put("performance", Map.of("type", "ARRAY", "items", Map.of("type", "OBJECT", "properties", Map.of(
                "title", Map.of("type", "STRING"),
                "line", Map.of("type", "INTEGER"),
                "description", Map.of("type", "STRING"),
                "fix", Map.of("type", "STRING")
        ))));
        props.put("codeSmells", Map.of("type", "ARRAY", "items", Map.of("type", "OBJECT", "properties", Map.of(
                "title", Map.of("type", "STRING"),
                "line", Map.of("type", "INTEGER"),
                "description", Map.of("type", "STRING"),
                "fix", Map.of("type", "STRING")
        ))));
        props.put("bestPractices", Map.of("type", "ARRAY", "items", Map.of("type", "OBJECT", "properties", Map.of(
                "title", Map.of("type", "STRING"),
                "line", Map.of("type", "INTEGER"),
                "description", Map.of("type", "STRING"),
                "fix", Map.of("type", "STRING")
        ))));

        schema.put("properties", props);
        return schema;
    }

    @SuppressWarnings("unchecked")
    private CodeReview parseAiResponse(String rawJson, Repository repo, String filePath, String branch) throws Exception {
        Map<String, Object> responseMap = objectMapper.readValue(rawJson, Map.class);
        
        // Extract content from candidates[0].content.parts[0].text
        List<Map<String, Object>> candidates = (List<Map<String, Object>>) responseMap.get("candidates");
        Map<String, Object> content = (Map<String, Object>) candidates.getFirst().get("content");
        List<Map<String, Object>> parts = (List<Map<String, Object>>) content.get("parts");
        String textReport = (String) parts.getFirst().get("text");

        Map<String, Object> report = objectMapper.readValue(textReport, Map.class);

        return CodeReview.builder()
                .repository(repo)
                .filePath(filePath)
                .branch(branch)
                .score((Integer) report.get("score"))
                .summary((String) report.get("summary"))
                .vulnerabilities(objectMapper.writeValueAsString(report.get("vulnerabilities")))
                .performance(objectMapper.writeValueAsString(report.get("performance")))
                .codeSmells(objectMapper.writeValueAsString(report.get("codeSmells")))
                .bestPractices(objectMapper.writeValueAsString(report.get("bestPractices")))
                .reviewedBy("Gemini Core Reviewer")
                .build();
    }

    private CodeReview executeFallbackAnalysis(String code, String path, String branch, Repository repo) {
        // Fallback rule analyzer to secure platform execution when keys are unconfigured
        int score = 85;
        String summary = "Analyzing code file statically. Quality is generally fine, but structural design could be optimized.";
        
        if (code.contains("DriverManager") || code.contains("Connection")) {
            score = 65;
            summary = "Critical warning: Raw JDBC management identified instead of DataSource pools. Potential SQL Injection risk.";
        }

        return CodeReview.builder()
                .repository(repo)
                .filePath(path)
                .branch(branch)
                .score(score)
                .summary(summary)
                .vulnerabilities("[]")
                .performance("[]")
                .codeSmells("[]")
                .bestPractices("[]")
                .reviewedBy("AI Local Rule Fallback Engine")
                .build();
    }
}
