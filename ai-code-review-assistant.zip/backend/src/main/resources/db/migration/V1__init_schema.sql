-- AI Code Review Assistant Schema Initialization

-- Create Users table
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'USER',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Index user emails
CREATE INDEX idx_users_email ON users(email);

-- Create Repositories table
CREATE TABLE repositories (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    owner VARCHAR(255) NOT NULL,
    description TEXT,
    language VARCHAR(100),
    default_branch VARCHAR(100) DEFAULT 'main',
    score INT DEFAULT 100,
    connected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_owner_repo UNIQUE (owner, name)
);

-- Index repository owners and language
CREATE INDEX idx_repositories_owner_name ON repositories(owner, name);
CREATE INDEX idx_repositories_language ON repositories(language);

-- Create Code Reviews table
CREATE TABLE code_reviews (
    id UUID PRIMARY KEY,
    repository_id UUID REFERENCES repositories(id) ON DELETE CASCADE,
    file_path VARCHAR(512) NOT NULL,
    branch VARCHAR(100) NOT NULL,
    score INT NOT NULL,
    summary TEXT,
    vulnerabilities JSONB,
    performance JSONB,
    code_smells JSONB,
    best_practices JSONB,
    reviewed_by VARCHAR(255),
    reviewed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Index code reviews for rapid analytical history lookups
CREATE INDEX idx_code_reviews_repo_id ON code_reviews(repository_id);
CREATE INDEX idx_code_reviews_score ON code_reviews(score);
CREATE INDEX idx_code_reviews_vulnerabilities ON code_reviews USING gin (vulnerabilities);

-- Create Audit Logs table for security and usage compliance
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY,
    user_email VARCHAR(255) NOT NULL,
    action VARCHAR(255) NOT NULL,
    details TEXT,
    request_ip VARCHAR(100),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_logs_user ON audit_logs(user_email);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp);
