package com.codereview.assistant.service;

import com.codereview.assistant.model.CodeReview;
import com.codereview.assistant.model.Repository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class AiReviewServiceTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private RestTemplateBuilder restTemplateBuilder;

    @Mock
    private ObjectMapper objectMapper;

    private AiReviewService aiReviewService;
    private Repository testRepository;

    @BeforeEach
    void setUp() {
        Mockito.when(restTemplateBuilder.setConnectTimeout(Mockito.any())).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.setReadTimeout(Mockito.any())).thenReturn(restTemplateBuilder);
        Mockito.when(restTemplateBuilder.build()).thenReturn(restTemplate);
        
        aiReviewService = new AiReviewService(restTemplateBuilder, objectMapper);
        
        testRepository = Repository.builder()
                .id(UUID.randomUUID())
                .name("test-repo")
                .owner("enterprise")
                .description("Unit Testing repository")
                .language("Java")
                .score(100)
                .build();
    }

    @Test
    void testExecuteAnalysisWithApiFailureFallsBackGracefully() {
        String badCode = "public class BadCode { private String pass = \"abc\"; }";
        
        // This will throw exception inside REST call (since URL/credentials are mocked/empty)
        // verify that the fallback system executes successfully and outputs a valid report
        CodeReview result = aiReviewService.executeAnalysis(badCode, "BadCode.java", "main", testRepository);
        
        assertNotNull(result);
        assertEquals("AI Local Rule Fallback Engine", result.getReviewedBy());
        assertTrue(result.getScore() <= 100);
        assertNotNull(result.getSummary());
        assertEquals("[]", result.getVulnerabilities());
    }

    @Test
    void testExecuteAnalysisDetectsBadConnectionPatternsInFallback() {
        String jdbcCode = "Connection conn = DriverManager.getConnection(url, user, pass);";
        
        CodeReview result = aiReviewService.executeAnalysis(jdbcCode, "JdbcSample.java", "main", testRepository);
        
        assertNotNull(result);
        assertEquals(65, result.getScore());
        assertTrue(result.getSummary().contains("JDBC"));
    }
}
