import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini API client lazily and safely
  let aiClient: GoogleGenAI | null = null;
  function getAiClient(): GoogleGenAI {
    if (!aiClient) {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        console.warn("GEMINI_API_KEY is not defined. AI features will fallback to simulation mode.");
      }
      aiClient = new GoogleGenAI({
        apiKey: apiKey || "MOCK_KEY",
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
    return aiClient;
  }

  // --- Mock Database In-Memory ---
  const users = [
    { id: 1, email: "admin@company.com", password: "password123", role: "ADMIN", name: "Senior Architect" },
    { id: 2, email: "developer@company.com", password: "password123", role: "USER", name: "Alex Codecraft" }
  ];

  const repositories = [
    {
      id: "spring-boot-api",
      name: "spring-boot-microservice",
      owner: "enterprise-org",
      description: "Spring Boot 3 Core Payment Microservice",
      language: "Java",
      defaultBranch: "main",
      branches: ["main", "feature/jwt-auth", "feature/redis-cache"],
      score: 74,
      files: [
        {
          path: "src/main/java/com/payment/service/PaymentService.java",
          content: `package com.payment.service;

import org.springframework.stereotype.Service;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

@Service
public class PaymentService {

    // Technical Debt & Security issue: hardcoded credentials and SQL Injection vulnerability
    private String dbUrl = "jdbc:postgresql://localhost:5432/payment_db";
    private String dbUser = "prod_admin";
    private String dbPass = "S3cr3tP@ssw0rd!";

    public double getAccountBalance(String accountId) {
        double balance = 0.0;
        try {
            // Unsecured connection creation inside method (bad practice, should use DataSource/ConnectionPool)
            Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
            Statement stmt = conn.createStatement();
            
            // SQL Injection vulnerability
            String query = "SELECT balance FROM accounts WHERE id = '" + accountId + "'";
            ResultSet rs = stmt.executeQuery(query);
            
            if (rs.next()) {
                balance = rs.getDouble("balance");
            }
            
            // Resource Leak: Connections, Statements, ResultSets not closed in finally block!
        } catch (Exception e) {
            e.printStackTrace(); // Bad practice: using printStackTrace instead of professional logging
        }
        return balance;
    }

    public synchronized void processTransaction(String fromId, String toId, double amount) {
        // Performance Smell: synchronized method blocks entire throughput. 
        // Better to use pessimistic locking or database transactions.
        try {
            Thread.sleep(500); // Artificial delay simulating heavy IO
        } catch (InterruptedException e) {}
        System.out.println("Processed transaction of " + amount + " from " + fromId + " to " + toId);
    }
}`
        },
        {
          path: "src/main/java/com/payment/config/JwtAuthenticationFilter.java",
          content: `package com.payment.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.filter.OncePerRequestFilter;

public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) {
        String authHeader = request.getHeader("Authorization");
        
        // Critical Vulnerability: Weak or missing verification
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            
            // SECURITY SMELL: Trusting token signature without real cryptographic signature validation
            if (token.contains("admin")) {
                // Instantly grants admin access by parsing plaintext string
                System.out.println("Mock auth success: User is admin");
            }
        }
        
        try {
            filterChain.doFilter(request, response);
        } catch (Exception e) {
            // Empty catch block - silently swallowing critical security exceptions!
        }
    }
}`
        }
      ]
    },
    {
      id: "react-dashboard",
      name: "developer-portal-ui",
      owner: "enterprise-org",
      description: "React and Tailwind CSS Developer Dashboard",
      language: "TypeScript",
      defaultBranch: "main",
      branches: ["main", "dev", "release/v1.0"],
      score: 88,
      files: [
        {
          path: "src/components/UserDashboard.tsx",
          content: `import React, { useEffect, useState } from 'react';

export default function UserDashboard() {
  const [data, setData] = useState<any>(null);
  
  // Bug/Performance issue: infinite render loop if state set inside hook without guards, 
  // or missing correct dependencies in dependency array.
  useEffect(() => {
    const fetchData = async () => {
      const res = await fetch('https://api.company.com/v1/metrics');
      const json = await res.json();
      setData(json);
    };
    fetchData();
  }); // Omitted empty dependency array! Will execute on EVERY single render!

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Metrics Dashboard</h1>
      {/* Danger: potential XSS if using raw dangerousHTML with user input */}
      <div dangerouslySetInnerHTML={{ __html: data?.description || '<p>Loading...</p>' }} />
      
      {/* Non-semantic button without keyboard accessibility or type */}
      <div 
        onClick={() => {
          localStorage.setItem("session_token", "unencrypted_sensitive_api_secret_token_abc123");
        }} 
        className="bg-blue-500 text-white p-2 rounded cursor-pointer text-center"
      >
        Store Session Token (Local Storage Vulnerability)
      </div>
    </div>
  );
}`
        }
      ]
    }
  ];

  const reviewHistory: any[] = [];
  
  // Initialize some historical audits
  reviewHistory.push({
    id: "rev-101",
    repositoryId: "spring-boot-api",
    repositoryName: "spring-boot-microservice",
    filePath: "src/main/java/com/payment/service/PaymentService.java",
    branch: "main",
    reviewer: "AI Review Engine",
    date: "2026-07-14T08:30:00-07:00",
    score: 62,
    summary: "The code contains several critical issues including severe SQL Injection, plain-text credentials exposure, resource leaks, and multithreading performance bottlenecks.",
    vulnerabilities: [
      {
        severity: "HIGH",
        title: "SQL Injection Vulnerability",
        line: 27,
        description: "The parameter 'accountId' is directly concatenated into a raw SQL statement inside Statement.executeQuery(). Attackers can manipulate this query to bypass authentication or extract arbitrary database contents.",
        fix: "Use NamedParameterJdbcTemplate or PreparedStatements with positional parameter placeholders (e.g. SELECT balance FROM accounts WHERE id = ?)."
      },
      {
        severity: "HIGH",
        title: "Hardcoded Admin Credentials",
        line: 14,
        description: "Sensitive database username 'prod_admin' and password 'S3cr3tP@ssw0rd!' are hardcoded in plain-text directly inside the source code.",
        fix: "Extract credentials to environment variables or Spring configuration files, injection-secured using Spring Vault or AWS Secrets Manager. Set in application.yml as: password: ${DB_PASSWORD}."
      }
    ],
    performance: [
      {
        title: "Database Connection Instantiated in Local Method",
        line: 21,
        description: "The connection is created via DriverManager.getConnection on every invocation. This causes heavy TCP handshake overhead, killing application performance.",
        fix: "Inject a connection pooled javax.sql.DataSource (like HikariCP) into the service."
      },
      {
        title: "Overbroad Synchronized Method",
        line: 39,
        description: "Synchronizing the entire processTransaction method enforces single-threaded bottlenecks across all incoming transaction HTTP threads.",
        fix: "Remove synchronized and leverage atomic database operations or transaction bounds (@Transactional with appropriate isolation levels)."
      }
    ],
    codeSmells: [
      {
        title: "Resource Leak: JDBC resources not closed",
        line: 21,
        description: "Connection, Statement, and ResultSet are not closed inside a finally block or using Java's Try-With-Resources. Under peak load, this will exhaust database connection pools.",
        fix: "Refactor to use standard Java 7+ Try-with-resources syntax: try (Connection conn = DriverManager.getConnection(...)) { ... }"
      }
    ],
    bestPractices: [
      {
        title: "Use of printStackTrace()",
        line: 34,
        description: "Calling e.printStackTrace() writes to standard error but bypasses logback/SLF4J configuration, which is unprofessional and leads to disk-space filling issues in cloud native clusters.",
        fix: "Use an injected Logger instance: private static final Logger log = LoggerFactory.getLogger(PaymentService.class); ... log.error('Failed to get balance', e);"
      }
    ]
  });

  // Track API Usage Metrics
  const apiMetrics = {
    requestsTotal: 42,
    tokensPrompt: 145200,
    tokensResponse: 38400,
    costEstimated: 0.1146,
    dailyUsage: [
      { date: "07/10", prompt: 18000, response: 4200, requests: 5 },
      { date: "07/11", prompt: 25000, response: 6100, requests: 8 },
      { date: "07/12", prompt: 32000, response: 8400, requests: 10 },
      { date: "07/13", prompt: 41000, response: 11200, requests: 12 },
      { date: "07/14", prompt: 29200, response: 8500, requests: 7 },
    ]
  };

  // --- API Routes ---

  // Auth
  app.post("/api/auth/register", (req, res) => {
    const { email, password, name } = req.body;
    if (!email || !password || !name) {
      return res.status(400).json({ error: "Missing required registration parameters." });
    }
    if (users.some(u => u.email === email)) {
      return res.status(400).json({ error: "Email address already registered." });
    }
    const newUser = { id: users.length + 1, email, password, role: "USER", name };
    users.push(newUser);
    res.status(201).json({
      token: `jwt-mock-token-${Date.now()}`,
      user: { id: newUser.id, email: newUser.email, name: newUser.name, role: newUser.role }
    });
  });

  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    const user = users.find(u => u.email === email && u.password === password);
    if (!user) {
      return res.status(401).json({ error: "Invalid email or password credentials." });
    }
    res.json({
      token: `jwt-mock-token-${Date.now()}`,
      user: { id: user.id, email: user.email, name: user.name, role: user.role }
    });
  });

  // Repositories
  app.get("/api/repositories", (req, res) => {
    res.json(repositories);
  });

  app.post("/api/repositories", (req, res) => {
    const { owner, name, description, language } = req.body;
    if (!owner || !name) {
      return res.status(400).json({ error: "Owner and Name are required to connect repository." });
    }
    const newRepo = {
      id: `${owner}-${name}`.toLowerCase().replace(/[^a-z0-9-]/g, "-"),
      name,
      owner,
      description: description || "Imported Code Repository",
      language: language || "JavaScript",
      defaultBranch: "main",
      branches: ["main", "dev"],
      score: 100, // Starts at 100 before any reviews
      files: [
        {
          path: "index.js",
          content: `// Sample entrypoint file
function calculateSum(a, b) {
  // TODO: Fix this potential bug where b is string
  return a + b;
}
console.log(calculateSum(10, "5"));`
        }
      ]
    };
    repositories.push(newRepo);
    res.status(201).json(newRepo);
  });

  // Get repository branches
  app.get("/api/repositories/:id/branches", (req, res) => {
    const repo = repositories.find(r => r.id === req.params.id);
    if (!repo) return res.status(404).json({ error: "Repository not found." });
    res.json(repo.branches);
  });

  // Get files inside branch (mocked structure)
  app.get("/api/repositories/:id/files", (req, res) => {
    const repo = repositories.find(r => r.id === req.params.id);
    if (!repo) return res.status(404).json({ error: "Repository not found." });
    res.json(repo.files.map(f => f.path));
  });

  // Add custom file to repository
  app.post("/api/repositories/:id/files", (req, res) => {
    const repo = repositories.find(r => r.id === req.params.id);
    if (!repo) return res.status(404).json({ error: "Repository not found." });
    const { path: filePath, content } = req.body;
    if (!filePath || !content) return res.status(400).json({ error: "Path and Content are required." });
    
    const existingFile = repo.files.find(f => f.path === filePath);
    if (existingFile) {
      existingFile.content = content;
    } else {
      repo.files.push({ path: filePath, content });
    }
    res.json({ message: "File created/updated successfully." });
  });

  // Get single file content
  app.get("/api/repositories/:id/file-content", (req, res) => {
    const repo = repositories.find(r => r.id === req.params.id);
    if (!repo) return res.status(404).json({ error: "Repository not found." });
    const filePath = req.query.path as string;
    const file = repo.files.find(f => f.path === filePath);
    if (!file) return res.status(404).json({ error: "File not found." });
    res.json({ content: file.content });
  });

  // Get Review History
  app.get("/api/reviews", (req, res) => {
    res.json(reviewHistory);
  });

  // Core Endpoint: PERFORM AI CODE REVIEW USING GEMINI API
  app.post("/api/review", async (req, res) => {
    const { code, repositoryId, filePath, branch, language } = req.body;
    if (!code) {
      return res.status(400).json({ error: "No source code provided for analysis." });
    }

    try {
      const apiKey = process.env.GEMINI_API_KEY;
      
      // If API key is available, run actual analysis!
      if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
        const client = getAiClient();
        
        const systemPrompt = `You are an elite Staff Software Engineer, SecOps Lead, and Static Analysis Architect.
Perform an extremely rigorous code quality, security vulnerability, performance optimization, best practices, and code smell review.
Analyze the provided code and output a valid JSON report following the requested schema.
Be extremely objective. Only find real issues.
Return the exact JSON containing code quality score, high-level summary, vulnerabilities (HIGH/MEDIUM/LOW), performance issues, code smells, and best practices.`;

        const userPrompt = `Language: ${language || "Auto-detect"}
File Path: ${filePath || "Inline Code"}
Branch: ${branch || "main"}

Analyze the following source code:
\`\`\`
${code}
\`\`\`

Return a strictly validated JSON response adhering to this format:
{
  "score": 0 to 100 (where 100 is flawless and 0 has fatal security issues),
  "summary": "High-level visual summary explaining the architectural quality, key issues found, and general feedback.",
  "vulnerabilities": [
    {
      "severity": "HIGH" | "MEDIUM" | "LOW",
      "title": "Short title",
      "line": line_number,
      "description": "Explaining the concrete danger",
      "fix": "Corrected code block or remediation"
    }
  ],
  "performance": [
    {
      "title": "Short title",
      "line": line_number,
      "description": "Detailing the performance overhead",
      "fix": "Optimized block or strategy"
    }
  ],
  "codeSmells": [
    {
      "title": "Short title",
      "line": line_number,
      "description": "What violates clean code/SOLID",
      "fix": "Refactoring recommendation"
    }
  ],
  "bestPractices": [
    {
      "title": "Short title",
      "line": line_number,
      "description": "Standard guideline violation",
      "fix": "Standard compliant approach"
    }
  ]
}`;

        console.log("Calling Gemini API for review...");
        const response = await client.models.generateContent({
          model: "gemini-3.5-flash",
          contents: userPrompt,
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                score: { type: Type.INTEGER },
                summary: { type: Type.STRING },
                vulnerabilities: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      severity: { type: Type.STRING },
                      title: { type: Type.STRING },
                      line: { type: Type.INTEGER },
                      description: { type: Type.STRING },
                      fix: { type: Type.STRING }
                    },
                    required: ["severity", "title", "description", "fix"]
                  }
                },
                performance: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      line: { type: Type.INTEGER },
                      description: { type: Type.STRING },
                      fix: { type: Type.STRING }
                    },
                    required: ["title", "description", "fix"]
                  }
                },
                codeSmells: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      line: { type: Type.INTEGER },
                      description: { type: Type.STRING },
                      fix: { type: Type.STRING }
                    },
                    required: ["title", "description", "fix"]
                  }
                },
                bestPractices: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      title: { type: Type.STRING },
                      line: { type: Type.INTEGER },
                      description: { type: Type.STRING },
                      fix: { type: Type.STRING }
                    },
                    required: ["title", "description", "fix"]
                  }
                }
              },
              required: ["score", "summary", "vulnerabilities", "performance", "codeSmells", "bestPractices"]
            }
          }
        });

        const textResponse = response.text;
        if (!textResponse) {
          throw new Error("No response received from Gemini engine.");
        }

        const report = JSON.parse(textResponse.trim());
        
        // Track stats
        apiMetrics.requestsTotal += 1;
        apiMetrics.tokensPrompt += 1800; // estimated
        apiMetrics.tokensResponse += 600; // estimated
        apiMetrics.costEstimated += 0.003; // estimated cost in $
        apiMetrics.dailyUsage[apiMetrics.dailyUsage.length - 1].requests += 1;
        apiMetrics.dailyUsage[apiMetrics.dailyUsage.length - 1].prompt += 1800;
        apiMetrics.dailyUsage[apiMetrics.dailyUsage.length - 1].response += 600;

        const finalReview = {
          id: `rev-${Date.now().toString().slice(-4)}`,
          repositoryId: repositoryId || "custom-upload",
          repositoryName: repositoryId ? (repositories.find(r => r.id === repositoryId)?.name || "custom-repo") : "Custom Upload",
          filePath: filePath || "custom-code",
          branch: branch || "main",
          reviewer: "AI Review Engine",
          date: new Date().toISOString(),
          ...report
        };

        // Add to history
        reviewHistory.unshift(finalReview);

        // If repository is selected, update its score
        if (repositoryId) {
          const repoIdx = repositories.findIndex(r => r.id === repositoryId);
          if (repoIdx !== -1) {
            repositories[repoIdx].score = report.score;
          }
        }

        return res.json(finalReview);
      } else {
        // FALLBACK: Simulate code review with professional insights if API is offline/key missing
        console.log("Simulating code review (Gemini API key not configured or fallback)...");
        
        // Let's inspect the code string briefly to tailor the simulated response to the input
        let score = 85;
        let summary = "Static analysis suggests code structure is acceptable, but identifies areas for modular refactoring, null safety, and clean practice adjustments.";
        const vulnerabilities: any[] = [];
        const performance: any[] = [];
        const codeSmells: any[] = [];
        const bestPractices: any[] = [];

        if (code.includes("Connection") || code.includes("DriverManager") || code.includes("SELECT")) {
          // Seems like Java JDBC database connection
          score = 64;
          summary = "Critical issues identified regarding database connection lifecycles, credentials configuration, and potential injection breaches.";
          vulnerabilities.push({
            severity: "HIGH",
            title: "Concatenated SQL Parameters (SQL Injection)",
            line: 18,
            description: "Direct string concatenation detected within database execute statement. This allows database execution parameters manipulation by injection vectors.",
            fix: "PreparedStatement pstmt = conn.prepareStatement(\"SELECT balance FROM accounts WHERE id = ?\");\npstmt.setString(1, accountId);"
          });
          vulnerabilities.push({
            severity: "MEDIUM",
            title: "Hardcoded Credentials Leak",
            line: 11,
            description: "Database parameters such as root passwords and administrative accounts are configured as plain-text constants inside class fields.",
            fix: "Extract secrets to secure environment variables, injected dynamically at startup."
          });
          performance.push({
            title: "In-Method Database Connection Instantiation",
            line: 15,
            description: "Establishing a new physical connection per balance request degrades database throughout and escalates container socket consumption.",
            fix: "Configure an HikariCP or HikariDataSource Connection Pool at the application tier."
          });
          codeSmells.push({
            title: "Swallowed or Swell JDBC Resource Cleanup",
            line: 30,
            description: "Resources like ResultSet, Statements and Connection are handled in raw statements without secure Try-With-Resources cleanup blocks.",
            fix: "try (Connection conn = dataSource.getConnection();\n     PreparedStatement ps = conn.prepareStatement(...)) {\n    ...\n}"
          });
        } else if (code.includes("useEffect") || code.includes("useState")) {
          // React file
          score = 72;
          summary = "The React component includes state mutations inside hooks that lack dependency declaration arrays, causing rendering loops.";
          performance.push({
            title: "Omitted useEffect Dependency Array",
            line: 10,
            description: "The useEffect hook does not specify a dependency array, triggering full API network requests on every re-render.",
            fix: "Add an empty dependency array `[]` to execute solely once at component mount, or pass tracked state variables."
          });
          vulnerabilities.push({
            severity: "MEDIUM",
            title: "Unencrypted Client Storage",
            line: 22,
            description: "Sensitive auth tokens or sessions are committed to local browser localStorage, rendering them vulnerable to cross-site scripting (XSS) extraction.",
            fix: "Set user credentials inside HttpOnly cookie scopes with Secure flags."
          });
          codeSmells.push({
            title: "Raw InnerHTML Rendering",
            line: 15,
            description: "Rendering data dynamically from non-validated origins using dangerouslySetInnerHTML exposes users to persistent script injection.",
            fix: "Use standard text components or process incoming HTML using a sanitizer like DOMPurify."
          });
        } else {
          // General template review
          score = 79;
          summary = "The submitted source code represents basic core logic. Main recommendations center on error governance, defensive bounds checking, and code readability optimizations.";
          codeSmells.push({
            title: "Omitted Error Bounds Validation",
            line: 4,
            description: "Incoming arguments are evaluated without pre-validation guards, exposing the runtime to potential null reference or indexing errors.",
            fix: "Add defensive guards check at method entry boundaries."
          });
          bestPractices.push({
            title: "Implicit Console Statement Logs",
            line: 8,
            description: "Usage of console.log inside application modules should be replaced with professional multi-level application loggers.",
            fix: "Inject and invoke standard Winston, Logback or Slf4j logs structures."
          });
        }

        const mockReview = {
          id: `rev-${Date.now().toString().slice(-4)}`,
          repositoryId: repositoryId || "custom-upload",
          repositoryName: repositoryId ? (repositories.find(r => r.id === repositoryId)?.name || "custom-repo") : "Custom Upload",
          filePath: filePath || "custom-code",
          branch: branch || "main",
          reviewer: "AI Simulation Engine",
          date: new Date().toISOString(),
          score,
          summary,
          vulnerabilities,
          performance,
          codeSmells,
          bestPractices
        };

        // Add to history
        reviewHistory.unshift(mockReview);

        if (repositoryId) {
          const repoIdx = repositories.findIndex(r => r.id === repositoryId);
          if (repoIdx !== -1) {
            repositories[repoIdx].score = score;
          }
        }

        res.json(mockReview);
      }
    } catch (err: any) {
      console.error("AI Code Review Error:", err);
      res.status(500).json({ error: err.message || "An error occurred during AI static analysis code review." });
    }
  });

  // Admin Stats
  app.get("/api/admin/stats", (req, res) => {
    res.json({
      metrics: apiMetrics,
      users: users.map(u => ({ id: u.id, name: u.name, email: u.email, role: u.role })),
      reviewsCount: reviewHistory.length
    });
  });

  // Admin User delete / update
  app.delete("/api/admin/users/:id", (req, res) => {
    const id = parseInt(req.params.id);
    const index = users.findIndex(u => u.id === id);
    if (index === -1) return res.status(404).json({ error: "User not found." });
    users.splice(index, 1);
    res.json({ message: "User deleted successfully." });
  });

  // --- Vite & Production Static Routing Middleware ---

  if (process.env.NODE_ENV !== "production") {
    console.log("Injecting Vite middleware for development");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Serving static production build from /dist");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start Full Stack Dev Server:", err);
});
