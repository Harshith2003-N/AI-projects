import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldAlert,
  CheckCircle,
  TrendingUp,
  GitBranch,
  Code2,
  Database,
  Cpu,
  Layers,
  Settings,
  LogOut,
  Plus,
  Trash2,
  Play,
  Copy,
  FileText,
  RefreshCw,
  User,
  Users,
  BarChart3,
  ArrowRight,
  Lock,
  Terminal,
  Server,
  Zap,
  Info,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Award
} from "lucide-react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { blueprints, Blueprint } from "./blueprints";
import { Repository, CodeReview, Vulnerability, IssueItem, User as AppUser, AdminStats } from "./types";

export default function App() {
  // --- Active Application States ---
  const [activeTab, setActiveTab] = useState<"dashboard" | "studio" | "architecture" | "admin">("dashboard");
  const [currentUser, setCurrentUser] = useState<AppUser | null>({
    id: 2,
    name: "Alex Codecraft",
    email: "developer@company.com",
    role: "USER"
  });

  // Auth screen state
  const [isLoginView, setIsLoginView] = useState(true);
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authName, setAuthName] = useState("");
  const [authError, setAuthError] = useState("");

  // Repository states
  const [repos, setRepos] = useState<Repository[]>([]);
  const [selectedRepoId, setSelectedRepoId] = useState<string>("");
  const [selectedBranch, setSelectedBranch] = useState<string>("main");
  const [branches, setBranches] = useState<string[]>([]);
  const [repoFiles, setRepoFiles] = useState<string[]>([]);
  const [selectedFile, setSelectedFile] = useState<string>("");

  // Code Input States
  const [editorCode, setEditorCode] = useState<string>("");
  const [editorLanguage, setEditorLanguage] = useState<string>("java");
  const [customFilePath, setCustomFilePath] = useState<string>("PaymentService.java");

  // Review states
  const [isReviewing, setIsReviewing] = useState(false);
  const [reviewProgress, setReviewProgress] = useState<string[]>([]);
  const [currentProgressStep, setCurrentProgressStep] = useState(0);
  const [latestReport, setLatestReport] = useState<CodeReview | null>(null);
  const [reviewHistory, setReviewHistory] = useState<CodeReview[]>([]);
  const [reviewHistoryFilter, setReviewHistoryFilter] = useState<string>("all");

  // Blueprint view state
  const [selectedBlueprint, setSelectedBlueprint] = useState<Blueprint>(blueprints[0]);
  const [copiedBlueprintId, setCopiedBlueprintId] = useState<string | null>(null);

  // Admin and Metrics states
  const [adminStats, setAdminStats] = useState<AdminStats | null>(null);
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserName, setNewUserName] = useState("");
  const [newUserPassword, setNewUserPassword] = useState("");
  const [newUserRole, setNewUserRole] = useState("USER");

  // Modal State
  const [isConnectRepoModalOpen, setIsConnectRepoModalOpen] = useState(false);
  const [newRepoName, setNewRepoName] = useState("");
  const [newRepoOwner, setNewRepoOwner] = useState("");
  const [newRepoDesc, setNewRepoDesc] = useState("");
  const [newRepoLanguage, setNewRepoLanguage] = useState("Java");

  // Toast Notification State
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);
  const showToast = (message: string, type: "success" | "error" | "info" = "info") => {
    setToast({ message, type });
  };

  // Clear toast dynamically after timeout
  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Fetch initial data
  useEffect(() => {
    fetchRepositories();
    fetchReviewHistory();
    fetchAdminStats();
  }, [currentUser]);

  // Handle repository selection change
  useEffect(() => {
    if (selectedRepoId) {
      const selected = repos.find(r => r.id === selectedRepoId);
      if (selected) {
        setBranches(selected.branches);
        setSelectedBranch(selected.defaultBranch || "main");
        setEditorLanguage(selected.language?.toLowerCase() === "typescript" ? "typescript" : "java");
        fetchRepoFiles(selected.id);
      }
    } else {
      setBranches([]);
      setRepoFiles([]);
      setSelectedFile("");
    }
  }, [selectedRepoId, repos]);

  // Handle file selection inside repository
  useEffect(() => {
    if (selectedRepoId && selectedFile) {
      fetchFileContent(selectedRepoId, selectedFile);
    }
  }, [selectedFile, selectedRepoId]);

  // --- API Integrations ---

  const fetchRepositories = async () => {
    try {
      const res = await fetch("/api/repositories");
      if (res.ok) {
        const data = await res.json();
        setRepos(data);
        if (data.length > 0 && !selectedRepoId) {
          setSelectedRepoId(data[0].id);
        }
      }
    } catch (err) {
      console.error("Error fetching repositories:", err);
    }
  };

  const fetchRepoFiles = async (repoId: string) => {
    try {
      const res = await fetch(`/api/repositories/${repoId}/files`);
      if (res.ok) {
        const files = await res.json();
        setRepoFiles(files);
        if (files.length > 0) {
          setSelectedFile(files[0]);
        }
      }
    } catch (err) {
      console.error("Error fetching repo files:", err);
    }
  };

  const fetchFileContent = async (repoId: string, filePath: string) => {
    try {
      const res = await fetch(`/api/repositories/${repoId}/file-content?path=${encodeURIComponent(filePath)}`);
      if (res.ok) {
        const data = await res.json();
        setEditorCode(data.content);
        setCustomFilePath(filePath);
      }
    } catch (err) {
      console.error("Error fetching file content:", err);
    }
  };

  const fetchReviewHistory = async () => {
    try {
      const res = await fetch("/api/reviews");
      if (res.ok) {
        const data = await res.json();
        setReviewHistory(data);
        if (data.length > 0 && !latestReport) {
          // Parse stringified JSON fields if they are strings
          const cleanReport = formatReportFields(data[0]);
          setLatestReport(cleanReport);
        }
      }
    } catch (err) {
      console.error("Error fetching review history:", err);
    }
  };

  const fetchAdminStats = async () => {
    try {
      const res = await fetch("/api/admin/stats");
      if (res.ok) {
        const data = await res.json();
        setAdminStats(data);
      }
    } catch (err) {
      console.error("Error fetching admin stats:", err);
    }
  };

  const formatReportFields = (report: any): CodeReview => {
    return {
      ...report,
      vulnerabilities: typeof report.vulnerabilities === "string" ? JSON.parse(report.vulnerabilities) : report.vulnerabilities,
      performance: typeof report.performance === "string" ? JSON.parse(report.performance) : report.performance,
      codeSmells: typeof report.codeSmells === "string" ? JSON.parse(report.codeSmells) : report.codeSmells,
      bestPractices: typeof report.bestPractices === "string" ? JSON.parse(report.bestPractices) : report.bestPractices
    };
  };

  // --- Interactive Actions ---

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    const endpoint = isLoginView ? "/api/auth/login" : "/api/auth/register";
    const body = isLoginView
      ? { email: authEmail, password: authPassword }
      : { email: authEmail, password: authPassword, name: authName };

    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) {
        setAuthError(data.error || "Authentication failed. Please verify credentials.");
      } else {
        localStorage.setItem("user", JSON.stringify(data.user));
        localStorage.setItem("token", data.token);
        setCurrentUser(data.user);
        // Clean auth fields
        setAuthEmail("");
        setAuthPassword("");
        setAuthName("");
      }
    } catch (err) {
      setAuthError("Failed to communicate with authentication server.");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    setCurrentUser(null);
    setActiveTab("dashboard");
  };

  const handleConnectRepo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRepoName || !newRepoOwner) return;

    try {
      const res = await fetch("/api/repositories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          owner: newRepoOwner,
          name: newRepoName,
          description: newRepoDesc,
          language: newRepoLanguage
        })
      });
      if (res.ok) {
        const newlyAdded = await res.json();
        setRepos(prev => [...prev, newlyAdded]);
        setSelectedRepoId(newlyAdded.id);
        setIsConnectRepoModalOpen(false);
        // Reset inputs
        setNewRepoName("");
        setNewRepoOwner("");
        setNewRepoDesc("");
        // Refresh stats
        fetchAdminStats();
      }
    } catch (err) {
      console.error("Error connecting repository:", err);
    }
  };

  const handleTriggerAnalysis = async () => {
    if (!editorCode.trim()) return;

    setIsReviewing(true);
    setReviewProgress([]);
    setCurrentProgressStep(0);

    const steps = [
      "Securing connection to AST sandbox analyzer...",
      "Generating lexical token stream mappings...",
      "Analyzing against OWASP Top 10 vulnerabilities index...",
      "Verifying performance and connection thread pool models...",
      "Compiling deep analysis metrics with Gemini Core Engine..."
    ];

    // Simulate progress checkmarks
    for (let i = 0; i < steps.length; i++) {
      setCurrentProgressStep(i);
      setReviewProgress(prev => [...prev, steps[i]]);
      await new Promise(resolve => setTimeout(resolve, i === steps.length - 1 ? 1200 : 800));
    }

    try {
      const res = await fetch("/api/review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: editorCode,
          repositoryId: selectedRepoId || undefined,
          filePath: customFilePath,
          branch: selectedBranch,
          language: editorLanguage
        })
      });

      if (res.ok) {
        const report = await res.json();
        const formatted = formatReportFields(report);
        setLatestReport(formatted);
        fetchReviewHistory();
        fetchAdminStats();
        fetchRepositories(); // Update repo quality score
      } else {
        showToast("An error occurred during AI static analysis code review.", "error");
      }
    } catch (err) {
      console.error("Error running code review:", err);
      showToast("Failed to communicate with AI review engine.", "error");
    } finally {
      setIsReviewing(false);
    }
  };

  // Pre-load specific buggy files for quick testing
  const loadBuggySample = (type: "java" | "react") => {
    if (type === "java") {
      const springRepo = repos.find(r => r.id === "spring-boot-api");
      if (springRepo && springRepo.files.length > 0) {
        setSelectedRepoId("spring-boot-api");
        setSelectedFile("src/main/java/com/payment/service/PaymentService.java");
      } else {
        setEditorLanguage("java");
        setCustomFilePath("PaymentService.java");
        setEditorCode(`package com.payment.service;

import org.springframework.stereotype.Service;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

@Service
public class PaymentService {

    private String dbUrl = "jdbc:postgresql://localhost:5432/payment_db";
    private String dbUser = "prod_admin";
    private String dbPass = "S3cr3tP@ssw0rd!"; // Hardcoded security leak

    public double getAccountBalance(String accountId) {
        double balance = 0.0;
        try {
            Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
            Statement stmt = conn.createStatement();
            
            // SQL Injection vulnerable line:
            String query = "SELECT balance FROM accounts WHERE id = '" + accountId + "'";
            ResultSet rs = stmt.executeQuery(query);
            
            if (rs.next()) {
                balance = rs.getDouble("balance");
            }
            // Leak: JDBC resources never closed in finally block!
        } catch (Exception e) {
            e.printStackTrace(); // Bad logging practice
        }
        return balance;
    }
}`);
      }
    } else {
      const reactRepo = repos.find(r => r.id === "react-dashboard");
      if (reactRepo && reactRepo.files.length > 0) {
        setSelectedRepoId("react-dashboard");
        setSelectedFile("src/components/UserDashboard.tsx");
      } else {
        setEditorLanguage("typescript");
        setCustomFilePath("UserDashboard.tsx");
        setEditorCode(`import React, { useEffect, useState } from 'react';

export default function UserDashboard() {
  const [data, setData] = useState<any>(null);
  
  // Bug: infinite render loop due to state mutation inside hook without dependencies array
  useEffect(() => {
    const fetchData = async () => {
      const res = await fetch('https://api.company.com/v1/metrics');
      const json = await res.json();
      setData(json);
    };
    fetchData();
  }); // Omitted empty dependency array []!

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Metrics Dashboard</h1>
      <div dangerouslySetInnerHTML={{ __html: data?.description || '<p>Loading...</p>' }} />
    </div>
  );
}`);
      }
    }
  };

  // Admin: Create simulated user
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserEmail || !newUserName || !newUserPassword) return;

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: newUserEmail,
          password: newUserPassword,
          name: newUserName,
          role: newUserRole
        })
      });
      if (res.ok) {
        // Reset states
        setNewUserEmail("");
        setNewUserName("");
        setNewUserPassword("");
        fetchAdminStats();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Admin: Delete simulated user
  const handleDeleteUser = async (userId: number) => {
    if (userId === currentUser?.id) {
      showToast("You cannot delete your own active session.", "error");
      return;
    }
    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: "DELETE"
      });
      if (res.ok) {
        fetchAdminStats();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Copy blueprint to clipboard
  const copyBlueprintCode = (blueprint: Blueprint) => {
    navigator.clipboard.writeText(blueprint.code);
    setCopiedBlueprintId(blueprint.id);
    setTimeout(() => setCopiedBlueprintId(null), 2000);
  };

  // Filter historical reviews
  const filteredHistory = reviewHistory.filter(h => {
    if (reviewHistoryFilter === "all") return true;
    return h.repositoryId === reviewHistoryFilter;
  });

  // Calculate Developer Score Metrics
  const averageQualityScore = repos.length > 0
    ? Math.round(repos.reduce((acc, r) => acc + r.score, 0) / repos.length)
    : 85;

  const totalVulnerabilitiesCount = reviewHistory.reduce((acc, r) => {
    const formatted = formatReportFields(r);
    return acc + (Array.isArray(formatted.vulnerabilities) ? formatted.vulnerabilities.length : 0);
  }, 0);

  // --- Auth Screen Layout ---
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative overflow-hidden font-sans">
        {/* Background ambient accents */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl" />

        <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10 text-center">
          <div className="mx-auto h-12 w-12 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30">
            <Cpu className="h-6 w-6 text-white" />
          </div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-white tracking-tight">
            AI Code Review Assistant
          </h2>
          <p className="mt-2 text-center text-sm text-slate-400">
            Enterprise static security analysis and architecture generator
          </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md relative z-10">
          <div className="bg-slate-800/80 backdrop-blur-md py-8 px-4 shadow-xl border border-slate-700 rounded-2xl sm:px-10">
            <form className="space-y-6" onSubmit={handleAuth}>
              {authError && (
                <div className="bg-red-900/40 border border-red-700 text-red-200 px-4 py-3 rounded-xl text-sm flex items-center gap-2">
                  <ShieldAlert className="h-5 w-5 shrink-0" />
                  <span>{authError}</span>
                </div>
              )}

              {!isLoginView && (
                <div>
                  <label className="block text-sm font-medium text-slate-300">Full Name</label>
                  <div className="mt-1">
                    <input
                      type="text"
                      required
                      value={authName}
                      onChange={(e) => setAuthName(e.target.value)}
                      placeholder="Alex Codecraft"
                      className="appearance-none block w-full px-4 py-3 border border-slate-600 rounded-xl bg-slate-950 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-300">Work Email Address</label>
                <div className="mt-1">
                  <input
                    type="email"
                    required
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    placeholder="developer@company.com"
                    className="appearance-none block w-full px-4 py-3 border border-slate-600 rounded-xl bg-slate-950 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300">Secure Password</label>
                <div className="mt-1">
                  <input
                    type="password"
                    required
                    value={authPassword}
                    onChange={(e) => setAuthPassword(e.target.value)}
                    placeholder="••••••••"
                    className="appearance-none block w-full px-4 py-3 border border-slate-600 rounded-xl bg-slate-950 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  />
                </div>
              </div>

              <div>
                <button
                  type="submit"
                  className="w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition"
                >
                  {isLoginView ? "Sign In to Platform" : "Create Enterprise Account"}
                </button>
              </div>
            </form>

            <div className="mt-6 text-center text-sm">
              <button
                type="button"
                onClick={() => {
                  setIsLoginView(!isLoginView);
                  setAuthError("");
                }}
                className="font-medium text-blue-400 hover:text-blue-300 transition"
              >
                {isLoginView ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
              </button>
            </div>

            <div className="mt-6 pt-6 border-t border-slate-700/60">
              <div className="text-center">
                <span className="text-xs text-slate-500">Demo accounts:</span>
                <div className="flex justify-center gap-2 mt-2">
                  <button
                    onClick={() => {
                      setAuthEmail("admin@company.com");
                      setAuthPassword("password123");
                      setIsLoginView(true);
                    }}
                    className="text-xs bg-slate-700/50 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg border border-slate-600 transition"
                  >
                    Admin Mock Log
                  </button>
                  <button
                    onClick={() => {
                      setAuthEmail("developer@company.com");
                      setAuthPassword("password123");
                      setIsLoginView(true);
                    }}
                    className="text-xs bg-slate-700/50 hover:bg-slate-700 text-slate-300 px-3 py-1.5 rounded-lg border border-slate-600 transition"
                  >
                    Developer Mock Log
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // --- Main Dashboard Layout ---
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Header */}
      <header className="bg-slate-900 border-b border-slate-800 text-white py-2 px-4 shrink-0 relative z-10 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="h-7 w-7 bg-blue-600 rounded-md flex items-center justify-center shadow-md shadow-blue-500/20">
            <Cpu className="h-4 w-4 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-tight">AI Code Review Assistant</h1>
            <p className="text-[9px] text-slate-400 font-mono">Senior Architect Portal v1.0.0</p>
          </div>
        </div>

        {/* User Session profile */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center">
              <User className="h-3.5 w-3.5 text-blue-400" />
            </div>
            <div className="text-right hidden sm:block">
              <p className="text-[11px] font-semibold leading-tight">{currentUser.name}</p>
              <p className="text-[9px] text-slate-400 font-mono uppercase tracking-wider">{currentUser.role} ROLE</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800/80 transition"
            title="Log out"
          >
            <LogOut className="h-3.5 w-3.5" />
          </button>
        </div>
      </header>

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Navigation */}
        <nav className="w-56 bg-slate-900 border-r border-slate-800 shrink-0 hidden md:flex flex-col text-white p-3 justify-between">
          <div className="space-y-1">
            <div className="pb-3 mb-3 border-b border-slate-800">
              <span className="text-[9px] text-slate-500 uppercase tracking-widest font-mono font-bold block mb-1.5">Systems Menu</span>
              <button
                onClick={() => setActiveTab("dashboard")}
                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition mb-1 ${
                  activeTab === "dashboard" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <BarChart3 className="h-3.5 w-3.5" />
                <span>Executive Dashboard</span>
              </button>
              <button
                onClick={() => setActiveTab("studio")}
                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition ${
                  activeTab === "studio" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <Code2 className="h-3.5 w-3.5" />
                <span>Review Studio</span>
              </button>
            </div>

            <div className="pb-3 mb-3 border-b border-slate-800">
              <span className="text-[9px] text-slate-500 uppercase tracking-widest font-mono font-bold block mb-1.5">Blueprints</span>
              <button
                onClick={() => setActiveTab("architecture")}
                className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition ${
                  activeTab === "architecture" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                <Layers className="h-3.5 w-3.5" />
                <span>Spring Clean Arch</span>
              </button>
            </div>

            {currentUser.role === "ADMIN" && (
              <div>
                <span className="text-[9px] text-slate-500 uppercase tracking-widest font-mono font-bold block mb-1.5">Platform</span>
                <button
                  onClick={() => setActiveTab("admin")}
                  className={`w-full flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition ${
                    activeTab === "admin" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  <Settings className="h-3.5 w-3.5" />
                  <span>Admin &amp; Telemetry</span>
                </button>
              </div>
            )}
          </div>

          <div className="p-2.5 bg-slate-950 rounded-lg border border-slate-800">
            <div className="flex items-center gap-1.5 mb-1">
              <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[9px] text-emerald-400 uppercase font-mono tracking-wider font-semibold">Gemini API Connection</span>
            </div>
            <p className="text-[9px] text-slate-400 leading-snug">
              Direct connection to <strong>gemini-3.5-flash</strong>. All reviews generated with live schema validation.
            </p>
          </div>
        </nav>

        {/* Content Panel */}
        <main className="flex-1 overflow-y-auto p-4 relative">
          {/* Active Component Wrapper */}
          <AnimatePresence mode="wait">
            {activeTab === "dashboard" && (
              <motion.div
                key="dashboard"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="space-y-6"
              >
                {/* Visual Header */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight text-slate-900">Executive Quality Metrics</h2>
                    <p className="text-sm text-slate-500">Repository analysis indexes, static issues mapping, and developer grades</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setIsConnectRepoModalOpen(true)}
                      className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2.5 rounded-xl text-sm font-semibold inline-flex items-center gap-2 shadow-sm transition"
                    >
                      <Plus className="h-4 w-4" />
                      Connect GitHub Repo
                    </button>
                  </div>
                </div>

                {/* Score Summary Metrics Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-500 font-medium uppercase tracking-wider block">Developer Score</span>
                      <span className="text-3xl font-extrabold text-slate-900 mt-1 block">{averageQualityScore}%</span>
                    </div>
                    <div className="h-11 w-11 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600">
                      <Award className="h-6 w-6" />
                    </div>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-500 font-medium uppercase tracking-wider block">Monitored Repositories</span>
                      <span className="text-3xl font-extrabold text-slate-900 mt-1 block">{repos.length}</span>
                    </div>
                    <div className="h-11 w-11 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600">
                      <GitBranch className="h-6 w-6" />
                    </div>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-500 font-medium uppercase tracking-wider block">Open Vulnerabilities</span>
                      <span className="text-3xl font-extrabold text-slate-900 mt-1 block">{totalVulnerabilitiesCount}</span>
                    </div>
                    <div className="h-11 w-11 bg-rose-100 rounded-xl flex items-center justify-center text-rose-600">
                      <ShieldAlert className="h-6 w-6" />
                    </div>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-500 font-medium uppercase tracking-wider block">Audits Executed</span>
                      <span className="text-3xl font-extrabold text-slate-900 mt-1 block">{reviewHistory.length}</span>
                    </div>
                    <div className="h-11 w-11 bg-amber-100 rounded-xl flex items-center justify-center text-amber-600">
                      <CheckCircle className="h-6 w-6" />
                    </div>
                  </div>
                </div>

                {/* Analytical charts & visualizations */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Historical review chart */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm lg:col-span-2">
                    <h3 className="text-sm font-semibold text-slate-900 mb-4 block">API Rate Consumption &amp; Request Flow</h3>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={adminStats?.metrics.dailyUsage || []}>
                          <defs>
                            <linearGradient id="colorRequests" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                              <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} tickLine={false} />
                          <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                          <Tooltip />
                          <Area type="monotone" dataKey="requests" stroke="#2563eb" strokeWidth={2} fillOpacity={1} fill="url(#colorRequests)" name="API Requests" />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Connected Repository Lists */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-sm font-semibold text-slate-900">Repositories Health</h3>
                        <span className="text-xs font-mono text-slate-400 font-bold uppercase">Index</span>
                      </div>
                      <div className="space-y-3">
                        {repos.map(r => (
                          <div key={r.id} className="p-3 bg-slate-50 border border-slate-200/60 rounded-xl flex items-center justify-between">
                            <div>
                              <p className="text-xs font-bold text-slate-900">{r.name}</p>
                              <p className="text-[10px] text-slate-500 font-mono mt-0.5">{r.language} • {r.owner}</p>
                            </div>
                            <div className="text-right">
                              <span className={`text-xs font-mono font-bold px-2 py-1 rounded-md ${
                                r.score >= 85 ? "bg-emerald-100 text-emerald-800" :
                                r.score >= 70 ? "bg-amber-100 text-amber-800" : "bg-red-100 text-red-800"
                              }`}>
                                {r.score}%
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <button
                      onClick={() => setActiveTab("studio")}
                      className="w-full text-center py-2.5 mt-4 bg-slate-100 hover:bg-slate-200 rounded-xl text-xs font-semibold text-slate-700 inline-flex items-center justify-center gap-1.5 transition"
                    >
                      Enter Static Review Studio <ChevronRight className="h-3 w-3" />
                    </button>
                  </div>
                </div>

                {/* Latest reviews lists */}
                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
                    <h3 className="text-sm font-semibold text-slate-900">Audit History Log</h3>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => setReviewHistoryFilter("all")}
                        className={`text-xs px-3 py-1 rounded-lg border transition ${
                          reviewHistoryFilter === "all" ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-600 border-slate-200"
                        }`}
                      >
                        All Repos
                      </button>
                      {repos.map(r => (
                        <button
                          key={r.id}
                          onClick={() => setReviewHistoryFilter(r.id)}
                          className={`text-xs px-3 py-1 rounded-lg border transition ${
                            reviewHistoryFilter === r.id ? "bg-slate-900 text-white border-slate-900" : "bg-white text-slate-600 border-slate-200"
                          }`}
                        >
                          {r.name}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="divide-y divide-slate-100">
                    {filteredHistory.length === 0 ? (
                      <div className="p-8 text-center text-slate-500">
                        <Info className="h-8 w-8 text-slate-300 mx-auto mb-2" />
                        <p className="text-sm">No analysis reports found matching filters.</p>
                      </div>
                    ) : (
                      filteredHistory.map(h => (
                        <div key={h.id} className="p-4 flex items-start sm:items-center justify-between gap-4 hover:bg-slate-50 transition">
                          <div className="flex gap-3 items-start">
                            <div className="h-9 w-9 bg-slate-100 border border-slate-200 rounded-xl flex items-center justify-center text-slate-600 shrink-0">
                              <FileText className="h-4.5 w-4.5" />
                            </div>
                            <div>
                              <p className="text-xs font-bold text-slate-900 leading-none">{h.filePath}</p>
                              <div className="flex flex-wrap gap-x-2 gap-y-0.5 text-[10px] text-slate-400 font-mono mt-1">
                                <span className="text-slate-600 font-bold">{h.repositoryName}</span>
                                <span>•</span>
                                <span>Branch: {h.branch}</span>
                                <span>•</span>
                                <span>{new Date(h.date).toLocaleDateString()}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-3 shrink-0">
                            <div className="text-right">
                              <span className="text-xs text-slate-400 block font-mono">Score</span>
                              <span className="text-sm font-bold text-slate-900">{h.score}%</span>
                            </div>
                            <button
                              onClick={() => {
                                const formatted = formatReportFields(h);
                                setLatestReport(formatted);
                                setActiveTab("studio");
                              }}
                              className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold transition"
                            >
                              Open Report
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Code Reviewer Studio Tab */}
            {activeTab === "studio" && (
              <motion.div
                key="studio"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="grid grid-cols-1 lg:grid-cols-12 gap-6"
              >
                {/* Left Side: Code Editor Workspace */}
                <div className="lg:col-span-5 flex flex-col gap-4">
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col gap-4">
                    <div>
                      <h2 className="text-lg font-bold text-slate-900">Review Studio Workspace</h2>
                      <p className="text-xs text-slate-500">Paste raw code or select a file from connected repositories</p>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Source Repository</label>
                        <select
                          value={selectedRepoId}
                          onChange={(e) => setSelectedRepoId(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-blue-500"
                        >
                          <option value="">Custom Paste Code Snippet</option>
                          {repos.map(r => (
                            <option key={r.id} value={r.id}>{r.owner}/{r.name}</option>
                          ))}
                        </select>
                      </div>

                      {selectedRepoId && (
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Branch</label>
                            <select
                              value={selectedBranch}
                              onChange={(e) => setSelectedBranch(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-blue-500"
                            >
                              {branches.map(b => (
                                <option key={b} value={b}>{b}</option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Target File</label>
                            <select
                              value={selectedFile}
                              onChange={(e) => setSelectedFile(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-blue-500 animate-fade-in"
                            >
                              {repoFiles.map(f => (
                                <option key={f} value={f}>{f.split("/").pop()}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                      )}

                      {!selectedRepoId && (
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Language</label>
                            <select
                              value={editorLanguage}
                              onChange={(e) => setEditorLanguage(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-xs"
                            >
                              <option value="java">Java 21</option>
                              <option value="typescript">TypeScript</option>
                              <option value="python">Python</option>
                              <option value="go">Go Programming</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Sandbox Path</label>
                            <input
                              type="text"
                              value={customFilePath}
                              onChange={(e) => setCustomFilePath(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-xs"
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Pre-seed helper buttons */}
                    <div className="pt-2">
                      <span className="text-[10px] text-slate-400 block font-bold mb-1">Quick-Load Vulnerable Boilerplates:</span>
                      <div className="flex gap-2">
                        <button
                          onClick={() => loadBuggySample("java")}
                          className="flex-1 text-[10px] font-semibold bg-blue-50 hover:bg-blue-100 text-blue-600 border border-blue-200/50 py-1.5 rounded-lg transition text-center"
                        >
                          Buggy Java JDBC
                        </button>
                        <button
                          onClick={() => loadBuggySample("react")}
                          className="flex-1 text-[10px] font-semibold bg-amber-50 hover:bg-amber-100 text-amber-600 border border-amber-200/50 py-1.5 rounded-lg transition text-center"
                        >
                          Vulnerable React useEffect
                        </button>
                      </div>
                    </div>

                    {/* Editor Component */}
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-[10px] font-mono text-slate-400">
                        <span>Workspace Editor</span>
                        <span>{editorCode.split("\n").length} Lines</span>
                      </div>
                      <textarea
                        value={editorCode}
                        onChange={(e) => setEditorCode(e.target.value)}
                        placeholder="// Enter your source code here for AI security static analysis..."
                        className="w-full h-80 bg-slate-950 text-emerald-400 p-4 font-mono text-xs rounded-xl focus:outline-none focus:ring-1 focus:ring-blue-500 leading-relaxed border border-slate-800 resize-none"
                      />
                    </div>

                    <button
                      onClick={handleTriggerAnalysis}
                      disabled={isReviewing || !editorCode.trim()}
                      className="w-full py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-300 text-white font-semibold rounded-xl text-sm transition inline-flex items-center justify-center gap-2 shadow-md shadow-blue-600/15"
                    >
                      {isReviewing ? (
                        <>
                          <RefreshCw className="h-4 w-4 animate-spin" />
                          <span>Executing Static Review...</span>
                        </>
                      ) : (
                        <>
                          <Play className="h-4 w-4" />
                          <span>Trigger AI Static Audit</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Active Analysis Progress Checklist */}
                  {isReviewing && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 shadow-lg space-y-3"
                    >
                      <h4 className="text-xs uppercase font-mono tracking-wider font-bold text-slate-500">Static AST Analysis Pipeline</h4>
                      <div className="space-y-2 font-mono text-xs text-slate-300">
                        {reviewProgress.map((step, idx) => (
                          <div key={idx} className="flex items-center gap-2">
                            {idx < currentProgressStep ? (
                              <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                            ) : (
                              <RefreshCw className="h-4 w-4 text-blue-500 animate-spin shrink-0" />
                            )}
                            <span className={idx < currentProgressStep ? "text-slate-400" : "text-white"}>{step}</span>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* Right Side: Quality Report Screen */}
                <div className="lg:col-span-7">
                  {latestReport ? (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
                    >
                      {/* Score Gauge header */}
                      <div className="p-6 bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-6 relative overflow-hidden">
                        {/* Background ambient light */}
                        <div className={`absolute right-0 top-0 w-48 h-48 rounded-full blur-3xl ${
                          latestReport.score >= 80 ? "bg-emerald-500/10" :
                          latestReport.score >= 60 ? "bg-amber-500/10" : "bg-red-500/10"
                        }`} />

                        <div className="space-y-1 relative z-10 text-center sm:text-left">
                          <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase font-bold block">AST Code Auditor Report</span>
                          <h3 className="text-lg font-bold tracking-tight">{latestReport.filePath.split("/").pop()}</h3>
                          <div className="flex items-center gap-2 text-slate-400 text-[10px] font-mono mt-1">
                            <span>Language: {latestReport.filePath.endsWith(".java") ? "Java" : "TypeScript"}</span>
                            <span>•</span>
                            <span>Reviewer: {latestReport.reviewer}</span>
                          </div>
                        </div>

                        {/* Large Score Indicator */}
                        <div className="flex items-center gap-3 shrink-0 relative z-10 bg-slate-950/40 p-4 rounded-xl border border-slate-800/80">
                          <div className="text-center">
                            <span className="text-[10px] text-slate-400 uppercase font-mono tracking-widest font-bold">Grade</span>
                            <span className={`text-4xl font-black block mt-0.5 ${
                              latestReport.score >= 80 ? "text-emerald-400" :
                              latestReport.score >= 60 ? "text-amber-400" : "text-rose-400"
                            }`}>
                              {latestReport.score}%
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Summary text block */}
                      <div className="p-6 border-b border-slate-100 bg-slate-50 flex gap-3">
                        <Info className="h-5 w-5 text-blue-500 shrink-0 mt-0.5" />
                        <div>
                          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Architectural Synthesis</h4>
                          <p className="text-xs text-slate-600 mt-1 leading-normal">{latestReport.summary}</p>
                        </div>
                      </div>

                      {/* Detail tabs of findings */}
                      <div className="p-6 space-y-6">
                        {/* Vulnerabilities Section */}
                        <div className="space-y-3">
                          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                            <ShieldAlert className="h-5 w-5 text-rose-500" />
                            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Security Vulnerabilities ({Array.isArray(latestReport.vulnerabilities) ? latestReport.vulnerabilities.length : 0})</h4>
                          </div>

                          {(!Array.isArray(latestReport.vulnerabilities) || latestReport.vulnerabilities.length === 0) ? (
                            <div className="text-center py-4 bg-emerald-50 text-emerald-800 border border-emerald-100 rounded-xl text-xs flex items-center justify-center gap-2">
                              <CheckCircle className="h-4.5 w-4.5 text-emerald-600" />
                              <span>Zero security vulnerabilities detected. Great work!</span>
                            </div>
                          ) : (
                            <div className="space-y-3">
                              {(latestReport.vulnerabilities as Vulnerability[]).map((v, i) => (
                                <div key={i} className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                                  <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-4">
                                    <div className="flex items-center gap-2">
                                      <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
                                        v.severity === "HIGH" ? "bg-rose-100 text-rose-800" :
                                        v.severity === "MEDIUM" ? "bg-amber-100 text-amber-800" : "bg-blue-100 text-blue-800"
                                      }`}>
                                        {v.severity}
                                      </span>
                                      <span className="text-xs font-bold text-slate-950">{v.title}</span>
                                    </div>
                                    <span className="text-[10px] font-mono text-slate-400 font-bold">Line {v.line}</span>
                                  </div>
                                  <div className="p-4 space-y-3">
                                    <div>
                                      <span className="text-[10px] text-slate-400 uppercase font-mono font-bold block mb-0.5">Threat Explanation</span>
                                      <p className="text-xs text-slate-600 leading-normal">{v.description}</p>
                                    </div>
                                    <div>
                                      <div className="flex justify-between items-center mb-1">
                                        <span className="text-[10px] text-slate-400 uppercase font-mono font-bold">Recommended Mitigation</span>
                                        <button
                                          onClick={() => {
                                            navigator.clipboard.writeText(v.fix);
                                            alert("Remediation code copied to clipboard!");
                                          }}
                                          className="text-[10px] text-blue-600 hover:text-blue-500 font-bold inline-flex items-center gap-1"
                                        >
                                          <Copy className="h-3 w-3" /> Copy Snippet
                                        </button>
                                      </div>
                                      <pre className="bg-slate-900 text-slate-100 p-3 rounded-xl font-mono text-[11px] overflow-x-auto leading-relaxed border border-slate-800 whitespace-pre-wrap">{v.fix}</pre>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Performance optimizations section */}
                        <div className="space-y-3">
                          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                            <Zap className="h-5 w-5 text-amber-500" />
                            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Performance Bottlenecks ({Array.isArray(latestReport.performance) ? latestReport.performance.length : 0})</h4>
                          </div>

                          {(!Array.isArray(latestReport.performance) || latestReport.performance.length === 0) ? (
                            <p className="text-xs text-slate-500 italic">No performance bottlenecks identified.</p>
                          ) : (
                            <div className="space-y-3">
                              {(latestReport.performance as IssueItem[]).map((v, i) => (
                                <div key={i} className="p-4 bg-slate-50 border border-slate-200/60 rounded-xl space-y-2">
                                  <div className="flex justify-between items-start gap-4">
                                    <h5 className="text-xs font-bold text-slate-900">{v.title}</h5>
                                    <span className="text-[10px] font-mono text-slate-400 font-semibold shrink-0">Line {v.line}</span>
                                  </div>
                                  <p className="text-xs text-slate-600 leading-normal">{v.description}</p>
                                  <pre className="bg-slate-950 text-emerald-400 p-3 rounded-xl font-mono text-[10px] overflow-x-auto whitespace-pre-wrap">{v.fix}</pre>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Code Smells Section */}
                        <div className="space-y-3">
                          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                            <Terminal className="h-5 w-5 text-blue-500" />
                            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Clean Code &amp; Code Smells ({Array.isArray(latestReport.codeSmells) ? latestReport.codeSmells.length : 0})</h4>
                          </div>

                          {(!Array.isArray(latestReport.codeSmells) || latestReport.codeSmells.length === 0) ? (
                            <p className="text-xs text-slate-500 italic">No structural code smells identified.</p>
                          ) : (
                            <div className="space-y-3">
                              {(latestReport.codeSmells as IssueItem[]).map((v, i) => (
                                <div key={i} className="p-4 bg-slate-50 border border-slate-200/60 rounded-xl space-y-2">
                                  <div className="flex justify-between items-start gap-4">
                                    <h5 className="text-xs font-bold text-slate-900">{v.title}</h5>
                                    <span className="text-[10px] font-mono text-slate-400 font-semibold shrink-0">Line {v.line}</span>
                                  </div>
                                  <p className="text-xs text-slate-600 leading-normal">{v.description}</p>
                                  <pre className="bg-slate-950 text-emerald-400 p-3 rounded-xl font-mono text-[10px] overflow-x-auto whitespace-pre-wrap">{v.fix}</pre>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Best Practices Section */}
                        <div className="space-y-3">
                          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
                            <CheckCircle className="h-5 w-5 text-purple-500" />
                            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide">Standard Best Practices ({Array.isArray(latestReport.bestPractices) ? latestReport.bestPractices.length : 0})</h4>
                          </div>

                          {(!Array.isArray(latestReport.bestPractices) || latestReport.bestPractices.length === 0) ? (
                            <p className="text-xs text-slate-500 italic">No static best practice violations found.</p>
                          ) : (
                            <div className="space-y-3">
                              {(latestReport.bestPractices as IssueItem[]).map((v, i) => (
                                <div key={i} className="p-4 bg-slate-50 border border-slate-200/60 rounded-xl space-y-2">
                                  <div className="flex justify-between items-start gap-4">
                                    <h5 className="text-xs font-bold text-slate-900">{v.title}</h5>
                                    <span className="text-[10px] font-mono text-slate-400 font-semibold shrink-0">Line {v.line}</span>
                                  </div>
                                  <p className="text-xs text-slate-600 leading-normal">{v.description}</p>
                                  <pre className="bg-slate-950 text-emerald-400 p-3 rounded-xl font-mono text-[10px] overflow-x-auto whitespace-pre-wrap">{v.fix}</pre>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  ) : (
                    <div className="h-full bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-center items-center p-8 text-center min-h-[400px]">
                      <Sparkles className="h-10 w-10 text-slate-300 mb-3 animate-pulse" />
                      <h4 className="text-sm font-bold text-slate-900">Awaiting Static Review Execution</h4>
                      <p className="text-xs text-slate-500 max-w-xs mt-1 leading-normal">
                        Select buggy code configurations or write your own files inside the sandbox, then click "Trigger AI Static Audit" to fetch model results.
                      </p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* Architecture Blueprints Explorer Tab */}
            {activeTab === "architecture" && (
              <motion.div
                key="architecture"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="space-y-6 animate-fade-in"
              >
                <div>
                  <h2 className="text-2xl font-bold tracking-tight text-slate-900 font-sans">Spring Boot Architectural Blueprints</h2>
                  <p className="text-sm text-slate-500">
                    Interact, view, and replicate our multi-tier clean architecture designed as a Senior Java Platform Engineer.
                  </p>
                </div>

                {/* Database layout visualization */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                  <div className="flex items-center gap-2 mb-2 pb-3 border-b border-slate-100">
                    <Database className="h-5 w-5 text-blue-600" />
                    <h3 className="text-sm font-bold text-slate-950">Relational Database Entity Relationship Model (ERD)</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Users ER block */}
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 shadow-sm">
                      <div className="bg-slate-900 text-white font-mono text-xs font-bold px-3 py-1.5 rounded-lg mb-2">
                        Table: users
                      </div>
                      <div className="font-mono text-xs divide-y divide-slate-200/50 space-y-1.5 text-slate-600">
                        <div className="flex justify-between pt-1.5"><span className="font-bold text-slate-950">id (PK)</span> <span>BIGSERIAL</span></div>
                        <div className="flex justify-between pt-1.5"><span className="font-bold text-slate-950">email (U)</span> <span>VARCHAR(255)</span></div>
                        <div className="flex justify-between pt-1.5"><span>password_hash</span> <span>VARCHAR(255)</span></div>
                        <div className="flex justify-between pt-1.5"><span>name</span> <span>VARCHAR(255)</span></div>
                        <div className="flex justify-between pt-1.5"><span>role</span> <span>VARCHAR(50)</span></div>
                      </div>
                    </div>

                    {/* Repositories ER block */}
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 shadow-sm relative">
                      <div className="bg-slate-900 text-white font-mono text-xs font-bold px-3 py-1.5 rounded-lg mb-2">
                        Table: repositories
                      </div>
                      <div className="font-mono text-xs divide-y divide-slate-200/50 space-y-1.5 text-slate-600">
                        <div className="flex justify-between pt-1.5"><span className="font-bold text-slate-950">id (PK)</span> <span>UUID</span></div>
                        <div className="flex justify-between pt-1.5"><span className="font-bold text-slate-950">owner, name (U)</span> <span>VARCHAR</span></div>
                        <div className="flex justify-between pt-1.5"><span>language</span> <span>VARCHAR(100)</span></div>
                        <div className="flex justify-between pt-1.5"><span>score</span> <span>INT</span></div>
                        <div className="flex justify-between pt-1.5"><span>connected_at</span> <span>TIMESTAMP</span></div>
                      </div>
                    </div>

                    {/* Reviews ER block */}
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 shadow-sm relative">
                      <div className="bg-slate-900 text-white font-mono text-xs font-bold px-3 py-1.5 rounded-lg mb-2">
                        Table: code_reviews
                      </div>
                      <div className="font-mono text-xs divide-y divide-slate-200/50 space-y-1.5 text-slate-600">
                        <div className="flex justify-between pt-1.5"><span className="font-bold text-slate-950">id (PK)</span> <span>UUID</span></div>
                        <div className="flex justify-between pt-1.5"><span className="font-bold text-slate-950">repository_id (FK)</span> <span>UUID</span></div>
                        <div className="flex justify-between pt-1.5"><span>file_path</span> <span>VARCHAR(512)</span></div>
                        <div className="flex justify-between pt-1.5"><span>score</span> <span>INT</span></div>
                        <div className="flex justify-between pt-1.5"><span>vulnerabilities</span> <span>JSONB</span></div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Java Clean Architecture file selector */}
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
                    <span className="text-[10px] text-slate-400 font-mono tracking-wider uppercase font-bold block mb-2">Enterprise File tree</span>
                    {blueprints.map(bp => (
                      <button
                        key={bp.id}
                        onClick={() => setSelectedBlueprint(bp)}
                        className={`w-full text-left p-3 rounded-xl transition ${
                          selectedBlueprint.id === bp.id
                            ? "bg-slate-900 text-white font-semibold"
                            : "hover:bg-slate-100 text-slate-700 text-xs"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs block font-bold leading-tight">{bp.name}</span>
                          <ChevronRight className="h-3.5 w-3.5 opacity-60" />
                        </div>
                        <span className={`text-[9px] font-mono block mt-1 ${
                          selectedBlueprint.id === bp.id ? "text-slate-400" : "text-slate-400"
                        }`}>
                          {bp.filePath.split("/").pop()}
                        </span>
                      </button>
                    ))}
                  </div>

                  {/* File Code Display panel */}
                  <div className="lg:col-span-3 bg-white border border-slate-200 shadow-sm rounded-2xl overflow-hidden flex flex-col justify-between">
                    <div>
                      {/* Header bar */}
                      <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
                        <div className="space-y-0.5">
                          <span className="text-[10px] text-blue-400 font-mono font-bold">{selectedBlueprint.filePath}</span>
                          <h4 className="text-xs font-bold leading-none">{selectedBlueprint.name}</h4>
                        </div>
                        <button
                          onClick={() => copyBlueprintCode(selectedBlueprint)}
                          className="bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white px-3 py-1.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1 transition"
                        >
                          {copiedBlueprintId === selectedBlueprint.id ? "Copied!" : "Copy Code"}
                        </button>
                      </div>

                      {/* Code Area */}
                      <pre className="p-5 bg-slate-950 text-slate-200 font-mono text-[11px] overflow-x-auto leading-relaxed border-b border-slate-800 whitespace-pre">
                        {selectedBlueprint.code}
                      </pre>
                    </div>

                    {/* Explanatory description card */}
                    <div className="p-5 bg-slate-50 flex gap-3">
                      <Server className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
                      <div>
                        <h5 className="text-xs font-bold text-slate-900 uppercase">Component Role Description</h5>
                        <p className="text-xs text-slate-600 mt-1 leading-normal">{selectedBlueprint.description}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Admin Command Portal Tab */}
            {activeTab === "admin" && currentUser.role === "ADMIN" && (
              <motion.div
                key="admin"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-2xl font-bold tracking-tight text-slate-900">Admin Telemetry Control</h2>
                  <p className="text-sm text-slate-500">Real-time LLM API token counts, daily consumption pricing, and developer security logs</p>
                </div>

                {/* API metrics visualizations */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Prompt vs Response tokens chart */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm md:col-span-2">
                    <h3 className="text-sm font-semibold text-slate-900 mb-4">Prompt &amp; Response Token Consumption</h3>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={adminStats?.metrics.dailyUsage || []}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                          <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} tickLine={false} />
                          <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="prompt" fill="#2563eb" radius={[4, 4, 0, 0]} name="Input Tokens" />
                          <Bar dataKey="response" fill="#f59e0b" radius={[4, 4, 0, 0]} name="Output Tokens" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Financial billing block */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                    <div>
                      <h3 className="text-sm font-semibold text-slate-900 mb-4 block">Billing Optimization</h3>
                      <div className="space-y-3.5">
                        <div className="flex justify-between">
                          <span className="text-xs text-slate-500">Total API Token Volume:</span>
                          <span className="text-xs font-mono font-bold">
                            {((adminStats?.metrics.tokensPrompt || 0) + (adminStats?.metrics.tokensResponse || 0)).toLocaleString()}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-xs text-slate-500">Prompt / Inbound Tokens:</span>
                          <span className="text-xs font-mono font-bold">{(adminStats?.metrics.tokensPrompt || 0).toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-xs text-slate-500">Response / Outbound Tokens:</span>
                          <span className="text-xs font-mono font-bold">{(adminStats?.metrics.tokensResponse || 0).toLocaleString()}</span>
                        </div>
                        <div className="h-px bg-slate-100" />
                        <div className="flex justify-between">
                          <span className="text-xs font-semibold text-slate-900">Estimated LLM Billing ($):</span>
                          <span className="text-xs font-mono font-bold text-emerald-600">${adminStats?.metrics.costEstimated.toFixed(4)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="p-3 bg-blue-50 border border-blue-100 rounded-xl flex items-center gap-2 mt-4">
                      <Zap className="h-4 w-4 text-blue-600 shrink-0" />
                      <p className="text-[10px] text-blue-800 leading-normal">
                        Using <strong>gemini-3.5-flash</strong> model pricing maps ($0.075 / 1M input, $0.30 / 1M output).
                      </p>
                    </div>
                  </div>
                </div>

                {/* User management and simulated table */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* User List Table */}
                  <div className="lg:col-span-8 bg-white border border-slate-200 shadow-sm rounded-2xl overflow-hidden">
                    <div className="px-5 py-4 border-b border-slate-100">
                      <h3 className="text-sm font-semibold text-slate-900">User Identity Registry</h3>
                    </div>
                    <table className="w-full text-left text-xs divide-y divide-slate-100">
                      <thead className="bg-slate-50 text-slate-500 font-mono font-bold uppercase tracking-wider">
                        <tr>
                          <th className="px-4 py-3">Full Name</th>
                          <th className="px-4 py-3">Email Address</th>
                          <th className="px-4 py-3">Role</th>
                          <th className="px-4 py-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {adminStats?.users.map(u => (
                          <tr key={u.id} className="hover:bg-slate-50 transition">
                            <td className="px-4 py-3 font-semibold text-slate-900">{u.name}</td>
                            <td className="px-4 py-3 text-slate-500 font-mono">{u.email}</td>
                            <td className="px-4 py-3">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                                u.role === "ADMIN" ? "bg-purple-100 text-purple-800" : "bg-blue-100 text-blue-800"
                              }`}>
                                {u.role}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-right">
                              <button
                                onClick={() => handleDeleteUser(u.id)}
                                className="text-slate-400 hover:text-red-600 p-1 rounded transition"
                                title="Delete user"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Create simulated User card */}
                  <div className="lg:col-span-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <h3 className="text-sm font-semibold text-slate-900 mb-4">Provision New User</h3>
                    <form className="space-y-4" onSubmit={handleCreateUser}>
                      <div>
                        <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Full Name</label>
                        <input
                          type="text"
                          required
                          value={newUserName}
                          onChange={(e) => setNewUserName(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                          placeholder="Dev Architect"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Email</label>
                        <input
                          type="email"
                          required
                          value={newUserEmail}
                          onChange={(e) => setNewUserEmail(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 font-mono"
                          placeholder="dev@company.com"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Password</label>
                        <input
                          type="password"
                          required
                          value={newUserPassword}
                          onChange={(e) => setNewUserPassword(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                          placeholder="••••••••"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">System Role</label>
                        <select
                          value={newUserRole}
                          onChange={(e) => setNewUserRole(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                        >
                          <option value="USER">USER</option>
                          <option value="ADMIN">ADMIN</option>
                        </select>
                      </div>
                      <button
                        type="submit"
                        className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl text-xs transition inline-flex items-center justify-center gap-1"
                      >
                        <Plus className="h-4 w-4" /> Provision Identity
                      </button>
                    </form>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>

      {/* Connect GitHub Repository Modal Overlay */}
      {isConnectRepoModalOpen && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-md w-full overflow-hidden"
          >
            <div className="px-6 py-4 bg-slate-900 text-white flex justify-between items-center">
              <h3 className="text-sm font-bold">Connect GitHub Repository</h3>
              <button
                onClick={() => setIsConnectRepoModalOpen(false)}
                className="text-slate-400 hover:text-white font-bold font-mono text-xs"
              >
                ✕
              </button>
            </div>
            <form onSubmit={handleConnectRepo} className="p-6 space-y-4">
              <div>
                <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">GitHub Owner / Org</label>
                <input
                  type="text"
                  required
                  value={newRepoOwner}
                  onChange={(e) => setNewRepoOwner(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                  placeholder="enterprise-org"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Repository Name</label>
                <input
                  type="text"
                  required
                  value={newRepoName}
                  onChange={(e) => setNewRepoName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                  placeholder="core-payment-api"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Brief Description</label>
                <input
                  type="text"
                  value={newRepoDesc}
                  onChange={(e) => setNewRepoDesc(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                  placeholder="Core enterprise transaction handler"
                />
              </div>
              <div>
                <label className="block text-[10px] text-slate-500 uppercase tracking-wider font-bold mb-1">Primary Programming Language</label>
                <select
                  value={newRepoLanguage}
                  onChange={(e) => setNewRepoLanguage(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800"
                >
                  <option value="Java">Java 21</option>
                  <option value="TypeScript">TypeScript</option>
                  <option value="Python">Python</option>
                  <option value="Go">Go Programming</option>
                </select>
              </div>
              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setIsConnectRepoModalOpen(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-xl text-xs transition"
                >
                  Connect Integration
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* Custom Toast Notification Overlay */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 max-w-sm w-full animate-bounce">
          <div className={`p-4 rounded-xl border shadow-lg flex items-center gap-3 backdrop-blur-md ${
            toast.type === "error"
              ? "bg-rose-900/90 text-rose-100 border-rose-700/50"
              : toast.type === "success"
              ? "bg-emerald-900/90 text-emerald-100 border-emerald-700/50"
              : "bg-slate-800/90 text-slate-100 border-slate-700/50"
          }`}>
            <ShieldAlert className="h-5 w-5 shrink-0" />
            <div className="text-xs font-semibold">{toast.message}</div>
          </div>
        </div>
      )}
    </div>
  );
}
