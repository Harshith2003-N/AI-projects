export interface Blueprint {
  id: string;
  name: string;
  filePath: string;
  language: string;
  description: string;
  code: string;
}

export const blueprints: Blueprint[] = [
  {
    id: "pom",
    name: "Maven Dependencies",
    filePath: "backend/pom.xml",
    language: "xml",
    description: "Spring Boot 3, Spring Security JWT, Postgres JDBC, Flyway, and Redis Starter coordinates.",
    code: `<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" ...>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.4</version>
    </parent>
    <groupId>com.codereview</groupId>
    <artifactId>assistant</artifactId>
    <version>1.0.0</version>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <scope>runtime</scope>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-redis</artifactId>
        </dependency>
        <dependency>
            <groupId>io.jsonwebtoken</groupId>
            <artifactId>jjwt-api</artifactId>
            <version>0.12.5</version>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
        </dependency>
    </dependencies>
</project>`
  },
  {
    id: "security",
    name: "Spring Security Auth",
    filePath: "backend/src/.../config/SecurityConfig.java",
    language: "java",
    description: "Configures stateless JWT token filters, path authentication bounds, and safe CORS policies.",
    code: `package com.codereview.assistant.config;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                .anyRequest().authenticated()
            )
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}`
  },
  {
    id: "jwt",
    name: "JWT Claim Tokenizer",
    filePath: "backend/src/.../config/JwtTokenProvider.java",
    language: "java",
    description: "Generates, decrypts, and cryptographically signs secure SHA-256 JWT claims with user credentials.",
    code: `package com.codereview.assistant.config;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import javax.crypto.SecretKey;

@Component
public class JwtTokenProvider {

    private final SecretKey key;
    private final long expirationMs;

    public String generateToken(String email, String role) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + expirationMs);

        return Jwts.builder()
                .subject(email)
                .claim("role", role)
                .issuedAt(now)
                .expiration(expiryDate)
                .signWith(key, Jwts.SIG.HS256)
                .compact();
    }

    public boolean validateToken(String token) {
        try {
            Jwts.parser().verifyWith(key).build().parseSignedClaims(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}`
  },
  {
    id: "schema",
    name: "PostgreSQL Database Schema",
    filePath: "backend/src/resources/db/migration/V1__init_schema.sql",
    language: "sql",
    description: "Flyway schema establishing standard enterprise constraints, primary UUID generators, and search indexing.",
    code: `-- Create Repositories table
CREATE TABLE repositories (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    owner VARCHAR(255) NOT NULL,
    description TEXT,
    language VARCHAR(100),
    score INT DEFAULT 100,
    connected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_owner_repo UNIQUE (owner, name)
);

-- Create Code Reviews table
CREATE TABLE code_reviews (
    id UUID PRIMARY KEY,
    repository_id UUID REFERENCES repositories(id) ON DELETE CASCADE,
    file_path VARCHAR(512) NOT NULL,
    branch VARCHAR(100) NOT NULL,
    score INT NOT NULL,
    summary TEXT,
    vulnerabilities JSONB,
    performance JSONB,
    code_smells JSONB,
    reviewed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_code_reviews_repo_id ON code_reviews(repository_id);
CREATE INDEX idx_code_reviews_score ON code_reviews(score);`
  },
  {
    id: "service",
    name: "AI Static Analyzer Service",
    filePath: "backend/src/.../service/AiReviewService.java",
    language: "java",
    description: "The core service integrating Spring RestTemplate and Jackson to post requests and enforce JSON schemas on Gemini output.",
    code: `package com.codereview.assistant.service;

import com.codereview.assistant.model.CodeReview;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class AiReviewService {

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    public CodeReview executeAnalysis(String sourceCode, String filePath, String branch) {
        String prompt = buildPrompt(sourceCode, filePath, branch);
        String requestUrl = String.format("%s/%s:generateContent?key=%s", endpointUrl, modelName, apiKey);
        
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            
            Map<String, Object> payload = buildPayload(prompt);
            HttpEntity<Map<String, Object>> request = new HttpEntity<>(payload, headers);
            
            ResponseEntity<String> response = restTemplate.postForEntity(requestUrl, request, String.class);
            if (response.getStatusCode() == HttpStatus.OK) {
                return parseAiResponse(response.getBody());
            }
        } catch (Exception e) {
            return executeFallbackAnalysis(sourceCode, filePath, branch);
        }
        return executeFallbackAnalysis(sourceCode, filePath, branch);
    }
}`
  },
  {
    id: "docker",
    name: "Docker Container Blueprints",
    filePath: "backend/Dockerfile & docker-compose.yml",
    language: "yaml",
    description: "Multi-stage alpine compiler build alongside composite database and caching architectures.",
    code: `# backend/Dockerfile
FROM maven:3.9.6-eclipse-temurin-21-alpine AS build
WORKDIR /app
COPY . .
RUN mvn package -DskipTests

FROM eclipse-temurin:21-jre-alpine AS runtime
WORKDIR /app
COPY --from=build /app/target/assistant-1.0.0.jar app.jar
ENTRYPOINT ["java", "-jar", "app.jar"]

# docker-compose.yml
version: '3.8'
services:
  postgres-db:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: review_db
  redis-cache:
    image: redis:7-alpine
  backend-service:
    build: .
    ports:
      - "8080:8080"`
  }
];
