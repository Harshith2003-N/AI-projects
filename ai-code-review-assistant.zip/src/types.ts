export interface User {
  id: number;
  name: string;
  email: string;
  role: string;
  token?: string;
}

export interface Repository {
  id: string;
  name: string;
  owner: string;
  description: string;
  language: string;
  defaultBranch: string;
  branches: string[];
  score: number;
}

export interface IssueItem {
  title: string;
  line: number;
  description: string;
  fix: string;
}

export interface Vulnerability extends IssueItem {
  severity: "HIGH" | "MEDIUM" | "LOW";
}

export interface CodeReview {
  id: string;
  repositoryId: string;
  repositoryName: string;
  filePath: string;
  branch: string;
  reviewer: string;
  date: string;
  score: number;
  summary: string;
  vulnerabilities: Vulnerability[] | string;
  performance: IssueItem[] | string;
  codeSmells: IssueItem[] | string;
  bestPractices: IssueItem[] | string;
}

export interface ApiUsage {
  date: string;
  prompt: number;
  response: number;
  requests: number;
}

export interface ApiMetrics {
  requestsTotal: number;
  tokensPrompt: number;
  tokensResponse: number;
  costEstimated: number;
  dailyUsage: ApiUsage[];
}

export interface AdminStats {
  metrics: ApiMetrics;
  users: User[];
  reviewsCount: number;
}
