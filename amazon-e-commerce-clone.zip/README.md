# Amazon E-Commerce Enterprise Clone

A production-level full-stack **Amazon E-Commerce Clone** featuring real-time catalog filtering, multi-vendor seller capabilities, administrative business analytics, secure role-based permissions, printable billing invoices, and a robust **Java 21 / Spring Boot 3.3** backend codebase reference with Docker & Redis cache bindings.

---

## 🛠️ Architecture & Technology Stack

The project follows a decoupled, **clean architecture** model:

| Layer | Technology | Details |
| :--- | :--- | :--- |
| **Frontend SPA** | React 19, Vite, Tailwind CSS, Motion | Pixel-perfect Amazon Slate Theme, responsive layout filters, active order checkout pipelines, and interactive developer diagnostics. |
| **Live API Backend** | Node.js Express (TypeScript) | Full server-side proxy handling JWT handshakes, category catalogs, product lists with cursor paging, wishlist/cart synchronizations, review write-backs, and sales tallies. |
| **Java Microservice** | Java 21, Spring Boot 3.3 | Enterprise-ready e-commerce engine configured with Spring Security, Spring JPA, Redis Templates, and Springdoc Swagger OpenAPI documentation. |
| **Storage & Caching** | PostgreSQL 16, Redis Cache | Relational normalization, indexing of lookup foreign keys, database transaction write-locks, and fast caching of product catalogs. |
| **Container Routing** | Docker, Docker Compose | Isolated multi-tier bridge networks, healthcheck states, and persistent storage volumes. |

---

## 📂 Project Directory Structure

```text
├── /                         # Workspace Root
│   ├── /src                  # React 19 Frontend Modules
│   │   ├── /components       # Modular reusable UI components
│   │   │   ├── Navigation.tsx         # Header search, account tags & role switcher
│   │   │   ├── ProductCard.tsx        # Styled market cards with ratings & stocks
│   │   │   ├── ProductDetailModal.tsx # Item descriptions, reviews & writing portal
│   │   │   ├── CheckoutModal.tsx      # Multi-step checkout & promo codes validation
│   │   │   ├── InvoiceViewer.tsx      # Printable retail packing list sheets
│   │   │   ├── SellerDashboard.tsx    # Multi-vendor listed warehouse inventory CENTRAL
│   │   │   ├── AdminDashboard.tsx     # Sales growth charts, category editors & coupons
│   │   │   └── ArchitectureViewer.tsx # Interactive PostgreSQL ERD & Swagger playground
│   │   ├── App.tsx           # Main core state and view controller
│   │   ├── types.ts          # Shared TypeScript interfaces & types
│   │   └── index.css         # Tailwind global style bindings
│   ├── /springboot-backend   # Enterprise Spring Boot Backend
│   │   ├── /src/main/java    # Java 21 Source Trees
│   │   │   └── /com/amazon/clone
│   │   │       ├── /controller  # REST Endpoints mapped with Swagger operations
│   │   │       ├── /exception   # Standardized Global HTTP exception managers
│   │   │       ├── /service     # Transactional checkout and Redis cache evictions
│   │   │       └── /repository  # Spring Data JPA Hibernate interfaces
│   │   ├── /src/main/resources
│   │   │   └── application.properties # PostgreSQL, Redis, and JWT credentials
│   │   ├── /src/test/java    # Mockito unit testing suites
│   │   ├── schema.sql        # Normalised SQL DDL schema & seed records
│   │   ├── Dockerfile        # Multi-stage optimized builder JRE alpine runner
│   │   ├── docker-compose.yml# Container orchestration spec sheets
│   │   └── pom.xml           # Maven dependency schema file
│   └── server.ts             # Express server executing real live APIs on port 3000
```

---

## 📦 Docker Container Setup & Deployment

Ensure you have **Docker** and **Docker Compose** installed on your host system.

### 1. Launch Services
Deploy the full e-commerce environment (PostgreSQL db, Redis caching layer, and Spring Boot application) with a single command:
```bash
cd springboot-backend
docker-compose up --build -d
```

### 2. Verify Container Health
Check the container health parameters:
```bash
docker-compose ps
```

### 3. Inspect Relational PostgreSQL Data
Connect to the Postgres client:
```bash
docker exec -it amazon-postgres psql -U amazon_user -d amazon_clone_db
```

### 4. Stop Services
Shut down the stack and preserve cached storage volumes:
```bash
docker-compose down
```

---

## 📚 API Endpoint Reference (Swagger Specifications)

When the backend Spring Boot app is running on `localhost:8080`, navigate to **`http://localhost:8080/swagger-ui.html`** to access the interactive OpenAPI console.

### 🗝️ Authentication & Roles
Default sandbox logins (all passwords are `password`):
- **Customer**: `customer@amazon.com` (Role: `CUSTOMER`)
- **Seller**: `seller@amazon.com` (Role: `SELLER`)
- **Admin**: `admin@amazon.com` (Role: `ADMIN`)

---

## 🧪 Unit & Integration Testing

The backend contains extensive unit tests under Mockito frameworks to guarantee e-commerce business integrity. Run the testing suite using:
```bash
cd springboot-backend
mvn clean test
```

*Includes mocks for `OrderRepository`, `ProductRepository`, `CouponRepository`, and `RedisTemplate` validating transactional checks, discount percentage rules, and inventory shortages.*
