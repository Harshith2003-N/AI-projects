import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { User, Product, Category, Order, Review, Coupon, SalesAnalytics, UserRole } from "./src/types";

const app = express();
const PORT = 3000;

app.use(express.json());

// ==========================================
// MOCK DATABASE STATE (In-Memory)
// ==========================================

const USERS: User[] = [
  { id: "u-1", email: "customer@amazon.com", name: "John Doe", role: "CUSTOMER" },
  { id: "u-2", email: "seller@amazon.com", name: "Apex Tech Seller", role: "SELLER" },
  { id: "u-3", email: "admin@amazon.com", name: "Primary Administrator", role: "ADMIN" }
];

const CATEGORIES: Category[] = [
  { id: "cat-1", name: "Electronics", icon: "Tv", productCount: 5 },
  { id: "cat-2", name: "Fashion", icon: "Shirt", productCount: 3 },
  { id: "cat-3", name: "Home & Kitchen", icon: "Home", productCount: 3 },
  { id: "cat-4", name: "Books", icon: "BookOpen", productCount: 2 },
  { id: "cat-5", name: "Sports & Outdoors", icon: "Flame", productCount: 2 }
];

let PRODUCTS: Product[] = [
  {
    id: "p-1",
    title: "Sony WH-1000XM4 Wireless Noise Canceling Headphones",
    description: "Industry-leading noise canceling with Dual Noise Sensor technology. Next-level music with Edge-AI. Up to 30-hour battery life with quick charging (10 min charge for 5 hours playback). Touch sensor controls to pause play skip tracks, control volume, activate your voice assistant, and answer phone calls.",
    price: 278.00,
    originalPrice: 349.99,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80",
    category: "Electronics",
    rating: 4.8,
    reviewsCount: 1420,
    inventoryCount: 45,
    sellerId: "u-2",
    sellerName: "Apex Tech Seller"
  },
  {
    id: "p-2",
    title: "Apple MacBook Pro 14-inch (M3 Chip)",
    description: "Striking 14.2-inch Liquid Retina XDR display with extreme dynamic range and contrast. Supercharged by M3 chip with an 8-core CPU and 10-core GPU. Up to 22 hours of battery life. Built for developers, designers, and creators.",
    price: 1599.00,
    originalPrice: 1799.00,
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=600&q=80",
    category: "Electronics",
    rating: 4.9,
    reviewsCount: 822,
    inventoryCount: 12,
    sellerId: "u-2",
    sellerName: "Apex Tech Seller"
  },
  {
    id: "p-3",
    title: "Kindle Paperwhite (16 GB)",
    description: "Now with a 6.8” display and thinner borders, adjustable warm light, up to 10 weeks of battery life, and 20% faster page turns. Purpose-built for reading with a flush-front design and 300 ppi glare-free display that reads like real paper, even in bright sunlight.",
    price: 149.99,
    image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=600&q=80",
    category: "Books",
    rating: 4.7,
    reviewsCount: 2310,
    inventoryCount: 88,
    sellerId: "u-2",
    sellerName: "Apex Tech Seller"
  },
  {
    id: "p-4",
    title: "Instant Pot Duo 7-in-1 Electric Pressure Cooker",
    description: "7-in-1 functionality: pressure cook, slow cook, rice cooker, yogurt maker, steams, sauté pan, and food warmer. Fast or slow with smart one-touch programs. Quick and easy clean-up with fingerprint-resistant stainless steel sides and dishwasher-safe lid, inner pot, and accessories.",
    price: 89.00,
    originalPrice: 99.99,
    image: "https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?auto=format&fit=crop&w=600&q=80",
    category: "Home & Kitchen",
    rating: 4.6,
    reviewsCount: 945,
    inventoryCount: 25,
    sellerId: "u-2",
    sellerName: "Apex Tech Seller"
  },
  {
    id: "p-5",
    title: "Nike Air Max Pulse Sneakers",
    description: "The Air Max Pulse pulls inspiration from the London music scene, bringing an underground touch to the iconic Air Max line. Its textile-wrapped midsole and point-loaded cushioning delivers a bounce that pushes limits.",
    price: 150.00,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80",
    category: "Fashion",
    rating: 4.5,
    reviewsCount: 310,
    inventoryCount: 18,
    sellerId: "u-2",
    sellerName: "Apex Tech Seller"
  },
  {
    id: "p-6",
    title: "Ergonomic High-Back Office Chair",
    description: "Adjustable 3D armrests, dynamic lumbar support, high breathability mesh, and premium gas lift. Designed to promote comfortable, healthy posture during long hours at your desk.",
    price: 219.00,
    originalPrice: 289.00,
    image: "https://images.unsplash.com/photo-1505797149-43b0069ec26b?auto=format&fit=crop&w=600&q=80",
    category: "Home & Kitchen",
    rating: 4.4,
    reviewsCount: 423,
    inventoryCount: 4,
    sellerId: "u-2",
    sellerName: "Apex Tech Seller"
  },
  {
    id: "p-7",
    title: "Clean Code: A Handbook of Agile Software Craftsmanship",
    description: "Even bad code can function. But if code isn't clean, it can bring a development organization to its knees. Every year, countless hours and significant resources are lost because of poorly written code. Relied on by software engineering experts worldwide.",
    price: 42.50,
    originalPrice: 49.99,
    image: "https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&w=600&q=80",
    category: "Books",
    rating: 4.9,
    reviewsCount: 512,
    inventoryCount: 150,
    sellerId: "u-2",
    sellerName: "Apex Tech Seller"
  },
  {
    id: "p-8",
    title: "Polaroid Now+ Gen 2 Instant Camera",
    description: "The app-connected analog instant camera that gives you more creative control. Get 5 lens filters, double exposure, light painting, manual control, and a self-timer. Rechargeable with USB-C and compatible with i-Type & 600 film.",
    price: 129.00,
    originalPrice: 149.99,
    image: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&w=600&q=80",
    category: "Electronics",
    rating: 4.3,
    reviewsCount: 188,
    inventoryCount: 14,
    sellerId: "u-2",
    sellerName: "Apex Tech Seller"
  },
  {
    id: "p-9",
    title: "NordicTrack Adjustable Dumbbells (Pair)",
    description: "Replace 30 individual dumbbells with 1 pair of compact, high-quality steel weight selectors. Adjusts seamlessly from 10 to 55 lbs, fitted with durable, non-slip handles and soft-grip ergonomics.",
    price: 329.00,
    originalPrice: 399.00,
    image: "https://images.unsplash.com/photo-1638536532686-d610adfc8e5c?auto=format&fit=crop&w=600&q=80",
    category: "Sports & Outdoors",
    rating: 4.7,
    reviewsCount: 289,
    inventoryCount: 8,
    sellerId: "u-2",
    sellerName: "Apex Tech Seller"
  }
];

let REVIEWS: Review[] = [
  { id: "r-1", productId: "p-1", username: "Alice Smith", rating: 5, comment: "Absolutely incredible noise cancellation! Best purchase of the year.", date: "2026-06-15" },
  { id: "r-2", productId: "p-1", username: "Bob Jones", rating: 4, comment: "Super comfortable for long flights, but the mic is just average.", date: "2026-06-20" },
  { id: "r-3", productId: "p-2", username: "TechGuru", rating: 5, comment: "The M3 chip handles all my Docker containers and compilation like a hot knife through butter. XDR screen is breathtaking.", date: "2026-07-01" },
  { id: "r-4", productId: "p-4", username: "ChefDave", rating: 4, comment: "Saves me so much time cooking stews and rice. Solid build quality.", date: "2026-05-10" }
];

let ORDERS: Order[] = [
  {
    id: "o-101",
    userId: "u-1",
    date: "2026-07-10T14:30:00Z",
    items: [
      { productId: "p-1", title: "Sony WH-1000XM4 Wireless Noise Canceling Headphones", price: 278.00, image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80", quantity: 1 }
    ],
    subtotal: 278.00,
    discount: 27.80, // 10% coupon applied
    tax: 20.02,
    total: 270.22,
    status: "DELIVERED",
    invoiceNumber: "INV-2026-0001",
    shippingAddress: {
      fullName: "John Doe",
      street: "123 Main Street, Apt 4B",
      city: "New York",
      zipCode: "10001",
      country: "United States"
    },
    paymentMethod: "Visa ending in 4242"
  },
  {
    id: "o-102",
    userId: "u-1",
    date: "2026-07-12T09:15:00Z",
    items: [
      { productId: "p-4", title: "Instant Pot Duo 7-in-1 Electric Pressure Cooker", price: 89.00, image: "https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?auto=format&fit=crop&w=600&q=80", quantity: 1 },
      { productId: "p-7", title: "Clean Code: A Handbook of Agile Software Craftsmanship", price: 42.50, image: "https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&w=600&q=80", quantity: 1 }
    ],
    subtotal: 131.50,
    discount: 0,
    tax: 10.52,
    total: 142.02,
    status: "SHIPPED",
    invoiceNumber: "INV-2026-0002",
    shippingAddress: {
      fullName: "John Doe",
      street: "123 Main Street, Apt 4B",
      city: "New York",
      zipCode: "10001",
      country: "United States"
    },
    paymentMethod: "Mastercard ending in 9876"
  }
];

const WISHLIST: { [userId: string]: string[] } = {
  "u-1": ["p-3", "p-5"]
};

const COUPONS: Coupon[] = [
  { code: "SAVE10", discountPercentage: 10, minSpend: 0, active: true },
  { code: "AMAZON20", discountPercentage: 20, minSpend: 50, active: true },
  { code: "BIGDEAL", discountPercentage: 50, minSpend: 150, active: true }
];

// ==========================================
// SECURITY & AUTHENTICATION MIDDLEWARE
// ==========================================

const getAuthUser = (req: express.Request): User | null => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) return null;
  const token = authHeader.split(" ")[1];
  
  if (token === "jwt-customer") return USERS[0];
  if (token === "jwt-seller") return USERS[1];
  if (token === "jwt-admin") return USERS[2];
  
  // Dynamic register token matching or fallback
  const userByEmail = USERS.find(u => `token-${u.email}` === token);
  return userByEmail || null;
};

const requireRole = (roles: UserRole[]) => {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const user = getAuthUser(req);
    if (!user) {
      return res.status(401).json({ error: "Unauthorized. Missing or invalid Bearer Token." });
    }
    if (!roles.includes(user.role)) {
      return res.status(403).json({ error: `Forbidden. Requires role: ${roles.join(" or ")}` });
    }
    next();
  };
};

// ==========================================
// REST ENDPOINTS
// ==========================================

// 1. AUTHENTICATION
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  // Find user
  const user = USERS.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!user) {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  // Simple hardcoded check for demo
  if (password !== "password") {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  // Generate mock JWT
  let token = "jwt-customer";
  if (user.role === "SELLER") token = "jwt-seller";
  if (user.role === "ADMIN") token = "jwt-admin";

  res.json({
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    token: token
  });
});

app.post("/api/auth/register", (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name || !email || !password || !role) {
    return res.status(400).json({ error: "Name, email, password, and role are required." });
  }

  if (USERS.some(u => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(400).json({ error: "A user with this email already exists." });
  }

  const newUser: User = {
    id: `u-${Date.now()}`,
    name,
    email,
    role: role as UserRole
  };

  USERS.push(newUser);

  res.json({
    id: newUser.id,
    email: newUser.email,
    name: newUser.name,
    role: newUser.role,
    token: `token-${newUser.email}`
  });
});

// 2. CATEGORIES
app.get("/api/categories", (req, res) => {
  res.json(CATEGORIES);
});

app.post("/api/categories", requireRole(["ADMIN"]), (req, res) => {
  const { name, icon } = req.body;
  if (!name) return res.status(400).json({ error: "Category name is required." });

  const newCat: Category = {
    id: `cat-${Date.now()}`,
    name,
    icon: icon || "Tag",
    productCount: 0
  };

  CATEGORIES.push(newCat);
  res.status(201).json(newCat);
});

// 3. PRODUCTS
app.get("/api/products", (req, res) => {
  const { search, category, sort, page = "1", limit = "10" } = req.query;

  let filtered = [...PRODUCTS];

  // Filter by category
  if (category && category !== "All") {
    filtered = filtered.filter(p => p.category.toLowerCase() === (category as string).toLowerCase());
  }

  // Filter by search query
  if (search) {
    const q = (search as string).toLowerCase();
    filtered = filtered.filter(p => 
      p.title.toLowerCase().includes(q) || 
      p.description.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q)
    );
  }

  // Sorting
  if (sort === "price-asc") {
    filtered.sort((a, b) => a.price - b.price);
  } else if (sort === "price-desc") {
    filtered.sort((a, b) => b.price - a.price);
  } else if (sort === "rating") {
    filtered.sort((a, b) => b.rating - a.rating);
  } else {
    // Relevance / default
    filtered.sort((a, b) => b.reviewsCount - a.reviewsCount);
  }

  // Pagination
  const pNum = parseInt(page as string, 10);
  const lNum = parseInt(limit as string, 10);
  const total = filtered.length;
  const startIndex = (pNum - 1) * lNum;
  const paginated = filtered.slice(startIndex, startIndex + lNum);

  res.json({
    products: paginated,
    pagination: {
      totalItems: total,
      totalPages: Math.ceil(total / lNum),
      currentPage: pNum,
      limit: lNum
    }
  });
});

app.get("/api/products/:id", (req, res) => {
  const product = PRODUCTS.find(p => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: "Product not found." });

  const productReviews = REVIEWS.filter(r => r.productId === req.params.id);
  res.json({ ...product, reviews: productReviews });
});

// Create product (Seller/Admin)
app.post("/api/products", requireRole(["SELLER", "ADMIN"]), (req, res) => {
  const user = getAuthUser(req)!;
  const { title, description, price, originalPrice, image, category, inventoryCount } = req.body;

  if (!title || !description || price === undefined || !category || inventoryCount === undefined) {
    return res.status(400).json({ error: "Missing required fields (title, description, price, category, inventoryCount)." });
  }

  const newProduct: Product = {
    id: `p-${Date.now()}`,
    title,
    description,
    price: Number(price),
    originalPrice: originalPrice ? Number(originalPrice) : undefined,
    image: image || "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80",
    category,
    rating: 5.0,
    reviewsCount: 0,
    inventoryCount: Number(inventoryCount),
    sellerId: user.id,
    sellerName: user.name
  };

  PRODUCTS.push(newProduct);

  // Update product count in category
  const cat = CATEGORIES.find(c => c.name.toLowerCase() === category.toLowerCase());
  if (cat) cat.productCount++;

  res.status(201).json(newProduct);
});

// Update product (Seller/Admin)
app.put("/api/products/:id", requireRole(["SELLER", "ADMIN"]), (req, res) => {
  const user = getAuthUser(req)!;
  const productIndex = PRODUCTS.findIndex(p => p.id === req.params.id);
  
  if (productIndex === -1) return res.status(404).json({ error: "Product not found." });
  
  const product = PRODUCTS[productIndex];

  // Sellers can only edit their own products
  if (user.role === "SELLER" && product.sellerId !== user.id) {
    return res.status(403).json({ error: "Forbidden. You can only edit your own products." });
  }

  const { title, description, price, originalPrice, image, category, inventoryCount } = req.body;

  PRODUCTS[productIndex] = {
    ...product,
    title: title !== undefined ? title : product.title,
    description: description !== undefined ? description : product.description,
    price: price !== undefined ? Number(price) : product.price,
    originalPrice: originalPrice !== undefined ? Number(originalPrice) : product.originalPrice,
    image: image !== undefined ? image : product.image,
    category: category !== undefined ? category : product.category,
    inventoryCount: inventoryCount !== undefined ? Number(inventoryCount) : product.inventoryCount
  };

  res.json(PRODUCTS[productIndex]);
});

// Delete product
app.delete("/api/products/:id", requireRole(["SELLER", "ADMIN"]), (req, res) => {
  const user = getAuthUser(req)!;
  const product = PRODUCTS.find(p => p.id === req.params.id);
  
  if (!product) return res.status(404).json({ error: "Product not found." });

  if (user.role === "SELLER" && product.sellerId !== user.id) {
    return res.status(403).json({ error: "Forbidden. You can only delete your own products." });
  }

  PRODUCTS = PRODUCTS.filter(p => p.id !== req.params.id);

  // Decrement product count
  const cat = CATEGORIES.find(c => c.name.toLowerCase() === product.category.toLowerCase());
  if (cat && cat.productCount > 0) cat.productCount--;

  res.json({ message: "Product successfully deleted." });
});

// 4. WISHLIST
app.get("/api/wishlist", (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.json([]); // Return empty for guest

  const ids = WISHLIST[user.id] || [];
  const items = PRODUCTS.filter(p => ids.includes(p.id));
  res.json(items);
});

app.post("/api/wishlist/toggle", (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: "Unauthorized." });

  const { productId } = req.body;
  if (!productId) return res.status(400).json({ error: "Product ID required." });

  if (!WISHLIST[user.id]) {
    WISHLIST[user.id] = [];
  }

  const index = WISHLIST[user.id].indexOf(productId);
  let added = false;
  if (index > -1) {
    WISHLIST[user.id].splice(index, 1);
  } else {
    WISHLIST[user.id].push(productId);
    added = true;
  }

  res.json({ added, wishlist: WISHLIST[user.id] });
});

// 5. COUPON VALIDATION & MANAGEMENT
app.get("/api/coupons", (req, res) => {
  res.json(COUPONS);
});

app.post("/api/coupons", requireRole(["ADMIN"]), (req, res) => {
  const { code, discountPercentage, minSpend } = req.body;
  if (!code || !discountPercentage) {
    return res.status(400).json({ error: "Coupon code and discount percentage are required." });
  }

  const cleanCode = code.trim().toUpperCase();
  if (COUPONS.some(c => c.code === cleanCode)) {
    return res.status(400).json({ error: "Coupon code already exists." });
  }

  const newCoupon: Coupon = {
    code: cleanCode,
    discountPercentage: Number(discountPercentage),
    minSpend: minSpend ? Number(minSpend) : 0,
    active: true
  };

  COUPONS.push(newCoupon);
  res.status(201).json(newCoupon);
});

app.patch("/api/coupons/:code/toggle", requireRole(["ADMIN"]), (req, res) => {
  const code = req.params.code.toUpperCase();
  const coupon = COUPONS.find(c => c.code === code);

  if (!coupon) {
    return res.status(404).json({ error: "Coupon not found." });
  }

  coupon.active = !coupon.active;
  res.json(coupon);
});

app.get("/api/coupons/validate/:code", (req, res) => {
  const code = req.params.code.toUpperCase();
  const coupon = COUPONS.find(c => c.code === code && c.active);

  if (!coupon) {
    return res.status(404).json({ error: "Invalid or expired coupon code." });
  }

  res.json(coupon);
});

// 6. CART OPERATIONS (Serviced client-side with simple sync fallback)
app.post("/api/orders", (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: "Unauthorized." });

  const { items, shippingAddress, paymentMethod, couponCode } = req.body;

  if (!items || items.length === 0 || !shippingAddress) {
    return res.status(400).json({ error: "Invalid order payload (missing items or shippingAddress)." });
  }

  // Validate items & Inventory checks
  let subtotal = 0;
  const orderItems = [];

  for (const item of items) {
    const product = PRODUCTS.find(p => p.id === item.productId);
    if (!product) {
      return res.status(400).json({ error: `Product not found: ${item.productId}` });
    }

    if (product.inventoryCount < item.quantity) {
      return res.status(400).json({ error: `Insufficient inventory for ${product.title}. Only ${product.inventoryCount} left.` });
    }

    // Deduct inventory
    product.inventoryCount -= item.quantity;

    const itemPrice = product.price;
    subtotal += itemPrice * item.quantity;

    orderItems.push({
      productId: product.id,
      title: product.title,
      price: itemPrice,
      image: product.image,
      quantity: item.quantity
    });
  }

  // Coupon processing
  let discount = 0;
  if (couponCode) {
    const coupon = COUPONS.find(c => c.code === couponCode.toUpperCase() && c.active);
    if (coupon && subtotal >= coupon.minSpend) {
      discount = Math.round((subtotal * coupon.discountPercentage) / 100 * 100) / 100;
    }
  }

  const tax = Math.round((subtotal - discount) * 0.08 * 100) / 100; // 8% tax
  const total = Math.round((subtotal - discount + tax) * 100) / 100;

  const invoiceNum = `INV-2026-${String(ORDERS.length + 1).padStart(4, "0")}`;

  const newOrder: Order = {
    id: `o-${Date.now()}`,
    userId: user.id,
    date: new Date().toISOString(),
    items: orderItems,
    subtotal,
    discount,
    tax,
    total,
    status: "PENDING",
    invoiceNumber: invoiceNum,
    shippingAddress,
    paymentMethod: paymentMethod || "Credit Card ending in 4242"
  };

  ORDERS.unshift(newOrder); // Add to beginning

  res.status(201).json(newOrder);
});

app.get("/api/orders", (req, res) => {
  const user = getAuthUser(req);
  if (!user) return res.status(401).json({ error: "Unauthorized." });

  // Customers see their own orders. Admin and Sellers see matching items.
  if (user.role === "ADMIN") {
    return res.json(ORDERS);
  } else if (user.role === "SELLER") {
    // Filter orders containing this seller's products
    const sellerOrders = ORDERS.map(order => {
      const sellerItems = order.items.filter(item => {
        const prod = PRODUCTS.find(p => p.id === item.productId);
        return prod?.sellerId === user.id;
      });
      if (sellerItems.length === 0) return null;
      
      const sub = sellerItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      return {
        ...order,
        items: sellerItems,
        total: sub, // seller portion
        subtotal: sub,
        discount: 0,
        tax: 0
      };
    }).filter(Boolean);
    return res.json(sellerOrders);
  } else {
    // CUSTOMER
    const myOrders = ORDERS.filter(o => o.userId === user.id);
    res.json(myOrders);
  }
});

// Update Order Status
app.patch("/api/orders/:id/status", requireRole(["SELLER", "ADMIN"]), (req, res) => {
  const { status } = req.body;
  if (!status) return res.status(400).json({ error: "Status is required." });

  const order = ORDERS.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found." });

  order.status = status;
  res.json(order);
});

// 7. REVIEWS & RATINGS
app.post("/api/products/:id/reviews", (req, res) => {
  const user = getAuthUser(req);
  const username = user ? user.name : "Anonymous Amazon Customer";
  const { rating, comment } = req.body;

  if (!rating || !comment) {
    return res.status(400).json({ error: "Rating and comment are required." });
  }

  const product = PRODUCTS.find(p => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: "Product not found." });

  const newReview: Review = {
    id: `r-${Date.now()}`,
    productId: req.params.id,
    username,
    rating: Number(rating),
    comment,
    date: new Date().toISOString().split("T")[0]
  };

  REVIEWS.unshift(newReview);

  // Recalculate rating
  const pReviews = REVIEWS.filter(r => r.productId === product.id);
  const sum = pReviews.reduce((acc, r) => acc + r.rating, 0);
  product.rating = Number((sum / pReviews.length).toFixed(1));
  product.reviewsCount = pReviews.length;

  res.status(201).json(newReview);
});

// 8. SALES ANALYTICS
app.get("/api/admin/analytics", requireRole(["ADMIN", "SELLER"]), (req, res) => {
  const user = getAuthUser(req)!;
  
  // Calculate analytics
  let applicableProducts = PRODUCTS;
  let applicableOrders = ORDERS;

  if (user.role === "SELLER") {
    applicableProducts = PRODUCTS.filter(p => p.sellerId === user.id);
    applicableOrders = ORDERS.map(order => {
      const items = order.items.filter(item => {
        const p = PRODUCTS.find(prod => prod.id === item.productId);
        return p?.sellerId === user.id;
      });
      if (items.length === 0) return null;
      const subtotal = items.reduce((sum, it) => sum + (it.price * it.quantity), 0);
      return { ...order, items, total: subtotal, subtotal };
    }).filter(o => o !== null) as Order[];
  }

  const revenue = applicableOrders.reduce((sum, o) => sum + o.total, 0);
  const ordersCount = applicableOrders.length;
  const customersCount = USERS.filter(u => u.role === "CUSTOMER").length;
  
  const lowStockItemsCount = applicableProducts.filter(p => p.inventoryCount <= 5).length;

  // Monthly breakdown
  const monthlyRevenue = [
    { month: "Jan", amount: 450, orders: 3 },
    { month: "Feb", amount: 620, orders: 4 },
    { month: "Mar", amount: 980, orders: 6 },
    { month: "Apr", amount: 810, orders: 5 },
    { month: "May", amount: 1200, orders: 8 },
    { month: "Jun", amount: 1450, orders: 9 },
    { month: "Jul", amount: Number(revenue.toFixed(2)), orders: ordersCount }
  ];

  // Category Distribution
  const categoryDistribution = CATEGORIES.map(cat => {
    const catProds = applicableProducts.filter(p => p.category.toLowerCase() === cat.name.toLowerCase());
    const count = catProds.length;
    
    // Revenue in this category
    let catRev = 0;
    applicableOrders.forEach(o => {
      o.items.forEach(item => {
        const p = PRODUCTS.find(prod => prod.id === item.productId);
        if (p && p.category.toLowerCase() === cat.name.toLowerCase()) {
          catRev += item.price * item.quantity;
        }
      });
    });

    return {
      name: cat.name,
      count,
      revenue: Number(catRev.toFixed(2))
    };
  });

  // Top Products sold
  const productSalesMap: { [prodId: string]: number } = {};
  applicableOrders.forEach(o => {
    o.items.forEach(it => {
      productSalesMap[it.productId] = (productSalesMap[it.productId] || 0) + it.quantity;
    });
  });

  const topProducts = applicableProducts.map(p => {
    const sold = productSalesMap[p.id] || 0;
    return {
      title: p.title,
      price: p.price,
      sold,
      revenue: Number((sold * p.price).toFixed(2))
    };
  }).sort((a, b) => b.sold - a.sold).slice(0, 5);

  const analytics: SalesAnalytics = {
    revenue: Number(revenue.toFixed(2)),
    salesGrowth: 23.5,
    ordersCount,
    ordersGrowth: 15.2,
    customersCount,
    customersGrowth: 8.4,
    lowStockItemsCount,
    monthlyRevenue,
    categoryDistribution,
    topProducts
  };

  res.json(analytics);
});

// ==========================================
// VITE DEV SERVER OR STATIC SERVING FLOW
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
