-- ==========================================
-- AMAZON CLONE POSTGRESQL SCHEMA INITIALIZATION
-- ==========================================

-- Drop tables if exist in correct relational sequence
DROP TABLE IF EXISTS reviews CASCADE;
DROP TABLE IF EXISTS coupons CASCADE;
DROP TABLE IF EXISTS order_items CASCADE;
DROP TABLE IF EXISTS orders CASCADE;
DROP TABLE IF EXISTS wishlists CASCADE;
DROP TABLE IF EXISTS products CASCADE;
DROP TABLE IF EXISTS categories CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- 1. USERS TABLE
CREATE TABLE users (
    id VARCHAR(50) PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(512) NOT NULL,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('CUSTOMER', 'SELLER', 'ADMIN')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. CATEGORIES TABLE
CREATE TABLE categories (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(50) DEFAULT 'Tag',
    product_count INT DEFAULT 0
);

-- 3. PRODUCTS TABLE
CREATE TABLE products (
    id VARCHAR(50) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    original_price DECIMAL(10, 2),
    image_url VARCHAR(512),
    category_id VARCHAR(50) NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    inventory_count INT NOT NULL DEFAULT 0 CHECK (inventory_count >= 0),
    seller_id VARCHAR(50) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    rating DECIMAL(2, 1) DEFAULT 5.0,
    reviews_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. WISHLISTS TABLE
CREATE TABLE wishlists (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id VARCHAR(50) NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, product_id)
);

-- 5. ORDERS TABLE
CREATE TABLE orders (
    id VARCHAR(50) PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    subtotal DECIMAL(10, 2) NOT NULL,
    discount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    tax DECIMAL(10, 2) NOT NULL,
    total DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'SHIPPED', 'DELIVERED', 'CANCELLED')),
    invoice_number VARCHAR(100) NOT NULL UNIQUE,
    shipping_address TEXT NOT NULL,
    payment_method VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. ORDER ITEMS TABLE
CREATE TABLE order_items (
    id VARCHAR(50) PRIMARY KEY,
    order_id VARCHAR(50) NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id VARCHAR(50) NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0)
);

-- 7. COUPONS TABLE
CREATE TABLE coupons (
    id VARCHAR(50) PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    discount_percentage INT NOT NULL CHECK (discount_percentage BETWEEN 1 AND 99),
    min_spend DECIMAL(10, 2) DEFAULT 0.00,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. REVIEWS TABLE
CREATE TABLE reviews (
    id VARCHAR(50) PRIMARY KEY,
    product_id VARCHAR(50) NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    user_id VARCHAR(50) NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    username VARCHAR(100) NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- E-COMMERCE DATABASE PERFORMANCE INDEXING
-- ==========================================
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_seller ON products(seller_id);
CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_reviews_product ON reviews(product_id);


-- ==========================================
-- SEED DEFAULT DATASET
-- ==========================================

-- Seed Users
INSERT INTO users (id, email, password_hash, name, role) VALUES
('u-1', 'customer@amazon.com', '$2a$10$tZg/P2kYj.V0uI4NfRGe9.Yx98M40r.Gk.MszW0/rWREjXoVlD7eG', 'John Doe', 'CUSTOMER'),
('u-2', 'seller@amazon.com', '$2a$10$tZg/P2kYj.V0uI4NfRGe9.Yx98M40r.Gk.MszW0/rWREjXoVlD7eG', 'Apex Tech Seller', 'SELLER'),
('u-3', 'admin@amazon.com', '$2a$10$tZg/P2kYj.V0uI4NfRGe9.Yx98M40r.Gk.MszW0/rWREjXoVlD7eG', 'Primary Administrator', 'ADMIN');

-- Seed Categories
INSERT INTO categories (id, name, icon, product_count) VALUES
('cat-1', 'Electronics', 'Tv', 3),
('cat-2', 'Fashion', 'Shirt', 1),
('cat-3', 'Home & Kitchen', 'Home', 2),
('cat-4', 'Books', 'BookOpen', 2),
('cat-5', 'Sports & Outdoors', 'Flame', 1);

-- Seed Products
INSERT INTO products (id, title, description, price, original_price, image_url, category_id, inventory_count, seller_id, rating, reviews_count) VALUES
('p-1', 'Sony WH-1000XM4 Wireless Headphones', 'Noise canceling with Dual Noise Sensor.', 278.00, 349.99, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e', 'cat-1', 45, 'u-2', 4.8, 2),
('p-2', 'Apple MacBook Pro 14-inch (M3 Chip)', 'Striking Liquid Retina XDR.', 1599.00, 1799.00, 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8', 'cat-1', 12, 'u-2', 4.9, 1),
('p-3', 'Kindle Paperwhite (16 GB)', '6.8 display, adjustable light.', 149.99, NULL, 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c', 'cat-4', 88, 'u-2', 4.7, 0),
('p-4', 'Instant Pot Duo 7-in-1 cooker', '7-in-1 cooking functionality.', 89.00, 99.99, 'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7', 'cat-3', 25, 'u-2', 4.6, 1);

-- Seed Coupons
INSERT INTO coupons (id, code, discount_percentage, min_spend, active) VALUES
('c-1', 'SAVE10', 10, 0.00, TRUE),
('c-2', 'AMAZON20', 20, 50.00, TRUE),
('c-3', 'BIGDEAL', 50, 150.00, TRUE);

-- Seed Reviews
INSERT INTO reviews (id, product_id, user_id, username, rating, comment) VALUES
('r-1', 'p-1', 'u-1', 'Alice Smith', 5, 'Absolutely incredible noise cancellation!'),
('r-2', 'p-1', 'u-1', 'Bob Jones', 4, 'Super comfortable but average microphone.'),
('r-3', 'p-2', 'u-1', 'TechGuru', 5, 'Breathtaking developers rig!'),
('r-4', 'p-4', 'u-1', 'ChefDave', 4, 'Solid stews cooking cooker.');
