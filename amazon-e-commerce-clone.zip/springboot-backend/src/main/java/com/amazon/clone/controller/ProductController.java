package com.amazon.clone.controller;

import com.amazon.clone.dto.ProductDto;
import com.amazon.clone.dto.ProductCreateDto;
import com.amazon.clone.dto.PageResponse;
import com.amazon.clone.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/products")
@Tag(name = "Product Catalog Controller", description = "Query, paginate, and manage Amazon Marketplace items.")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    @Operation(summary = "Get paginated, filtered, and sorted products")
    public ResponseEntity<PageResponse<ProductDto>> getAllProducts(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) String category,
            @RequestParam(defaultValue = "relevance") String sort,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int limit
    ) {
        // Build sort order
        Sort sortOrder = switch (sort) {
            case "price-asc" -> Sort.by("price").ascending();
            case "price-desc" -> Sort.by("price").descending();
            case "rating" -> Sort.by("rating").descending();
            default -> Sort.by("reviewsCount").descending();
        };

        // Spring PageRequest is 0-indexed, clients send 1-indexed
        Pageable pageable = PageRequest.of(page - 1, limit, sortOrder);
        Page<ProductDto> products = productService.getProducts(search, category, pageable);

        return ResponseEntity.ok(PageResponse.fromPage(products));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get product details by ID")
    public ResponseEntity<ProductDto> getProductById(@PathVariable String id) {
        ProductDto product = productService.getProductById(id);
        return ResponseEntity.ok(product);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SELLER', 'ADMIN')")
    @Operation(summary = "Create a new product listing (Sellers/Admins only)")
    public ResponseEntity<ProductDto> createProduct(
            @Valid @RequestBody ProductCreateDto productCreateDto,
            @AuthenticationPrincipal UserDetails sellerDetails
    ) {
        ProductDto created = productService.createProduct(productCreateDto, sellerDetails.getUsername());
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('SELLER', 'ADMIN')")
    @Operation(summary = "Update an existing product listing (Seller owner or Admin only)")
    public ResponseEntity<ProductDto> updateProduct(
            @PathVariable String id,
            @Valid @RequestBody ProductCreateDto productUpdateDto,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        ProductDto updated = productService.updateProduct(id, productUpdateDto, userDetails);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('SELLER', 'ADMIN')")
    @Operation(summary = "Delete a product listing (Seller owner or Admin only)")
    public ResponseEntity<Void> deleteProduct(
            @PathVariable String id,
            @AuthenticationPrincipal UserDetails userDetails
    ) {
        productService.deleteProduct(id, userDetails);
        return ResponseEntity.noContent().build();
    }
}
