package com.amazon.clone.service;

import com.amazon.clone.dto.OrderRequest;
import com.amazon.clone.dto.OrderDto;
import com.amazon.clone.model.Order;
import com.amazon.clone.model.OrderItem;
import com.amazon.clone.model.Product;
import com.amazon.clone.model.Coupon;
import com.amazon.clone.exception.ResourceNotFoundException;
import com.amazon.clone.exception.InsufficientInventoryException;
import com.amazon.clone.repository.OrderRepository;
import com.amazon.clone.repository.ProductRepository;
import com.amazon.clone.repository.CouponRepository;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final CouponRepository couponRepository;
    private final RedisTemplate<String, Object> redisTemplate;

    public OrderService(OrderRepository orderRepository, 
                        ProductRepository productRepository, 
                        CouponRepository couponRepository,
                        RedisTemplate<String, Object> redisTemplate) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
        this.couponRepository = couponRepository;
        this.redisTemplate = redisTemplate;
    }

    @Transactional
    public OrderDto processCheckout(String userId, OrderRequest request) {
        BigDecimal subtotal = BigDecimal.ZERO;
        List<OrderItem> orderItems = new ArrayList<>();
        Order order = new Order();
        order.setId("o-" + UUID.randomUUID().toString().substring(0, 8));
        order.setUserId(userId);
        order.setDate(LocalDateTime.now());
        order.setShippingAddress(request.getShippingAddress().toString());
        order.setPaymentMethod(request.getPaymentMethod());

        // 1. Process items and decrement inventory under transactional database lock
        for (var requestItem : request.getItems()) {
            Product product = productRepository.findByIdWithLock(requestItem.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product not found with ID: " + requestItem.getProductId()));

            if (product.getInventoryCount() < requestItem.getQuantity()) {
                throw new InsufficientInventoryException("Insufficient inventory for " + product.getTitle() 
                        + ". Stock left: " + product.getInventoryCount());
            }

            // Decrement stock
            product.setInventoryCount(product.getInventoryCount() - requestItem.getQuantity());
            productRepository.save(product);

            // Accumulate prices
            BigDecimal itemTotal = product.getPrice().multiply(BigDecimal.valueOf(requestItem.getQuantity()));
            subtotal = subtotal.add(itemTotal);

            OrderItem orderItem = new OrderItem();
            orderItem.setId(UUID.randomUUID().toString());
            orderItem.setOrder(order);
            orderItem.setProduct(product);
            orderItem.setPrice(product.getPrice());
            orderItem.setQuantity(requestItem.getQuantity());
            orderItems.add(orderItem);

            // Evict product cache so customers get updated live stocks
            String cacheKey = "product::" + product.getId();
            redisTemplate.delete(cacheKey);
        }

        order.setItems(orderItems);
        order.setSubtotal(subtotal);

        // 2. Validate and apply coupon code if present
        BigDecimal discount = BigDecimal.ZERO;
        if (request.getCouponCode() != null && !request.getCouponCode().trim().isEmpty()) {
            Coupon coupon = couponRepository.findByCodeAndActiveTrue(request.getCouponCode().toUpperCase())
                    .orElseThrow(() -> new ResourceNotFoundException("Invalid or expired coupon code: " + request.getCouponCode()));

            if (subtotal.compareTo(coupon.getMinSpend()) >= 0) {
                BigDecimal multiplier = BigDecimal.valueOf(coupon.getDiscountPercentage()).divide(BigDecimal.valueOf(100));
                discount = subtotal.multiply(multiplier);
            } else {
                throw new IllegalArgumentException("Minimum spend requirement not met for promo: " + coupon.getCode());
            }
        }
        order.setDiscount(discount);

        // 3. Tax and Totals
        BigDecimal taxableAmount = subtotal.subtract(discount);
        BigDecimal tax = taxableAmount.multiply(BigDecimal.valueOf(0.08)); // 8% sales tax
        BigDecimal total = taxableAmount.add(tax);

        order.setTax(tax);
        order.setTotal(total);
        order.setStatus("PENDING");
        order.setInvoiceNumber("INV-2026-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase());

        // Save order and cascade order items
        Order savedOrder = orderRepository.save(order);

        // Clear active checkout locks and cached cart for this customer in Redis
        redisTemplate.delete("cart::" + userId);

        return OrderDto.fromEntity(savedOrder);
    }
}
