package com.amazon.clone.service;

import com.amazon.clone.dto.OrderRequest;
import com.amazon.clone.dto.OrderDto;
import com.amazon.clone.dto.OrderItemRequest;
import com.amazon.clone.model.Product;
import com.amazon.clone.model.Order;
import com.amazon.clone.model.Coupon;
import com.amazon.clone.exception.InsufficientInventoryException;
import com.amazon.clone.repository.OrderRepository;
import com.amazon.clone.repository.ProductRepository;
import com.amazon.clone.repository.CouponRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.core.RedisTemplate;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private CouponRepository couponRepository;

    @Mock
    private RedisTemplate<String, Object> redisTemplate;

    @InjectMocks
    private OrderService orderService;

    private Product testProduct;
    private OrderRequest sampleRequest;

    @BeforeEach
    void setUp() {
        // Setup Product
        testProduct = new Product();
        testProduct.setId("p-1");
        testProduct.setTitle("Sony WH-1000XM4 Wireless Headphones");
        testProduct.setPrice(BigDecimal.valueOf(278.00));
        testProduct.setInventoryCount(10);

        // Setup Checkout Request
        sampleRequest = new OrderRequest();
        OrderItemRequest item = new OrderItemRequest();
        item.setProductId("p-1");
        item.setQuantity(2);
        sampleRequest.setItems(List.of(item));
        sampleRequest.setShippingAddress("123 Main St, New York");
        sampleRequest.setPaymentMethod("Visa ending in 4242");
    }

    @Test
    void testCheckoutSuccess_ReducesStockAndCalculatesTotal() {
        // Mock DB calls
        when(productRepository.findByIdWithLock("p-1")).thenReturn(Optional.of(testProduct));
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> {
            Order o = invocation.getArgument(0);
            o.setId("o-test");
            o.setInvoiceNumber("INV-TEST-0001");
            return o;
        });

        // Execute service
        OrderDto result = orderService.processCheckout("user-1", sampleRequest);

        // Asserts
        assertNotNull(result);
        assertEquals("o-test", result.getId());
        assertEquals(8, testProduct.getInventoryCount()); // Stock reduced by 2
        assertEquals(BigDecimal.valueOf(556.00), result.getSubtotal()); // 278.00 * 2
        
        // Verify mock logs
        verify(productRepository, times(1)).save(testProduct);
        verify(redisTemplate, times(1)).delete("product::p-1");
        verify(redisTemplate, times(1)).delete("cart::user-1");
    }

    @Test
    void testCheckout_ThrowsInsufficientInventoryException_WhenStockExhausted() {
        // Configure demand > supply
        sampleRequest.getItems().getFirst().setQuantity(15); // Demand 15, stock is 10

        when(productRepository.findByIdWithLock("p-1")).thenReturn(Optional.of(testProduct));

        // Assert Exception
        assertThrows(InsufficientInventoryException.class, () -> {
            orderService.processCheckout("user-1", sampleRequest);
        });

        // Ensure database orders were NOT saved
        verify(orderRepository, never()).save(any(Order.class));
        verify(productRepository, never()).save(any(Product.class));
    }
}
