import { useState, useEffect } from "react";
import { User, Product, Category, CartItem, Order, UserRole } from "./types";
import Navigation from "./components/Navigation";
import ProductCard from "./components/ProductCard";
import ProductDetailModal from "./components/ProductDetailModal";
import CheckoutModal from "./components/CheckoutModal";
import LoginModal from "./components/LoginModal";
import InvoiceViewer from "./components/InvoiceViewer";
import SellerDashboard from "./components/SellerDashboard";
import AdminDashboard from "./components/AdminDashboard";
import ArchitectureViewer from "./components/ArchitectureViewer";
import { ShoppingBag, ChevronLeft, ChevronRight, X, Heart, Sparkles, Database, Github, Terminal, ArrowRight, ShieldCheck } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  // Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const cached = localStorage.getItem("amazon_clone_user");
    if (cached) return JSON.parse(cached);
    // Auto-login default Customer for immediate out-of-the-box experience
    const defaultUser: User = { id: "u-1", email: "customer@amazon.com", name: "John Doe", role: "CUSTOMER", token: "jwt-customer" };
    localStorage.setItem("amazon_clone_user", JSON.stringify(defaultUser));
    return defaultUser;
  });

  // Cart & Wishlist State (Client side persistent sync)
  const [cart, setCart] = useState<CartItem[]>(() => {
    const cached = localStorage.getItem("amazon_clone_cart");
    return cached ? JSON.parse(cached) : [];
  });
  const [wishlist, setWishlist] = useState<Product[]>([]);

  // Server Fetched State
  const [products, setProducts] = useState<Product[]>([]);
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  // Query & Filter routing
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [sort, setSort] = useState("relevance");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // App View Controllers
  const [activeView, setActiveView] = useState<'catalog' | 'orders' | 'architecture' | 'wishlist'>('catalog');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Modals Controller
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [activeInvoiceOrder, setActiveInvoiceOrder] = useState<Order | null>(null);

  // Loading & Feedback
  const [catalogLoading, setCatalogLoading] = useState(true);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [catalogError, setCatalogError] = useState("");
  const [notification, setNotification] = useState("");

  // Sync state modifications to cache
  useEffect(() => {
    localStorage.setItem("amazon_clone_cart", JSON.stringify(cart));
  }, [cart]);

  // Fetch product catalog from active express server with query parameters
  const fetchCatalog = async () => {
    setCatalogLoading(true);
    setCatalogError("");
    try {
      const queryParams = new URLSearchParams({
        category: selectedCategory,
        search: searchQuery,
        sort,
        page: String(page),
        limit: "8" // 8 products per page layout
      });

      const [res, allRes] = await Promise.all([
        fetch(`/api/products?${queryParams.toString()}`),
        fetch("/api/products?limit=1000")
      ]);

      if (!res.ok) throw new Error("A server network handshake occurred.");
      const data = await res.json();
      
      setProducts(data.products || []);
      setTotalPages(data.pagination?.totalPages || 1);

      if (allRes.ok) {
        const allData = await allRes.json();
        setAllProducts(allData.products || []);
      }
    } catch (err: any) {
      setCatalogError(err.message || "Failed to load e-commerce items.");
    } finally {
      setCatalogLoading(false);
    }
  };

  // Fetch categories on mount
  const fetchCategories = async () => {
    try {
      const res = await fetch("/api/categories");
      const data = await res.json();
      setCategories(data);
    } catch (err) {
      console.error("Failed to load department categories.", err);
    }
  };

  // Fetch orders from server
  const fetchOrders = async () => {
    if (!currentUser) return;
    setOrdersLoading(true);
    try {
      const res = await fetch("/api/orders", {
        headers: { "Authorization": `Bearer ${currentUser.token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setOrders(data);
      }
    } catch (err) {
      console.error("Failed to load user transactions.", err);
    } finally {
      setOrdersLoading(false);
    }
  };

  // Fetch wishlist
  const fetchWishlist = async () => {
    if (!currentUser) return;
    try {
      const res = await fetch("/api/wishlist", {
        headers: { "Authorization": `Bearer ${currentUser.token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setWishlist(data);
      }
    } catch (err) {
      console.error("Failed to load wishlist.", err);
    }
  };

  // Trigger reload workflows
  useEffect(() => {
    fetchCatalog();
  }, [selectedCategory, searchQuery, sort, page]);

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    if (currentUser) {
      fetchOrders();
      fetchWishlist();
    } else {
      setOrders([]);
      setWishlist([]);
    }
  }, [currentUser]);

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(""), 3000);
  };

  // Authentication managers
  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem("amazon_clone_user", JSON.stringify(user));
    showToast(`Signed in as ${user.name}`);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem("amazon_clone_user");
    setCart([]);
    showToast("Signed out from sandbox profile.");
  };

  const handleRoleSwitch = async (role: UserRole) => {
    if (!currentUser) return;
    
    // Switch token and role directly in current sandbox user profile
    const mapping: { [key in UserRole]: string } = {
      CUSTOMER: "jwt-customer",
      SELLER: "jwt-seller",
      ADMIN: "jwt-admin"
    };

    const updatedUser: User = {
      ...currentUser,
      role,
      token: mapping[role]
    };

    setCurrentUser(updatedUser);
    localStorage.setItem("amazon_clone_user", JSON.stringify(updatedUser));
    
    // Return to home catalog
    setActiveView("catalog");
    showToast(`Sandbox Role updated to ${role}`);
  };

  // Shopping Cart & Wishlist Actions
  const handleAddToCart = (product: Product) => {
    if (currentUser && currentUser.role !== 'CUSTOMER') {
      showToast("Access Restricted: Sellers and Admins cannot use customer cart.");
      return;
    }

    setCart(prev => {
      const existing = prev.find(item => item.productId === product.id);
      if (existing) {
        return prev.map(item => 
          item.productId === product.id 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        );
      }
      return [...prev, { productId: product.id, quantity: 1 }];
    });

    showToast(`Added "${product.title.slice(0, 30)}..." to Cart!`);
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.productId !== productId));
  };

  const handleQuantityChange = (productId: string, qty: number) => {
    if (qty <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item => 
      item.productId === productId ? { ...item, quantity: qty } : item
    ));
  };

  const handleToggleWishlist = async (product: Product) => {
    if (!currentUser) {
      setShowLoginModal(true);
      return;
    }

    try {
      const res = await fetch("/api/wishlist/toggle", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${currentUser.token}`
        },
        body: JSON.stringify({ productId: product.id })
      });

      if (res.ok) {
        const data = await res.json();
        showToast(data.added ? "Added to Wishlist!" : "Removed from Wishlist.");
        fetchWishlist();
      }
    } catch (err) {
      console.error("Failed to toggle wishlist", err);
    }
  };

  const handleOrderCompleted = (finalizedOrder: Order) => {
    setShowCheckoutModal(false);
    setCart([]); // Reset Cart
    setActiveInvoiceOrder(finalizedOrder); // Show printable receipt invoice
    fetchOrders(); // update lists
    fetchCatalog(); // replenish stock totals
  };

  // Total cart calculation
  const subtotalCartValue = cart.reduce((sum, item) => {
    const prod = allProducts.find(p => p.id === item.productId);
    return sum + (prod ? prod.price * item.quantity : 0);
  }, 0);

  return (
    <div className="min-h-screen bg-[#EAEDED] flex flex-col font-sans text-slate-800">
      
      {/* Toast Notification HUD */}
      <AnimatePresence>
        {notification && (
          <motion.div
            initial={{ opacity: 0, y: -40 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -40 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 bg-slate-900 border border-slate-700 text-amber-500 font-bold text-xs px-5 py-3 rounded-md shadow-2xl flex items-center gap-2.5 z-50 pointer-events-none"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{notification}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Nav Header */}
      <Navigation
        currentUser={currentUser}
        categories={categories}
        cart={cart}
        selectedCategory={selectedCategory}
        searchQuery={searchQuery}
        onCategoryChange={(cat) => {
          setSelectedCategory(cat);
          setPage(1);
          setActiveView("catalog");
        }}
        onSearchChange={(query) => {
          setSearchQuery(query);
          setPage(1);
          setActiveView("catalog");
        }}
        onRoleSwitch={handleRoleSwitch}
        onLogout={handleLogout}
        onLoginClick={() => setShowLoginModal(true)}
        onCartClick={() => setActiveView("catalog")} // trigger slide bar or view
        onOrdersClick={() => {
          fetchOrders();
          setActiveView("orders");
        }}
        onWishlistClick={() => {
          fetchWishlist();
          setActiveView("wishlist");
        }}
        onHomeClick={() => {
          setSelectedCategory("All");
          setSearchQuery("");
          setActiveView("catalog");
        }}
        onArchitectureClick={() => setActiveView("architecture")}
        activeView={activeView}
      />

      {/* Main app block */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 py-6">
        
        {/* VIEW 1: SELLER OR ADMIN OVERRIDE VIEWS */}
        {activeView === "catalog" && currentUser && currentUser.role === "SELLER" && (
          <SellerDashboard authToken={currentUser.token!} />
        )}

        {activeView === "catalog" && currentUser && currentUser.role === "ADMIN" && (
          <AdminDashboard authToken={currentUser.token!} />
        )}

        {/* VIEW 2: STANDARD CUSTOMER MARKETPLACE CATALOG */}
        {activeView === "catalog" && (!currentUser || currentUser.role === "CUSTOMER") && (
          <div className="space-y-6">
            
            {/* Amazon Landing Carousel Banner */}
            <div className="relative h-44 sm:h-64 rounded-lg overflow-hidden bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 flex items-center px-6 sm:px-12 shadow-md">
              <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:16px_16px]"></div>
              <div className="space-y-2 sm:space-y-4 max-w-lg relative z-10 text-white">
                <span className="text-[10px] sm:text-xs uppercase tracking-widest font-extrabold text-[#febd69] bg-[#febd69]/15 border border-[#febd69]/30 px-2.5 py-1 rounded inline-block">
                  Amazon Prime Day Deals
                </span>
                <h1 className="text-xl sm:text-3xl font-extrabold tracking-tight font-sans leading-tight">
                  Discover curated hardware tech, books, & apparel
                </h1>
                <p className="text-[11px] sm:text-xs text-slate-300 leading-normal max-w-md hidden sm:block">
                  Shop exclusive checkout coupon discounts, dynamic rating review sheets, and standard multi-role administration profiles.
                </p>
              </div>
              <div className="absolute right-0 top-0 bottom-0 w-1/2 bg-gradient-to-l from-amber-500/10 to-transparent pointer-events-none"></div>
            </div>

            {/* Catalog Grid Split: Left Filters Sidebar, Right Products Grid */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
              
              {/* Left Sidebar Filters */}
              <div className="md:col-span-3 space-y-6">
                
                {/* Department checklist */}
                <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs">
                  <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-3 border-b border-slate-100 pb-2">
                    Departments
                  </h3>
                  <div className="space-y-2 text-xs text-slate-600 font-semibold">
                    <button
                      onClick={() => { setSelectedCategory("All"); setPage(1); }}
                      className={`w-full text-left py-1 hover:text-[#c45500] transition-colors cursor-pointer flex justify-between items-center ${selectedCategory === "All" ? "text-[#c45500] font-bold" : ""}`}
                    >
                      <span>All Departments</span>
                      <span className="font-mono bg-slate-100 text-slate-400 px-1.5 py-0.5 rounded text-[10px]">
                        {allProducts.length}
                      </span>
                    </button>
                    {categories.map((c) => (
                      <button
                        key={c.id}
                        onClick={() => { setSelectedCategory(c.name); setPage(1); }}
                        className={`w-full text-left py-1 hover:text-[#c45500] transition-colors cursor-pointer flex justify-between items-center ${selectedCategory === c.name ? "text-[#c45500] font-bold" : ""}`}
                      >
                        <span>{c.name}</span>
                        <span className="font-mono bg-slate-100 text-slate-400 px-1.5 py-0.5 rounded text-[10px]">
                          {c.productCount}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Shopping Cart Drawer Side Box */}
                {cart.length > 0 && (
                  <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs space-y-4">
                    <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 border-b border-slate-100 pb-2 flex items-center justify-between">
                      <span>Shopping Cart</span>
                      <span className="font-mono text-slate-900 bg-amber-500/10 px-1.5 py-0.5 rounded text-[10px] font-bold">
                        {cart.reduce((sum, i) => sum + i.quantity, 0)} items
                      </span>
                    </h3>

                    {/* Cart Items List */}
                    <div className="divide-y divide-slate-100 max-h-48 overflow-y-auto pr-1">
                      {cart.map((item) => {
                        const p = allProducts.find(prod => prod.id === item.productId);
                        if (!p) return null;
                        
                        return (
                          <div key={item.productId} className="py-2.5 flex items-start gap-2.5 text-xs">
                            <img 
                              src={p.image} 
                              alt={p.title} 
                              className="w-8 h-8 object-contain bg-slate-50 rounded border border-slate-100 flex-shrink-0" 
                              referrerPolicy="no-referrer"
                            />
                            <div className="min-w-0 flex-1">
                              <p className="font-bold text-slate-800 truncate leading-tight">{p.title}</p>
                              <div className="flex items-center justify-between mt-1 text-[11px] text-slate-400">
                                <div className="flex items-center gap-1.5">
                                  <button
                                    onClick={() => handleQuantityChange(item.productId, item.quantity - 1)}
                                    className="px-1 bg-slate-100 hover:bg-slate-200 rounded font-bold cursor-pointer"
                                  >
                                    -
                                  </button>
                                  <span className="font-semibold text-slate-600">{item.quantity}</span>
                                  <button
                                    onClick={() => handleQuantityChange(item.productId, item.quantity + 1)}
                                    className="px-1 bg-slate-100 hover:bg-slate-200 rounded font-bold cursor-pointer"
                                  >
                                    +
                                  </button>
                                </div>
                                <span className="font-mono text-slate-700 font-semibold">${(p.price * item.quantity).toFixed(2)}</span>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Subtotal & Checkout */}
                    <div className="border-t border-slate-100 pt-3 text-xs text-slate-600 space-y-3">
                      <div className="flex justify-between font-bold text-slate-800">
                        <span>Cart Subtotal:</span>
                        <span className="font-mono text-[#c45500]">${subtotalCartValue.toFixed(2)}</span>
                      </div>
                      
                      <button
                        onClick={() => {
                          if (!currentUser) {
                            setShowLoginModal(true);
                          } else {
                            setShowCheckoutModal(true);
                          }
                        }}
                        className="w-full py-1.5 bg-[#ffd814] hover:bg-[#f7ca00] text-black font-bold rounded-full cursor-pointer transition-colors text-center text-xs block shadow-sm"
                      >
                        Proceed to Checkout
                      </button>
                    </div>

                  </div>
                )}

              </div>

              {/* Right Side Products List */}
              <div className="md:col-span-9 space-y-6">
                
                {/* Search Sorting Header HUD */}
                <div className="bg-white px-5 py-3.5 rounded-lg border border-slate-200 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div className="text-xs font-semibold text-slate-500">
                    {searchQuery ? (
                      <p>
                        Showing results for "<strong className="text-slate-800">{searchQuery}</strong>" in 
                        <strong className="text-slate-800 ml-1">{selectedCategory}</strong>
                      </p>
                    ) : (
                      <p>
                        Browsing shelf: <strong className="text-[#c45500] uppercase font-bold tracking-wide">{selectedCategory}</strong>
                      </p>
                    )}
                  </div>
                  
                  {/* Sort Trigger dropdown */}
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-slate-400 font-medium">Sort by:</span>
                    <select
                      value={sort}
                      onChange={(e) => { setSort(e.target.value); setPage(1); }}
                      className="px-2.5 py-1 bg-slate-50 border border-slate-300 rounded text-slate-700 font-semibold cursor-pointer focus:outline-hidden"
                    >
                      <option value="relevance">Featured Relevance</option>
                      <option value="price-asc">Price: Low to High</option>
                      <option value="price-desc">Price: High to Low</option>
                      <option value="rating">Avg. Customer Review</option>
                    </select>
                  </div>
                </div>

                {/* Catalog Cards Grid */}
                {catalogLoading ? (
                  <div className="flex flex-col items-center justify-center py-24 text-slate-400">
                    <Database className="w-8 h-8 animate-spin text-[#febd69] mb-2" />
                    <p className="text-xs font-medium">Syncing database assets...</p>
                  </div>
                ) : catalogError ? (
                  <div className="bg-rose-50 border border-rose-200 text-rose-700 p-6 rounded-lg text-center text-xs font-semibold">
                    {catalogError}
                  </div>
                ) : products.length === 0 ? (
                  <div className="bg-white border border-slate-200 p-12 rounded-lg text-center text-slate-500">
                    <ShoppingBag className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="text-sm font-semibold">No products found matching query specs.</p>
                    <button
                      onClick={() => { setSelectedCategory("All"); setSearchQuery(""); }}
                      className="text-[#c45500] text-xs font-bold hover:underline mt-2 cursor-pointer"
                    >
                      Clear search queries
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {products.map((p) => (
                      <ProductCard
                        key={p.id}
                        product={p}
                        isInWishlist={wishlist.some(w => w.id === p.id)}
                        onAddToCart={handleAddToCart}
                        onToggleWishlist={handleToggleWishlist}
                        onProductClick={(prod) => setSelectedProduct(prod)}
                        currentUserRole={currentUser?.role}
                      />
                    ))}
                  </div>
                )}

                {/* Pagination HUD */}
                {totalPages > 1 && (
                  <div className="flex justify-center items-center gap-4 pt-4 text-xs font-semibold">
                    <button
                      disabled={page === 1}
                      onClick={() => setPage(p => Math.max(p - 1, 1))}
                      className="p-1.5 rounded-full border border-slate-300 hover:bg-white active:bg-slate-100 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed text-slate-600 bg-slate-50 transition-colors"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                    <span className="text-slate-500">
                      Page <strong className="text-slate-800 font-mono">{page}</strong> of <strong className="text-slate-800 font-mono">{totalPages}</strong>
                    </span>
                    <button
                      disabled={page === totalPages}
                      onClick={() => setPage(p => Math.min(p + 1, totalPages))}
                      className="p-1.5 rounded-full border border-slate-300 hover:bg-white active:bg-slate-100 disabled:opacity-30 cursor-pointer disabled:cursor-not-allowed text-slate-600 bg-slate-50 transition-colors"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                )}

              </div>

            </div>

          </div>
        )}

        {/* VIEW 3: ORDER HISTORY */}
        {activeView === "orders" && (
          <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm space-y-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">Your Order History</h2>
              <p className="text-xs text-slate-500 mt-1">Review active delivery schedules, verify transaction records, and download print-ready invoice receipts.</p>
            </div>

            {ordersLoading ? (
              <div className="flex flex-col items-center py-12 text-slate-400">
                <Database className="w-6 h-6 animate-spin text-amber-500 mb-1" />
                <p className="text-xs">Fetching past transactions...</p>
              </div>
            ) : orders.length === 0 ? (
              <div className="py-12 text-center border-2 border-dashed border-slate-200 rounded-lg">
                <ShoppingBag className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-500">No transactions inside databases.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {orders.map((order) => {
                  const statusColors = 
                    order.status === "PENDING" ? "bg-amber-50 text-amber-600 border border-amber-200" :
                    order.status === "SHIPPED" ? "bg-sky-50 text-sky-600 border border-sky-200" :
                    order.status === "DELIVERED" ? "bg-emerald-50 text-emerald-600 border border-emerald-200" :
                    "bg-rose-50 text-rose-600 border border-rose-200";

                  return (
                    <div key={order.id} className="border border-slate-250 rounded-lg overflow-hidden bg-white text-xs">
                      {/* Order Header info block */}
                      <div className="bg-slate-50 border-b border-slate-200 p-4 grid grid-cols-2 sm:grid-cols-4 gap-4 text-slate-500">
                        <div>
                          <p className="text-[10px] uppercase font-bold text-slate-400">Date Placed</p>
                          <p className="font-semibold text-slate-700 mt-0.5">{new Date(order.date).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase font-bold text-slate-400">Total Charged</p>
                          <p className="font-semibold text-slate-700 font-mono mt-0.5">${order.total.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase font-bold text-slate-400">Ship To</p>
                          <p className="font-semibold text-slate-700 truncate mt-0.5" title={order.shippingAddress.fullName}>
                            {order.shippingAddress.fullName}
                          </p>
                        </div>
                        <div className="sm:text-right">
                          <p className="text-[10px] uppercase font-bold text-slate-400">Invoice Number</p>
                          <button
                            onClick={() => setActiveInvoiceOrder(order)}
                            className="text-amber-600 font-bold hover:underline mt-0.5 text-left sm:text-right cursor-pointer"
                          >
                            {order.invoiceNumber}
                          </button>
                        </div>
                      </div>

                      {/* Order Products details */}
                      <div className="p-4 space-y-4">
                        <div className="flex justify-between items-center pb-2.5 border-b border-slate-100">
                          <span className="font-semibold text-slate-800">Status:</span>
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${statusColors}`}>
                            {order.status}
                          </span>
                        </div>

                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex gap-4 items-center">
                            <img 
                              src={item.image} 
                              alt={item.title} 
                              className="w-12 h-12 object-contain bg-slate-50 border border-slate-100 rounded flex-shrink-0" 
                              referrerPolicy="no-referrer"
                            />
                            <div className="min-w-0 flex-1">
                              <h4 className="font-bold text-slate-800 leading-snug truncate">{item.title}</h4>
                              <p className="text-slate-400 mt-1">Quantity: <strong className="text-slate-600 font-semibold">{item.quantity}</strong> @ ${item.price.toFixed(2)}</p>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Footer Generate Receipt button */}
                      <div className="bg-slate-50 border-t border-slate-100 px-4 py-3 flex justify-between items-center text-[10px]">
                        <span className="font-mono text-slate-400">Transaction ID: {order.id}</span>
                        <button
                          onClick={() => setActiveInvoiceOrder(order)}
                          className="px-3 py-1.5 bg-white hover:bg-slate-50 text-slate-700 font-bold border border-slate-300 rounded shadow-2xs transition-colors cursor-pointer"
                        >
                          Show Printable Invoice
                        </button>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* VIEW 4: WISHLIST VIEW */}
        {activeView === "wishlist" && (
          <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm space-y-6">
            <div>
              <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
                <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
                Your Wishlist Catalog
              </h2>
              <p className="text-xs text-slate-500 mt-1">Review saved products, track real-time pricing updates, and directly load them to your active cart checklist.</p>
            </div>

            {wishlist.length === 0 ? (
              <div className="py-12 text-center border-2 border-dashed border-slate-200 rounded-lg text-slate-400">
                <Heart className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="text-xs italic">Your saved lists are empty.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {wishlist.map((p) => (
                  <ProductCard
                    key={p.id}
                    product={p}
                    isInWishlist={true}
                    onAddToCart={handleAddToCart}
                    onToggleWishlist={handleToggleWishlist}
                    onProductClick={(prod) => setSelectedProduct(prod)}
                    currentUserRole={currentUser?.role}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* VIEW 5: ARCHITECTURE VIEW */}
        {activeView === "architecture" && <ArchitectureViewer />}

      </main>

      {/* Comprehensive Branded Footer */}
      <footer className="bg-[#131921] border-t border-slate-800 text-white py-12 px-4 select-none print:hidden">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 text-xs text-slate-400">
          
          <div className="md:col-span-4 space-y-4">
            <div className="text-lg font-bold tracking-tight text-white font-sans flex items-baseline">
              amazon<span className="text-[#febd69] text-sm font-medium">clone</span>
            </div>
            <p className="leading-relaxed text-slate-400 font-sans">
              A robust multi-role retail pipeline demonstrating microservices architecture endpoints, interactive PostgreSQL ER diagramming, inventory thresholds, and printable receipts.
            </p>
            <div className="flex items-center gap-2 bg-slate-950/40 border border-slate-800 p-3 rounded text-[10px] text-[#febd69] font-mono leading-relaxed">
              <ShieldCheck className="w-4 h-4 text-emerald-500 flex-shrink-0" />
              <span>Full-stack sandbox server active on Port 3000</span>
            </div>
          </div>

          <div className="md:col-span-4 space-y-3">
            <h4 className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5 font-mono text-[11px]">
              <Database className="w-4 h-4 text-slate-400" />
              Relational Modules
            </h4>
            <ul className="space-y-1.5 leading-normal">
              <li>• Role Based Authentication (JWT Sandbox)</li>
              <li>• Pagination, Text Search, Price Sorting</li>
              <li>• Seller Catalog & Stock replenish</li>
              <li>• Business Sales Tally Analytics</li>
              <li>• Invoice receipts compiling</li>
            </ul>
          </div>

          <div className="md:col-span-4 space-y-3">
            <h4 className="font-bold text-white uppercase tracking-wider flex items-center gap-1.5 font-mono text-[11px]">
              <Terminal className="w-4 h-4 text-slate-400" />
              Spring Boot & Docker References
            </h4>
            <p className="leading-relaxed">
              We compiled complete Java 21 Spring Boot + Docker compose codebase files. Toggle the <strong>"Spring Boot APIs & ER Diagram"</strong> control tab in the subheader to inspect specifications!
            </p>
          </div>

        </div>

        <div className="max-w-7xl mx-auto border-t border-slate-800 pt-8 mt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-[11px] text-slate-500">
          <p>© 2026 Amazon Clone Sandbox Environment. Follow clean software engineering architectures.</p>
          <div className="flex gap-4">
            <span className="text-slate-400">Java 21</span>
            <span className="text-slate-400">Spring Boot 3.3</span>
            <span className="text-slate-400">PostgreSQL</span>
            <span className="text-slate-400">Docker</span>
          </div>
        </div>
      </footer>

      {/* MODALS RENDER PANEL */}
      
      {/* 1. Login Sandbox Trigger */}
      {showLoginModal && (
        <LoginModal
          onClose={() => setShowLoginModal(false)}
          onLoginSuccess={handleLoginSuccess}
        />
      )}

      {/* 2. Checkout Panel */}
      {showCheckoutModal && (
        <CheckoutModal
          cart={cart}
          products={allProducts}
          authToken={currentUser?.token || ""}
          onClose={() => setShowCheckoutModal(false)}
          onOrderCompleted={handleOrderCompleted}
        />
      )}

      {/* 3. Product Detail review modal */}
      {selectedProduct && (
        <ProductDetailModal
          product={selectedProduct}
          authToken={currentUser?.token}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
        />
      )}

      {/* 4. Invoice printer modal */}
      {activeInvoiceOrder && (
        <InvoiceViewer
          order={activeInvoiceOrder}
          onClose={() => setActiveInvoiceOrder(null)}
        />
      )}

    </div>
  );
}
