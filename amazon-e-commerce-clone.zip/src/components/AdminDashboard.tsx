import React, { useState, useEffect } from "react";
import { SalesAnalytics, Order, Coupon, Category } from "../types";
import { TrendingUp, ShoppingBag, Users, AlertTriangle, ChevronRight, PlusCircle, Check, X, RefreshCw, Layers, Ticket } from "lucide-react";

interface AdminDashboardProps {
  authToken: string;
}

export default function AdminDashboard({ authToken }: AdminDashboardProps) {
  const [analytics, setAnalytics] = useState<SalesAnalytics | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [newCouponCode, setNewCouponCode] = useState("");
  const [newCouponDiscount, setNewCouponDiscount] = useState(15);
  const [newCouponMin, setNewCouponMin] = useState(30);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchData = async () => {
    setLoading(true);
    setError("");
    try {
      // 1. Fetch Analytics
      const analRes = await fetch("/api/admin/analytics", {
        headers: { "Authorization": `Bearer ${authToken}` }
      });
      if (!analRes.ok) throw new Error("Failed to fetch business analytics.");
      const analData = await analRes.json();
      setAnalytics(analData);

      // 2. Fetch Orders
      const orderRes = await fetch("/api/orders", {
        headers: { "Authorization": `Bearer ${authToken}` }
      });
      const orderData = await orderRes.json();
      setOrders(orderData);

      // 3. Fetch Categories
      const catRes = await fetch("/api/categories");
      const catData = await catRes.json();
      setCategories(catData);

      // 4. Fetch Coupons
      const couponRes = await fetch("/api/coupons");
      if (couponRes.ok) {
        const couponData = await couponRes.json();
        setCoupons(couponData);
      }

    } catch (err: any) {
      setError(err.message || "An unexpected error occurred during admin fetch.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [authToken]);

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;

    try {
      const res = await fetch("/api/categories", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${authToken}`
        },
        body: JSON.stringify({ name: newCategoryName, icon: "Layers" })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to create category");
      }

      setNewCategoryName("");
      fetchData(); // reload
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleCreateCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim() || !newCouponDiscount) return;
    setError("");

    const code = newCouponCode.trim().toUpperCase();

    try {
      const res = await fetch("/api/coupons", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${authToken}`
        },
        body: JSON.stringify({
          code,
          discountPercentage: Number(newCouponDiscount),
          minSpend: Number(newCouponMin)
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to register coupon");
      }

      setNewCouponCode("");
      fetchData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const toggleCoupon = async (code: string) => {
    setError("");
    try {
      const res = await fetch(`/api/coupons/${code}/toggle`, {
        method: "PATCH",
        headers: {
          "Authorization": `Bearer ${authToken}`
        }
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to toggle coupon");
      }

      fetchData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleUpdateOrderStatus = async (orderId: string, currentStatus: string) => {
    const statuses: ('PENDING' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED')[] = ['PENDING', 'SHIPPED', 'DELIVERED', 'CANCELLED'];
    const nextIdx = (statuses.indexOf(currentStatus as any) + 1) % statuses.length;
    const nextStatus = statuses[nextIdx];

    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${authToken}`
        },
        body: JSON.stringify({ status: nextStatus })
      });
      if (!res.ok) throw new Error("Failed to update status.");
      fetchData();
    } catch (err: any) {
      setError(err.message);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-500">
        <RefreshCw className="w-8 h-8 animate-spin text-amber-500 mb-2" />
        <p className="text-sm font-medium">Recompiling dashboard analytics...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-slate-50 p-6 rounded-lg border border-slate-200">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Sales Administration Engine</h2>
          <p className="text-xs text-slate-500 mt-1">
            Real-time sales tally, multi-vendor margins, stock audits, and e-commerce parameters.
          </p>
        </div>
        <button
          onClick={fetchData}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded border border-slate-300 transition-colors cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Refresh Stats
        </button>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 px-4 py-3 rounded text-sm flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError("")} className="text-rose-500 hover:text-rose-700">✕</button>
        </div>
      )}

      {/* Analytics Bento Grid */}
      {analytics && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Card 1 */}
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Gross Revenue</p>
                <p className="text-2xl font-bold text-slate-900 mt-1.5">${analytics.revenue.toFixed(2)}</p>
              </div>
              <div className="p-2 bg-amber-50 rounded-lg text-amber-600">
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-4 text-xs">
              <span className="text-emerald-600 font-bold">+{analytics.salesGrowth}%</span>
              <span className="text-slate-400">vs historical baseline</span>
            </div>
          </div>

          {/* Card 2 */}
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Completed Orders</p>
                <p className="text-2xl font-bold text-slate-900 mt-1.5">{analytics.ordersCount}</p>
              </div>
              <div className="p-2 bg-slate-100 rounded-lg text-slate-600">
                <ShoppingBag className="w-5 h-5" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-4 text-xs">
              <span className="text-emerald-600 font-bold">+{analytics.ordersGrowth}%</span>
              <span className="text-slate-400">increase this quarter</span>
            </div>
          </div>

          {/* Card 3 */}
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Acquired Clients</p>
                <p className="text-2xl font-bold text-slate-900 mt-1.5">{analytics.customersCount}</p>
              </div>
              <div className="p-2 bg-sky-50 rounded-lg text-sky-600">
                <Users className="w-5 h-5" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-4 text-xs">
              <span className="text-emerald-600 font-bold">+{analytics.customersGrowth}%</span>
              <span className="text-slate-400">new registrations</span>
            </div>
          </div>

          {/* Card 4 */}
          <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Low Stock Audits</p>
                <p className="text-2xl font-bold text-rose-600 mt-1.5">{analytics.lowStockItemsCount}</p>
              </div>
              <div className="p-2 bg-rose-50 rounded-lg text-rose-600">
                <AlertTriangle className="w-5 h-5" />
              </div>
            </div>
            <div className="flex items-center gap-1 mt-4 text-xs text-rose-500 font-semibold">
              {analytics.lowStockItemsCount > 0 ? "⚠️ Immediate replenishment required" : "✅ All items fully stocked"}
            </div>
          </div>
        </div>
      )}

      {/* Charts and Lists Grid */}
      {analytics && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Chart Section: Monthly Growth */}
          <div className="lg:col-span-8 bg-white p-6 rounded-lg border border-slate-200 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-6">Monthly Revenue Chart</h3>
            
            {/* Visual Custom Chart Bar */}
            <div className="h-64 flex items-end gap-3.5 sm:gap-6 border-b border-l border-slate-200 pb-3 pt-6 pl-4 relative">
              {/* Horizontal Help Gridlines */}
              <div className="absolute left-4 right-0 top-1/4 border-t border-slate-100/80 border-dashed pointer-events-none"></div>
              <div className="absolute left-4 right-0 top-2/4 border-t border-slate-100/80 border-dashed pointer-events-none"></div>
              <div className="absolute left-4 right-0 top-3/4 border-t border-slate-100/80 border-dashed pointer-events-none"></div>

              {analytics.monthlyRevenue.map((data, idx) => {
                // Find relative height against max
                const max = Math.max(...analytics.monthlyRevenue.map(m => m.amount)) || 1000;
                const percent = (data.amount / max) * 100;
                
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center group relative h-full justify-end">
                    
                    {/* Tooltip on Hover */}
                    <div className="absolute -top-7 opacity-0 group-hover:opacity-100 bg-slate-900 text-white text-[10px] font-mono px-1.5 py-0.5 rounded shadow-md pointer-events-none transition-all z-10 whitespace-nowrap">
                      ${data.amount} ({data.orders} ords)
                    </div>

                    {/* Visual Bar */}
                    <div 
                      className="w-full bg-[#febd69] group-hover:bg-[#f3a847] rounded-t-xs transition-all relative flex justify-center" 
                      style={{ height: `${percent}%` }}
                    >
                      {/* Interactive light gleam */}
                      <div className="absolute top-0 inset-x-0 h-1 bg-white/20"></div>
                    </div>

                    {/* Label */}
                    <span className="text-[10px] font-bold text-slate-400 mt-2 font-mono">
                      {data.month}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Category Split Table */}
          <div className="lg:col-span-4 bg-white p-6 rounded-lg border border-slate-200 shadow-xs flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-6">Revenue By Shelf</h3>
              <div className="space-y-4">
                {analytics.categoryDistribution.map((cat, idx) => {
                  const max = Math.max(...analytics.categoryDistribution.map(c => c.revenue)) || 1;
                  const ratio = (cat.revenue / max) * 100;

                  return (
                    <div key={idx} className="space-y-1.5">
                      <div className="flex justify-between text-xs font-semibold text-slate-700">
                        <span>{cat.name}</span>
                        <span className="font-mono text-slate-900">${cat.revenue.toFixed(2)}</span>
                      </div>
                      
                      {/* Bar tracker */}
                      <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-slate-700 rounded-full"
                          style={{ width: `${ratio}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="mt-6 pt-4 border-t border-slate-100 text-[11px] text-slate-400 leading-normal">
              Values tally active SKU items grouped by direct parent category node indices.
            </div>
          </div>
        </div>
      )}

      {/* Control Settings Panels (Categories & Coupons) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Category Config */}
        <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-1.5">
            <Layers className="w-4 h-4 text-slate-500" />
            Category Editor
          </h3>
          <form onSubmit={handleCreateCategory} className="flex gap-2 mb-6">
            <input
              type="text"
              placeholder="e.g., Home Decor"
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              className="flex-1 px-3 py-1.5 border border-slate-300 rounded text-xs focus:ring-1 focus:ring-[#febd69] focus:outline-hidden"
            />
            <button
              type="submit"
              className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded cursor-pointer transition-colors flex items-center gap-1"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              Add
            </button>
          </form>

          {/* Categories List */}
          <div className="divide-y divide-slate-100">
            {categories.map((cat) => (
              <div key={cat.id} className="py-2.5 flex justify-between items-center text-xs">
                <span className="font-semibold text-slate-700">{cat.name}</span>
                <span className="font-mono bg-slate-100 text-slate-500 px-2 py-0.5 rounded font-bold">
                  {cat.productCount} items
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Coupon Config */}
        <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-1.5">
            <Ticket className="w-4 h-4 text-slate-500" />
            Coupon Console
          </h3>
          <form onSubmit={handleCreateCoupon} className="space-y-3 mb-6">
            <div className="grid grid-cols-3 gap-2">
              <input
                type="text"
                placeholder="PROMOCODE"
                value={newCouponCode}
                onChange={(e) => setNewCouponCode(e.target.value)}
                className="col-span-1 px-3 py-1.5 border border-slate-300 rounded text-xs uppercase focus:ring-1 focus:ring-[#febd69] focus:outline-hidden"
              />
              <input
                type="number"
                placeholder="Discount %"
                min="1"
                max="99"
                value={newCouponDiscount}
                onChange={(e) => setNewCouponDiscount(Number(e.target.value))}
                className="px-2 py-1.5 border border-slate-300 rounded text-xs focus:ring-1 focus:ring-[#febd69] focus:outline-hidden"
              />
              <input
                type="number"
                placeholder="Min Spend $"
                min="0"
                value={newCouponMin}
                onChange={(e) => setNewCouponMin(Number(e.target.value))}
                className="px-2 py-1.5 border border-slate-300 rounded text-xs focus:ring-1 focus:ring-[#febd69] focus:outline-hidden"
              />
            </div>
            <button
              type="submit"
              className="w-full py-2 bg-[#ffd814] hover:bg-[#f7ca00] text-black text-xs font-bold rounded-full cursor-pointer transition-colors flex items-center justify-center gap-1 shadow-sm"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              Register New Active Coupon
            </button>
          </form>

          {/* Coupons List */}
          <div className="divide-y divide-slate-100">
            {coupons.map((coupon) => (
              <div key={coupon.code} className="py-2.5 flex justify-between items-center text-xs">
                <div>
                  <span className="font-mono font-bold bg-[#febd69]/10 text-[#c45500] px-2 py-0.5 border border-[#febd69]/30 rounded">
                    {coupon.code}
                  </span>
                  <span className="text-slate-400 text-[11px] ml-2 font-medium">
                    ({coupon.discountPercentage}% off, min ${coupon.minSpend})
                  </span>
                </div>
                <button
                  onClick={() => toggleCoupon(coupon.code)}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-all ${
                    coupon.active 
                      ? "bg-emerald-50 text-emerald-600 border border-emerald-200 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200" 
                      : "bg-slate-100 text-slate-400 border border-slate-200 hover:bg-emerald-50 hover:text-emerald-600 hover:border-emerald-200"
                  }`}
                >
                  {coupon.active ? "Active" : "Disabled"}
                </button>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Orders Management Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-150">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Order Book & Invoices</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-250">
                <th className="px-6 py-3">Order ID / Invoice</th>
                <th className="px-6 py-3">Billing Name</th>
                <th className="px-6 py-3 text-right">Tally</th>
                <th className="px-6 py-3 text-center">Tally Qty</th>
                <th className="px-6 py-3 text-center">Workflow Stage</th>
                <th className="px-6 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {orders.map((order) => {
                const totalQty = order.items.reduce((sum, it) => sum + it.quantity, 0);
                
                const statusColors = 
                  order.status === "PENDING" ? "bg-amber-50 text-amber-600 border border-amber-200" :
                  order.status === "SHIPPED" ? "bg-sky-50 text-sky-600 border border-sky-200" :
                  order.status === "DELIVERED" ? "bg-emerald-50 text-emerald-600 border border-emerald-200" :
                  "bg-rose-50 text-rose-600 border border-rose-200";

                return (
                  <tr key={order.id} className="hover:bg-slate-50/50">
                    <td className="px-6 py-3.5">
                      <p className="font-mono font-bold text-slate-900">{order.id}</p>
                      <p className="text-[10px] text-slate-400 font-semibold mt-0.5">{order.invoiceNumber}</p>
                    </td>
                    <td className="px-6 py-3.5">
                      <p className="font-semibold text-slate-700">{order.shippingAddress.fullName}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">{order.shippingAddress.city}, {order.shippingAddress.zipCode}</p>
                    </td>
                    <td className="px-6 py-3.5 text-right font-semibold font-mono text-slate-800">
                      ${order.total.toFixed(2)}
                    </td>
                    <td className="px-6 py-3.5 text-center font-mono font-semibold text-slate-500">
                      {totalQty}
                    </td>
                    <td className="px-6 py-3.5 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${statusColors}`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="px-6 py-3.5 text-right">
                      <button
                        onClick={() => handleUpdateOrderStatus(order.id, order.status)}
                        className="flex items-center gap-0.5 px-2 py-1 bg-slate-900 hover:bg-slate-800 text-white text-[10px] font-semibold rounded cursor-pointer transition-colors ml-auto"
                      >
                        Advance State
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-10 text-center text-slate-400 italic">
                    No active transaction records inside database registries.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
