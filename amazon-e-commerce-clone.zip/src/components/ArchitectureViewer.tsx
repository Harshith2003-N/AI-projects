import { useState } from "react";
import { Database, Link2, Key, Info, Play, Server, Code, Layers, FileJson } from "lucide-react";

interface DBField {
  name: string;
  type: string;
  desc?: string;
  isPK?: boolean;
  isFK?: boolean;
}

interface DBTable {
  name: string;
  fields: DBField[];
}

export default function ArchitectureViewer() {
  const [activeTab, setActiveTab] = useState<'er' | 'swagger'>('er');
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>("login");
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [apiLoading, setApiLoading] = useState<boolean>(false);

  // Database Schema Tables
  const tables: DBTable[] = [
    {
      name: "users",
      fields: [
        { name: "id", type: "UUID", desc: "Primary Key", isPK: true },
        { name: "email", type: "VARCHAR(255)", desc: "Unique login identifier" },
        { name: "password_hash", type: "VARCHAR(512)", desc: "Argon2/BCrypt secure hash" },
        { name: "name", type: "VARCHAR(100)", desc: "Full display name" },
        { name: "role", type: "ENUM", desc: "'CUSTOMER', 'SELLER', 'ADMIN'" },
        { name: "created_at", type: "TIMESTAMP" }
      ]
    },
    {
      name: "products",
      fields: [
        { name: "id", type: "UUID", desc: "Primary Key", isPK: true },
        { name: "title", type: "VARCHAR(255)" },
        { name: "description", type: "TEXT" },
        { name: "price", type: "DECIMAL(10,2)" },
        { name: "original_price", type: "DECIMAL(10,2)" },
        { name: "image_url", type: "VARCHAR(512)" },
        { name: "category_id", type: "UUID", desc: "FK to categories", isFK: true },
        { name: "inventory_count", type: "INT" },
        { name: "seller_id", type: "UUID", desc: "FK to users", isFK: true },
        { name: "created_at", type: "TIMESTAMP" }
      ]
    },
    {
      name: "categories",
      fields: [
        { name: "id", type: "UUID", desc: "Primary Key", isPK: true },
        { name: "name", type: "VARCHAR(100)", desc: "Unique name" },
        { name: "icon", type: "VARCHAR(50)" }
      ]
    },
    {
      name: "orders",
      fields: [
        { name: "id", type: "UUID", desc: "Primary Key", isPK: true },
        { name: "user_id", type: "UUID", desc: "FK to users", isFK: true },
        { name: "subtotal", type: "DECIMAL(10,2)" },
        { name: "discount", type: "DECIMAL(10,2)" },
        { name: "tax", type: "DECIMAL(10,2)" },
        { name: "total", type: "DECIMAL(10,2)" },
        { name: "status", type: "VARCHAR(50)", desc: "'PENDING', 'SHIPPED', 'DELIVERED', 'CANCELLED'" },
        { name: "invoice_number", type: "VARCHAR(100)", desc: "Unique billing code" },
        { name: "shipping_address", type: "TEXT" },
        { name: "payment_method", type: "VARCHAR(100)" },
        { name: "created_at", type: "TIMESTAMP" }
      ]
    },
    {
      name: "order_items",
      fields: [
        { name: "id", type: "UUID", desc: "Primary Key", isPK: true },
        { name: "order_id", type: "UUID", desc: "FK to orders", isFK: true },
        { name: "product_id", type: "UUID", desc: "FK to products", isFK: true },
        { name: "price", type: "DECIMAL(10,2)" },
        { name: "quantity", type: "INT" }
      ]
    },
    {
      name: "reviews",
      fields: [
        { name: "id", type: "UUID", desc: "Primary Key", isPK: true },
        { name: "product_id", type: "UUID", desc: "FK to products", isFK: true },
        { name: "user_id", type: "UUID", desc: "FK to users", isFK: true },
        { name: "rating", type: "INT", desc: "Value 1 to 5" },
        { name: "comment", type: "TEXT" },
        { name: "created_at", type: "TIMESTAMP" }
      ]
    }
  ];

  // Swagger Endpoint Specifications with Spring Boot Java Counterparts
  const endpoints = [
    {
      id: "login",
      method: "POST",
      path: "/api/auth/login",
      summary: "User authentication & JWT sign",
      roles: "ALL",
      javaClass: "AuthController.java",
      javaSnippet: `@PostMapping("/login")\n@Operation(summary = "Authenticate user and return JWT")\npublic ResponseEntity<JwtResponse> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {\n    Authentication authentication = authenticationManager.authenticate(\n        new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword())\n    );\n    SecurityContextHolder.getContext().setAuthentication(authentication);\n    String jwt = jwtUtils.generateJwtToken(authentication);\n    UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();\n    return ResponseEntity.ok(new JwtResponse(jwt, userDetails.getId(), userDetails.getEmail(), userDetails.getRole()));\n}`,
      payload: { email: "customer@amazon.com", password: "password" }
    },
    {
      id: "products_list",
      method: "GET",
      path: "/api/products",
      summary: "Get products with search, paging, filters",
      roles: "ALL",
      javaClass: "ProductController.java",
      javaSnippet: `@GetMapping\n@Operation(summary = "Fetch list of paginated and filtered products")\npublic ResponseEntity<PageResponse<ProductDto>> getAllProducts(\n    @RequestParam(required = false) String search,\n    @RequestParam(required = false) String category,\n    @RequestParam(required = false) String sort,\n    @RequestParam(defaultValue = "1") int page,\n    @RequestParam(defaultValue = "10") int limit\n) {\n    Pageable pageable = PageRequest.of(page - 1, limit, getSortOrder(sort));\n    Page<ProductDto> products = productService.getProducts(search, category, pageable);\n    return ResponseEntity.ok(PageResponse.fromPage(products));\n}`,
      payload: {}
    },
    {
      id: "order_create",
      method: "POST",
      path: "/api/orders",
      summary: "Create order & deduct product inventory",
      roles: "CUSTOMER",
      javaClass: "OrderController.java",
      javaSnippet: `@PostMapping\n@PreAuthorize("hasRole('CUSTOMER')")\n@Operation(summary = "Submit new e-commerce checkout and bill order")\npublic ResponseEntity<OrderDto> createOrder(\n    @Valid @RequestBody OrderRequest orderRequest,\n    @AuthenticationPrincipal UserDetailsImpl userDetails\n) {\n    OrderDto createdOrder = orderService.processOrder(userDetails.getId(), orderRequest);\n    redisTemplate.delete("cart::" + userDetails.getId());\n    return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);\n}`,
      payload: {
        items: [{ productId: "p-1", quantity: 1 }],
        shippingAddress: {
          fullName: "John Doe",
          street: "123 Main Street, Apt 4B",
          city: "New York",
          zipCode: "10001",
          country: "United States"
        },
        paymentMethod: "Visa ending in 4242",
        couponCode: "SAVE10"
      }
    },
    {
      id: "analytics",
      method: "GET",
      path: "/api/admin/analytics",
      summary: "Retrieve full admin/seller sales statistics",
      roles: "SELLER, ADMIN",
      javaClass: "AnalyticsController.java",
      javaSnippet: `@GetMapping("/analytics")\n@PreAuthorize("hasAnyRole('ADMIN', 'SELLER')")\n@Operation(summary = "Compile full multi-dimensional revenue, metrics, and stock sheets")\npublic ResponseEntity<SalesAnalyticsDto> getSalesAnalytics(\n    @AuthenticationPrincipal UserDetailsImpl userDetails\n) {\n    SalesAnalyticsDto analytics = analyticsService.getAnalyticsForUser(userDetails.getId(), userDetails.getRole());\n    return ResponseEntity.ok(analytics);\n}`,
      payload: {}
    }
  ];

  const handleTryItOut = async (endpoint: typeof endpoints[0]) => {
    setApiLoading(true);
    setApiResponse(null);
    try {
      // Set auth headers if needed
      const headers: HeadersInit = { "Content-Type": "application/json" };
      if (endpoint.roles !== "ALL") {
        const tokenRole = endpoint.roles.includes("ADMIN") ? "jwt-admin" : "jwt-customer";
        headers["Authorization"] = `Bearer ${tokenRole}`;
      }

      const options: RequestInit = {
        method: endpoint.method,
        headers,
      };

      if (endpoint.method !== "GET" && Object.keys(endpoint.payload).length > 0) {
        options.body = JSON.stringify(endpoint.payload);
      }

      // Add query params for list to avoid default page issue
      let fetchPath = endpoint.path;
      if (endpoint.id === "products_list") {
        fetchPath += "?limit=3";
      }

      const res = await fetch(fetchPath, options);
      const data = await res.json();
      setApiResponse(data);
    } catch (err: any) {
      setApiResponse({ error: err.message || "Failed to make fetch call." });
    } finally {
      setApiLoading(false);
    }
  };

  const currEndpoint = endpoints.find(e => e.id === selectedEndpoint) || endpoints[0];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg shadow-xl overflow-hidden text-slate-100">
      
      {/* Visual Tab Header */}
      <div className="bg-slate-950 border-b border-slate-800 px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-amber-500" />
            <h2 className="text-lg font-bold text-white tracking-tight">E-Commerce Architecture & APIs</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Explore the relational model mapping and backend controller specifications.
          </p>
        </div>
        <div className="flex bg-slate-900 border border-slate-800 p-1 rounded-md text-xs">
          <button
            onClick={() => setActiveTab('er')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-sm font-semibold transition-all cursor-pointer ${
              activeTab === 'er' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            ER Diagram (PostgreSQL)
          </button>
          <button
            onClick={() => {
              setActiveTab('swagger');
              handleTryItOut(currEndpoint);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-sm font-semibold transition-all cursor-pointer ${
              activeTab === 'swagger' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            Spring Boot Swagger Playground
          </button>
        </div>
      </div>

      {/* Tab Contents */}
      <div className="p-6">
        
        {/* TAB 1: ER DIAGRAM */}
        {activeTab === 'er' && (
          <div>
            <div className="bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded p-4 mb-6 flex items-start gap-3">
              <Info className="w-5 h-5 flex-shrink-0 mt-0.5 text-amber-400" />
              <div className="text-xs space-y-1">
                <p className="font-semibold">Relational Database Schematics (PostgreSQL 16+)</p>
                <p className="text-slate-300 leading-relaxed">
                  This diagram represents the structural layout of our e-commerce engine. Primary keys are marked as 
                  <span className="text-amber-400 font-semibold mx-1">PK</span> and foreign relational references as 
                  <span className="text-sky-400 font-semibold mx-1">FK</span>. High performance is maintained using indexing tables on frequently queried keys.
                </p>
              </div>
            </div>

            {/* Tables Grid Layout */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tables.map((tbl) => (
                <div key={tbl.name} className="bg-slate-950 border border-slate-800 rounded-md overflow-hidden shadow-md">
                  <div className="bg-slate-850 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
                    <span className="font-mono text-sm font-bold text-amber-400 flex items-center gap-1.5">
                      <Database className="w-3.5 h-3.5 text-slate-400" />
                      {tbl.name}
                    </span>
                    <span className="text-[10px] uppercase tracking-wider font-semibold bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">
                      Table
                    </span>
                  </div>
                  <div className="divide-y divide-slate-900/60 font-mono text-xs">
                    {tbl.fields.map((field) => (
                      <div key={field.name} className="px-4 py-2 flex items-center justify-between hover:bg-slate-900/40">
                        <div className="flex items-center gap-1.5 min-w-0">
                          {field.isPK && (
                            <span className="text-[10px] font-bold bg-amber-500/20 text-amber-400 px-1 rounded-xs flex-shrink-0">
                              PK
                            </span>
                          )}
                          {field.isFK && (
                            <span className="text-[10px] font-bold bg-sky-500/20 text-sky-400 px-1 rounded-xs flex-shrink-0">
                              FK
                            </span>
                          )}
                          <span className={`font-semibold truncate ${field.isPK ? "text-slate-100" : "text-slate-300"}`}>
                            {field.name}
                          </span>
                        </div>
                        <div className="text-right flex-shrink-0 pl-2">
                          <span className="text-slate-500 text-[11px]">{field.type}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Visual Relations Section */}
            <div className="mt-8 bg-slate-950 border border-slate-850 p-4 rounded-md">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
                <Link2 className="w-3.5 h-3.5 text-slate-400" />
                Relational Keys Map
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono text-slate-400">
                <div className="flex items-center gap-2 bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-amber-400">users.id</span>
                  <span>➜</span>
                  <span className="text-sky-400">products.seller_id</span>
                  <span className="text-[10px] bg-slate-800 px-1 rounded text-slate-400 font-semibold ml-auto">1-to-Many</span>
                </div>
                <div className="flex items-center gap-2 bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-amber-400">categories.id</span>
                  <span>➜</span>
                  <span className="text-sky-400">products.category_id</span>
                  <span className="text-[10px] bg-slate-800 px-1 rounded text-slate-400 font-semibold ml-auto">1-to-Many</span>
                </div>
                <div className="flex items-center gap-2 bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-amber-400">users.id</span>
                  <span>➜</span>
                  <span className="text-sky-400">orders.user_id</span>
                  <span className="text-[10px] bg-slate-800 px-1 rounded text-slate-400 font-semibold ml-auto">1-to-Many</span>
                </div>
                <div className="flex items-center gap-2 bg-slate-900 p-2.5 rounded border border-slate-800">
                  <span className="text-amber-400">orders.id</span>
                  <span>➜</span>
                  <span className="text-sky-400">order_items.order_id</span>
                  <span className="text-[10px] bg-slate-800 px-1 rounded text-slate-400 font-semibold ml-auto">Cascade</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: SWAGGER PLAYGROUND */}
        {activeTab === 'swagger' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left: Endpoint List */}
            <div className="lg:col-span-4 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">REST Endpoints</h3>
              <div className="space-y-2">
                {endpoints.map((ep) => {
                  const isSelected = selectedEndpoint === ep.id;
                  const methodColor = 
                    ep.method === "POST" ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/20" :
                    ep.method === "PUT" ? "text-amber-400 bg-amber-500/10 border-amber-500/20" :
                    ep.method === "DELETE" ? "text-rose-400 bg-rose-500/10 border-rose-500/20" :
                    "text-sky-400 bg-sky-500/10 border-sky-500/20";

                  return (
                    <button
                      key={ep.id}
                      onClick={() => {
                        setSelectedEndpoint(ep.id);
                        handleTryItOut(ep);
                      }}
                      className={`w-full text-left p-3.5 rounded-lg border transition-all cursor-pointer flex flex-col gap-1.5 ${
                        isSelected 
                          ? "bg-slate-850 border-amber-500/50 shadow-inner" 
                          : "bg-slate-950 border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded border ${methodColor}`}>
                          {ep.method}
                        </span>
                        <span className="font-mono text-xs font-semibold text-slate-100 truncate">{ep.path}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 leading-tight truncate">{ep.summary}</p>
                      
                      {/* Sub Meta Info */}
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-500 font-mono">
                        <span className="flex items-center gap-0.5">
                          <Key className="w-3 h-3" />
                          Role: {ep.roles}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Right: Code Details & Try Sandbox */}
            <div className="lg:col-span-8 space-y-6">
              
              {/* API Specs Panel */}
              <div className="bg-slate-950 border border-slate-800 rounded-lg overflow-hidden">
                <div className="bg-slate-900 border-b border-slate-800 px-4 py-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Code className="w-4 h-4 text-amber-500" />
                    <span className="font-mono text-xs font-semibold text-white">{currEndpoint.javaClass}</span>
                  </div>
                  <span className="text-[10px] font-bold uppercase tracking-wider bg-slate-850 text-slate-400 px-2 py-0.5 rounded border border-slate-800/80">
                    Spring Boot REST Controller
                  </span>
                </div>
                
                {/* Java Snippet */}
                <div className="p-4 bg-slate-950/80 overflow-x-auto max-h-56">
                  <pre className="font-mono text-[11px] leading-relaxed text-slate-300">
                    {currEndpoint.javaSnippet}
                  </pre>
                </div>
              </div>

              {/* Try Playground Execution Box */}
              <div className="bg-slate-950 border border-slate-800 rounded-lg overflow-hidden">
                <div className="bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Play className="w-3.5 h-3.5 text-emerald-500 fill-emerald-500" />
                    <span className="text-xs font-semibold text-white">Live Endpoint Execution Playground</span>
                  </div>
                  <button
                    onClick={() => handleTryItOut(currEndpoint)}
                    disabled={apiLoading}
                    className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white text-xs font-bold rounded shadow-xs cursor-pointer transition-colors"
                  >
                    {apiLoading ? "Sending request..." : "Execute API"}
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-slate-850">
                  {/* Left: Request Parameters */}
                  <div className="p-4 space-y-3">
                    <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                      <FileJson className="w-3.5 h-3.5" />
                      Client Request RequestBody
                    </h4>
                    {Object.keys(currEndpoint.payload).length > 0 ? (
                      <pre className="p-3 bg-slate-900/60 border border-slate-850 rounded text-[11px] font-mono text-slate-300 overflow-x-auto">
                        {JSON.stringify(currEndpoint.payload, null, 2)}
                      </pre>
                    ) : (
                      <p className="text-xs text-slate-500 italic bg-slate-900/30 p-4 border border-dashed border-slate-800 rounded">
                        No RequestBody required for this operation. Pass variables as URL query variables.
                      </p>
                    )}
                  </div>

                  {/* Right: Live Sandbox Response */}
                  <div className="p-4 space-y-3">
                    <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                      <Server className="w-3.5 h-3.5" />
                      Server JSON ResponseEntity
                    </h4>
                    <div className="bg-slate-900/60 border border-slate-850 rounded p-3 h-48 overflow-y-auto font-mono text-[11px] text-slate-300">
                      {apiLoading ? (
                        <div className="flex items-center justify-center h-full text-slate-500 text-xs">
                          Sending handshakes and awaiting response stream...
                        </div>
                      ) : apiResponse ? (
                        <pre className="text-emerald-400">{JSON.stringify(apiResponse, null, 2)}</pre>
                      ) : (
                        <div className="flex items-center justify-center h-full text-slate-600 text-xs italic">
                          Click "Execute API" to query endpoint and fetch JSON body
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
}
