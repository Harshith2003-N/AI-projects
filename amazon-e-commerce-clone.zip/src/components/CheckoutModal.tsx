import React, { useState } from "react";
import { Coupon, CartItem, Product } from "../types";
import { Check, Ticket, Lock, ShoppingBag, X, HelpCircle, ArrowRight } from "lucide-react";

interface CheckoutModalProps {
  cart: CartItem[];
  products: Product[];
  authToken: string;
  onClose: () => void;
  onOrderCompleted: (finalizedOrder: any) => void;
}

export default function CheckoutModal({ cart, products, authToken, onClose, onOrderCompleted }: CheckoutModalProps) {
  // Address State
  const [fullName, setFullName] = useState("John Doe");
  const [street, setStreet] = useState("123 Main Street, Apt 4B");
  const [city, setCity] = useState("New York");
  const [zipCode, setZipCode] = useState("10001");
  const [country, setCountry] = useState("United States");

  // Payment State
  const [cardName, setCardName] = useState("John Doe");
  const [cardNumber, setCardNumber] = useState("4111 2222 3333 4444");
  const [cardExpiry, setCardExpiry] = useState("12/28");
  const [cardCVV, setCardCVV] = useState("123");

  // Coupon State
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState("");
  const [couponSuccess, setCouponSuccess] = useState("");

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  // Calculations
  const subtotal = cart.reduce((sum, item) => {
    const prod = products.find(p => p.id === item.productId);
    return sum + (prod ? prod.price * item.quantity : 0);
  }, 0);

  const discount = appliedCoupon ? (subtotal * appliedCoupon.discountPercentage) / 100 : 0;
  const tax = (subtotal - discount) * 0.08; // 8% sales tax
  const grandTotal = subtotal - discount + tax;

  const handleValidateCoupon = async (e: React.MouseEvent) => {
    e.preventDefault();
    setCouponError("");
    setCouponSuccess("");
    if (!couponCode.trim()) return;

    try {
      const res = await fetch(`/api/coupons/validate/${couponCode.trim()}`);
      if (!res.ok) {
        throw new Error("Invalid or expired promotional code.");
      }
      const data: Coupon = await res.json();
      
      if (subtotal < data.minSpend) {
        throw new Error(`Minimum spend for ${data.code} is $${data.minSpend}.`);
      }

      setAppliedCoupon(data);
      setCouponSuccess(`Coupon Applied! Save ${data.discountPercentage}% on checkout items.`);
    } catch (err: any) {
      setAppliedCoupon(null);
      setCouponError(err.message || "Failed to validate coupon.");
    }
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError("");
    setIsSubmitting(true);

    try {
      const payload = {
        items: cart.map(item => ({ productId: item.productId, quantity: item.quantity })),
        shippingAddress: {
          fullName,
          street,
          city,
          zipCode,
          country
        },
        paymentMethod: `Visa ending in ${cardNumber.slice(-4)}`,
        couponCode: appliedCoupon ? appliedCoupon.code : undefined
      };

      const res = await fetch("/api/orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${authToken}`
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to process checkout transaction.");
      }

      const orderData = await res.json();
      onOrderCompleted(orderData); // trigger receipt invoice
    } catch (err: any) {
      setSubmitError(err.message || "An unexpected error occurred during order routing.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-2xl max-w-4xl w-full text-slate-800 grid grid-cols-1 md:grid-cols-12 overflow-hidden max-h-[90vh]">
        
        {/* Left Column: Form Info */}
        <form onSubmit={handleSubmitOrder} className="md:col-span-8 p-6 overflow-y-auto max-h-[90vh] space-y-6">
          <div className="flex justify-between items-center border-b border-slate-100 pb-4">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#febd69]" />
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">Checkout Secure Connection</h2>
            </div>
            <button type="button" onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors cursor-pointer">
              <X className="w-5 h-5" />
            </button>
          </div>

          {submitError && (
            <div className="bg-rose-50 border border-rose-200 text-rose-700 px-4 py-2.5 rounded text-xs">
              {submitError}
            </div>
          )}

          {/* Section 1: Address */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">1. Shipping Coordinates</h3>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="col-span-2">
                <label className="block text-slate-500 font-medium mb-1">Full Delivery Name *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-[#febd69] focus:outline-hidden"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-slate-500 font-medium mb-1">Street Address *</label>
                <input
                  type="text"
                  required
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-[#febd69] focus:outline-hidden"
                />
              </div>
              <div>
                <label className="block text-slate-500 font-medium mb-1">City *</label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-[#febd69] focus:outline-hidden"
                />
              </div>
              <div>
                <label className="block text-slate-500 font-medium mb-1">ZIP / Postal *</label>
                <input
                  type="text"
                  required
                  value={zipCode}
                  onChange={(e) => setZipCode(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-[#febd69] focus:outline-hidden"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Payment */}
          <div className="space-y-3 border-t border-slate-100 pt-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">2. Marketplace Billing</h3>
            <div className="grid grid-cols-3 gap-3 text-xs">
              <div className="col-span-3">
                <label className="block text-slate-500 font-medium mb-1">Cardholder Name *</label>
                <input
                  type="text"
                  required
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-[#febd69] focus:outline-hidden"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-slate-500 font-medium mb-1">Card Number *</label>
                <input
                  type="text"
                  required
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  placeholder="4111 2222 3333 4444"
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-[#febd69] focus:outline-hidden font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-500 font-medium mb-1">Expiration *</label>
                <input
                  type="text"
                  required
                  value={cardExpiry}
                  onChange={(e) => setCardExpiry(e.target.value)}
                  placeholder="MM/YY"
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-[#febd69] focus:outline-hidden text-center font-mono"
                />
              </div>
            </div>
          </div>

          {/* Submit Trigger */}
          <button
            type="submit"
            disabled={isSubmitting || cart.length === 0}
            className="w-full py-3 bg-[#ffd814] hover:bg-[#f7ca00] disabled:bg-slate-300 text-black font-bold rounded-full shadow-sm cursor-pointer transition-colors flex items-center justify-center gap-1.5"
          >
            <Lock className="w-4 h-4" />
            {isSubmitting ? "Finalizing Transaction..." : `Place Your Order - $${grandTotal.toFixed(2)}`}
          </button>
        </form>

        {/* Right Column: Order Summary, Items & Coupon */}
        <div className="md:col-span-4 bg-slate-50 p-6 border-l border-slate-100 flex flex-col justify-between overflow-y-auto max-h-[90vh]">
          <div className="space-y-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">Tally Breakdown</h3>

            {/* List Mini cart items */}
            <div className="space-y-3.5 max-h-48 overflow-y-auto">
              {cart.map((item) => {
                const p = products.find(prod => prod.id === item.productId);
                if (!p) return null;
                
                return (
                  <div key={item.productId} className="flex gap-2.5 text-xs">
                    <img 
                      src={p.image} 
                      alt={p.title} 
                      className="w-8 h-8 object-cover rounded border border-slate-200 flex-shrink-0" 
                      referrerPolicy="no-referrer"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-slate-800 truncate leading-tight">{p.title}</p>
                      <p className="text-slate-400 mt-0.5">{item.quantity}x @ ${p.price.toFixed(2)}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Coupon Application Block */}
            <div className="border-t border-slate-250 pt-5 space-y-2 text-xs">
              <label className="block text-slate-600 font-bold mb-1">Promotional Code</label>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  placeholder="e.g., SAVE10"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="flex-1 px-2.5 py-1.5 border border-slate-300 rounded uppercase font-mono focus:ring-1 focus:ring-[#febd69] focus:outline-hidden text-xs"
                />
                <button
                  type="button"
                  onClick={handleValidateCoupon}
                  className="px-3 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded cursor-pointer text-xs"
                >
                  Apply
                </button>
              </div>
              
              {/* Promo Info help */}
              <div className="text-[10px] text-slate-400 flex items-center gap-1">
                <HelpCircle className="w-3 h-3" />
                <span>Try active promo codes: <strong>SAVE10</strong>, <strong>AMAZON20</strong></span>
              </div>

              {couponError && <p className="text-rose-600 text-[11px] font-semibold">{couponError}</p>}
              {couponSuccess && <p className="text-emerald-600 text-[11px] font-semibold">{couponSuccess}</p>}
            </div>
          </div>

          {/* Pricing Totals */}
          <div className="border-t border-slate-250 pt-5 space-y-2 text-xs text-slate-600 mt-6">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span className="font-mono text-slate-900 font-semibold">${subtotal.toFixed(2)}</span>
            </div>
            
            {discount > 0 && (
              <div className="flex justify-between text-emerald-600 font-semibold">
                <span className="flex items-center gap-0.5">
                  <Ticket className="w-3 h-3" />
                  Promo Saving:
                </span>
                <span className="font-mono">-${discount.toFixed(2)}</span>
              </div>
            )}

            <div className="flex justify-between">
              <span>Standard Shipping:</span>
              <span className="text-emerald-600 font-semibold uppercase">FREE</span>
            </div>

            <div className="flex justify-between border-b border-slate-200 pb-2">
              <span>Sales Tax (8%):</span>
              <span className="font-mono text-slate-900 font-semibold">${tax.toFixed(2)}</span>
            </div>

            <div className="flex justify-between text-sm font-bold text-slate-900 pt-1">
              <span>Order Total:</span>
              <span className="font-mono text-[#c45500] text-base">${grandTotal.toFixed(2)}</span>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
