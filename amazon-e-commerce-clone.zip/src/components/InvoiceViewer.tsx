import { Order } from "../types";
import { Printer, CheckCircle2, ShoppingBag } from "lucide-react";

interface InvoiceViewerProps {
  order: Order;
  onClose: () => void;
}

export default function InvoiceViewer({ order, onClose }: InvoiceViewerProps) {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full my-8 text-slate-800 overflow-hidden print:shadow-none print:my-0">
        
        {/* Actions bar - Hidden in Print */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-100 border-b border-slate-200 print:hidden">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span className="font-semibold text-slate-700">Order Completed Successfully</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-slate-900 font-medium text-sm rounded shadow-xs cursor-pointer transition-colors"
            >
              <Printer className="w-4 h-4" />
              Print Invoice
            </button>
            <button
              onClick={onClose}
              className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 active:bg-slate-400 text-slate-700 font-medium text-sm rounded cursor-pointer transition-colors"
            >
              Close
            </button>
          </div>
        </div>

        {/* Invoice Page Body */}
        <div className="p-8 print:p-0" id={`invoice-${order.id}`}>
          {/* Header */}
          <div className="flex justify-between items-start border-b border-slate-200 pb-6 mb-6">
            <div>
              <div className="flex items-center gap-1 mb-2">
                <span className="text-2xl font-bold tracking-tight text-slate-900 font-sans">
                  amazon<span className="text-[#febd69]">.com</span>
                </span>
                <span className="text-xs font-mono text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded ml-1">
                  Clone App
                </span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Amazon.com Services LLC<br />
                410 Terry Ave. N<br />
                Seattle, WA 98109-5210<br />
                United States
              </p>
            </div>
            <div className="text-right">
              <h1 className="text-xl font-bold text-slate-900 uppercase tracking-wider">Final Invoice</h1>
              <p className="text-xs font-mono text-slate-500 mt-1">Order # {order.id}</p>
              <p className="text-xs text-slate-500 mt-0.5">Date: {new Date(order.date).toLocaleDateString()}</p>
              <p className="text-xs font-semibold text-slate-700 mt-2 bg-[#febd69]/10 border border-[#febd69]/30 px-2.5 py-1 rounded-sm inline-block">
                Invoice: {order.invoiceNumber}
              </p>
            </div>
          </div>

          {/* Addresses */}
          <div className="grid grid-cols-2 gap-8 mb-8">
            <div className="bg-slate-50 p-4 rounded-md border border-slate-100">
              <h3 className="text-xs font-bold uppercase text-slate-500 tracking-wider mb-2">Shipping Address</h3>
              <p className="text-sm font-semibold text-slate-950">{order.shippingAddress.fullName}</p>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                {order.shippingAddress.street}<br />
                {order.shippingAddress.city}, {order.shippingAddress.zipCode}<br />
                {order.shippingAddress.country}
              </p>
            </div>
            <div className="bg-slate-50 p-4 rounded-md border border-slate-100">
              <h3 className="text-xs font-bold uppercase text-slate-500 tracking-wider mb-2">Payment Information</h3>
              <p className="text-sm font-semibold text-slate-950">{order.paymentMethod}</p>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                Transaction Status: <span className="font-semibold text-emerald-600">PAID</span><br />
                Auth Token Code: <span className="font-mono text-[10px] text-slate-500 bg-slate-200/60 px-1 rounded">AUTH-SIM-{order.id.slice(2, 8)}</span><br />
                Service Channel: Standard Ingress
              </p>
            </div>
          </div>

          {/* Items Table */}
          <table className="w-full text-left mb-8 border-collapse">
            <thead>
              <tr className="border-b border-slate-300 text-xs font-bold uppercase text-slate-500 tracking-wider">
                <th className="py-2">Product Details</th>
                <th className="py-2 text-center w-16">Qty</th>
                <th className="py-2 text-right w-24">Unit Price</th>
                <th className="py-2 text-right w-24">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              {order.items.map((item, index) => (
                <tr key={index} className="border-b border-slate-100 text-sm">
                  <td className="py-3">
                    <p className="font-semibold text-slate-900 leading-tight">{item.title}</p>
                    <p className="text-xs text-slate-400 mt-0.5">Product ID: {item.productId}</p>
                  </td>
                  <td className="py-3 text-center text-slate-600 font-semibold">{item.quantity}</td>
                  <td className="py-3 text-right font-mono text-slate-600">${item.price.toFixed(2)}</td>
                  <td className="py-3 text-right font-semibold font-mono text-slate-900">
                    ${(item.price * item.quantity).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Pricing breakdown */}
          <div className="flex justify-end">
            <div className="w-64">
              <div className="flex justify-between text-xs py-1.5 text-slate-600">
                <span>Items Subtotal:</span>
                <span className="font-mono">${order.subtotal.toFixed(2)}</span>
              </div>
              
              {order.discount > 0 && (
                <div className="flex justify-between text-xs py-1.5 text-emerald-600 font-semibold">
                  <span>Coupon Discount Applied:</span>
                  <span className="font-mono">-${order.discount.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between text-xs py-1.5 text-slate-600">
                <span>Estimated Shipping & Handling:</span>
                <span className="font-mono text-emerald-600 font-semibold">FREE Shipping</span>
              </div>

              <div className="flex justify-between text-xs py-1.5 text-slate-600 border-b border-slate-200 pb-1.5">
                <span>Tax (8%):</span>
                <span className="font-mono">${order.tax.toFixed(2)}</span>
              </div>

              <div className="flex justify-between text-base font-bold py-2.5 text-slate-900">
                <span>Order Total:</span>
                <span className="font-mono text-amber-600">${order.total.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Footer Receipt Note */}
          <div className="border-t border-slate-200 pt-6 mt-8 text-center">
            <p className="text-xs text-slate-400 font-medium">
              Thank you for shopping with Amazon Clone! This is a secure, sandboxed checkout transaction demonstration.
            </p>
            <div className="flex justify-center mt-3 gap-1 opacity-20">
              <ShoppingBag className="w-4 h-4 text-slate-700" />
              <div className="font-sans text-xs font-bold text-slate-900">
                amazon<span className="text-amber-500">.com</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
