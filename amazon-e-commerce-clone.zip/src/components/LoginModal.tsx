import React, { useState } from "react";
import { User } from "../types";
import { LogIn, UserPlus, X, HelpCircle } from "lucide-react";

interface LoginModalProps {
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
}

export default function LoginModal({ onClose, onLoginSuccess }: LoginModalProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("customer@amazon.com");
  const [password, setPassword] = useState("password");
  const [role, setRole] = useState("CUSTOMER");
  
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const url = isRegistering ? "/api/auth/register" : "/api/auth/login";
      const payload = isRegistering 
        ? { name, email, password, role } 
        : { email, password };

      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Authentication failed.");
      }

      const userData: User = await res.json();
      onLoginSuccess(userData);
      onClose();
    } catch (err: any) {
      setError(err.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  const handleShortcutClick = (shortcutEmail: string) => {
    setEmail(shortcutEmail);
    setPassword("password");
    setIsRegistering(false);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-2xl max-w-sm w-full text-slate-800 p-6 space-y-5 relative">
        
        <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors p-1 cursor-pointer">
          <X className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center gap-1.5 border-b border-slate-100 pb-3">
          <div className="text-xl font-bold tracking-tight text-slate-900 font-sans flex items-baseline">
            amazon<span className="text-amber-500 text-sm font-medium">clone</span>
          </div>
          <h2 className="text-sm font-semibold text-slate-500">
            {isRegistering ? "Register Sandbox Account" : "Sign In to Amazon Clone"}
          </h2>
        </div>

        {error && (
          <div className="bg-rose-50 border border-rose-200 text-rose-700 px-3 py-2 rounded text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          {isRegistering && (
            <div>
              <label className="block text-slate-500 font-bold mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="John Doe"
                className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-amber-500 focus:outline-hidden"
              />
            </div>
          )}

          <div>
            <label className="block text-slate-500 font-bold mb-1">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="customer@amazon.com"
              className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-[#febd69] focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-slate-500 font-bold mb-1">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-[#febd69] focus:outline-hidden"
            />
          </div>

          {isRegistering && (
            <div>
              <label className="block text-slate-500 font-bold mb-1">Account Role Type</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full px-2 py-2 border border-slate-300 rounded bg-white focus:ring-1 focus:ring-[#febd69] focus:outline-hidden font-semibold"
              >
                <option value="CUSTOMER">Customer</option>
                <option value="SELLER">Seller / Multi-Vendor</option>
                <option value="ADMIN">System Administrator</option>
              </select>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2 bg-[#ffd814] hover:bg-[#f7ca00] disabled:bg-slate-300 text-black font-bold rounded-full shadow-sm cursor-pointer transition-colors mt-2 text-xs flex items-center justify-center gap-1.5"
          >
            {isRegistering ? <UserPlus className="w-3.5 h-3.5" /> : <LogIn className="w-3.5 h-3.5" />}
            {loading ? "Please wait..." : isRegistering ? "Register Account" : "Sign In"}
          </button>
        </form>

        {/* Toggle option */}
        <div className="text-center text-[11px] text-slate-500 border-t border-slate-100 pt-3">
          <button
            onClick={() => setIsRegistering(!isRegistering)}
            className="text-[#c45500] hover:underline font-semibold cursor-pointer"
          >
            {isRegistering ? "Already have a sandbox account? Sign In" : "Don't have an account? Register as Customer/Seller"}
          </button>
        </div>

        {/* Sandbox quick log-ins */}
        {!isRegistering && (
          <div className="bg-slate-50 border border-slate-200 rounded p-3 text-[10px] text-slate-500 space-y-1.5">
            <p className="font-bold flex items-center gap-1">
              <HelpCircle className="w-3.5 h-3.5 text-slate-400" />
              Quick Sandbox Credentials (pwd: <em>password</em>)
            </p>
            <div className="flex flex-wrap gap-1">
              <button
                type="button"
                onClick={() => handleShortcutClick("customer@amazon.com")}
                className="px-2 py-0.5 bg-white hover:bg-amber-50 rounded border border-slate-200 cursor-pointer text-slate-600 font-semibold text-[9px]"
              >
                Customer
              </button>
              <button
                type="button"
                onClick={() => handleShortcutClick("seller@amazon.com")}
                className="px-2 py-0.5 bg-white hover:bg-amber-50 rounded border border-slate-200 cursor-pointer text-slate-600 font-semibold text-[9px]"
              >
                Seller
              </button>
              <button
                type="button"
                onClick={() => handleShortcutClick("admin@amazon.com")}
                className="px-2 py-0.5 bg-white hover:bg-amber-50 rounded border border-slate-200 cursor-pointer text-slate-600 font-semibold text-[9px]"
              >
                Admin
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
