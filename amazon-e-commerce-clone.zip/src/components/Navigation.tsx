import { Search, ShoppingCart, MapPin, ChevronDown, Database, LogIn, LogOut, Heart } from "lucide-react";
import { User, Category, CartItem } from "../types";

interface NavigationProps {
  currentUser: User | null;
  categories: Category[];
  cart: CartItem[];
  selectedCategory: string;
  searchQuery: string;
  onCategoryChange: (cat: string) => void;
  onSearchChange: (query: string) => void;
  onRoleSwitch: (role: 'CUSTOMER' | 'SELLER' | 'ADMIN') => void;
  onLogout: () => void;
  onLoginClick: () => void;
  onCartClick: () => void;
  onOrdersClick: () => void;
  onWishlistClick: () => void;
  onHomeClick: () => void;
  onArchitectureClick: () => void;
  activeView: string;
}

export default function Navigation({
  currentUser,
  categories,
  cart,
  selectedCategory,
  searchQuery,
  onCategoryChange,
  onSearchChange,
  onRoleSwitch,
  onLogout,
  onLoginClick,
  onCartClick,
  onOrdersClick,
  onWishlistClick,
  onHomeClick,
  onArchitectureClick,
  activeView
}: NavigationProps) {
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="bg-[#131921] text-white select-none print:hidden">
      
      {/* Top Banner Nav */}
      <div className="max-w-7xl mx-auto px-4 py-2.5 flex items-center justify-between gap-4">
        
        {/* Amazon Logo */}
        <button
          onClick={onHomeClick}
          className="flex items-center gap-1 cursor-pointer group text-left flex-shrink-0"
        >
          <span className="text-xl font-extrabold tracking-tight text-white font-sans flex items-baseline">
            amazon<span className="text-[#febd69] text-sm font-medium">clone</span>
          </span>
        </button>

        {/* Location selector */}
        <div className="hidden md:flex items-center gap-1 text-xs cursor-pointer hover:border hover:border-white p-1 rounded-sm border border-transparent">
          <MapPin className="w-4 h-4 text-slate-300 mt-1" />
          <div>
            <p className="text-slate-400 font-medium">Deliver to</p>
            <p className="font-bold text-slate-100">{currentUser ? currentUser.name.split(" ")[0] : "Guest"}</p>
          </div>
        </div>

        {/* Big Search Bar */}
        <div className="flex-1 flex max-w-2xl bg-white rounded-md overflow-hidden text-slate-800 focus-within:ring-2 focus-within:ring-[#febd69] focus-within:ring-offset-1 focus-within:ring-offset-[#131921] transition-all shadow-sm">
          {/* Category Dropdown */}
          <select
            value={selectedCategory}
            onChange={(e) => onCategoryChange(e.target.value)}
            className="px-3 bg-slate-100 border-r border-slate-300 text-slate-600 text-xs font-semibold cursor-pointer py-1.5 focus:outline-hidden hover:bg-slate-200"
          >
            <option value="All">All Departments</option>
            {categories.map((c) => (
              <option key={c.id} value={c.name}>{c.name}</option>
            ))}
          </select>
          
          <input
            type="text"
            placeholder="Search Amazon Clone Marketplace..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="flex-1 px-4 text-sm text-slate-900 focus:outline-hidden"
          />
          
          <button className="px-5 bg-[#febd69] hover:bg-[#f3a847] active:bg-[#f3a847] text-[#131921] cursor-pointer transition-colors flex items-center justify-center">
            <Search className="w-4 h-4 font-bold" />
          </button>
        </div>

        {/* User Account Controls */}
        <div className="flex items-center gap-1 sm:gap-4 flex-shrink-0">
          
          {/* Role switcher for developers */}
          {currentUser && (
            <div className="relative group text-xs hover:border hover:border-white px-2 py-1.5 rounded-sm border border-transparent cursor-pointer">
              <p className="text-slate-400">Sandbox Role</p>
              <div className="flex items-center gap-0.5 font-bold text-white uppercase tracking-wide">
                <span>{currentUser.role}</span>
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </div>

              {/* Hover Dropdown */}
              <div className="absolute right-0 top-full mt-0 w-36 bg-white rounded border border-slate-200 shadow-xl py-1 text-slate-800 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-all z-50">
                <p className="px-3 py-1.5 border-b border-slate-100 text-[10px] uppercase font-bold text-slate-400">Switch Identity</p>
                <button
                  onClick={() => onRoleSwitch('CUSTOMER')}
                  className={`w-full text-left px-3 py-2 text-xs font-semibold hover:bg-slate-50 cursor-pointer ${currentUser.role === 'CUSTOMER' ? 'text-[#c45500] bg-amber-50/50' : 'text-slate-700'}`}
                >
                  Customer
                </button>
                <button
                  onClick={() => onRoleSwitch('SELLER')}
                  className={`w-full text-left px-3 py-2 text-xs font-semibold hover:bg-slate-50 cursor-pointer ${currentUser.role === 'SELLER' ? 'text-[#c45500] bg-amber-50/50' : 'text-slate-700'}`}
                >
                  Seller Panel
                </button>
                <button
                  onClick={() => onRoleSwitch('ADMIN')}
                  className={`w-full text-left px-3 py-2 text-xs font-semibold hover:bg-slate-50 cursor-pointer ${currentUser.role === 'ADMIN' ? 'text-[#c45500] bg-amber-50/50' : 'text-slate-700'}`}
                >
                  Admin Center
                </button>
              </div>
            </div>
          )}

          {/* SignIn / SignOut */}
          {currentUser ? (
            <div className="text-xs hover:border hover:border-white px-2 py-1.5 rounded-sm border border-transparent cursor-pointer flex items-center gap-1.5" onClick={onLogout}>
              <div className="hidden sm:block">
                <p className="text-slate-400 leading-tight">Hello, {currentUser.name.split(" ")[0]}</p>
                <p className="font-bold text-white leading-tight">Sign Out</p>
              </div>
              <LogOut className="w-4 h-4 text-slate-300" />
            </div>
          ) : (
            <div className="text-xs hover:border hover:border-white px-2 py-1.5 rounded-sm border border-transparent cursor-pointer flex items-center gap-1.5" onClick={onLoginClick}>
              <div>
                <p className="text-slate-400 leading-tight">Hello, Sign In</p>
                <p className="font-bold text-white leading-tight">Account & Lists</p>
              </div>
              <LogIn className="w-4 h-4 text-slate-300" />
            </div>
          )}

          {/* Returns and Orders */}
          {currentUser && (
            <button
              onClick={onOrdersClick}
              className={`text-xs hover:border hover:border-white px-2 py-1.5 rounded-sm border border-transparent cursor-pointer ${activeView === 'orders' ? 'border-white' : ''}`}
            >
              <p className="text-slate-400 leading-tight">Returns</p>
              <p className="font-bold text-white leading-tight">& Orders</p>
            </button>
          )}

          {/* Wishlist Icon */}
          {currentUser && currentUser.role === 'CUSTOMER' && (
            <button
              onClick={onWishlistClick}
              className="relative hover:border hover:border-white p-1.5 rounded-sm border border-transparent cursor-pointer text-slate-300 hover:text-rose-500 transition-colors"
              title="View Wishlist"
            >
              <Heart className="w-5 h-5 fill-current" />
            </button>
          )}

          {/* Cart Icon */}
          {(!currentUser || currentUser.role === 'CUSTOMER') && (
            <button
              onClick={onCartClick}
              className="relative flex items-center gap-1 hover:border hover:border-white px-2 py-1 rounded-sm border border-transparent cursor-pointer"
            >
              <div className="relative">
                <ShoppingCart className="w-6 h-6 text-slate-100" />
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1 bg-[#febd69] text-[#131921] text-[10px] font-bold w-4.5 h-4.5 rounded-full flex items-center justify-center border-2 border-[#131921] shadow-sm font-mono">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:block text-xs font-bold text-slate-100 mt-2">Cart</span>
            </button>
          )}

        </div>
      </div>

      {/* Sub Navigation Bar */}
      <div className="bg-[#232f3e] text-xs py-1.5 px-4 font-semibold text-slate-300 border-t border-slate-700/50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          
          <div className="flex items-center gap-4 sm:gap-6">
            <button 
              onClick={onHomeClick} 
              className={`hover:text-white cursor-pointer ${activeView === 'catalog' ? 'text-[#febd69] font-bold' : ''}`}
            >
              Today's Deals
            </button>
            <button 
              onClick={() => onCategoryChange("Electronics")} 
              className="hover:text-white cursor-pointer"
            >
              Electronics
            </button>
            <button 
              onClick={() => onCategoryChange("Fashion")} 
              className="hover:text-white cursor-pointer"
            >
              Fashion
            </button>
            <button 
              onClick={() => onCategoryChange("Books")} 
              className="hover:text-white cursor-pointer"
            >
              Books
            </button>

            {/* Seller/Admin portals shortcut inside Subnav */}
            {currentUser && currentUser.role === 'SELLER' && (
              <span className="text-[#febd69] font-bold bg-[#febd69]/10 px-2 py-0.5 rounded border border-[#febd69]/20">
                Seller Console Active
              </span>
            )}
            {currentUser && currentUser.role === 'ADMIN' && (
              <span className="text-[#febd69] font-bold bg-[#febd69]/10 px-2 py-0.5 rounded border border-[#febd69]/20">
                Admin Console Active
              </span>
            )}
          </div>

          {/* Database and architecture viewer toggle */}
          <button
            onClick={onArchitectureClick}
            className={`flex items-center gap-1 text-xs text-[#febd69] bg-[#febd69]/10 hover:bg-[#febd69]/20 active:bg-[#febd69]/30 px-3 py-1 rounded border border-[#febd69]/30 transition-all font-mono font-bold cursor-pointer ${
              activeView === 'architecture' ? 'bg-[#febd69] text-[#131921] border-[#febd69] font-bold hover:bg-[#febd69]/90' : ''
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            Spring Boot APIs & ER Diagram
          </button>

        </div>
      </div>

    </header>
  );
}
