import { Product } from "../types";
import { Star, Heart, ShoppingCart } from "lucide-react";

interface ProductCardProps {
  key?: string;
  product: Product;
  isInWishlist: boolean;
  onAddToCart: (p: Product) => void;
  onToggleWishlist: (p: Product) => void;
  onProductClick: (p: Product) => void;
  currentUserRole?: string;
}

export default function ProductCard({
  product,
  isInWishlist,
  onAddToCart,
  onToggleWishlist,
  onProductClick,
  currentUserRole
}: ProductCardProps) {
  
  // Calculate discount percentage
  const discountPercent = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  // Star Rating Array
  const fullStars = Math.floor(product.rating);
  const halfStar = product.rating % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);

  return (
    <div className="bg-white rounded-md border border-gray-200 overflow-hidden hover:shadow-lg transition-all group flex flex-col justify-between h-full relative">
      
      {/* Wishlist Button - Only for Customers or Guest */}
      {(!currentUserRole || currentUserRole === 'CUSTOMER') && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-2.5 right-2.5 p-1.5 rounded-full shadow-xs border transition-all z-10 bg-white cursor-pointer ${
            isInWishlist 
              ? "text-rose-600 border-rose-100 hover:bg-rose-50" 
              : "text-slate-400 border-slate-200 hover:bg-slate-50 hover:text-rose-500"
          }`}
          title={isInWishlist ? "Remove from wishlist" : "Add to wishlist"}
        >
          <Heart className={`w-4 h-4 ${isInWishlist ? "fill-current" : ""}`} />
        </button>
      )}

      {/* Main product clickable details area */}
      <div className="cursor-pointer p-4 flex flex-col gap-2 flex-1" onClick={() => onProductClick(product)}>
        
        {/* Product Image */}
        <div className="h-44 w-full flex items-center justify-center bg-slate-50/50 mb-2 overflow-hidden rounded relative">
          <img
            src={product.image}
            alt={product.title}
            className="h-full w-full object-contain group-hover:scale-105 transition-transform duration-300"
            referrerPolicy="no-referrer"
          />
          {discountPercent > 0 && (
            <span className="absolute bottom-2 left-2 bg-[#febd69] text-[#131921] text-[10px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider">
              Save {discountPercent}%
            </span>
          )}
        </div>

        {/* Category Shelf */}
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
          {product.category}
        </span>

        {/* Product Title */}
        <h3 className="font-sans text-sm font-semibold text-slate-900 group-hover:text-[#c45500] transition-colors line-clamp-2 leading-tight">
          {product.title}
        </h3>

        {/* Ratings Review Area */}
        <div className="flex items-center gap-1">
          <div className="flex text-yellow-500 items-center">
            {Array.from({ length: fullStars }).map((_, i) => (
              <Star key={`f-${i}`} className="w-3.5 h-3.5 fill-current" />
            ))}
            {halfStar && <Star className="w-3.5 h-3.5 fill-current opacity-60" />}
            {Array.from({ length: emptyStars }).map((_, i) => (
              <Star key={`e-${i}`} className="w-3.5 h-3.5 opacity-20" />
            ))}
          </div>
          <span className="text-xs text-slate-500 font-semibold font-sans">{product.rating}</span>
          <span className="text-xs text-slate-400 font-medium">({product.reviewsCount})</span>
        </div>

        {/* Stock Status Warn */}
        {product.inventoryCount <= 5 && product.inventoryCount > 0 && (
          <p className="text-[10px] text-rose-600 font-bold tracking-wide">
            ⚠️ Only {product.inventoryCount} left in stock - order soon.
          </p>
        )}
        {product.inventoryCount === 0 && (
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
            ❌ Out of Stock
          </p>
        )}
      </div>

      {/* Cart & Price footer */}
      <div className="px-4 pb-4 border-t border-slate-100/60 pt-3">
        <div className="flex items-baseline gap-1.5 mb-3.5">
          <span className="text-lg font-extrabold text-slate-900 font-mono">${product.price.toFixed(2)}</span>
          {product.originalPrice && (
            <span className="text-xs text-slate-400 line-through font-mono">
              ${product.originalPrice.toFixed(2)}
            </span>
          )}
        </div>

        {(!currentUserRole || currentUserRole === 'CUSTOMER') && (
          <button
            onClick={() => onAddToCart(product)}
            disabled={product.inventoryCount === 0}
            className={`w-full py-2 text-xs font-bold rounded-full shadow-sm flex items-center justify-center gap-1.5 cursor-pointer transition-colors ${
              product.inventoryCount === 0
                ? "bg-slate-100 text-slate-400 cursor-not-allowed shadow-none"
                : "bg-[#ffd814] hover:bg-[#f7ca00] text-black"
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            {product.inventoryCount === 0 ? "Out of Stock" : "Add to Cart"}
          </button>
        )}

        {(currentUserRole === 'SELLER' || currentUserRole === 'ADMIN') && (
          <div className="text-[11px] text-slate-400 font-medium border border-dashed border-slate-200 bg-slate-50 p-2 text-center rounded">
            Seller: <span className="font-bold text-slate-600">{product.sellerName}</span>
          </div>
        )}
      </div>

    </div>
  );
}
