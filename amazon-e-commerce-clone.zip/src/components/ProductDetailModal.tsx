import React, { useState, useEffect } from "react";
import { Product, Review } from "../types";
import { Star, MessageSquare, Plus, ShoppingCart, X, HelpCircle, User } from "lucide-react";

interface ProductDetailModalProps {
  product: Product;
  authToken?: string;
  onClose: () => void;
  onAddToCart: (p: Product) => void;
}

export default function ProductDetailModal({ product, authToken, onClose, onAddToCart }: ProductDetailModalProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [reviewsLoaded, setReviewsLoaded] = useState(false);
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState("");
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewError, setReviewError] = useState("");

  const loadReviews = async () => {
    try {
      const res = await fetch(`/api/products/${product.id}`);
      const data = await res.json();
      setReviews(data.reviews || []);
      setReviewsLoaded(true);
    } catch (err) {
      console.error("Failed to load product reviews", err);
    }
  };

  // Load reviews on mount or product change safely
  useEffect(() => {
    loadReviews();
  }, [product.id]);

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    setReviewError("");
    setSubmittingReview(true);

    try {
      const headers: HeadersInit = { "Content-Type": "application/json" };
      if (authToken) {
        headers["Authorization"] = `Bearer ${authToken}`;
      }

      const res = await fetch(`/api/products/${product.id}/reviews`, {
        method: "POST",
        headers,
        body: JSON.stringify({ rating: newRating, comment: newComment })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to submit review.");
      }

      setNewComment("");
      setNewRating(5);
      loadReviews(); // reload
    } catch (err: any) {
      setReviewError(err.message || "Unable to save review.");
    } finally {
      setSubmittingReview(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-2xl max-w-4xl w-full text-slate-800 flex flex-col md:flex-row overflow-hidden max-h-[90vh]">
        
        {/* Left Column: Product visual and info */}
        <div className="md:w-1/2 p-6 overflow-y-auto max-h-[90vh] space-y-4 border-r border-slate-100 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono bg-slate-50 border border-slate-200 px-2 py-0.5 rounded">
                  {product.category}
                </span>
                <h2 className="text-base sm:text-lg font-bold text-slate-900 mt-2 leading-snug">
                  {product.title}
                </h2>
              </div>
              <button onClick={onClose} className="md:hidden text-slate-400 hover:text-slate-600 transition-colors p-1 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Large Image container */}
            <div className="bg-slate-50/50 p-4 rounded border border-slate-150 h-64 flex items-center justify-center overflow-hidden">
              <img 
                src={product.image} 
                alt={product.title} 
                className="max-h-full max-w-full object-contain rounded" 
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Detailed Description */}
            <div className="mt-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">Product Description</h3>
              <p className="text-xs text-slate-600 leading-relaxed font-sans">{product.description}</p>
            </div>
          </div>

          {/* Action Row */}
          <div className="border-t border-slate-100/80 pt-4 mt-6">
            <div className="flex justify-between items-center mb-4">
              <div>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Price</p>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-extrabold text-slate-950 font-mono">${product.price.toFixed(2)}</span>
                  {product.originalPrice && (
                    <span className="text-sm text-slate-400 line-through font-mono">
                      ${product.originalPrice.toFixed(2)}
                    </span>
                  )}
                </div>
              </div>
              <div className="text-right">
                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Availability</p>
                {product.inventoryCount > 0 ? (
                  <span className="text-xs font-bold text-emerald-600">
                    In Stock ({product.inventoryCount} units)
                  </span>
                ) : (
                  <span className="text-xs font-bold text-rose-600">Out of Stock</span>
                )}
              </div>
            </div>

            <button
              onClick={() => onAddToCart(product)}
              disabled={product.inventoryCount === 0}
              className={`w-full py-2.5 text-xs font-bold rounded-full shadow-sm flex items-center justify-center gap-2 cursor-pointer transition-colors ${
                product.inventoryCount === 0
                  ? "bg-slate-100 text-slate-400 cursor-not-allowed"
                  : "bg-[#ffd814] hover:bg-[#f7ca00] text-black"
              }`}
            >
              <ShoppingCart className="w-4 h-4" />
              {product.inventoryCount === 0 ? "Out of Stock" : "Add to Cart"}
            </button>
            <p className="text-[10px] text-center text-slate-400 mt-2 font-medium">
              Sold and fulfilled by <strong className="text-slate-500">{product.sellerName}</strong>. Standard return policies apply.
            </p>
          </div>
        </div>

        {/* Right Column: Reviews & ratings panel */}
        <div className="md:w-1/2 p-6 overflow-y-auto max-h-[90vh] flex flex-col justify-between bg-slate-50/50">
          <div className="space-y-6">
            <div className="flex justify-between items-center border-b border-slate-200 pb-3">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4" />
                Customer Reviews
              </h3>
              <button onClick={onClose} className="hidden md:block text-slate-400 hover:text-slate-600 transition-colors p-1 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* List current reviews */}
            <div className="space-y-4 max-h-[40vh] overflow-y-auto pr-1">
              {reviews.map((rev) => (
                <div key={rev.id} className="bg-white p-3.5 rounded border border-slate-200 text-xs">
                  <div className="flex justify-between items-start mb-1.5">
                    <div className="flex items-center gap-1.5">
                      <div className="p-1 bg-slate-100 text-slate-500 rounded-full">
                        <User className="w-3 h-3" />
                      </div>
                      <span className="font-bold text-slate-700">{rev.username}</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-medium">{rev.date}</span>
                  </div>

                  {/* Rating Stars */}
                  <div className="flex text-yellow-500 items-center gap-0.5 mb-2">
                    {Array.from({ length: rev.rating }).map((_, i) => (
                      <Star key={`f-${i}`} className="w-3 h-3 fill-current" />
                    ))}
                    {Array.from({ length: 5 - rev.rating }).map((_, i) => (
                      <Star key={`e-${i}`} className="w-3 h-3 opacity-20" />
                    ))}
                  </div>

                  <p className="text-slate-600 leading-normal font-sans italic">"{rev.comment}"</p>
                </div>
              ))}
              {reviews.length === 0 && (
                <p className="text-slate-400 text-xs text-center py-6 italic">No reviews submitted yet for this listing. Be the first to review!</p>
              )}
            </div>
          </div>

          {/* Form to submit review */}
          <div className="border-t border-slate-200 pt-5 mt-6">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1">
              <Plus className="w-4 h-4" />
              Write a Review
            </h4>
            
            {reviewError && (
              <p className="text-rose-600 text-[11px] font-semibold mb-2">{reviewError}</p>
            )}

            <form onSubmit={handleReviewSubmit} className="space-y-3.5 text-xs">
              <div className="flex items-center gap-3">
                <span className="font-bold text-slate-600">Select Rating:</span>
                <div className="flex gap-1 text-yellow-500">
                  {[1, 2, 3, 4, 5].map((starVal) => (
                    <button
                      key={starVal}
                      type="button"
                      onClick={() => setNewRating(starVal)}
                      className="cursor-pointer hover:scale-110 transition-transform"
                    >
                      <Star className={`w-5 h-5 ${starVal <= newRating ? "fill-current" : "opacity-30"}`} />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <textarea
                  required
                  rows={2}
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Share your experience and product highlights..."
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-[#febd69] focus:outline-hidden bg-white resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={submittingReview}
                className="w-full py-1.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white font-semibold rounded transition-colors cursor-pointer"
              >
                {submittingReview ? "Saving review..." : "Submit Review"}
              </button>
            </form>
          </div>
        </div>

      </div>
    </div>
  );
}
