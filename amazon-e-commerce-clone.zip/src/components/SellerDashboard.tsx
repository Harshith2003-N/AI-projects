import React, { useState, useEffect } from "react";
import { Product } from "../types";
import { PlusCircle, Edit2, Trash2, Check, X, RefreshCw, Layers, TrendingUp, DollarSign, Package, Star } from "lucide-react";

interface SellerDashboardProps {
  authToken: string;
}

export default function SellerDashboard({ authToken }: SellerDashboardProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  
  // Form State
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [originalPrice, setOriginalPrice] = useState("");
  const [image, setImage] = useState("");
  const [category, setCategory] = useState("");
  const [inventoryCount, setInventoryCount] = useState("50");

  // Editing state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState("");
  const [editStock, setEditStock] = useState("");
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const fetchProducts = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/products");
      if (!res.ok) throw new Error("Failed to fetch product catalog.");
      const data = await res.json();
      
      // Filter products only by this seller (simulate server filter or execute client side)
      // Since our mock database sets owner sellerId to "u-2" for default products, match that
      const sellerProducts = data.products.filter((p: Product) => p.sellerId === "u-2");
      setProducts(sellerProducts);

      // Fetch Categories
      const catRes = await fetch("/api/categories");
      const catData = await catRes.json();
      setCategories(catData.map((c: any) => c.name));
      if (catData.length > 0) setCategory(catData[0].name);

    } catch (err: any) {
      setError(err.message || "An error occurred fetching catalog.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccessMsg("");

    if (!title.trim() || !description.trim() || !price || !inventoryCount) {
      setError("Please fill in all required fields.");
      return;
    }

    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${authToken}`
        },
        body: JSON.stringify({
          title,
          description,
          price: Number(price),
          originalPrice: originalPrice ? Number(originalPrice) : undefined,
          image: image.trim() || undefined,
          category,
          inventoryCount: Number(inventoryCount)
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to create product listing.");
      }

      setSuccessMsg(`Successfully listed "${title}"!`);
      setTitle("");
      setDescription("");
      setPrice("");
      setOriginalPrice("");
      setImage("");
      setInventoryCount("50");
      
      fetchProducts();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    setError("");
    setSuccessMsg("");

    try {
      const res = await fetch(`/api/products/${productId}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${authToken}`
        }
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to delete product.");
      }

      setSuccessMsg("Product listed item removed successfully.");
      fetchProducts();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const startEditing = (prod: Product) => {
    setEditingId(prod.id);
    setEditPrice(String(prod.price));
    setEditStock(String(prod.inventoryCount));
  };

  const saveProductEdit = async (productId: string) => {
    setError("");
    setSuccessMsg("");

    try {
      const res = await fetch(`/api/products/${productId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${authToken}`
        },
        body: JSON.stringify({
          price: Number(editPrice),
          inventoryCount: Number(editStock)
        })
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "Failed to update product.");
      }

      setSuccessMsg("Listing updated successfully.");
      setEditingId(null);
      fetchProducts();
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Stats summaries
  const totalListed = products.length;
  const totalStockCount = products.reduce((sum, p) => sum + p.inventoryCount, 0);
  const averageRating = totalListed > 0 
    ? Number((products.reduce((sum, p) => sum + p.rating, 0) / totalListed).toFixed(1)) 
    : 5.0;

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-500">
        <RefreshCw className="w-8 h-8 animate-spin text-amber-500 mb-2" />
        <p className="text-sm font-medium">Reindexing seller catalog inventory...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      
      {/* Seller Portal Header */}
      <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
        <h2 className="text-xl font-bold text-slate-900 tracking-tight">Seller Central Dashboard</h2>
        <p className="text-xs text-slate-500 mt-1">
          Review listed SKUs, track inventory quotas, modify catalog prices, and view customer rating metrics.
        </p>
      </div>

      {error && (
        <div className="bg-rose-50 border border-rose-200 text-rose-700 px-4 py-3 rounded text-sm flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError("")} className="text-rose-500 hover:text-rose-700">✕</button>
        </div>
      )}

      {successMsg && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-700 px-4 py-3 rounded text-sm flex items-center justify-between">
          <span>{successMsg}</span>
          <button onClick={() => setSuccessMsg("")} className="text-emerald-500 hover:text-emerald-700">✕</button>
        </div>
      )}

      {/* Seller Stats Card Rows */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-amber-50 rounded-lg text-amber-600">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">SKUs Listed</p>
            <p className="text-2xl font-bold text-slate-900 mt-0.5">{totalListed}</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-slate-100 rounded-lg text-slate-600">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Warehouse Stock</p>
            <p className="text-2xl font-bold text-slate-900 mt-0.5">{totalStockCount}</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-lg border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-yellow-50 rounded-lg text-yellow-500">
            <Star className="w-6 h-6 fill-yellow-500" />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Average Shop Rating</p>
            <p className="text-2xl font-bold text-slate-900 mt-0.5">{averageRating} / 5.0</p>
          </div>
        </div>
      </div>

      {/* Grid: Create Listing Form & Active Listing Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Create Product Listing Form */}
        <div className="lg:col-span-4 bg-white p-6 rounded-lg border border-slate-200 shadow-xs h-fit">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-5 flex items-center gap-1.5">
            <PlusCircle className="w-4 h-4 text-amber-500" />
            Add New Product Listing
          </h3>
          <form onSubmit={handleCreateProduct} className="space-y-4 text-xs text-slate-700">
            <div>
              <label className="block font-bold text-slate-600 mb-1">Product Title *</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Wireless Mouse"
                className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-amber-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-600 mb-1">Detailed Description *</label>
              <textarea
                required
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Enter item specifications and key selling points..."
                className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-amber-500 focus:outline-hidden resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-600 mb-1">Sale Price ($) *</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="29.99"
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-600 mb-1">MSRP / Original ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={originalPrice}
                  onChange={(e) => setOriginalPrice(e.target.value)}
                  placeholder="49.99"
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-600 mb-1">Shelf Category *</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-2 py-2 border border-slate-300 rounded bg-white focus:ring-1 focus:ring-amber-500 focus:outline-hidden"
                >
                  {categories.map((catName) => (
                    <option key={catName} value={catName}>{catName}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-600 mb-1">Warehouse Qty *</label>
                <input
                  type="number"
                  required
                  value={inventoryCount}
                  onChange={(e) => setInventoryCount(e.target.value)}
                  placeholder="100"
                  className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-600 mb-1">Product Photo URL</label>
              <input
                type="url"
                value={image}
                onChange={(e) => setImage(e.target.value)}
                placeholder="Leave blank for a placeholder image"
                className="w-full px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-amber-500 focus:outline-hidden"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold rounded shadow-xs cursor-pointer transition-colors mt-2"
            >
              List Item on Amazon Marketplace
            </button>
          </form>
        </div>

        {/* Catalog Table */}
        <div className="lg:col-span-8 bg-white p-6 rounded-lg border border-slate-200 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-5">Your Listed Warehouse Catalog</h3>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                  <th className="px-4 py-2.5">Item Info</th>
                  <th className="px-4 py-2.5 text-right w-28">Price</th>
                  <th className="px-4 py-2.5 text-center w-28">Stock Level</th>
                  <th className="px-4 py-2.5 text-right w-24">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {products.map((p) => {
                  const isEditing = editingId === p.id;
                  
                  return (
                    <tr key={p.id} className="hover:bg-slate-50/50">
                      <td className="px-4 py-3 flex items-center gap-3">
                        <img 
                          src={p.image} 
                          alt={p.title} 
                          className="w-10 h-10 object-cover rounded border border-slate-200 flex-shrink-0" 
                          referrerPolicy="no-referrer"
                        />
                        <div className="min-w-0">
                          <p className="font-bold text-slate-900 truncate leading-tight">{p.title}</p>
                          <p className="text-[10px] text-slate-400 mt-0.5">{p.category} | Rating: {p.rating} ★</p>
                        </div>
                      </td>

                      {/* Price Cell */}
                      <td className="px-4 py-3 text-right">
                        {isEditing ? (
                          <input
                            type="number"
                            step="0.01"
                            value={editPrice}
                            onChange={(e) => setEditPrice(e.target.value)}
                            className="w-20 px-1.5 py-1 border border-slate-300 rounded text-right text-xs"
                          />
                        ) : (
                          <span className="font-semibold font-mono text-slate-800">${p.price.toFixed(2)}</span>
                        )}
                      </td>

                      {/* Stock Cell */}
                      <td className="px-4 py-3 text-center">
                        {isEditing ? (
                          <input
                            type="number"
                            value={editStock}
                            onChange={(e) => setEditStock(e.target.value)}
                            className="w-16 px-1.5 py-1 border border-slate-300 rounded text-center text-xs"
                          />
                        ) : (
                          <span className={`px-2 py-0.5 rounded font-mono font-bold ${
                            p.inventoryCount <= 5 
                              ? "bg-rose-50 text-rose-600 border border-rose-200" 
                              : "bg-emerald-50 text-emerald-600 border border-emerald-100"
                          }`}>
                            {p.inventoryCount} units
                          </span>
                        )}
                      </td>

                      {/* Action Cell */}
                      <td className="px-4 py-3 text-right">
                        {isEditing ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => saveProductEdit(p.id)}
                              className="p-1 bg-emerald-500 hover:bg-emerald-600 text-white rounded cursor-pointer transition-colors"
                              title="Save changes"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setEditingId(null)}
                              className="p-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded cursor-pointer transition-colors"
                              title="Cancel"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : deleteConfirmId === p.id ? (
                          <div className="flex items-center justify-end gap-1 select-none animate-pulse">
                            <span className="text-[10px] text-rose-600 font-bold mr-1">Delete?</span>
                            <button
                              onClick={() => {
                                handleDeleteProduct(p.id);
                                setDeleteConfirmId(null);
                              }}
                              className="px-1.5 py-0.5 bg-rose-600 text-white rounded text-[10px] font-bold cursor-pointer hover:bg-rose-700 transition-colors"
                            >
                              Yes
                            </button>
                            <button
                              onClick={() => setDeleteConfirmId(null)}
                              className="px-1.5 py-0.5 bg-slate-200 text-slate-700 rounded text-[10px] font-bold cursor-pointer hover:bg-slate-300 transition-colors"
                            >
                              No
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => startEditing(p)}
                              className="p-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded border border-slate-200 cursor-pointer transition-colors"
                              title="Quick edit"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => setDeleteConfirmId(p.id)}
                              className="p-1 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded border border-rose-200 cursor-pointer transition-colors"
                              title="Remove listing"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </td>

                    </tr>
                  );
                })}
                {products.length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-4 py-8 text-center text-slate-400 italic">
                      You do not have any listings in your active sales portfolio.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>

    </div>
  );
}
