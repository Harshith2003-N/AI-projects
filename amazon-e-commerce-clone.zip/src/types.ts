export type UserRole = 'CUSTOMER' | 'SELLER' | 'ADMIN';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  token?: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  productCount: number;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  rating: number;
  reviewsCount: number;
  inventoryCount: number;
  sellerId: string;
  sellerName: string;
}

export interface Review {
  id: string;
  productId: string;
  username: string;
  rating: number;
  comment: string;
  date: string;
}

export interface CartItem {
  productId: string;
  quantity: number;
}

export interface OrderItem {
  productId: string;
  title: string;
  price: number;
  image: string;
  quantity: number;
}

export interface Order {
  id: string;
  userId: string;
  date: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  status: 'PENDING' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED';
  invoiceNumber: string;
  shippingAddress: {
    fullName: string;
    street: string;
    city: string;
    zipCode: string;
    country: string;
  };
  paymentMethod: string;
}

export interface Coupon {
  code: string;
  discountPercentage: number;
  minSpend: number;
  active: boolean;
}

export interface SalesAnalytics {
  revenue: number;
  salesGrowth: number; // percentage
  ordersCount: number;
  ordersGrowth: number; // percentage
  customersCount: number;
  customersGrowth: number; // percentage
  lowStockItemsCount: number;
  monthlyRevenue: { month: string; amount: number; orders: number }[];
  categoryDistribution: { name: string; count: number; revenue: number }[];
  topProducts: { title: string; price: number; sold: number; revenue: number }[];
}
