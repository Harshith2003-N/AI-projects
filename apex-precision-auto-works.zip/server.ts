import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());

// Lazy-initialized Gemini Client
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not defined");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// 1. API: Health Check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// 2. API: Symptoms Analyzer (Gemini Powered)
app.post("/api/diagnose", async (req, res) => {
  const { symptoms, carInfo } = req.body;

  if (!symptoms) {
    return res.status(400).json({ error: "Symptoms description is required" });
  }

  try {
    const ai = getAiClient();

    const prompt = `
      You are a world-class automotive diagnostics mechanical engineer.
      Analyze the customer's reported vehicle symptoms and vehicle context.
      
      Vehicle Context: ${carInfo || "Unknown Car"}
      Customer Reported Symptoms: "${symptoms}"

      Provide an expert, professional, and friendly diagnostic evaluation.
      You must return structured JSON that recommends:
      - Recommended Service: Select one of the available shop packages:
        1. "basic_service" (For general fluid, wiper, low-risk checks)
        2. "major_service" (For multiple/deep issues, spark plugs, filters, engine issues)
        3. "brake_overhaul" (For squeaking brakes, grinding rotors, soft pedal feel)
        4. "wheel_alignment" (For steering pulling, tyre wear, vibration)
        5. "detailing_spa" (For paint defects, interior smells, dirty cabin)
      - Recommended Add-ons: Select a list of relevant addon IDs from these:
        1. "synthetic_oil_upgrade" (If they want premium performance, or long travel)
        2. "wiper_replacement" (If they mention vision, rain, noise on windshield)
        3. "cabin_pollen_filter" (If they mention bad smells inside, dusty AC, stuffiness)
        4. "engine_flush" (If they mention engine sludge, heavy carbon, old car ticking)
        5. "tire_rotation" (If they have tire wear, vibrations)
      - Diagnostic Summary: A concise, highly informative, reassuring summary explaining what parts are likely causing the issue and how critical it is.
      - Risk Level: Hazard level, either "LOW", "MEDIUM", or "HIGH".
      - Suggested Repairs: 2-4 bullet list strings of what our mechanics will inspect or resolve during the repair.
      - Explanation: A professional engineer's explanation connecting their symptom to our recommendations.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        temperature: 0.2,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendedServiceId: {
              type: Type.STRING,
              description: "Must be: basic_service, major_service, brake_overhaul, wheel_alignment, or detailing_spa."
            },
            recommendedAddOnIds: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Subset of: synthetic_oil_upgrade, wiper_replacement, cabin_pollen_filter, engine_flush, tire_rotation."
            },
            diagnosticSummary: {
              type: Type.STRING,
              description: "A short, reassuring mechanic's summary of what is likely wrong."
            },
            riskLevel: {
              type: Type.STRING,
              description: "Safety risk rating. Must be: LOW, MEDIUM, or HIGH."
            },
            suggestedRepairs: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "2 to 4 bullet points of mechanical checks to perform."
            },
            explanation: {
              type: Type.STRING,
              description: "A brief engineering justification for the recommended service."
            }
          },
          required: [
            "recommendedServiceId",
            "recommendedAddOnIds",
            "diagnosticSummary",
            "riskLevel",
            "suggestedRepairs",
            "explanation"
          ]
        }
      }
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error("Empty response received from AI model");
    }

    const diagnosisResult = JSON.parse(textOutput);
    return res.json(diagnosisResult);

  } catch (error: any) {
    console.error("Gemini diagnostics error:", error.message || error);
    
    // Elegant, highly realistic Local Backup Diagnostic Engine fallback
    // Matches common keywords to mock an intelligent response so the user gets a working app
    let recommendedServiceId = "basic_service";
    let recommendedAddOnIds: string[] = [];
    let diagnosticSummary = "Our backup diagnostics indicate a standard engine or safety threshold. A full mechanical inspection is recommended.";
    let riskLevel: "LOW" | "MEDIUM" | "HIGH" = "MEDIUM";
    let suggestedRepairs = ["General system health inspection", "Fluid levels verification"];
    let explanation = "Our localized diagnostics recommendation has been configured as a precaution. Our master technician will verify this upon arrival.";

    const queryLower = symptoms.toLowerCase();
    if (queryLower.includes("brake") || queryLower.includes("squeak") || queryLower.includes("grind") || queryLower.includes("stop")) {
      recommendedServiceId = "brake_overhaul";
      diagnosticSummary = "Suspected friction material wear on your brake pads. Grinding or squealing symptoms point to thin pads rubbing against the rotors.";
      riskLevel = "HIGH";
      suggestedRepairs = ["Brake pad thickness micrometer test", "Rotor runout measurement", "Hydraulic caliper slide pin service"];
      explanation = "To ensure vehicle stopping distance and prevent rotor scoring, we have selected the Brake Overhaul package.";
    } else if (queryLower.includes("pull") || queryLower.includes("align") || queryLower.includes("steer") || queryLower.includes("tire") || queryLower.includes("wear") || queryLower.includes("shake")) {
      recommendedServiceId = "wheel_alignment";
      diagnosticSummary = "Chassis wheel mis-alignment or wheel imbalance detected. Pulling to the side and uneven wear are primary indicators.";
      riskLevel = "MEDIUM";
      recommendedAddOnIds = ["tire_rotation"];
      suggestedRepairs = ["3D Laser wheel alignment tracking", "Camber/toe correction", "Dynamic wheel balance inspection"];
      explanation = "A 3D Alignment is recommended to correct tracking angles and stop the car from pulling.";
    } else if (queryLower.includes("smell") || queryLower.includes("odour") || queryLower.includes("stink") || queryLower.includes("air") || queryLower.includes("ac") || queryLower.includes("filter")) {
      recommendedServiceId = "detailing_spa";
      recommendedAddOnIds = ["cabin_pollen_filter"];
      diagnosticSummary = "Likely microbial or spore collection inside the AC evaporator unit or heavily clogged cabin air filter.";
      riskLevel = "LOW";
      suggestedRepairs = ["AC evaporator sanitization spray", "Cabin air plenum extraction", "Interior extraction wash"];
      explanation = "Replacing the cabin filter and running our interior sanitizer spa will completely eliminate odour-causing spores.";
    } else if (queryLower.includes("engine") || queryLower.includes("ticking") || queryLower.includes("sludge") || queryLower.includes("oil") || queryLower.includes("leak") || queryLower.includes("smoke")) {
      recommendedServiceId = "major_service";
      recommendedAddOnIds = ["engine_flush", "synthetic_oil_upgrade"];
      diagnosticSummary = "Possible internal lubricant degradation or ignition cylinder wear. Ticking sounds or leak reports indicate heavy logbook oversight is due.";
      riskLevel = "HIGH";
      suggestedRepairs = ["Compression cylinder pressure check", "Engine block leak dye testing", "OBD-II full electronic ECU scan"];
      explanation = "A comprehensive logbook overhaul is critical to verify key combustion elements and replace degraded synthetic lubricants.";
    }

    return res.json({
      recommendedServiceId,
      recommendedAddOnIds,
      diagnosticSummary,
      riskLevel,
      suggestedRepairs,
      explanation: `${explanation} (Using local backup expert system)`
    });
  }
});

async function main() {
  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

main();
