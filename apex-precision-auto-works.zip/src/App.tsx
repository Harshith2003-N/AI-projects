import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import * as Icons from 'lucide-react';
import { Car, Booking, BookingStatus, DiagnosticReport } from './types';
import { SERVICE_TYPES } from './data/carServiceData';

// Component Imports
import FacilitiesExplorer from './components/FacilitiesExplorer';
import GarageManager from './components/GarageManager';
import BookingWizard from './components/BookingWizard';
import LiveProgressDashboard from './components/LiveProgressDashboard';
import ShopAnalytics from './components/ShopAnalytics';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'garage' | 'booking' | 'tracker' | 'analytics'>('garage');

  // Garage State persistence
  const [cars, setCars] = useState<Car[]>(() => {
    const saved = localStorage.getItem('apex_garage_cars_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // Fallback
      }
    }
    // High-fidelity preloaded vehicles to play with immediately
    return [
      { id: 'car_1', make: 'Tesla', model: 'Model Y', year: 2024, mileage: 14200, fuelType: 'Electric' },
      { id: 'car_2', make: 'BMW', model: '330i Sedan', year: 2021, mileage: 48900, fuelType: 'Petrol' },
    ];
  });

  const [activeCarId, setActiveCarId] = useState<string | null>(() => {
    return cars.length > 0 ? cars[0].id : null;
  });

  // Bookings State persistence
  const [bookings, setBookings] = useState<Booking[]>(() => {
    const saved = localStorage.getItem('apex_bookings_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // Fallback
      }
    }
    return [];
  });

  const [activeBookingId, setActiveBookingId] = useState<string | null>(() => {
    const saved = localStorage.getItem('apex_active_booking_id_v1');
    return saved || null;
  });

  // Persist states
  useEffect(() => {
    localStorage.setItem('apex_garage_cars_v1', JSON.stringify(cars));
  }, [cars]);

  useEffect(() => {
    localStorage.setItem('apex_bookings_v1', JSON.stringify(bookings));
  }, [bookings]);

  useEffect(() => {
    if (activeBookingId) {
      localStorage.setItem('apex_active_booking_id_v1', activeBookingId);
    } else {
      localStorage.removeItem('apex_active_booking_id_v1');
    }
  }, [activeBookingId]);

  const activeCar = cars.find(c => c.id === activeCarId) || null;
  const activeBooking = bookings.find(b => b.id === activeBookingId) || null;

  // Handlers for Garage Management
  const handleSelectCar = (carId: string) => {
    setActiveCarId(carId);
  };

  const handleAddCar = (carData: Omit<Car, 'id'>) => {
    const newCar: Car = {
      ...carData,
      id: `car_${Date.now()}`,
    };
    setCars(prev => [...prev, newCar]);
    setActiveCarId(newCar.id);
  };

  const handleAddGuestCar = () => {
    const newCar: Car = {
      id: `car_${Date.now()}`,
      make: 'Tesla',
      model: 'Model S Plaid',
      year: 2025,
      mileage: 6200,
      fuelType: 'Electric',
    };
    setCars(prev => [...prev, newCar]);
    setActiveCarId(newCar.id);
  };

  const handleDeleteCar = (carId: string) => {
    setCars(prev => prev.filter(c => c.id !== carId));
    if (activeCarId === carId) {
      const remaining = cars.filter(c => c.id !== carId);
      setActiveCarId(remaining.length > 0 ? remaining[0].id : null);
    }
  };

  // Handlers for Booking Management
  const handleBookingSubmit = (bookingData: {
    serviceId: string;
    addOnIds: string[];
    date: string;
    timeSlot: string;
    notes: string;
    totalPrice: number;
    aiDiagnosticReport?: {
      summary: string;
      risk: 'LOW' | 'MEDIUM' | 'HIGH';
      suggestedRepairs: string[];
    };
  }) => {
    if (!activeCar) return;

    const selectedService = SERVICE_TYPES.find(s => s.id === bookingData.serviceId)!;

    // Generate random yet tailored physical diagnostic telemetry for health gauges
    const isMajor = selectedService.id === 'major_service';
    const isBrake = selectedService.id === 'brake_overhaul';

    const diagnosticReport: DiagnosticReport = {
      oilHealth: isMajor ? 12 : 35 + Math.round(Math.random() * 40),
      tireTreadDepthFront: 2.1 + Number((Math.random() * 4.5).toFixed(1)),
      tireTreadDepthRear: 3.5 + Number((Math.random() * 3.5).toFixed(1)),
      brakePadWear: isBrake ? 88 : 15 + Math.round(Math.random() * 45),
      batteryVoltage: Number((11.4 + Math.random() * 2.1).toFixed(1)),
      diagnosticSummary: bookingData.aiDiagnosticReport?.summary || "Standard system sanity diagnostics passed. All structural frame channels are true.",
      recommendedRepairs: bookingData.aiDiagnosticReport?.suggestedRepairs || [
        "Verify power circuit integrity",
        "Inspect primary hydraulic cylinders"
      ]
    };

    const newBooking: Booking = {
      id: `book_${Date.now()}`,
      car: activeCar,
      service: selectedService,
      date: bookingData.date,
      timeSlot: bookingData.timeSlot,
      addOns: bookingData.addOnIds,
      notes: bookingData.notes,
      totalPrice: bookingData.totalPrice,
      status: BookingStatus.AWAITING_ARRIVAL,
      progressPercent: 0,
      technician: 'Sarah Martinez (Senior EV & Powertrain Expert)',
      currentStep: 0,
      diagnosticReport,
      additionalRecommendationApproved: null,
    };

    setBookings(prev => [newBooking, ...prev]);
    setActiveBookingId(newBooking.id);
    setCurrentTab('tracker'); // Jump straight to live progress dashboard!
  };

  // Live progress simulation stepper
  const handleAdvanceProgressSimulated = () => {
    if (!activeBooking) return;

    let nextStatus = activeBooking.status;
    let progress = activeBooking.progressPercent;

    if (activeBooking.status === BookingStatus.AWAITING_ARRIVAL) {
      nextStatus = BookingStatus.DIAGNOSING;
      progress = 25;
    } else if (activeBooking.status === BookingStatus.DIAGNOSING) {
      nextStatus = BookingStatus.IN_PROGRESS;
      progress = 50;
    } else if (activeBooking.status === BookingStatus.IN_PROGRESS) {
      nextStatus = BookingStatus.QUALITY_CHECK;
      progress = 75;
    } else if (activeBooking.status === BookingStatus.QUALITY_CHECK) {
      nextStatus = BookingStatus.READY_FOR_PICKUP;
      progress = 100;
    } else if (activeBooking.status === BookingStatus.READY_FOR_PICKUP) {
      nextStatus = BookingStatus.COMPLETED;
      progress = 100;
    }

    setBookings(prev =>
      prev.map(b =>
        b.id === activeBooking.id
          ? { ...b, status: nextStatus, progressPercent: progress }
          : b
      )
    );
  };

  // Approve additional recommendation (the cabin filter upsell)
  const handleApproveRecommendation = (approved: boolean) => {
    if (!activeBooking) return;

    let updatedTotalPrice = activeBooking.totalPrice;
    let updatedAddOns = [...activeBooking.addOns];

    if (approved) {
      updatedTotalPrice += 35 + Math.round(35 * 0.1); // Add $35 filter + GST
      updatedAddOns.push('cabin_pollen_filter');
    }

    setBookings(prev =>
      prev.map(b =>
        b.id === activeBooking.id
          ? {
              ...b,
              additionalRecommendationApproved: approved,
              totalPrice: updatedTotalPrice,
              addOns: updatedAddOns,
            }
          : b
      )
    );
  };

  // Jump from Blueprint Work Service directly to booking tab with configured service
  const handleSelectServiceFromBlueprint = (serviceId: string) => {
    setCurrentTab('booking');
  };

  const handleUpdateDiagnostics = (updatedReport: DiagnosticReport) => {
    if (!activeBooking) return;
    setBookings(prev =>
      prev.map(b =>
        b.id === activeBooking.id
          ? { ...b, diagnosticReport: updatedReport }
          : b
      )
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans antialiased flex flex-col justify-between" id="app_root">
      
      {/* Top Banner Header */}
      <header className="bg-slate-900 border-b border-slate-800 shrink-0 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          {/* Logo Brand Brand */}
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500 text-slate-950 rounded-xl font-bold shadow-lg shadow-emerald-500/20">
              <Icons.ShieldAlert className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight text-white flex items-center gap-1.5 leading-none">
                APEX PRECISION
                <span className="text-emerald-400 font-bold text-xs uppercase bg-emerald-950/80 border border-emerald-900 px-2 py-0.5 rounded">
                  AUTO WORKS
                </span>
              </h1>
              <p className="text-[10px] text-slate-500 font-mono tracking-widest mt-1 uppercase">
                MECHANICAL DIAGNOSTICS & LOGBOOK CENTRE
              </p>
            </div>
          </div>

          {/* Tab Navigation Menu */}
          <nav className="flex gap-1.5 bg-slate-950 p-1.5 rounded-2xl border border-slate-850">
            <button
              onClick={() => setCurrentTab('garage')}
              className={`text-xs px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
                currentTab === 'garage'
                  ? 'bg-slate-800 text-white font-bold shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icons.Warehouse className="w-4 h-4" />
              <span>Shop & Garage</span>
            </button>

            <button
              onClick={() => setCurrentTab('booking')}
              className={`text-xs px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
                currentTab === 'booking'
                  ? 'bg-slate-800 text-white font-bold shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icons.CalendarRange className="w-4 h-4" />
              <span>Book Service</span>
            </button>

            <button
              onClick={() => setCurrentTab('tracker')}
              id="live_tracker_tab_btn"
              className={`text-xs px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 relative ${
                currentTab === 'tracker'
                  ? 'bg-slate-800 text-white font-bold shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icons.Radio className="w-4 h-4" />
              <span>Live Tracker</span>
              {activeBooking && activeBooking.status !== BookingStatus.COMPLETED && (
                activeBooking.status === BookingStatus.READY_FOR_PICKUP ? (
                  <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5 animate-pulse z-30">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-amber-500 border border-amber-300 shadow-[0_0_8px_rgba(245,158,11,0.6)] flex items-center justify-center text-[8px] text-slate-950 font-black">
                      !
                    </span>
                  </span>
                ) : (
                  <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                )
              )}
            </button>

            <button
              onClick={() => setCurrentTab('analytics')}
              className={`text-xs px-4 py-2 rounded-xl transition-all flex items-center gap-1.5 ${
                currentTab === 'analytics'
                  ? 'bg-slate-800 text-white font-bold shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icons.TrendingUp className="w-4 h-4" />
              <span>Analytics</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Container Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8 space-y-8">
        
        <AnimatePresence mode="wait">
          {currentTab === 'garage' && (
            <motion.div
              key="garage-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="space-y-8"
            >
              {/* Split screen: Garage vehicle register & Floor Plan Blueprint */}
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
                <div className="xl:col-span-4 h-full">
                  <GarageManager
                    cars={cars}
                    activeCarId={activeCarId}
                    onSelectCar={handleSelectCar}
                    onAddCar={handleAddCar}
                    onDeleteCar={handleDeleteCar}
                  />
                </div>
                <div className="xl:col-span-8 h-full">
                  <FacilitiesExplorer 
                    activeBooking={activeBooking} 
                    onSelectServiceFromFacility={handleSelectServiceFromBlueprint} 
                  />
                </div>
              </div>
            </motion.div>
          )}

          {currentTab === 'booking' && (
            <motion.div
              key="booking-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
            >
              <BookingWizard
                activeCar={activeCar}
                onBookingSubmit={handleBookingSubmit}
                onOpenGarage={() => setCurrentTab('garage')}
                onAddGuestCar={handleAddGuestCar}
              />
            </motion.div>
          )}

          {currentTab === 'tracker' && (
            <motion.div
              key="tracker-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
            >
              {activeBooking ? (
                <LiveProgressDashboard
                  booking={activeBooking}
                  onApproveRecommendation={handleApproveRecommendation}
                  onAdvanceProgressSimulated={handleAdvanceProgressSimulated}
                  onUpdateDiagnostics={handleUpdateDiagnostics}
                />
              ) : (
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center shadow-2xl flex flex-col items-center justify-center max-w-2xl mx-auto my-12">
                  <div className="p-4 bg-slate-950 border border-slate-850 rounded-full mb-4 text-slate-500">
                    <Icons.Radio className="w-12 h-12" />
                  </div>
                  <h3 className="text-xl font-bold text-white">No Active Service Tracker</h3>
                  <p className="text-slate-400 text-sm mt-2 leading-relaxed">
                    You currently have no active service diagnostics. Configure your car package on the <strong>Book Service</strong> tab to monitor live mechanics and calibration gauges.
                  </p>
                  <button
                    onClick={() => setCurrentTab('booking')}
                    id="tracker_tab_book_now_btn"
                    className="mt-6 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-5 py-2.5 rounded-xl text-xs transition-all flex items-center gap-2"
                  >
                    <Icons.CalendarRange className="w-4 h-4" />
                    <span>Book Your Service Now</span>
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {currentTab === 'analytics' && (
            <motion.div
              key="analytics-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
            >
              <ShopAnalytics />
            </motion.div>
          )}
        </AnimatePresence>

      </main>

      {/* Footer bar */}
      <footer className="bg-slate-950 border-t border-slate-850 shrink-0 select-none">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex gap-6 font-mono font-medium">
            <span>DIAGNOSTICS HUB: APEX_BAY_3</span>
            <span>CUSTOMER COFFEE: BREWING LATTE</span>
            <span>SHOP EFFICIENCY: 98.4%</span>
          </div>
          <div>
            &copy; 2026 Apex Precision Auto Works. Built for precision.
          </div>
        </div>
      </footer>
    </div>
  );
}
