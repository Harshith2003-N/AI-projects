import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import * as Icons from 'lucide-react';
import { Car, ServiceType, AddOn } from '../types';
import { SERVICE_TYPES, ADD_ONS } from '../data/carServiceData';

interface BookingWizardProps {
  activeCar: Car | null;
  onBookingSubmit: (bookingData: {
    serviceId: string;
    addOnIds: string[];
    date: string;
    timeSlot: string;
    notes: string;
    totalPrice: number;
    aiDiagnosticReport?: {
      summary: string;
      risk: 'LOW' | 'MEDIUM' | 'HIGH';
      suggestedRepairs: string[];
    };
  }) => void;
  onOpenGarage: () => void;
  onAddGuestCar?: () => void;
}

interface AiResponse {
  recommendedServiceId: string;
  recommendedAddOnIds: string[];
  diagnosticSummary: string;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  suggestedRepairs: string[];
  explanation: string;
}

export default function BookingWizard({
  activeCar,
  onBookingSubmit,
  onOpenGarage,
  onAddGuestCar,
}: BookingWizardProps) {
  const [selectedServiceId, setSelectedServiceId] = useState<string>('basic_service');
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [date, setDate] = useState<string>('2026-07-08');
  const [timeSlot, setTimeSlot] = useState<string>('10:00');
  const [notes, setNotes] = useState<string>('');
  const [aiQuery, setAiQuery] = useState<string>('');
  const [aiLoading, setAiLoading] = useState<boolean>(false);
  const [aiResult, setAiResult] = useState<AiResponse | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);

  // Time Slots for booking
  const timeSlots = [
    { time: '08:00', status: 'Available' },
    { time: '09:00', status: 'Busy' },
    { time: '10:00', status: 'Available' },
    { time: '11:00', status: 'Almost Full' },
    { time: '12:00', status: 'Lunch Break' },
    { time: '13:00', status: 'Available' },
    { time: '14:00', status: 'Available' },
    { time: '15:00', status: 'Busy' },
    { time: '16:00', status: 'Available' },
  ];

  // Calculations
  const selectedService = SERVICE_TYPES.find(s => s.id === selectedServiceId) || SERVICE_TYPES[0];
  const servicePrice = selectedService.price;
  const addOnsPrice = selectedAddOns.reduce((sum, addOnId) => {
    const addOn = ADD_ONS.find(a => a.id === addOnId);
    return sum + (addOn ? addOn.price : 0);
  }, 0);

  const subTotal = servicePrice + addOnsPrice;
  const gst = Math.round(subTotal * 0.1); // 10% Goods and Service Tax
  const grandTotal = subTotal + gst;

  const handleServiceChange = (id: string) => {
    setSelectedServiceId(id);
  };

  const handleAddOnToggle = (id: string) => {
    setSelectedAddOns(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleAiConsult = async () => {
    if (!aiQuery.trim()) return;
    setAiLoading(true);
    setAiResult(null);
    setAiError(null);

    try {
      const response = await fetch('/api/diagnose', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          symptoms: aiQuery,
          carInfo: activeCar
            ? `${activeCar.year} ${activeCar.make} ${activeCar.model} (${activeCar.fuelType}, ${activeCar.mileage}km)`
            : 'Unknown Car',
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to run AI Diagnostic engine.');
      }

      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }

      setAiResult(data);
    } catch (err: unknown) {
      console.error(err);
      setAiError(err instanceof Error ? err.message : 'An unexpected error occurred during diagnostics.');
    } finally {
      setAiLoading(false);
    }
  };

  const applyAiRecommendation = () => {
    if (!aiResult) return;
    if (aiResult.recommendedServiceId) {
      setSelectedServiceId(aiResult.recommendedServiceId);
    }
    if (aiResult.recommendedAddOnIds && aiResult.recommendedAddOnIds.length > 0) {
      // Filter out invalid IDs that don't match our data
      const validAddOns = aiResult.recommendedAddOnIds.filter(id =>
        ADD_ONS.some(a => a.id === id)
      );
      setSelectedAddOns(validAddOns);
    }
    // Pre-fill notes with the AI-suggested repairs
    const summaryHeader = `[AI Diagnostic Note]: Risk Level: ${aiResult.riskLevel}\n${aiResult.diagnosticSummary}\n`;
    setNotes(summaryHeader + notes);
  };

  const handleConfirmBooking = () => {
    onBookingSubmit({
      serviceId: selectedServiceId,
      addOnIds: selectedAddOns,
      date,
      timeSlot,
      notes,
      totalPrice: grandTotal,
      aiDiagnosticReport: aiResult
        ? {
            summary: aiResult.diagnosticSummary,
            risk: aiResult.riskLevel,
            suggestedRepairs: aiResult.suggestedRepairs,
          }
        : undefined,
    });
  };

  const getRiskColor = (risk?: 'LOW' | 'MEDIUM' | 'HIGH') => {
    if (risk === 'HIGH') return 'bg-rose-950/80 border-rose-800 text-rose-400';
    if (risk === 'MEDIUM') return 'bg-amber-950/80 border-amber-800 text-amber-400';
    return 'bg-emerald-950/80 border-emerald-800 text-emerald-400';
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative" id="booking_wizard_root">
      {!activeCar ? (
        <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
          <div className="p-4 bg-slate-950 border border-slate-850 rounded-full mb-4">
            <Icons.CarFront className="w-12 h-12 text-slate-500 animate-bounce" />
          </div>
          <h3 className="text-lg font-bold text-white">No Car Selected</h3>
          <p className="text-slate-400 text-xs max-w-sm mt-1.5 leading-relaxed">
            Please register or select a vehicle from your Garage first so we can tailor the diagnostic analysis and parts compatibility.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 mt-6">
            <button
              onClick={onOpenGarage}
              id="wizard_open_garage_btn"
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold px-5 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-md"
            >
              <Icons.Plus className="w-4 h-4" />
              <span>Open Garage Manager</span>
            </button>
            {onAddGuestCar && (
              <button
                onClick={onAddGuestCar}
                id="wizard_quick_guest_btn"
                className="bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-750 font-semibold px-5 py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 transition-all shadow-md"
              >
                <Icons.Zap className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                <span>Quick Register Guest EV</span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Active vehicle banner */}
          <div className="bg-slate-950 border border-slate-850 rounded-2xl p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-emerald-950/55 border border-emerald-900/40 rounded-xl">
                <Icons.CheckSquare className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Active Car for Booking</span>
                <h4 className="text-sm font-bold text-white mt-0.5">
                  {activeCar.year} {activeCar.make} {activeCar.model}
                </h4>
              </div>
            </div>
            <button
              onClick={onOpenGarage}
              className="text-xs text-slate-400 hover:text-emerald-400 flex items-center gap-1.5 underline underline-offset-4 decoration-slate-700 transition-colors"
            >
              <Icons.Shuffle className="w-3.5 h-3.5" />
              Change Vehicle
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left side parameters configurator (col-span-7) */}
            <div className="lg:col-span-7 space-y-6">
              {/* AI Diagnostic Assistant Section */}
              <div className="bg-slate-950/80 border border-slate-850 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-900 pb-2.5">
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                    <Icons.Cpu className="w-4 h-4 text-emerald-400 animate-pulse" />
                    AI Diagnostics assistant (Gemini Powered)
                  </span>
                  <span className="text-[9px] bg-emerald-950 text-emerald-400 font-mono font-bold px-2 py-0.5 rounded-full">
                    REAL-TIME ENG
                  </span>
                </div>

                <div className="space-y-3">
                  <p className="text-slate-400 text-xs leading-relaxed">
                    Describe any noises, vibrations, smells, dashboard lights, or mechanical symptoms below. Our AI diagnostic engine will assess safety risk and suggest corrective services.
                  </p>
                  <div className="relative">
                    <textarea
                      value={aiQuery}
                      id="ai_diagnostic_input"
                      onChange={(e) => setAiQuery(e.target.value)}
                      placeholder="e.g. My brakes are making a loud squealing noise when slowing down, and the steering wheel pulls to the left slightly..."
                      rows={3}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500"
                    ></textarea>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      id="ai_diagnose_submit_btn"
                      onClick={handleAiConsult}
                      disabled={aiLoading || !aiQuery.trim()}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-850 disabled:text-slate-600 text-white font-bold py-2.5 rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-md"
                    >
                      {aiLoading ? (
                        <>
                          <Icons.Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
                          <span>AI Technician Analyzing Engine Data...</span>
                        </>
                      ) : (
                        <>
                          <Icons.Brain className="w-4 h-4 text-white" />
                          <span>Consult AI Diagnostic Engineer</span>
                        </>
                      )}
                    </button>
                    {aiResult && (
                      <button
                        type="button"
                        onClick={() => {
                          setAiResult(null);
                          setAiQuery('');
                        }}
                        className="p-2.5 bg-slate-900 text-slate-400 hover:text-white border border-slate-800 rounded-xl"
                        title="Clear Result"
                      >
                        <Icons.RotateCcw className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* AI Output Result Box */}
                <AnimatePresence>
                  {aiResult && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 space-y-3"
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-white flex items-center gap-1.5">
                          <Icons.Activity className="w-4 h-4 text-cyan-400" />
                          Diagnostic Assessment Report
                        </span>
                        <span className={`text-[10px] font-black tracking-widest px-2 py-0.5 rounded border uppercase ${getRiskColor(aiResult.riskLevel)}`}>
                          Risk: {aiResult.riskLevel}
                        </span>
                      </div>

                      <p className="text-slate-300 text-xs leading-relaxed italic">
                        &ldquo;{aiResult.diagnosticSummary}&rdquo;
                      </p>

                      <div className="text-xs space-y-1 bg-slate-950 p-3 rounded-lg border border-slate-850">
                        <div className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Suggested Fixes:</div>
                        <ul className="list-disc list-inside text-slate-300 space-y-0.5 mt-1 pl-1">
                          {aiResult.suggestedRepairs.map((repair, idx) => (
                            <li key={idx}>{repair}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="flex items-center justify-between border-t border-slate-800 pt-3 mt-3">
                        <div className="text-[11px] text-slate-400">
                          Recommended Package: <strong>{SERVICE_TYPES.find(s => s.id === aiResult.recommendedServiceId)?.name || 'Major Service'}</strong>
                        </div>
                        <button
                          type="button"
                          id="apply_ai_pkg_btn"
                          onClick={applyAiRecommendation}
                          className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold px-3 py-1.5 rounded-lg text-[10px] flex items-center gap-1 transition-all"
                        >
                          <Icons.Sparkles className="w-3.5 h-3.5" />
                          <span>Configure Services</span>
                        </button>
                      </div>
                    </motion.div>
                  )}
                  {aiError && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="text-xs text-rose-400 bg-rose-950/40 border border-rose-900/60 p-3 rounded-xl flex items-center gap-2"
                    >
                      <Icons.AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{aiError}</span>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Service Types Selector Card */}
              <div className="space-y-3">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                  <Icons.Wrench className="w-4 h-4 text-slate-400" /> Choose Shop Service Package
                </span>
                <div className="flex flex-col gap-2.5">
                  {SERVICE_TYPES.map((service) => {
                    const isSelected = selectedServiceId === service.id;
                    return (
                      <div
                        key={service.id}
                        id={`service_option_${service.id}`}
                        onClick={() => handleServiceChange(service.id)}
                        className={`cursor-pointer rounded-xl p-4 border transition-all flex justify-between items-start ${
                          isSelected
                            ? 'bg-slate-950 border-emerald-500 shadow-md'
                            : 'bg-slate-950/40 border-slate-850 hover:border-slate-800'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <input
                            type="radio"
                            name="service_selection"
                            checked={isSelected}
                            onChange={() => handleServiceChange(service.id)}
                            className="mt-1 accent-emerald-500 cursor-pointer"
                          />
                          <div className="space-y-1 max-w-[80%]">
                            <h4 className="text-sm font-bold text-white">{service.name}</h4>
                            <p className="text-xs text-slate-400 leading-snug">{service.description}</p>
                            <div className="flex flex-wrap gap-1.5 mt-2">
                              {service.benefits.slice(0, 3).map((benefit, idx) => (
                                <span key={idx} className="text-[9px] bg-slate-900 border border-slate-850 px-2 py-0.5 rounded text-slate-400">
                                  {benefit}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="text-base font-black text-emerald-400 font-mono">${service.price}</span>
                          <p className="text-[10px] text-slate-500 mt-1">{service.durationMinutes} mins</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Add-on Upgrades Selector */}
              <div className="space-y-3">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                  <Icons.Layers className="w-4 h-4 text-slate-400" /> Parts & Consumables Upgrades (Optional)
                </span>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {ADD_ONS.map((addon) => {
                    const isSelected = selectedAddOns.includes(addon.id);
                    return (
                      <div
                        key={addon.id}
                        onClick={() => handleAddOnToggle(addon.id)}
                        className={`cursor-pointer rounded-xl p-3 border transition-all flex justify-between items-center ${
                          isSelected
                            ? 'bg-slate-950 border-emerald-500 shadow-md'
                            : 'bg-slate-950/40 border-slate-850 hover:border-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 max-w-[75%]">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => {}} // handled by div click
                            className="accent-emerald-500 rounded cursor-pointer shrink-0"
                          />
                          <div className="truncate">
                            <h5 className="text-xs font-bold text-white truncate">{addon.name}</h5>
                            <p className="text-[10px] text-slate-500 truncate mt-0.5">{addon.description}</p>
                          </div>
                        </div>
                        <span className="text-xs font-bold font-mono text-emerald-400 shrink-0">+${addon.price}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Right side date, slot, summary invoicing (col-span-5) */}
            <div className="lg:col-span-5 space-y-6">
              {/* Date & Interactive Slot Picker */}
              <div className="bg-slate-950 border border-slate-850 rounded-2xl p-5 space-y-4">
                <h3 className="text-sm font-bold text-white flex items-center gap-2 pb-2.5 border-b border-slate-900">
                  <Icons.Calendar className="w-4 h-4 text-emerald-400" /> Schedule Booking Date
                </h3>

                <div className="flex flex-col gap-1.5">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Select Date</label>
                  <input
                    type="date"
                    value={date}
                    id="booking_date_input"
                    onChange={(e) => setDate(e.target.value)}
                    className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Select Service Bay Slot</label>
                  <div className="grid grid-cols-3 gap-2">
                    {timeSlots.map((slot) => {
                      const isSelected = timeSlot === slot.time;
                      const isBusy = slot.status === 'Busy';
                      const isBreak = slot.status === 'Lunch Break';

                      return (
                        <button
                          key={slot.time}
                          type="button"
                          id={`timeslot_${slot.time}`}
                          disabled={isBusy || isBreak}
                          onClick={() => setTimeSlot(slot.time)}
                          className={`rounded-xl p-2.5 border text-center transition-all ${
                            isSelected
                              ? 'bg-emerald-600 border-emerald-500 text-white font-bold'
                              : isBusy
                              ? 'bg-slate-950/20 border-slate-900 text-slate-600 cursor-not-allowed'
                              : isBreak
                              ? 'bg-slate-950/10 border-slate-900 text-slate-600 text-[10px] cursor-not-allowed flex items-center justify-center'
                              : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-850'
                          }`}
                        >
                          <span className="block text-xs font-semibold">{slot.time}</span>
                          <span className={`block text-[8px] mt-0.5 ${
                            isSelected 
                              ? 'text-white/80' 
                              : isBusy 
                              ? 'text-rose-600 font-bold' 
                              : isBreak 
                              ? 'text-slate-500' 
                              : 'text-emerald-500 font-semibold'
                          }`}>
                            {slot.status}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Special instruction notes */}
              <div className="bg-slate-950 border border-slate-850 rounded-2xl p-5">
                <label className="text-xs font-bold text-white flex items-center gap-1.5 mb-2">
                  <Icons.MessageSquareCode className="w-4 h-4 text-slate-400" /> Special Requests or Custom Notes
                </label>
                <textarea
                  value={notes}
                  id="booking_notes"
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Please leave the replaced parts in my boot for inspection. Cabin filter needs carbon lining."
                  rows={2}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-emerald-500"
                ></textarea>
              </div>

              {/* Interactive Invoice Summary */}
              <div className="bg-slate-950 border border-slate-850 rounded-2xl p-5 space-y-4">
                <h3 className="text-sm font-bold text-white flex items-center gap-2 pb-2.5 border-b border-slate-900">
                  <Icons.Receipt className="w-4 h-4 text-emerald-400" /> Invoicing & Cost Breakdown
                </h3>

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between items-center text-slate-400">
                    <span>{selectedService.name} (Labour & Standard Fluids)</span>
                    <span className="font-mono text-slate-200">${servicePrice}</span>
                  </div>

                  {selectedAddOns.length > 0 && (
                    <div className="space-y-1 pt-1 border-t border-slate-900/60">
                      <div className="text-slate-500 text-[10px] uppercase font-bold tracking-wider">Parts Upgrades:</div>
                      {selectedAddOns.map(addonId => {
                        const ad = ADD_ONS.find(a => a.id === addonId);
                        if (!ad) return null;
                        return (
                          <div key={ad.id} className="flex justify-between items-center text-slate-400 pl-2 text-[11px]">
                            <span>+ {ad.name}</span>
                            <span className="font-mono text-slate-300">${ad.price}</span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  <div className="flex justify-between items-center text-slate-400 border-t border-slate-900 pt-2.5">
                    <span>GST (Goods and Service Tax 10%)</span>
                    <span className="font-mono text-slate-300">${gst}</span>
                  </div>

                  <div className="flex justify-between items-center text-sm font-bold text-white border-t border-slate-800 pt-3 mt-1">
                    <span className="flex items-center gap-1.5 text-emerald-400">
                      <Icons.ShieldAlert className="w-4 h-4 text-emerald-400" /> Total Invoiced Price
                    </span>
                    <span className="font-mono text-lg text-emerald-400">${grandTotal}</span>
                  </div>
                </div>

                <button
                  type="button"
                  id="wizard_submit_booking_btn"
                  onClick={handleConfirmBooking}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3.5 rounded-xl text-xs transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/30"
                >
                  <Icons.CheckCircle2 className="w-5 h-5 text-white" />
                  <span>Finalize & Confirm Booking Slot</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
