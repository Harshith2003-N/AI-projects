import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import * as Icons from 'lucide-react';
import { Facility, FacilityStatus, ServiceType, Booking, BookingStatus } from '../types';
import { FACILITIES, SERVICE_TYPES } from '../data/carServiceData';

interface FacilitiesExplorerProps {
  onSelectServiceFromFacility?: (serviceId: string) => void;
  activeBooking?: Booking | null;
}

export default function FacilitiesExplorer({ onSelectServiceFromFacility, activeBooking }: FacilitiesExplorerProps) {
  const [selectedFacility, setSelectedFacility] = useState<Facility>(FACILITIES[0]);
  
  // Determine which facility has the customer's car based on progress status
  const getActiveCarFacilityId = (): string | null => {
    if (!activeBooking || activeBooking.status === BookingStatus.COMPLETED) return null;
    switch (activeBooking.status) {
      case BookingStatus.DIAGNOSING:
        return 'diagnostic';
      case BookingStatus.IN_PROGRESS:
        return 'service_lift_1';
      case BookingStatus.QUALITY_CHECK:
        return 'alignment_bay';
      case BookingStatus.READY_FOR_PICKUP:
        return 'lounge';
      default:
        return null;
    }
  };

  const activeCarFacilityId = getActiveCarFacilityId();
  const [coffeePoured, setCoffeePoured] = useState(false);
  const [pouringCoffee, setPouringCoffee] = useState(false);
  const [selectedCoffee, setSelectedCoffee] = useState('Latte');
  const [runTreadScan, setRunTreadScan] = useState(false);
  const [scanValue, setScanValue] = useState<string | null>(null);

  // Helper to dynamically get Lucide Icon
  const renderIcon = (iconName: string, className: string = "w-6 h-6") => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const IconComponent = (Icons as any)[iconName] || Icons.HelpCircle;
    return <IconComponent className={className} />;
  };

  const handlePourCoffee = () => {
    setPouringCoffee(true);
    setCoffeePoured(false);
    setTimeout(() => {
      setPouringCoffee(false);
      setCoffeePoured(true);
    }, 2000);
  };

  const handleRunTreadScan = () => {
    setRunTreadScan(true);
    setScanValue(null);
    setTimeout(() => {
      const tread = (2.5 + Math.random() * 5.0).toFixed(1);
      setScanValue(`${tread} mm`);
      setRunTreadScan(false);
    }, 1500);
  };

  // Get services that use this facility
  const getAssociatedServices = (facilityId: string): ServiceType[] => {
    return SERVICE_TYPES.filter(service => service.facilitiesUsed.includes(facilityId));
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl overflow-hidden" id="facilities_explorer_root">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 border-b border-slate-800 pb-5">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Icons.Warehouse className="text-emerald-400 w-7 h-7" />
            Interactive Shop Explorer
          </h2>
          <p className="text-slate-400 text-sm mt-1">
            Tap facilities in our digital blueprint to inspect live diagnostics, occupancy, and premium shop features.
          </p>
        </div>
        <div className="flex gap-2">
          <div className="flex items-center gap-1.5 text-xs bg-emerald-950/40 text-emerald-400 border border-emerald-800/60 px-3 py-1.5 rounded-full">
            <span className="w-2 h-2 bg-emerald-400 rounded-full animate-ping"></span>
            <span>All Bays Operational</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Grid: The Interactive Floor Plan Map / Blueprint */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          <div className="text-xs uppercase tracking-wider font-bold text-slate-500 mb-1 flex items-center gap-2">
            <Icons.Map className="w-4 h-4 text-slate-400" />
            Shop Floor Blueprint Layout
          </div>

          <div className="relative bg-slate-950 border border-slate-800 rounded-2xl p-4 sm:p-6 min-h-[440px] sm:min-h-[500px] flex flex-col justify-between overflow-hidden shadow-inner">
            {/* Ambient Background Grid lines */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:32px_32px] opacity-20"></div>

            {/* Simulated Outer Walls & Sections */}
            <div className="grid grid-cols-3 grid-rows-2 gap-3 sm:gap-4 h-full relative z-10">
              {FACILITIES.map((facility) => {
                const isSelected = selectedFacility.id === facility.id;
                const isBusy = facility.status === FacilityStatus.BUSY;
                const hasActiveCar = activeCarFacilityId === facility.id;

                return (
                  <motion.button
                    key={facility.id}
                    id={`facility_btn_${facility.id}`}
                    onClick={() => {
                      setSelectedFacility(facility);
                      setCoffeePoured(false);
                      setScanValue(null);
                    }}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className={`relative rounded-xl p-3 sm:p-4 flex flex-col justify-between items-start text-left border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-slate-900 border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.2)] z-20'
                        : hasActiveCar
                        ? 'bg-slate-900 border-emerald-400 shadow-[0_0_20px_rgba(52,211,153,0.35)] z-10 animate-pulse'
                        : isBusy
                        ? 'bg-slate-950/80 border-rose-950 hover:bg-slate-900/60 hover:border-rose-900'
                        : 'bg-slate-950/80 border-slate-800 hover:bg-slate-900/60 hover:border-slate-700'
                    }`}
                  >
                    {/* Top Status & Icon */}
                    <div className="flex justify-between items-center w-full gap-1.5">
                      <div className={`p-1.5 sm:p-2 rounded-lg shrink-0 ${
                        isSelected 
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50' 
                          : hasActiveCar
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/50'
                          : isBusy 
                          ? 'bg-rose-950 text-rose-400 border border-rose-900/50' 
                          : 'bg-slate-855 text-slate-400 border border-slate-800'
                      }`}>
                        {renderIcon(facility.icon, "w-4 h-4 sm:w-5 sm:h-5")}
                      </div>
                      <span className={`text-[8px] sm:text-[10px] font-bold uppercase tracking-wider px-1.5 sm:px-2 py-0.5 rounded-full shrink-0 ${
                        hasActiveCar
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/80'
                          : isBusy 
                          ? 'bg-rose-950 text-rose-400 border border-rose-900' 
                          : 'bg-emerald-950 text-emerald-400 border border-emerald-900'
                      }`}>
                        {hasActiveCar ? 'Active' : facility.status}
                      </span>
                    </div>

                    {/* Facility Label */}
                    <div className="mt-2.5 sm:mt-4 w-full">
                      <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight truncate w-full" title={facility.name}>
                        {facility.name}
                      </h4>
                      <p className="text-slate-500 text-[10px] sm:text-[11px] mt-0.5 truncate w-full">
                        {facility.id === 'lounge' 
                          ? `${facility.currentOccupancy} clients` 
                          : `${facility.currentOccupancy}/${facility.capacity} bays`}
                      </p>
                    </div>

                    {/* Interactive "Your vehicle is here" bouncing tag */}
                    {hasActiveCar && activeBooking && (
                      <div className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 bg-emerald-500 text-slate-950 text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border border-emerald-300 shadow-md flex items-center gap-1 z-30 whitespace-nowrap animate-bounce">
                        <Icons.MapPin className="w-2.5 h-2.5 fill-slate-950 text-slate-950" />
                        <span>{activeBooking.car.make} Here</span>
                      </div>
                    )}

                    {/* Animated Ripple Effect for Active Bays */}
                    {isBusy && !hasActiveCar && (
                      <span className="absolute top-2 right-2 flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                      </span>
                    )}
                  </motion.button>
                );
              })}
            </div>

            {/* Shop Entry/Exit indicators on floor blueprint */}
            <div className="absolute left-6 bottom-0 translate-y-1/2 flex items-center gap-1 text-[10px] uppercase font-bold text-slate-600 bg-slate-950 px-3 border border-slate-800 rounded-full z-10">
              <Icons.ArrowUp className="w-3 h-3 text-slate-500" /> Drive-In Roll Gate
            </div>
            <div className="absolute right-6 bottom-0 translate-y-1/2 flex items-center gap-1 text-[10px] uppercase font-bold text-slate-600 bg-slate-950 px-3 border border-slate-800 rounded-full z-10">
              <Icons.ArrowDown className="w-3 h-3 text-slate-500" /> Detailer Outgate
            </div>
          </div>
        </div>

        {/* Right Detail Pane: Selected Facility Overview */}
        <div className="lg:col-span-5 flex flex-col h-full bg-slate-950 border border-slate-850 rounded-2xl p-6 relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedFacility.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-col h-full justify-between gap-5"
            >
              {/* Header */}
              <div>
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-emerald-950 text-emerald-400 border border-emerald-800 rounded-xl">
                    {renderIcon(selectedFacility.icon, "w-6 h-6")}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white tracking-tight">
                      {selectedFacility.name}
                    </h3>
                    <p className="text-xs font-mono text-emerald-400 uppercase tracking-widest mt-0.5">
                      Facility ID: {selectedFacility.id}
                    </p>
                  </div>
                </div>

                <p className="text-slate-400 text-sm mt-4 leading-relaxed">
                  {selectedFacility.description}
                </p>

                {/* Bays & Active State */}
                <div className="mt-5 border-t border-slate-850 pt-5">
                  <h5 className="text-xs uppercase tracking-wider font-bold text-slate-400 mb-3 flex items-center gap-2">
                    <Icons.Grid className="w-3.5 h-3.5 text-slate-500" />
                    Dedicated Bay Slots
                  </h5>
                  <div className="flex flex-wrap gap-2">
                    {selectedFacility.bays.map((bay, idx) => (
                      <div
                        key={bay}
                        className="flex items-center gap-2 text-xs bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-300"
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          selectedFacility.status === FacilityStatus.BUSY && idx === 0 
                            ? 'bg-rose-500 animate-pulse' 
                            : 'bg-emerald-400'
                        }`}></span>
                        <span>{bay}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Special Interactive Widgets for Selected Facilities */}
              <div className="bg-slate-900 border border-slate-850 p-4 rounded-xl">
                {selectedFacility.id === 'lounge' && (
                  <div className="flex flex-col gap-3">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                      <span className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
                        <Icons.Coffee className="w-4 h-4 text-amber-500" /> Barista Corner Console
                      </span>
                      <span className="text-[10px] text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded">Free Unlimited</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {['Latte', 'Espresso', 'Cappuccino', 'Mocha'].map((coffee) => (
                        <button
                          key={coffee}
                          onClick={() => setSelectedCoffee(coffee)}
                          className={`text-xs px-2.5 py-1 rounded-md transition-colors ${
                            selectedCoffee === coffee
                              ? 'bg-amber-600 text-white font-semibold shadow-md'
                              : 'bg-slate-950 text-slate-400 hover:bg-slate-800 hover:text-slate-300'
                          }`}
                        >
                          {coffee}
                        </button>
                      ))}
                    </div>
                    <button
                      onClick={handlePourCoffee}
                      disabled={pouringCoffee}
                      className="w-full mt-1 bg-slate-800 hover:bg-slate-700 disabled:bg-slate-900 text-slate-200 hover:text-white font-medium py-1.5 rounded-lg text-xs transition-colors flex items-center justify-center gap-2 border border-slate-700"
                    >
                      {pouringCoffee ? (
                        <>
                          <Icons.Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Brewing & Frothing...</span>
                        </>
                      ) : (
                        <>
                          <Icons.Play className="w-3 h-3 text-emerald-400" />
                          <span>Pour Fresh {selectedCoffee}</span>
                        </>
                      )}
                    </button>
                    {coffeePoured && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="text-[11px] text-amber-400 bg-amber-950/40 border border-amber-900/60 p-2.5 rounded-lg flex items-center gap-2"
                      >
                        <Icons.Check className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>A fresh, warm cup of <strong>{selectedCoffee}</strong> is ready for you in the lounge! ☕️</span>
                      </motion.div>
                    )}
                  </div>
                )}

                {selectedFacility.id === 'diagnostic' && (
                  <div className="flex flex-col gap-3">
                    <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                      <span className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
                        <Icons.Zap className="w-4 h-4 text-cyan-400" /> Tread Depth Laser Scanner
                      </span>
                    </div>
                    <p className="text-slate-500 text-[11px] leading-snug">
                      Test-drive the laser measurement scanner. Run an instant tire depth scan.
                    </p>
                    <button
                      onClick={handleRunTreadScan}
                      disabled={runTreadScan}
                      className="w-full bg-slate-800 hover:bg-slate-700 disabled:bg-slate-900 text-slate-200 hover:text-white font-medium py-1.5 rounded-lg text-xs transition-colors flex items-center justify-center gap-2 border border-slate-700"
                    >
                      {runTreadScan ? (
                        <>
                          <Icons.Loader2 className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                          <span>Calibrating Laser Arrays...</span>
                        </>
                      ) : (
                        <>
                          <Icons.Gauge className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Run Fast Laser Scan</span>
                        </>
                      )}
                    </button>
                    {scanValue && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="text-xs text-cyan-400 bg-cyan-950/40 border border-cyan-900/60 p-2.5 rounded-lg flex justify-between items-center"
                      >
                        <span className="flex items-center gap-1.5">
                          <Icons.Activity className="w-4 h-4 animate-pulse text-cyan-400" />
                          Scan Complete:
                        </span>
                        <span className="font-mono font-bold text-sm text-white">{scanValue}</span>
                      </motion.div>
                    )}
                  </div>
                )}

                {/* Default associated services widget */}
                {selectedFacility.id !== 'lounge' && selectedFacility.id !== 'diagnostic' && (
                  <div className="flex flex-col gap-2">
                    <span className="text-xs font-bold text-slate-400 flex items-center gap-1">
                      <Icons.Wrench className="w-3.5 h-3.5 text-slate-500" />
                      Associated Work Services
                    </span>
                    <div className="flex flex-col gap-1.5">
                      {getAssociatedServices(selectedFacility.id).map(service => (
                        <div key={service.id} className="flex justify-between items-center text-xs bg-slate-950 p-2 rounded border border-slate-850 hover:border-slate-800 transition-colors">
                          <span className="text-white font-medium truncate pr-2">{service.name}</span>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className="text-emerald-400 font-semibold font-mono">${service.price}</span>
                            {onSelectServiceFromFacility && (
                              <button
                                onClick={() => onSelectServiceFromFacility(service.id)}
                                className="text-[10px] bg-slate-850 hover:bg-emerald-600 hover:text-white text-slate-300 font-bold px-2 py-0.5 rounded transition-all"
                              >
                                Book
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Occupancy Indicator */}
              <div className="flex items-center justify-between text-xs text-slate-500 border-t border-slate-850 pt-4">
                <span>Total Capacity: {selectedFacility.capacity} slots</span>
                <span className="font-semibold text-slate-300 font-mono">
                  {selectedFacility.id === 'lounge' 
                    ? `${selectedFacility.currentOccupancy} clients seated` 
                    : `${selectedFacility.currentOccupancy} bays loaded`}
                </span>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
