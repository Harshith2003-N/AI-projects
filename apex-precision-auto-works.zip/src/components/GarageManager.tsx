import { useState, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import * as Icons from 'lucide-react';
import { Car } from '../types';
import { MOCK_POPULAR_CARS } from '../data/carServiceData';

interface GarageManagerProps {
  cars: Car[];
  activeCarId: string | null;
  onSelectCar: (carId: string) => void;
  onAddCar: (car: Omit<Car, 'id'>) => void;
  onDeleteCar: (carId: string) => void;
}

export default function GarageManager({
  cars,
  activeCarId,
  onSelectCar,
  onAddCar,
  onDeleteCar,
}: GarageManagerProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [make, setMake] = useState('Tesla');
  const [model, setModel] = useState('Model Y');
  const [year, setYear] = useState(2024);
  const [mileage, setMileage] = useState(15000);
  const [fuelType, setFuelType] = useState('Electric');

  const handleMakeChange = (selectedMake: string) => {
    setMake(selectedMake);
    const popular = MOCK_POPULAR_CARS.find(c => c.make === selectedMake);
    if (popular && popular.models.length > 0) {
      setModel(popular.models[0]);
    } else {
      setModel('');
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!make || !model || !year || mileage <= 0) return;
    onAddCar({
      make,
      model,
      year: Number(year),
      mileage: Number(mileage),
      fuelType,
    });
    setShowAddForm(false);
    // Reset states
    setYear(2024);
    setMileage(15000);
  };

  // Pre-defined values for fuel types
  const fuelTypes = ['Electric', 'Hybrid', 'Petrol', 'Diesel'];

  const getCarIcon = (fuel: string) => {
    if (fuel === 'Electric') return <Icons.Zap className="w-5 h-5 text-yellow-400" />;
    if (fuel === 'Hybrid') return <Icons.Leaf className="w-5 h-5 text-emerald-400" />;
    return <Icons.Fuel className="w-5 h-5 text-cyan-400" />;
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl" id="garage_manager_root">
      <div className="flex justify-between items-center mb-6 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Icons.Car className="text-emerald-400 w-6 h-6" />
            My Garage
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Select or register vehicles to perform custom service diagnostics and bookings.
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          id="toggle_add_car_btn"
          className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow-md"
        >
          {showAddForm ? <Icons.X className="w-4 h-4" /> : <Icons.Plus className="w-4 h-4" />}
          <span>{showAddForm ? 'Cancel' : 'Add Vehicle'}</span>
        </button>
      </div>

      <AnimatePresence mode="wait">
        {showAddForm ? (
          <motion.form
            key="add-car-form"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleSubmit}
            className="bg-slate-950 border border-slate-800 p-5 rounded-2xl mb-6 space-y-4 overflow-hidden"
          >
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5 border-b border-slate-850 pb-2">
              <Icons.PlusCircle className="w-4 h-4 text-emerald-400" /> Register New Vehicle
            </h3>

            <div className="grid grid-cols-2 gap-4">
              {/* Brand Select */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Brand / Make</label>
                <select
                  value={make}
                  onChange={(e) => handleMakeChange(e.target.value)}
                  className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                >
                  {MOCK_POPULAR_CARS.map(c => (
                    <option key={c.make} value={c.make}>{c.make}</option>
                  ))}
                  <option value="Custom">Other / Custom</option>
                </select>
              </div>

              {/* Model select or write */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Model Name</label>
                {make === 'Custom' ? (
                  <input
                    type="text"
                    required
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    placeholder="e.g. Mustang, Corolla"
                    className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                ) : (
                  <select
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    {MOCK_POPULAR_CARS.find(c => c.make === make)?.models.map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                    <option value="Other">Other Model</option>
                  </select>
                )}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {/* Year */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Year</label>
                <input
                  type="number"
                  min="1990"
                  max="2027"
                  required
                  value={year}
                  onChange={(e) => setYear(Number(e.target.value))}
                  className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Fuel Type */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Fuel Type</label>
                <select
                  value={fuelType}
                  onChange={(e) => setFuelType(e.target.value)}
                  className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                >
                  {fuelTypes.map(f => (
                    <option key={f} value={f}>{f}</option>
                  ))}
                </select>
              </div>

              {/* Odometer Mileage */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Odometer (km)</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={mileage}
                  onChange={(e) => setMileage(Number(e.target.value))}
                  className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <button
              type="submit"
              id="submit_add_car_btn"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 rounded-xl text-xs transition-all flex items-center justify-center gap-2 mt-2 shadow-md"
            >
              <Icons.CheckCircle2 className="w-4 h-4" />
              <span>Confirm Registration</span>
            </button>
          </motion.form>
        ) : null}
      </AnimatePresence>

      {/* Vehicles list */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {cars.map((car) => {
          const isActive = activeCarId === car.id;
          // Calculate arbitrary recommended mileage service due
          const nextServiceKm = Math.ceil(car.mileage / 10000) * 10000;
          const kmRemaining = nextServiceKm - car.mileage;
          const servicePercentage = Math.max(0, Math.min(100, (kmRemaining / 10000) * 100));

          return (
            <motion.div
              key={car.id}
              id={`car_card_${car.id}`}
              whileHover={{ scale: 1.01 }}
              onClick={() => onSelectCar(car.id)}
              className={`relative cursor-pointer rounded-2xl p-5 border text-left flex flex-col justify-between h-48 transition-all ${
                isActive
                  ? 'bg-slate-950 border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.1)]'
                  : 'bg-slate-950/60 border-slate-850 hover:border-slate-700'
              }`}
            >
              <div>
                {/* Header info */}
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2.5">
                    <div className={`p-2.5 rounded-xl ${isActive ? 'bg-emerald-950/80 border border-emerald-900/60' : 'bg-slate-900'}`}>
                      {getCarIcon(car.fuelType)}
                    </div>
                    <div>
                      <span className="text-[10px] bg-slate-900 text-slate-400 px-2 py-0.5 rounded font-mono font-bold">
                        {car.year}
                      </span>
                      <h4 className="text-base font-bold text-white tracking-tight leading-snug mt-0.5">
                        {car.make} {car.model}
                      </h4>
                    </div>
                  </div>

                  {isActive ? (
                    <span className="flex items-center gap-1 text-[10px] font-black uppercase tracking-widest bg-emerald-950 text-emerald-400 border border-emerald-800 px-2.5 py-1 rounded-full shadow-inner animate-pulse">
                      <Icons.Check className="w-3 h-3" />
                      Active Booking Car
                    </span>
                  ) : (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteCar(car.id);
                      }}
                      className="p-1.5 bg-slate-900 text-slate-500 hover:text-rose-400 hover:bg-slate-850 rounded-lg transition-colors"
                      title="Remove Car"
                    >
                      <Icons.Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {/* Specific features display */}
                <div className="grid grid-cols-2 gap-2 mt-4 text-xs text-slate-400 border-t border-slate-850/60 pt-3">
                  <div className="flex items-center gap-1.5">
                    <Icons.Gauge className="w-3.5 h-3.5 text-slate-500" />
                    <span>Odometer: <strong className="text-slate-200">{car.mileage.toLocaleString()} km</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Icons.ShieldAlert className="w-3.5 h-3.5 text-slate-500" />
                    <span>Engine: <strong className="text-slate-200">{car.fuelType}</strong></span>
                  </div>
                </div>
              </div>

              {/* Service health indicator */}
              <div className="mt-3">
                <div className="flex justify-between items-center text-[10px] text-slate-500 mb-1">
                  <span>Logbook Service Health:</span>
                  <span className={kmRemaining < 1500 ? 'text-rose-400 font-bold' : 'text-slate-400 font-medium'}>
                    {kmRemaining < 0 ? 'Service Overdue!' : `${kmRemaining.toLocaleString()} km left`}
                  </span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-850">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      servicePercentage < 20 
                        ? 'bg-rose-500 shadow-[0_0_8px_rgba(239,68,68,0.4)]' 
                        : servicePercentage < 50 
                        ? 'bg-amber-500' 
                        : 'bg-emerald-500'
                    }`}
                    style={{ width: `${servicePercentage}%` }}
                  ></div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
