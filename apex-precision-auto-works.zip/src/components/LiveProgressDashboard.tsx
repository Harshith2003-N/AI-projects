import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import * as Icons from 'lucide-react';
import { jsPDF } from 'jspdf';
import { Booking, BookingStatus, DiagnosticReport } from '../types';
import { SERVICE_TYPES, ADD_ONS } from '../data/carServiceData';

interface LiveProgressDashboardProps {
  booking: Booking;
  onApproveRecommendation: (approve: boolean) => void;
  onAdvanceProgressSimulated: () => void;
  onUpdateDiagnostics?: (updatedReport: DiagnosticReport) => void;
}

export default function LiveProgressDashboard({
  booking,
  onApproveRecommendation,
  onAdvanceProgressSimulated,
  onUpdateDiagnostics,
}: LiveProgressDashboardProps) {
  const [logs, setLogs] = useState<string[]>([]);
  const [logIndex, setLogIndex] = useState(0);

  // Calibration state managers
  const [calibratingTool, setCalibratingTool] = useState<string | null>(null);
  const [calibrationProgress, setCalibrationProgress] = useState(0);
  const [calibrationStatusText, setCalibrationStatusText] = useState('');

  const downloadPdfReceipt = () => {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    // Color Palette
    const primaryColor = [15, 23, 42]; // Slate 900 #0f172a
    const accentColor = [16, 185, 129]; // Emerald 500 #10b981
    const textDark = [30, 41, 59]; // Slate 800
    const textMuted = [100, 116, 139]; // Slate 500
    const lightBg = [248, 250, 252]; // Slate 50
    const white = [255, 255, 255];

    // Top Accent bar
    doc.setFillColor(accentColor[0], accentColor[1], accentColor[2]);
    doc.rect(0, 0, 210, 8, 'F');

    // Company Name & Logo
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(22);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('APEX PRECISION AUTOWORKS', 15, 22);

    // Slogan
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(9);
    doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
    doc.text('PREMIUM CALIBRATION & MECHANICAL SERVICE CENTRE', 15, 27);

    // Meta Info (Right side)
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
    doc.text('DOCUMENT ID: APX-' + booking.id.toUpperCase(), 140, 18);
    doc.text('DATE GENERATED: ' + new Date().toLocaleDateString(), 140, 23);
    doc.text('STATUS: ' + booking.status.replace('_', ' '), 140, 28);

    // Divider
    doc.setDrawColor(226, 232, 240); // Slate 200
    doc.setLineWidth(0.5);
    doc.line(15, 34, 195, 34);

    // Section 1: Customer & Vehicle Info
    doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
    doc.rect(15, 38, 85, 36, 'F');
    doc.rect(110, 38, 85, 36, 'F');

    // Box 1: Client & Booking
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('BOOKING DETAILS', 18, 44);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(`Booking Date: ${booking.date}`, 18, 49);
    doc.text(`Time Slot: ${booking.timeSlot}`, 18, 54);
    doc.text(`Technician: ${booking.technician}`, 18, 59);
    doc.text(`Assigned Bay: Bay 3 (Precision Lab)`, 18, 64);

    // Box 2: Vehicle
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('VEHICLE PROFILE', 113, 44);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(`Model: ${booking.car.year} ${booking.car.make} ${booking.car.model}`, 113, 49);
    doc.text(`Engine/Propulsion: ${booking.car.fuelType}`, 113, 54);
    doc.text(`Registered Odometer: ${booking.car.mileage.toLocaleString()} mi`, 113, 59);
    doc.text(`System ID: ${booking.car.id}`, 113, 64);

    // Divider
    doc.line(15, 78, 195, 78);

    // Section 2: Diagnostic Telemetry Reports
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('SYSTEM DIAGNOSTICS SCAN REPORT', 15, 85);

    // Build grid for metrics
    const metricsY = 90;
    
    const drawMetricRow = (label: string, value: string, rating: string, yPos: number, accentBarColor: number[]) => {
      doc.setFillColor(lightBg[0], lightBg[1], lightBg[2]);
      doc.rect(15, yPos, 180, 10, 'F');
      
      // left accent indicator
      doc.setFillColor(accentBarColor[0], accentBarColor[1], accentBarColor[2]);
      doc.rect(15, yPos, 2, 10, 'F');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(textDark[0], textDark[1], textDark[2]);
      doc.text(label, 20, yPos + 6.5);

      doc.setFont('helvetica', 'normal');
      doc.text(value, 90, yPos + 6.5);

      doc.setFont('helvetica', 'bold');
      doc.setTextColor(accentBarColor[0], accentBarColor[1], accentBarColor[2]);
      doc.text(rating, 160, yPos + 6.5);
    };

    const oilHealth = booking.diagnosticReport.oilHealth;
    const oilRating = oilHealth > 50 ? 'EXCELLENT' : oilHealth > 20 ? 'MONITOR' : 'CRITICAL REPLACE';
    const oilColor = oilHealth > 50 ? accentColor : oilHealth > 20 ? [245, 158, 11] : [239, 68, 68];

    const brakeWear = booking.diagnosticReport.brakePadWear;
    const brakeRating = brakeWear < 40 ? 'EXCELLENT' : brakeWear < 75 ? 'MONITOR' : 'CRITICAL REPLACE';
    const brakeColor = brakeWear < 40 ? accentColor : brakeWear < 75 ? [245, 158, 11] : [239, 68, 68];

    const batteryVolts = booking.diagnosticReport.batteryVoltage;
    const batteryRating = batteryVolts >= 12.0 ? 'OPTIMAL' : batteryVolts >= 11.5 ? 'LOW CHARGE' : 'CRITICAL FAULT';
    const batteryColor = batteryVolts >= 12.0 ? accentColor : batteryVolts >= 11.5 ? [245, 158, 11] : [239, 68, 68];

    drawMetricRow('Oil Health & Fluid Lubricity', `${oilHealth}% Active life remaining`, oilRating, metricsY, oilColor);
    drawMetricRow('Brake Pad Friction Lining', `${brakeWear}% Wear depth index`, brakeRating, metricsY + 12, brakeColor);
    drawMetricRow('Alternator / Rest Voltage', `${batteryVolts} Volts potential`, batteryRating, metricsY + 24, batteryColor);
    drawMetricRow(
      'Tire Tread Safety Profiles', 
      `Front: ${booking.diagnosticReport.tireTreadDepthFront} mm / Rear: ${booking.diagnosticReport.tireTreadDepthRear} mm`, 
      Math.min(booking.diagnosticReport.tireTreadDepthFront, booking.diagnosticReport.tireTreadDepthRear) > 3 ? 'NOMINAL' : 'CRITICAL', 
      metricsY + 36, 
      Math.min(booking.diagnosticReport.tireTreadDepthFront, booking.diagnosticReport.tireTreadDepthRear) > 3 ? accentColor : [239, 68, 68]
    );

    // Diagnostic summary block
    doc.setFillColor(241, 245, 249); // slate-100
    doc.rect(15, metricsY + 50, 180, 18, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
    doc.text('DIAGNOSTICIANS NOTE & REPAIR NOTES:', 18, metricsY + 54);
    
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(8.5);
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    
    const splitSummary = doc.splitTextToSize(booking.diagnosticReport.diagnosticSummary, 172);
    doc.text(splitSummary, 18, metricsY + 59);

    // Divider
    doc.setDrawColor(226, 232, 240);
    doc.line(15, metricsY + 73, 195, metricsY + 73);

    // Section 3: Billing & Invoice items
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('LINE ITEM INVOICE RECEIPT', 15, metricsY + 80);

    // Table Header
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(15, metricsY + 84, 180, 7, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(white[0], white[1], white[2]);
    doc.text('SERVICE DESCRIPTION', 18, metricsY + 89);
    doc.text('TYPE', 110, metricsY + 89);
    doc.text('PRICE', 175, metricsY + 89);

    let currentY = metricsY + 95;

    // Item 1: Core Service
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(textDark[0], textDark[1], textDark[2]);
    doc.text(booking.service.name, 18, currentY);
    doc.setFont('helvetica', 'normal');
    doc.text('Core Service', 110, currentY);
    doc.setFont('helvetica', 'bold');
    doc.text(`$${booking.service.price}.00`, 175, currentY);

    currentY += 6;

    // Item 2: Add-ons
    booking.addOns.forEach((addOnId) => {
      const addOn = ADD_ONS.find(a => a.id === addOnId);
      if (addOn) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        doc.setTextColor(textDark[0], textDark[1], textDark[2]);
        doc.text(addOn.name, 18, currentY);
        doc.setFont('helvetica', 'normal');
        doc.text('Optional Add-on', 110, currentY);
        doc.setFont('helvetica', 'bold');
        doc.text(`$${addOn.price}.00`, 175, currentY);
        currentY += 6;
      }
    });

    // Item 3: Recommended Repairs (if approved)
    if (booking.additionalRecommendationApproved === true) {
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
      doc.text('Approved Recommended Calibrations', 18, currentY);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(textDark[0], textDark[1], textDark[2]);
      doc.text('Diagnostic Upgrade', 110, currentY);
      doc.setFont('helvetica', 'bold');
      doc.text('+$95.00', 175, currentY);
      currentY += 6;
    }

    // Border line under items
    doc.setDrawColor(241, 245, 249);
    doc.line(15, currentY, 195, currentY);
    currentY += 5;

    // Total Display
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('GRAND TOTAL DUE:', 110, currentY + 1);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
    doc.text(`$${booking.totalPrice}.00`, 175, currentY + 1.2);

    // Receipt footer terms
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(7.5);
    doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
    doc.text('APEX Precision Autoworks verifies all mechanical sensors were balanced and calibrated using certified laser metrics.', 15, 280);
    doc.text('All parts carry a 24-month OEM-backed parts guarantee. Thank you for your business!', 15, 284);

    // Save File
    doc.save(`APEX-Receipt-${booking.car.make}-${booking.car.model}.pdf`);
  };

  const runCalibration = (type: 'oil' | 'battery' | 'brakes') => {
    if (calibratingTool) return;
    setCalibratingTool(type);
    setCalibrationProgress(0);
    setCalibrationStatusText('Establishing mechanical link...');

    const stepSets = {
      oil: [
        { progress: 20, text: 'Connecting high-vacuum drainage lines...' },
        { progress: 50, text: 'Extracting depleted fluid particles...' },
        { progress: 80, text: 'Injecting Ultra-Synthetic performance oil (5.0L)...' },
        { progress: 100, text: 'Viscosity parameters restored to 100%!' }
      ],
      battery: [
        { progress: 25, text: 'Connecting high-amperage charger terminals...' },
        { progress: 60, text: 'Executing battery load-rebalancing algorithms...' },
        { progress: 85, text: 'Saturating chemical cells with micro-volt pulses...' },
        { progress: 100, text: 'Alternator circuit stable at 13.8V!' }
      ],
      brakes: [
        { progress: 20, text: 'Retracting front brake caliper pistons...' },
        { progress: 50, text: 'Removing safety pin and scraping pad glazed layer...' },
        { progress: 80, text: 'Positioning high-friction ceramic pads...' },
        { progress: 100, text: 'Brake pad thickness restored to safe limits!' }
      ]
    };

    let idx = 0;
    const currentSteps = stepSets[type];
    
    const interval = setInterval(() => {
      if (idx < currentSteps.length) {
        const step = currentSteps[idx];
        setCalibrationProgress(step.progress);
        setCalibrationStatusText(step.text);
        
        // Append a live feedback log with a professional calibration stamp!
        setLogs(prev => [
          ...prev, 
          `[SYS_OVERRIDE] Calibration Step ${idx + 1}: ${step.text}`
        ]);
        
        idx++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          if (onUpdateDiagnostics) {
            const updated = { ...booking.diagnosticReport };
            if (type === 'oil') {
              updated.oilHealth = 100;
              updated.diagnosticSummary = "Fully flushed system. Fresh synthetic fluid running clean with zero particulate loading.";
            } else if (type === 'battery') {
              updated.batteryVoltage = 13.8;
              updated.diagnosticSummary = "Alternator charging circuit recalibrated. Battery resting potential stabilized at 13.8 Volts.";
            } else if (type === 'brakes') {
              updated.brakePadWear = 15;
              updated.diagnosticSummary = "Caliper sliding cylinders lubricated. Front and rear friction materials measured at 15% wear (new).";
            }
            onUpdateDiagnostics(updated);
          }
          setCalibratingTool(null);
        }, 1000);
      }
    }, 1200);
  };

  const steps = [
    { label: 'Awaiting Arrival', desc: 'Bring vehicle to check-in bay' },
    { label: 'Diagnostics', desc: 'OBD ECU scan & gauge mapping' },
    { label: 'In Progress', desc: 'Mechanical operations underway' },
    { label: 'Quality Check', desc: 'Master tech test & system reset' },
    { label: 'Ready for Pickup', desc: 'Invoice clear & keys prepared' },
  ];

  // Map BookingStatus to step index
  const statusToStepIndex = (status: BookingStatus): number => {
    switch (status) {
      case BookingStatus.AWAITING_ARRIVAL: return 0;
      case BookingStatus.DIAGNOSING: return 1;
      case BookingStatus.IN_PROGRESS: return 2;
      case BookingStatus.QUALITY_CHECK: return 3;
      case BookingStatus.READY_FOR_PICKUP: return 4;
      case BookingStatus.COMPLETED: return 5;
      default: return 0;
    }
  };

  const currentStepIdx = statusToStepIndex(booking.status);

  // Generate logs based on booking progress
  const allPossibleLogs: Record<number, string[]> = {
    0: [
      'Waiting for car to pull into check-in bay...',
      'Digital license plate scanner active.',
      'Customer check-in details matched. Welcome!',
    ],
    1: [
      'Vehicle positioned on diagnostic hoist.',
      'Connecting OBD-II computerized scanner to ECU...',
      'ECU connected. Scanning fault registers...',
      'Testing battery voltage: Load test outputting 11.9V (Threshold low).',
      'Scanning tire tread depths with 3D laser scanner...',
      'Front right tyre tread: 3.2mm. Rear left tyre tread: 4.5mm.',
      'Analyzing engine oil degradation index...',
      'Diagnostics completed. Full diagnostic report mapped to user dashboard.',
    ],
    2: [
      'Unscrewing under-chassis drainage bolt.',
      'Draining high-shear engine lubricants...',
      'Extracting oil filter capsule. Heavy particulate build-up noted.',
      'Installing new premium OEM air filter cartridge.',
      'Injecting fresh Ultra-Glide fully synthetic oil (5.0 Litres).',
      'Bleeding brake lines. Flushing old hydraulic fluid from master cylinder...',
      'Fitting fresh brake friction pads and lubricating caliper slides...',
      'Executing electronic throttle body carbon cleansing...',
    ],
    3: [
      'Double checking torque load specs on cylinder bolts.',
      'Clearing transient dashboard MIL error codes.',
      'Flashing vehicle ECU module to latest OEM firmware release.',
      'Performing dynamic chassis road-holding & braking test.',
      'Braking system efficiency rated: 98% (Excellent).',
      'Passing vehicle through Aqua-Jet Wash & Spa Detailing bay...',
      'Final mechanical safety certificate signed by Master Diagnostic Specialist.',
    ],
    4: [
      'Vehicle parked in prime pickup Bay 3.',
      'Cabin sanitized and lavender scent diffusers applied.',
      'Key fob tagged and locked in security locker.',
      'Digital booking status set to READY_FOR_PICKUP.',
    ],
    5: [
      'Customer arrived at APEX Precision check-out bay.',
      'Diagnostic logs synchronized to cloud profile.',
      'Key fob hand-off completed successfully.',
      'Vehicle departed detailing outgate. Service successfully finalized!',
      'Thank you for booking with APEX Precision. Drive safely!',
    ],
  };

  useEffect(() => {
    // Reset logs when status shifts
    setLogs(allPossibleLogs[currentStepIdx] ? [allPossibleLogs[currentStepIdx][0]] : []);
    setLogIndex(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [booking.status]);

  useEffect(() => {
    const currentLogs = allPossibleLogs[currentStepIdx] || [];
    if (logIndex < currentLogs.length) {
      const timer = setTimeout(() => {
        setLogs(prev => [...prev, currentLogs[logIndex]]);
        setLogIndex(prev => prev + 1);
      }, 3000 + Math.random() * 2000); // add logs every few seconds
      return () => clearTimeout(timer);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [logIndex, booking.status]);

  // Gauge helpers
  const getProgressColor = (val: number, isReversedLevel = false) => {
    if (isReversedLevel) {
      if (val > 70) return 'bg-rose-500';
      if (val > 40) return 'bg-amber-500';
      return 'bg-emerald-500';
    }
    if (val < 20) return 'bg-rose-500';
    if (val < 50) return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  const getTreadColor = (mm: number) => {
    if (mm < 3) return 'bg-rose-500';
    if (mm < 5) return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-8" id="live_progress_dashboard_root">
      {/* Title block with simulate trigger */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-800 pb-5">
        <div>
          <span className="text-xs bg-cyan-950 text-cyan-400 border border-cyan-800 px-3 py-1 rounded-full font-semibold inline-flex items-center gap-1">
            <span className="w-2 h-2 bg-cyan-400 rounded-full animate-ping"></span>
            LIVE SERVICE BAY TRACKER
          </span>
          <h2 className="text-2xl font-bold tracking-tight text-white mt-2 flex items-center gap-2">
            <Icons.Radio className="text-emerald-400 w-6 h-6 animate-pulse" />
            Active Service Dashboard
          </h2>
          <p className="text-slate-400 text-xs mt-1">
            Watch real-time mechanical telemetry, technician notes, and progress logs as your vehicle is serviced.
          </p>
        </div>

        {/* Advance simulator button */}
        {booking.status !== BookingStatus.COMPLETED && (
          <button
            onClick={onAdvanceProgressSimulated}
            id="simulate_advance_progress_btn"
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-xs font-bold px-4 py-2.5 rounded-xl transition-all flex items-center gap-2 shadow-md"
          >
            <Icons.FastForward className="w-4 h-4 text-emerald-400" />
            <span>Simulate Step Advance</span>
          </button>
        )}
      </div>

      {/* Stepper progress pipeline */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
        {/* Connection line helper */}
        <div className="hidden md:block absolute top-[18px] left-[10%] right-[10%] h-1.5 bg-slate-800 z-0 rounded-full overflow-hidden">
          <div
            className="h-full bg-emerald-500 transition-all duration-1000"
            style={{ width: `${(currentStepIdx / 4) * 100}%` }}
          ></div>
        </div>

        {steps.map((step, idx) => {
          const isDone = idx < currentStepIdx;
          const isActive = idx === currentStepIdx;
          const isPending = idx > currentStepIdx;

          return (
            <div
              key={step.label}
              className={`flex md:flex-col items-center md:text-center gap-3 md:gap-2.5 relative z-10 p-3.5 rounded-xl border transition-all ${
                isActive
                  ? 'bg-slate-950 border-emerald-500 shadow-lg shadow-emerald-950/20'
                  : isDone
                  ? 'bg-slate-950/30 border-slate-850 opacity-80'
                  : 'bg-slate-950/10 border-slate-900 opacity-40'
              }`}
            >
              {/* Step indicator circle */}
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 border transition-all ${
                isDone
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                  : isActive
                  ? 'bg-slate-900 border-emerald-500 text-white shadow-[0_0_12px_rgba(16,185,129,0.4)]'
                  : 'bg-slate-950 border-slate-800 text-slate-500'
              }`}>
                {isDone ? (
                  <Icons.Check className="w-4 h-4 text-emerald-400 font-bold" />
                ) : (
                  <span className="text-xs font-bold font-mono">{idx + 1}</span>
                )}
              </div>

              {/* Text info */}
              <div>
                <h4 className={`text-xs font-bold tracking-tight ${
                  isActive ? 'text-white' : isDone ? 'text-slate-300' : 'text-slate-500'
                }`}>
                  {step.label}
                </h4>
                <p className="text-[10px] text-slate-500 mt-0.5 leading-snug hidden md:block">
                  {step.desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Live diagnostics camera logs & Technician recommendation (col-span-7) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Live Bay Cam Diagnostics console */}
          <div className="relative bg-slate-950 border border-slate-850 rounded-2xl overflow-hidden shadow-inner flex flex-col h-80">
            {/* Cam Header */}
            <div className="bg-slate-900 px-4 py-2.5 border-b border-slate-850 flex justify-between items-center text-[11px] font-mono">
              <span className="text-slate-200 flex items-center gap-2 font-bold uppercase tracking-wider">
                <Icons.Video className="w-4 h-4 text-rose-500 animate-pulse" />
                Live Feed // APEX_BAY_3_CAM
              </span>
              <div className="flex items-center gap-4 text-slate-500 text-[10px]">
                <span className="hidden sm:inline text-emerald-400 font-semibold animate-pulse">● SIGNAL: 100%</span>
                <span className="hidden md:inline">FPS: 30.0</span>
                <span className="hidden md:inline">TEMP: 38.6°C</span>
                <span className="text-slate-400 font-bold uppercase tracking-widest">
                  REC [UTC 2026]
                </span>
              </div>
            </div>

            {/* Logs list console */}
            <div className="flex-1 p-4 overflow-y-auto font-mono text-xs text-emerald-400 space-y-2 flex flex-col justify-end bg-black">
              {/* Overlay simulation scanlines */}
              <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,_rgba(0,0,0,0.25)_50%),_linear-gradient(90deg,_rgba(255,0,0,0.06),_rgba(0,255,0,0.02),_rgba(0,0,255,0.06))] bg-[size:100%_4px,_3px_100%] opacity-35"></div>

              {logs.map((log, idx) => (
                <div key={idx} className="flex gap-2">
                  <span className="text-slate-600 font-bold">[{new Date().toLocaleTimeString('en-US', { hour12: false })}]</span>
                  <span className="text-slate-400">&gt;</span>
                  <p className="flex-1 leading-relaxed text-emerald-400">{log}</p>
                </div>
              ))}
              <div className="flex gap-2 items-center text-emerald-500">
                <span className="text-slate-600">[{new Date().toLocaleTimeString('en-US', { hour12: false })}]</span>
                <span className="text-slate-400">&gt;</span>
                <span className="inline-block w-2 h-4 bg-emerald-400 animate-pulse"></span>
              </div>
            </div>
          </div>

          {/* Interactive Technician recommendation box (Upsell alert!) */}
          <AnimatePresence>
            {currentStepIdx >= 1 && currentStepIdx <= 3 && booking.additionalRecommendationApproved === null && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-amber-950/40 border border-amber-900/60 rounded-2xl p-5 space-y-4 shadow-xl"
                id="technician_recommendation_box"
              >
                <div className="flex justify-between items-center border-b border-amber-900/40 pb-2.5">
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Icons.AlertTriangle className="w-4 h-4 text-amber-500 animate-bounce" />
                    Technician Mid-Service Consultation
                  </span>
                  <span className="text-[9px] bg-amber-900 text-amber-400 font-bold px-2 py-0.5 rounded-full uppercase">
                    Awaiting authorization
                  </span>
                </div>

                <div className="flex gap-4">
                  <div className="hidden sm:block p-3 bg-amber-950 text-amber-400 rounded-xl shrink-0 h-11 w-11 border border-amber-900">
                    <Icons.UserCheck className="w-5 h-5" />
                  </div>
                  <div className="space-y-3">
                    <h5 className="text-xs font-bold text-amber-300">Elena Rostova (Master Diagnostic Technician):</h5>
                    <p className="text-slate-300 text-xs leading-relaxed">
                      &ldquo;While conducting our 25-point physical teardown, we noticed your **Cabin Air AC filter** is heavily clogged with gray leaf mold. It restricts airflow and emits spore odors. We recommend a fresh activated-carbon filter upgrade for **+$35** (parts & installation included). Would you like to authorize this?&rdquo;
                    </p>
                    <div className="flex flex-wrap gap-2 pt-1">
                      <button
                        onClick={() => onApproveRecommendation(true)}
                        id="approve_upsell_btn"
                        className="bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs px-4 py-2 rounded-xl transition-all flex items-center gap-1 shadow-md"
                      >
                        <Icons.CheckCircle2 className="w-4 h-4 text-white" />
                        <span>Approve Cabin Filter (+$35)</span>
                      </button>
                      <button
                        onClick={() => onApproveRecommendation(false)}
                        id="decline_upsell_btn"
                        className="bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-300 border border-slate-800 font-bold text-xs px-4 py-2 rounded-xl transition-all"
                      >
                        Decline & Proceed
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {booking.additionalRecommendationApproved === true && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-emerald-950/30 border border-emerald-900/50 p-4 rounded-2xl flex items-center gap-3"
              >
                <div className="p-2 bg-emerald-950 text-emerald-400 rounded-xl">
                  <Icons.CheckCircle className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-emerald-400">Cabin Filter Upgrade Authorized</h4>
                  <p className="text-slate-400 text-[11px] mt-0.5 leading-relaxed">
                    Our logistics hub is dispatching the replacement activated-carbon filter. It has been added to your booking invoice total.
                  </p>
                </div>
              </motion.div>
            )}

            {booking.additionalRecommendationApproved === false && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-slate-950 border border-slate-850 p-4 rounded-2xl flex items-center gap-3 text-slate-500"
              >
                <Icons.Info className="w-5 h-5" />
                <p className="text-xs">
                  Upgrade declined. Proceeding with your original booking instructions only.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right Column: Diagnostic Health Gauges Telemetry (col-span-5) */}
        <div className="lg:col-span-5 bg-slate-950 border border-slate-850 rounded-2xl p-5 space-y-5">
          <div className="flex justify-between items-center border-b border-slate-900 pb-2.5 gap-2">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Icons.Gauge className="w-4 h-4 text-emerald-400" />
              Active Car Diagnostic Telemetry
            </h3>
            <button
              type="button"
              onClick={downloadPdfReceipt}
              className="bg-slate-900 hover:bg-slate-850 border border-slate-800 text-[10.5px] font-bold text-slate-300 hover:text-white px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shadow-sm active:scale-95"
              title="Download official APEX Diagnostic PDF Receipt"
            >
              <Icons.FileDown className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export PDF</span>
            </button>
          </div>

          <div className="space-y-4">
            {/* Oil life gauge */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <Icons.Droplet className="w-3.5 h-3.5 text-amber-500" /> Oil Lifespan / Lubricity
                </span>
                <span className="font-mono font-bold text-slate-200">
                  {booking.diagnosticReport.oilHealth}%
                </span>
              </div>
              <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-850">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${getProgressColor(booking.diagnosticReport.oilHealth)}`}
                  style={{ width: `${booking.diagnosticReport.oilHealth}%` }}
                ></div>
              </div>
              <p className="text-[10px] text-slate-500">
                {booking.diagnosticReport.oilHealth < 15 ? 'Critical wear index: Carbon loading detected' : 'Lubricity values within recommended limits'}
              </p>
            </div>

            {/* Brake Pad Wear gauge */}
            <div className="space-y-1.5 pt-1 border-t border-slate-900/60">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <Icons.Disc className="w-3.5 h-3.5 text-rose-400" /> Brake Pad Wear Index
                </span>
                <span className="font-mono font-bold text-slate-200">
                  {booking.diagnosticReport.brakePadWear}% Wear
                </span>
              </div>
              <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-850">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${getProgressColor(booking.diagnosticReport.brakePadWear, true)}`}
                  style={{ width: `${booking.diagnosticReport.brakePadWear}%` }}
                ></div>
              </div>
              <p className="text-[10px] text-slate-500">
                {booking.diagnosticReport.brakePadWear > 80 ? 'CRITICAL: Brake material exhausted (Replace pads immediately)' : 'Brake thickness nominal'}
              </p>
            </div>

            {/* Battery Voltage gauge */}
            <div className="space-y-1.5 pt-1 border-t border-slate-900/60">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400 flex items-center gap-1">
                  <Icons.Zap className="w-3.5 h-3.5 text-yellow-500" /> Alternator Charge Telemetry
                </span>
                <span className="font-mono font-bold text-slate-200">
                  {booking.diagnosticReport.batteryVoltage} V
                </span>
              </div>
              <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-850">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    booking.diagnosticReport.batteryVoltage < 12.0 ? 'bg-amber-500' : 'bg-emerald-500'
                  }`}
                  style={{ width: `${((booking.diagnosticReport.batteryVoltage - 11.0) / 3.5) * 100}%` }}
                ></div>
              </div>
              <p className="text-[10px] text-slate-500">
                {booking.diagnosticReport.batteryVoltage < 12.0 ? 'Alternator output nominal, but battery chemistry low charge' : 'Battery charge & alternator circuit optimal'}
              </p>
            </div>

            {/* Tires wear depth gauge */}
            <div className="grid grid-cols-2 gap-3 pt-1 border-t border-slate-900/60">
              <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-850 space-y-1">
                <div className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Front Tires Tread</div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-black font-mono text-white">{booking.diagnosticReport.tireTreadDepthFront} mm</span>
                  <span className={`w-2 h-2 rounded-full ${getTreadColor(booking.diagnosticReport.tireTreadDepthFront)}`}></span>
                </div>
                <div className="text-[9px] text-slate-500">Min safety limits: 1.6 mm</div>
              </div>
              <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-850 space-y-1">
                <div className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Rear Tires Tread</div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-black font-mono text-white">{booking.diagnosticReport.tireTreadDepthRear} mm</span>
                  <span className={`w-2 h-2 rounded-full ${getTreadColor(booking.diagnosticReport.tireTreadDepthRear)}`}></span>
                </div>
                <div className="text-[9px] text-slate-500">Nominal tread wear</div>
              </div>
            </div>
          </div>

          {/* Diagnostic Summary Note Box */}
          <div className="bg-slate-900/60 border border-slate-850 p-3 rounded-xl space-y-1.5 text-xs">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Engine Diagnostic Assessment Note:</span>
            <p className="text-slate-300 leading-relaxed font-sans">
              {booking.diagnosticReport.diagnosticSummary}
            </p>
          </div>

          {/* Interactive Override/Calibration Control Panel */}
          <div className="bg-slate-900/60 border border-slate-850 p-4 rounded-xl space-y-3.5" id="calibration_overrides_panel">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Icons.Sliders className="w-3.5 h-3.5 text-emerald-400" />
                Live Calibration Overrides
              </span>
              <span className="text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-900 px-1.5 py-0.5 rounded uppercase font-mono font-bold tracking-wider animate-pulse">
                Active Link
              </span>
            </div>

            {calibratingTool ? (
              <div className="space-y-2 bg-slate-950 p-3 rounded-lg border border-slate-850">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-emerald-400 font-bold font-mono animate-pulse uppercase tracking-wider">
                    {calibratingTool === 'oil' ? 'Flushing System' : calibratingTool === 'battery' ? 'Balancing Alternator' : 'Fitting Brake Pads'}...
                  </span>
                  <span className="text-white font-mono font-bold">{calibrationProgress}%</span>
                </div>
                <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-850">
                  <div
                    className="h-full bg-emerald-400 transition-all duration-300"
                    style={{ width: `${calibrationProgress}%` }}
                  ></div>
                </div>
                <p className="text-[10px] text-slate-400 leading-snug">
                  {calibrationStatusText}
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-[10.5px] text-slate-500 leading-relaxed">
                  Trigger diagnostic overrides to simulate immediate fluid flushing, alternator testing, or mechanical brake calibration tasks.
                </p>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => runCalibration('oil')}
                    className="bg-slate-950 hover:bg-slate-850 text-[10px] font-bold text-slate-300 p-2 rounded-lg border border-slate-850 hover:border-slate-700 transition-all text-center flex flex-col items-center justify-center gap-1.5"
                    title="Simulate fluid replacement"
                  >
                    <Icons.Droplet className="w-3.5 h-3.5 text-amber-500" />
                    <span>Flush Oil</span>
                  </button>
                  <button
                    onClick={() => runCalibration('battery')}
                    className="bg-slate-950 hover:bg-slate-850 text-[10px] font-bold text-slate-300 p-2 rounded-lg border border-slate-850 hover:border-slate-700 transition-all text-center flex flex-col items-center justify-center gap-1.5"
                    title="Recharge cells"
                  >
                    <Icons.Zap className="w-3.5 h-3.5 text-yellow-500" />
                    <span>Charge Volt</span>
                  </button>
                  <button
                    onClick={() => runCalibration('brakes')}
                    className="bg-slate-950 hover:bg-slate-850 text-[10px] font-bold text-slate-300 p-2 rounded-lg border border-slate-850 hover:border-slate-700 transition-all text-center flex flex-col items-center justify-center gap-1.5"
                    title="Install friction linings"
                  >
                    <Icons.Disc className="w-3.5 h-3.5 text-rose-400" />
                    <span>Repad Brakes</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
