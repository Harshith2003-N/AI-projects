import { useState } from 'react';
import { motion } from 'motion/react';
import * as Icons from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { SHOP_OCCUPANCY_TREND, REVIEWS, FACILITIES } from '../data/carServiceData';

export default function ShopAnalytics() {
  const [selectedReviewFilter, setSelectedReviewFilter] = useState<number>(0); // 0 = All, 5 = 5 star, 4 = 4 star

  // Mock data for facility utilization
  const facilityUtilizationData = FACILITIES.map(facility => ({
    name: facility.name.split(' ')[0] || facility.name,
    utilization: Math.round((facility.currentOccupancy / facility.capacity) * 100),
    occupancy: facility.currentOccupancy,
    capacity: facility.capacity,
  }));

  const filteredReviews = selectedReviewFilter === 0
    ? REVIEWS
    : REVIEWS.filter(r => r.rating === selectedReviewFilter);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-8" id="shop_analytics_root">
      {/* Header */}
      <div className="border-b border-slate-800 pb-5">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Icons.LineChart className="text-emerald-400 w-6 h-6" />
          Shop Performance & Analytics
        </h2>
        <p className="text-xs text-slate-400 mt-0.5">
          Review live facility loads, daily busy hour spikes, and interactive performance reports.
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="bg-slate-950 border border-slate-850 p-4 rounded-2xl space-y-1">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Average Satisfaction</span>
          <div className="flex items-center gap-1.5">
            <span className="text-xl font-black text-white font-mono">4.92</span>
            <Icons.Star className="w-4 h-4 fill-amber-500 text-amber-500" />
          </div>
          <span className="text-[9px] text-emerald-400 block font-semibold">+0.04% this month</span>
        </div>

        {/* KPI 2 */}
        <div className="bg-slate-950 border border-slate-850 p-4 rounded-2xl space-y-1">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Active Bay Load</span>
          <div className="flex items-center gap-1.5">
            <span className="text-xl font-black text-white font-mono">82%</span>
            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
          </div>
          <span className="text-[9px] text-slate-500 block">6 bays loaded of 10</span>
        </div>

        {/* KPI 3 */}
        <div className="bg-slate-950 border border-slate-850 p-4 rounded-2xl space-y-1">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Avg Turnaround Time</span>
          <div className="flex items-center gap-1.5">
            <span className="text-xl font-black text-white font-mono">62 mins</span>
            <Icons.Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <span className="text-[9px] text-emerald-400 block font-semibold">-5 mins diagnostic queue</span>
        </div>

        {/* KPI 4 */}
        <div className="bg-slate-950 border border-slate-850 p-4 rounded-2xl space-y-1">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block">Eco Carbon Offset</span>
          <div className="flex items-center gap-1.5">
            <span className="text-xl font-black text-white font-mono">420 kg</span>
            <Icons.Leaf className="w-4 h-4 text-emerald-400" />
          </div>
          <span className="text-[9px] text-slate-500 block">EV & Hybrid engine calibrations</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Busy hours graph */}
        <div className="bg-slate-950 border border-slate-850 rounded-2xl p-5 space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Icons.Clock className="w-4 h-4 text-emerald-400" />
              Hourly Occupancy Waves
            </h3>
            <span className="text-[10px] font-semibold text-slate-500">Normal operating cycle</span>
          </div>

          <div className="h-48 text-slate-400 text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={SHOP_OCCUPANCY_TREND} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorBookings" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.3} />
                <XAxis dataKey="hour" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                  labelStyle={{ color: '#fff', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="bookingsCount" name="Active Bookings" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorBookings)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[10px] text-slate-500 leading-snug">
            💡 <strong>Efficiency Tip:</strong> Booking between <strong>08:00–09:00</strong> or <strong>15:00–17:00</strong> generally ensures the quickest mechanic assignment due to low booking cycles.
          </p>
        </div>

        {/* Facility utilization */}
        <div className="bg-slate-950 border border-slate-850 rounded-2xl p-5 space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Icons.BarChart4 className="w-4 h-4 text-emerald-400" />
              Facility Capacity Utilization
            </h3>
            <span className="text-[10px] font-semibold text-slate-500">Live bay occupancy</span>
          </div>

          <div className="h-48 text-slate-400 text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={facilityUtilizationData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.3} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} unit="%" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                  labelStyle={{ color: '#fff', fontWeight: 'bold' }}
                />
                <Bar dataKey="utilization" name="Utilization Rate" fill="#06b6d4" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[10px] text-slate-500 leading-snug">
            Our Under-Chassis lifts are currently at high load. Our diagnostics and wheel aligner decks remain fully operational with minimal queue.
          </p>
        </div>
      </div>

      {/* Interactive Maintenance Savings & Planner Section */}
      <InteractiveSavingsPlanner />

      {/* Customer Reviews panel */}
      <div className="space-y-4 pt-4 border-t border-slate-800">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
            <Icons.MessageSquareQuote className="w-4 h-4 text-emerald-400" />
            Verified Customer Experiences
          </h3>

          <div className="flex gap-1 bg-slate-950 p-1 rounded-xl border border-slate-850">
            <button
              onClick={() => setSelectedReviewFilter(0)}
              className={`text-[10px] px-3 py-1 rounded-lg transition-colors ${
                selectedReviewFilter === 0 ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'
              }`}
            >
              All Reviews
            </button>
            <button
              onClick={() => setSelectedReviewFilter(5)}
              className={`text-[10px] px-3 py-1 rounded-lg transition-colors flex items-center gap-0.5 ${
                selectedReviewFilter === 5 ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'
              }`}
            >
              5 <Icons.Star className="w-2.5 h-2.5 fill-current text-amber-500" />
            </button>
            <button
              onClick={() => setSelectedReviewFilter(4)}
              className={`text-[10px] px-3 py-1 rounded-lg transition-colors flex items-center gap-0.5 ${
                selectedReviewFilter === 4 ? 'bg-slate-800 text-white font-bold' : 'text-slate-400'
              }`}
            >
              4 <Icons.Star className="w-2.5 h-2.5 fill-current text-amber-500" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredReviews.map((review) => (
            <div key={review.id} className="bg-slate-950 border border-slate-850 rounded-2xl p-4 space-y-2.5">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-xs font-bold text-white">{review.customerName}</h4>
                  <span className="text-[10px] text-slate-500 font-mono">{review.carModel} // {review.serviceType}</span>
                </div>
                <div className="flex gap-0.5">
                  {Array.from({ length: review.rating }).map((_, i) => (
                    <Icons.Star key={i} className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                  ))}
                </div>
              </div>
              <p className="text-slate-400 text-xs leading-relaxed italic">&ldquo;{review.comment}&rdquo;</p>
              <div className="text-[10px] text-slate-600 font-mono text-right">{review.date}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function InteractiveSavingsPlanner() {
  const [driveType, setDriveType] = useState<'gas' | 'hybrid' | 'electric'>('electric');
  const [mileage, setMileage] = useState<number>(12000);
  const [lastCheckedMonths, setLastCheckedMonths] = useState<number>(8);
  const [serviceTier, setServiceTier] = useState<'basic' | 'tuneup' | 'full'>('tuneup');

  // Interactive calculations based on toggles
  const calculateMetrics = () => {
    // Basic factor: Electric cars have lower fluid costs but high tire/battery recalibration returns.
    // Gas/Hybrid cars benefit heavily on fuel economy.
    let rangeBoost = 0; // range % or fuel mpg boost
    let preventiveSavings = 0; // $ saved in future high-cost repairs
    let downtimeMinutesSaved = 0; // minutes saved by using synchronous bays

    const mileageMultiplier = mileage / 10000;
    const neglectedFactor = lastCheckedMonths > 6 ? (lastCheckedMonths - 6) * 0.15 : 0;

    if (driveType === 'electric') {
      rangeBoost = Math.round((5 + neglectedFactor * 3) * (serviceTier === 'full' ? 1.8 : serviceTier === 'tuneup' ? 1.3 : 0.8));
      preventiveSavings = Math.round(180 * mileageMultiplier * (1 + neglectedFactor) * (serviceTier === 'full' ? 2.2 : 1.4));
      downtimeMinutesSaved = Math.round(45 * (serviceTier === 'full' ? 1.8 : 1.2));
    } else if (driveType === 'hybrid') {
      rangeBoost = Math.round((6 + neglectedFactor * 4) * (serviceTier === 'full' ? 1.7 : serviceTier === 'tuneup' ? 1.25 : 0.85));
      preventiveSavings = Math.round(250 * mileageMultiplier * (1 + neglectedFactor) * (serviceTier === 'full' ? 2.0 : 1.35));
      downtimeMinutesSaved = Math.round(55 * (serviceTier === 'full' ? 1.6 : 1.15));
    } else {
      rangeBoost = Math.round((8 + neglectedFactor * 5) * (serviceTier === 'full' ? 1.6 : serviceTier === 'tuneup' ? 1.2 : 0.9));
      preventiveSavings = Math.round(310 * mileageMultiplier * (1 + neglectedFactor) * (serviceTier === 'full' ? 1.9 : 1.3));
      downtimeMinutesSaved = Math.round(70 * (serviceTier === 'full' ? 1.5 : 1.1));
    }

    return {
      rangeBoost,
      preventiveSavings,
      downtimeMinutesSaved,
    };
  };

  const metrics = calculateMetrics();

  return (
    <div className="bg-slate-950 border border-slate-850 rounded-2xl p-5 sm:p-6 space-y-6" id="savings_planner_section">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-850 pb-4 gap-2">
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Icons.BadgePercent className="w-4 h-4 text-emerald-400" />
            Interactive Maintenance Savings Planner
          </h3>
          <p className="text-[11px] text-slate-500">
            Simulate mileage parameters to calculate the productivity, range optimization, and cost savings of preventive care.
          </p>
        </div>
        <span className="text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-900/50 px-2 py-0.5 rounded font-mono font-bold tracking-wider">
          PRO-CALC V1.2
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Input Parameters Form */}
        <div className="lg:col-span-7 space-y-5">
          {/* Drive Type Select */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">1. Select Vehicle Propulsion</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setDriveType('electric')}
                className={`p-2.5 rounded-xl border text-xs font-bold transition-all text-center flex flex-col items-center gap-1 ${
                  driveType === 'electric'
                    ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.15)]'
                    : 'bg-slate-900 border-slate-850 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <Icons.Zap className="w-4 h-4 text-cyan-400" />
                <span>Full Electric EV</span>
              </button>
              <button
                type="button"
                onClick={() => setDriveType('hybrid')}
                className={`p-2.5 rounded-xl border text-xs font-bold transition-all text-center flex flex-col items-center gap-1 ${
                  driveType === 'hybrid'
                    ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.15)]'
                    : 'bg-slate-900 border-slate-850 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <Icons.Sparkles className="w-4 h-4 text-amber-400" />
                <span>Hybrid Drive</span>
              </button>
              <button
                type="button"
                onClick={() => setDriveType('gas')}
                className={`p-2.5 rounded-xl border text-xs font-bold transition-all text-center flex flex-col items-center gap-1 ${
                  driveType === 'gas'
                    ? 'bg-emerald-950/60 border-emerald-500 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.15)]'
                    : 'bg-slate-900 border-slate-850 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <Icons.Flame className="w-4 h-4 text-rose-400" />
                <span>Gas Combustion</span>
              </button>
            </div>
          </div>

          {/* Sliders */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Annual Mileage Slider */}
            <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-850 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-slate-400">Annual Travel</span>
                <span className="font-mono text-white font-bold">{mileage.toLocaleString()} mi</span>
              </div>
              <input
                type="range"
                min={2000}
                max={35000}
                step={1000}
                value={mileage}
                onChange={(e) => setMileage(Number(e.target.value))}
                className="w-full accent-emerald-500 bg-slate-950 h-1 rounded-lg cursor-pointer"
              />
              <span className="text-[9px] text-slate-500 block leading-tight">Increases potential wear probability of friction seals & battery cell balancing.</span>
            </div>

            {/* Neglected interval */}
            <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-850 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-slate-400">Last Service Age</span>
                <span className="font-mono text-white font-bold">{lastCheckedMonths} months ago</span>
              </div>
              <input
                type="range"
                min={1}
                max={24}
                step={1}
                value={lastCheckedMonths}
                onChange={(e) => setLastCheckedMonths(Number(e.target.value))}
                className="w-full accent-emerald-500 bg-slate-950 h-1 rounded-lg cursor-pointer"
              />
              <span className="text-[9px] text-slate-500 block leading-tight">Periods of neglected inspections compound friction degradation linearly.</span>
            </div>
          </div>

          {/* Service Level Tier Toggles */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">2. Select Scheduled Calibration Tier</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setServiceTier('basic')}
                className={`p-2 rounded-lg text-[10.5px] font-bold transition-all border ${
                  serviceTier === 'basic'
                    ? 'bg-slate-800 border-slate-600 text-white font-black'
                    : 'bg-slate-900/50 border-slate-850 text-slate-500 hover:text-slate-300'
                }`}
              >
                Basic Inspection
              </button>
              <button
                type="button"
                onClick={() => setServiceTier('tuneup')}
                className={`p-2 rounded-lg text-[10.5px] font-bold transition-all border ${
                  serviceTier === 'tuneup'
                    ? 'bg-slate-800 border-slate-600 text-white font-black'
                    : 'bg-slate-900/50 border-slate-850 text-slate-500 hover:text-slate-300'
                }`}
              >
                Precision Tune-Up
              </button>
              <button
                type="button"
                onClick={() => setServiceTier('full')}
                className={`p-2 rounded-lg text-[10.5px] font-bold transition-all border ${
                  serviceTier === 'full'
                    ? 'bg-slate-800 border-slate-600 text-white font-black'
                    : 'bg-slate-900/50 border-slate-850 text-slate-500 hover:text-slate-300'
                }`}
              >
                Full Hyper-Calibration
              </button>
            </div>
          </div>
        </div>

        {/* Dynamic Calculated Outcomes Display */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
          <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400 block">Optimized Savings Outcomes</span>

          <div className="space-y-3">
            {/* Metric 1 */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-850 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 bg-emerald-950 rounded text-emerald-400">
                  <Icons.TrendingUp className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-bold block uppercase">Efficiency Booster</span>
                  <p className="text-[10px] text-slate-400">Regenerative range return</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-base font-black text-white font-mono block">+{metrics.rangeBoost}%</span>
                <span className="text-[9px] text-slate-500 font-mono">more miles/charge</span>
              </div>
            </div>

            {/* Metric 2 */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-850 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 bg-cyan-950 rounded text-cyan-400">
                  <Icons.DollarSign className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-bold block uppercase">Preventive Return</span>
                  <p className="text-[10px] text-slate-400">Averted emergency repairs</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-base font-black text-emerald-400 font-mono block">${metrics.preventiveSavings}</span>
                <span className="text-[9px] text-slate-500 font-mono">annualized savings</span>
              </div>
            </div>

            {/* Metric 3 */}
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-850 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 bg-amber-950 rounded text-amber-400">
                  <Icons.Activity className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-bold block uppercase">Downtime Mitigated</span>
                  <p className="text-[10px] text-slate-400">With APEX synchronized lifts</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-base font-black text-white font-mono block">{metrics.downtimeMinutesSaved}m</span>
                <span className="text-[9px] text-slate-500 font-mono">less shop waiting</span>
              </div>
            </div>
          </div>

          <div className="bg-emerald-950/30 border border-emerald-900/50 p-3 rounded-lg text-center">
            <span className="text-[9px] text-emerald-400 font-black uppercase tracking-wider block mb-1">APEX Recommended Plan</span>
            <p className="text-[10.5px] text-slate-300 leading-relaxed">
              {lastCheckedMonths > 12 
                ? "Your vehicle's inspection cycle is heavily overdue. Schedule a Full Hyper-Calibration now to avert critical friction wear and restore power cell potential."
                : "Your scheduling cycle remains optimal. A Precision Tune-up will maintain high fuel/electron density efficiency."
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
