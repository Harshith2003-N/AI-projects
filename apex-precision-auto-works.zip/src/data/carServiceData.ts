import { ServiceType, Facility, FacilityStatus, AddOn, ShopReview } from '../types';

export const FACILITIES: Facility[] = [
  {
    id: 'lounge',
    name: 'Elite Customer Lounge',
    description: 'Relax in style. Features complimentary barista-made coffee, high-speed Wi-Fi, premium massage chairs, and live progress display monitors.',
    capacity: 12,
    currentOccupancy: 4,
    icon: 'Coffee',
    status: FacilityStatus.OPERATIONAL,
    bays: ['Lounge Area', 'Workspaces', 'Barista Counter']
  },
  {
    id: 'diagnostic',
    name: 'Advanced Diagnostics Lab',
    description: 'Equipped with computer OBD-II scan tools, battery/alternator analyzer rigs, and automatic 3D tire tread depth scanners.',
    capacity: 2,
    currentOccupancy: 1,
    icon: 'Cpu',
    status: FacilityStatus.OPERATIONAL,
    bays: ['Diagnostic Bay A', 'Diagnostic Bay B']
  },
  {
    id: 'service_lift_1',
    name: 'Under-Chassis Lifting Bay',
    description: 'Dual-post hydraulic lift specialized in rapid oil changes, transmission servicing, exhaust checks, and deep undercarriage repairs.',
    capacity: 2,
    currentOccupancy: 2,
    icon: 'Wrench',
    status: FacilityStatus.BUSY,
    bays: ['Hoist Lift 1', 'Hoist Lift 2']
  },
  {
    id: 'alignment_bay',
    name: 'Precision Laser Wheel Aligner',
    description: 'Features a high-precision 3D laser tracking rig to measure and adjust camber, caster, and toe to factory specs.',
    capacity: 1,
    currentOccupancy: 0,
    icon: 'Disc',
    status: FacilityStatus.OPERATIONAL,
    bays: ['Laser Alignment Rack']
  },
  {
    id: 'detailing_bay',
    name: 'Aqua-Jet Detailing & Wash Spa',
    description: 'Equipped with high-pressure snow foam cannons, dual-action orbit buffers, and dynamic under-body water sprays.',
    capacity: 2,
    currentOccupancy: 1,
    icon: 'Sparkles',
    status: FacilityStatus.OPERATIONAL,
    bays: ['Wash Station', 'Detailing Deck']
  },
  {
    id: 'parts_depot',
    name: 'Logistics & OEM Parts Hub',
    description: 'Stocks over 5,000 certified OEM parts, filters, premium synthetic lubricants, and high-performance brake pads.',
    capacity: 5,
    currentOccupancy: 1,
    icon: 'Layers',
    status: FacilityStatus.OPERATIONAL,
    bays: ['Parts Counter', 'Fluid Inventory']
  }
];

export const SERVICE_TYPES: ServiceType[] = [
  {
    id: 'basic_service',
    name: 'Basic Express Service',
    description: 'An essential maintenance check for high-performance or commuter vehicles. Keeps your engine running smoothly and validates warranty.',
    price: 149,
    durationMinutes: 45,
    facilitiesUsed: ['service_lift_1', 'parts_depot', 'lounge'],
    benefits: [
      'Full Synthetic Engine Oil Change (up to 5L)',
      'Premium OEM Oil Filter Replacement',
      '25-Point Comprehensive Safety Check',
      'Fluid Top-Ups (Coolant, Brake, Washer)',
      'Elite Lounge Access with Barista Coffee'
    ]
  },
  {
    id: 'major_service',
    name: 'Major Logbook Overhaul',
    description: 'Deep mechanical overhaul recommended every 24 months/30,000 km. Comprehensive assessment and replacement of essential system elements.',
    price: 349,
    durationMinutes: 120,
    facilitiesUsed: ['diagnostic', 'service_lift_1', 'parts_depot', 'lounge'],
    benefits: [
      'Everything in Basic Express Service',
      'Engine Air Filter & Cabin Pollen Filter Swap',
      'Full OBD-II ECU System Fault Code Scan & Reset',
      'Spark Plugs Wear Assessment & Torque Adjustment',
      'Brake Line Bleed, Rotor Measure & Pad Check',
      'Suspension, Ball Joints & CV Boot Inspection'
    ]
  },
  {
    id: 'brake_overhaul',
    name: 'Brake & Safety Restoration',
    description: 'Restores maximum stopping power and response. Ideal if brakes are squeaking, vibrating, or feeling soft.',
    price: 229,
    durationMinutes: 90,
    facilitiesUsed: ['service_lift_1', 'parts_depot'],
    benefits: [
      'Premium OEM Brake Pad Replacement (Front or Rear)',
      'Rotors Clean, Measure, or Machine Refinishing',
      'Brake Fluid Hydraulic Flush & System Bleed',
      'Caliper Inspection, Slide Pins Lubrication',
      'Post-Service Road Safety Stopping Test'
    ]
  },
  {
    id: 'wheel_alignment',
    name: '3D Laser Alignment & Balance',
    description: 'Perfect for cars experiencing steering pull or uneven tire wear. Enhances fuel economy and extends tire lifespan.',
    price: 99,
    durationMinutes: 45,
    facilitiesUsed: ['alignment_bay', 'lounge'],
    benefits: [
      '4-Wheel Digital 3D Laser Alignment Calibration',
      'Front & Rear Toe, Camber, and Caster Tuning',
      'High-Speed Dynamic Wheel Balancing',
      'Tire Pressure Calibration & Safety Check',
      'Detailed Pre/Post Alignment Printout Report'
    ]
  },
  {
    id: 'detailing_spa',
    name: 'Signature Detailing & Paint Spa',
    description: 'Restores showroom shine inside and out. Deep cleaning and protective layering for your car\'s upholstery and paint.',
    price: 129,
    durationMinutes: 60,
    facilitiesUsed: ['detailing_bay', 'lounge'],
    benefits: [
      'Hydrophobic Snow Foam Hand Wash & Decontamination',
      'Clay Bar treatment & Express Wax Paint Sealer',
      'Deep Cabin Vacuum, Dashboard & Door Card UV Polish',
      'Alloy Wheels Brake-Dust Clean & Tire Dressing',
      'Air Freshener Treatment & Interior Sanitization'
    ]
  }
];

export const ADD_ONS: AddOn[] = [
  {
    id: 'synthetic_oil_upgrade',
    name: 'Premium Ultra-Synthetic Oil Upgrade',
    description: 'Upgrade standard oil to ultra-glide synthetic formulation for better fuel mileage and thermal stability.',
    price: 35
  },
  {
    id: 'wiper_replacement',
    name: 'Aero-Flex Front Wiper Blade Set',
    description: 'All-weather streak-free hybrid wiper blades installed on both front windshield arms.',
    price: 25
  },
  {
    id: 'cabin_pollen_filter',
    name: 'Activated Carbon Cabin AC Filter',
    description: 'Heavy duty filter to remove exhaust fumes, mold spores, and allergens from entering cabin.',
    price: 35
  },
  {
    id: 'engine_flush',
    name: 'High-Performance Engine Internal Flush',
    description: 'Clears accumulated sludge and carbon buildup from engine passages before adding fresh oil.',
    price: 29
  },
  {
    id: 'tire_rotation',
    name: 'All-Tire Rotation & Tread Balancing',
    description: 'Ensures even wear patterns across all four tires to maximize tread lifecycle.',
    price: 20
  }
];

export const TECHNICIANS = [
  'Alex Carter (Master Diagnostic Specialist)',
  'Sarah Martinez (Senior EV & Powertrain Expert)',
  'David Chen (Precision Alignment & Chassis Technician)',
  'Elena Rostova (Fluid Systems & Maintenance Lead)',
  'Jordan Blake (Aesthetics & Paint Restoration Chief)'
];

export const REVIEWS: ShopReview[] = [
  {
    id: 'rev_1',
    customerName: 'Marcus Vance',
    carModel: 'Audi R8 V10',
    rating: 5,
    comment: 'The advanced OBD-II diagnosis pinpointed a vacuum leak that three other shops missed. I watched the live status while enjoying a premium latte in the lounge. Exemplary service!',
    date: '2026-06-25',
    serviceType: 'Major Logbook Overhaul'
  },
  {
    id: 'rev_2',
    customerName: 'Clara Jenkins',
    carModel: 'Tesla Model Y',
    rating: 5,
    comment: 'Booked the Detailing Spa. Hand wash was flawless, paint feels smooth as glass. I love that they have high-speed workspaces in the lounge so I did not lose any billable hours!',
    date: '2026-07-02',
    serviceType: 'Signature Detailing & Paint Spa'
  },
  {
    id: 'rev_3',
    customerName: 'Kenji Sato',
    carModel: 'Subaru WRX STI',
    rating: 5,
    comment: 'Got a 3D Laser Alignment after installing new coilovers. Camber is perfectly balanced now, steering pull is 100% gone. Highly technical team who knows what they are doing.',
    date: '2026-07-05',
    serviceType: '3D Laser Alignment & Balance'
  },
  {
    id: 'rev_4',
    customerName: 'Sophia Lin',
    carModel: 'Honda Civic',
    rating: 4,
    comment: 'Very professional. The mechanic diagnostic report on my dashboard showed my tire treads were down to 2.1mm. Easy online booking, quick turnaround, highly interactive interface.',
    date: '2026-07-06',
    serviceType: 'Basic Express Service'
  }
];

export const SHOP_OCCUPANCY_TREND = [
  { hour: '08:00', bookingsCount: 2, capacityLimit: 8 },
  { hour: '09:00', bookingsCount: 5, capacityLimit: 8 },
  { hour: '10:00', bookingsCount: 7, capacityLimit: 8 },
  { hour: '11:00', bookingsCount: 8, capacityLimit: 8 },
  { hour: '12:00', bookingsCount: 4, capacityLimit: 8 },
  { hour: '13:00', bookingsCount: 5, capacityLimit: 8 },
  { hour: '14:00', bookingsCount: 7, capacityLimit: 8 },
  { hour: '15:00', bookingsCount: 6, capacityLimit: 8 },
  { hour: '16:00', bookingsCount: 4, capacityLimit: 8 },
  { hour: '17:00', bookingsCount: 1, capacityLimit: 8 }
];

export const MOCK_POPULAR_CARS = [
  { make: 'Tesla', models: ['Model 3', 'Model Y', 'Model S', 'Model X'] },
  { make: 'Toyota', models: ['RAV4', 'Camry', 'Prius', 'Supra', 'Tacoma'] },
  { make: 'BMW', models: ['3 Series', '5 Series', 'M3', 'X5', 'i4'] },
  { make: 'Honda', models: ['Civic', 'Accord', 'CR-V', 'NSX'] },
  { make: 'Ford', models: ['Mustang', 'F-150', 'Explorer', 'Focus'] },
  { make: 'Audi', models: ['A4', 'Q5', 'S5', 'R8', 'e-tron'] }
];
