/**
 * Core Types for the Car Service Booking System
 */

export enum BookingStatus {
  AWAITING_ARRIVAL = "AWAITING_ARRIVAL",
  DIAGNOSING = "DIAGNOSING",
  IN_PROGRESS = "IN_PROGRESS",
  QUALITY_CHECK = "QUALITY_CHECK",
  READY_FOR_PICKUP = "READY_FOR_PICKUP",
  COMPLETED = "COMPLETED"
}

export enum FacilityStatus {
  OPERATIONAL = "OPERATIONAL",
  BUSY = "BUSY",
  MAINTENANCE = "MAINTENANCE"
}

export interface Car {
  id: string;
  make: string;
  model: string;
  year: number;
  mileage: number;
  fuelType: string;
}

export interface ServiceType {
  id: string;
  name: string;
  description: string;
  price: number;
  durationMinutes: number;
  facilitiesUsed: string[];
  benefits: string[];
}

export interface Facility {
  id: string;
  name: string;
  description: string;
  capacity: number;
  currentOccupancy: number;
  icon: string;
  status: FacilityStatus;
  bays: string[];
}

export interface DiagnosticReport {
  oilHealth: number; // 0 to 100%
  tireTreadDepthFront: number; // in mm, e.g. 1.6 to 8.0
  tireTreadDepthRear: number; // in mm
  brakePadWear: number; // 0 to 100%
  batteryVoltage: number; // in Volts, e.g. 11.5 to 14.2
  diagnosticSummary: string;
  recommendedRepairs: string[];
}

export interface Booking {
  id: string;
  car: Car;
  service: ServiceType;
  date: string;
  timeSlot: string;
  addOns: string[];
  notes?: string;
  totalPrice: number;
  status: BookingStatus;
  progressPercent: number;
  technician: string;
  currentStep: number;
  diagnosticReport: DiagnosticReport;
  additionalRecommendationApproved: boolean | null; // null = pending, true = approved, false = declined
}

export interface AddOn {
  id: string;
  name: string;
  description: string;
  price: number;
}

export interface ShopReview {
  id: string;
  customerName: string;
  carModel: string;
  rating: number;
  comment: string;
  date: string;
  serviceType: string;
}
