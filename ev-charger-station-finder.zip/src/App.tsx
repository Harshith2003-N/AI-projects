/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { APIProvider } from '@vis.gl/react-google-maps';
import { EVStation, EVConnectorType, FilterState } from './types';
import EVMap from './components/EVMap';
import Sidebar from './components/Sidebar';
import StationDetail from './components/StationDetail';
import Login from './components/Login';
import {
  getMockStationsForLocation,
  simulateRealTimeCheck,
  fallbackCityHubs,
  calculateDistance
} from './utils';
import { Activity, Map, List, RefreshCw } from 'lucide-react';

const API_KEY =
  (typeof process !== 'undefined' ? process.env?.GOOGLE_MAPS_PLATFORM_KEY : '') ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';

const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

export default function App() {
  const [isDemo, setIsDemo] = useState(!hasValidKey);
  const [currentCityName, setCurrentCityName] = useState<'Bengaluru' | 'Mumbai' | 'Delhi' | 'Hyderabad'>('Bengaluru');
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number }>(fallbackCityHubs['Bengaluru']);
  const [rawStations, setRawStations] = useState<EVStation[]>([]);
  const [selectedStation, setSelectedStation] = useState<EVStation | null>(null);
  const [mobileActiveTab, setMobileActiveTab] = useState<'map' | 'list'>('map');
  
  const [isVerifying, setIsVerifying] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [showRoute, setShowRoute] = useState(false);
  const [routeInfo, setRouteInfo] = useState<{ distance: string; duration: string } | null>(null);

  // User Authentication State
  const [loggedInUser, setLoggedInUser] = useState<string | null>(() => {
    return (typeof window !== 'undefined' ? localStorage.getItem('voltfinder_user_phone') : null) || null;
  });

  const handleLoginSuccess = useCallback((phone: string) => {
    localStorage.setItem('voltfinder_user_phone', phone);
    setLoggedInUser(phone);
  }, []);

  const handleLogout = useCallback(() => {
    localStorage.removeItem('voltfinder_user_phone');
    setLoggedInUser(null);
  }, []);

  // Filter criteria state
  const [filters, setFilters] = useState<FilterState>({
    connectorTypes: [],
    minPowerKw: 0,
    networks: [],
    status: [],
    searchQuery: ''
  });

  const [geolocationStatus, setGeolocationStatus] = useState<'idle' | 'detecting' | 'granted' | 'denied' | 'error'>('idle');
  const [geolocationErrorMsg, setGeolocationErrorMsg] = useState<string>('');

  const requestUserLocation = useCallback(() => {
    if (typeof window === 'undefined' || !navigator.geolocation) {
      setGeolocationStatus('error');
      setGeolocationErrorMsg('Geolocation is not supported by your browser.');
      return;
    }

    setGeolocationStatus('detecting');
    setGeolocationErrorMsg('');

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const loc = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        setUserLocation(loc);
        setGeolocationStatus('granted');
        setCurrentCityName('' as any); // Clear active preset city hub selection
        
        // Refresh stations surrounding this dynamic coordinate
        const initialStations = getMockStationsForLocation(loc.lat, loc.lng);
        setRawStations(initialStations);
      },
      (error) => {
        console.warn('Geolocation access failed:', error);
        setGeolocationStatus('denied');
        let errMsg = 'Location access denied or timed out.';
        if (error.code === error.PERMISSION_DENIED) {
          errMsg = 'Location permission was denied. Please verify your browser settings or click the lock icon next to the URL to grant permission, then retry.';
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          errMsg = 'Location information is unavailable on your device network.';
        } else if (error.code === error.TIMEOUT) {
          errMsg = 'Location request timed out. Please click "Detect Location" again.';
        }
        setGeolocationErrorMsg(errMsg);
        
        // Retain current station list centered on the fallback coordinate
        const initialStations = getMockStationsForLocation(userLocation.lat, userLocation.lng);
        setRawStations(initialStations);
      },
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 }
    );
  }, [userLocation]);

  // Request location automatically on mount
  useEffect(() => {
    requestUserLocation();
  }, []);

  // Update stations when shifting between global cities
  const handleSelectCityHub = useCallback((cityName: 'Bengaluru' | 'Mumbai' | 'Delhi' | 'Hyderabad') => {
    setCurrentCityName(cityName);
    setGeolocationStatus('idle');
    setGeolocationErrorMsg('');
    const coords = fallbackCityHubs[cityName];
    setUserLocation(coords);
    setSelectedStation(null);
    setShowRoute(false);
    setRouteInfo(null);
    
    // Refresh list centered on new city center
    const freshStations = getMockStationsForLocation(coords.lat, coords.lng);
    setRawStations(freshStations);
  }, []);

  // Live checking action for a selected station (simulated loading latency)
  const handleVerifyRealTime = useCallback(async (stationId: string) => {
    if (!selectedStation || isVerifying) return;
    setIsVerifying(true);

    try {
      const updated = await simulateRealTimeCheck(selectedStation);
      
      // Update global stations reference list
      setRawStations((prev) =>
        prev.map((s) => (s.id === stationId ? updated : s))
      );
      
      // Update selected station detailed view panel
      setSelectedStation(updated);
    } catch (err) {
      console.error('Error in verifying status:', err);
    } finally {
      setIsVerifying(false);
    }
  }, [selectedStation, isVerifying]);

  // Bulk scan nearby network chargers
  const handleRefreshAll = useCallback(async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);

    // Short simulated network ping
    setTimeout(() => {
      setRawStations((prev) =>
        prev.map((station) => {
          const updatedConnectors = station.connectors.map((c) => {
            const outOfService = Math.random() > 0.95 ? 1 : 0;
            const available = Math.max(0, c.count - outOfService - Math.floor(Math.random() * c.count));
            return { ...c, availableCount: available, outOfServiceCount: outOfService };
          });
          const totalAvailable = updatedConnectors.reduce((acc, c) => acc + c.availableCount, 0);
          const totalOutOfService = updatedConnectors.reduce((acc, c) => acc + c.outOfServiceCount, 0);
          
          let status: EVStation['status'] = 'Available';
          if (totalAvailable === 0) {
            status = totalOutOfService === station.connectorCount ? 'Offline' : 'Busy';
          }
          
          const now = new Date();
          const lastUpdated = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

          return {
            ...station,
            connectors: updatedConnectors,
            status,
            isRealTimeVerified: true,
            lastUpdated
          };
        })
      );
      setIsRefreshing(false);
    }, 1500);
  }, [isRefreshing]);

  // Handle click selects on list or map
  const handleSelectStation = useCallback((station: EVStation | null) => {
    setSelectedStation(station);
    setShowRoute(false);
    setRouteInfo(null);
    if (station) {
      setMobileActiveTab('map');
    }
  }, []);

  // Filter application pipeline
  const filteredStations = useMemo(() => {
    return rawStations.filter((station) => {
      // 1. Search text queries
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase();
        const matchesName = station.name.toLowerCase().includes(query);
        const matchesAddress = station.address.toLowerCase().includes(query);
        const matchesNetwork = station.network.toLowerCase().includes(query);
        if (!matchesName && !matchesAddress && !matchesNetwork) return false;
      }

      // 2. Connector type filter (must match at least one selected)
      if (filters.connectorTypes.length > 0) {
        const hasMatchingConnector = station.connectors.some((conn) =>
          filters.connectorTypes.includes(conn.type)
        );
        if (!hasMatchingConnector) return false;
      }

      // 3. Minimum power kW (at least one connector must equal or exceed)
      if (filters.minPowerKw > 0) {
        const hasHighPower = station.connectors.some(
          (conn) => conn.maxChargeRateKw >= filters.minPowerKw
        );
        if (!hasHighPower) return false;
      }

      // 4. Provider Networks
      if (filters.networks.length > 0) {
        if (!filters.networks.includes(station.network)) return false;
      }

      return true;
    }).sort((a, b) => {
      // Sort by distance (closest first)
      if (a.distanceKm === null) return 1;
      if (b.distanceKm === null) return -1;
      return a.distanceKm - b.distanceKm;
    });
  }, [rawStations, filters]);

  // APP WORKSPACE COMPONENT (DUAL GOOGLE MAP / OFFLINE VECTOR MODE)
  const appWorkspace = (
    <div className="h-screen w-screen flex flex-col md:flex-row overflow-hidden bg-slate-950 font-sans" id="voltfinder-app-root">
      {/* Sidebar List and Filters (only visible on mobile if 'list' active, always visible on desktop) */}
      <div className={`h-full ${mobileActiveTab === 'list' ? 'flex flex-col w-full' : 'hidden md:flex md:w-[420px] md:flex-shrink-0'}`}>
        <Sidebar
          stations={filteredStations}
          selectedStation={selectedStation}
          onSelectStation={handleSelectStation}
          filters={filters}
          onUpdateFilters={setFilters}
          currentCityName={currentCityName}
          onSelectCityHub={handleSelectCityHub}
          onRefreshAll={handleRefreshAll}
          isRefreshing={isRefreshing}
          loggedInUser={loggedInUser}
          onLogout={handleLogout}
          onLocateMe={requestUserLocation}
          geolocationStatus={geolocationStatus}
          geolocationErrorMsg={geolocationErrorMsg}
        />
      </div>

      {/* Main Map Stage (only visible on mobile if 'map' active, always visible on desktop) */}
      <div className={`flex-1 h-full relative overflow-hidden ${mobileActiveTab === 'map' ? 'block' : 'hidden md:block'}`} id="map-stage">
        <EVMap
          isDemo={isDemo}
          userLocation={userLocation}
          stations={filteredStations}
          selectedStation={selectedStation}
          onSelectStation={handleSelectStation}
          showRouteToStation={showRoute}
          onRouteLoaded={setRouteInfo}
        />

        {/* Selected Charger Detail Overlaid Sliding Drawer */}
        {selectedStation && (
          <StationDetail
            station={selectedStation}
            onClose={() => {
              setSelectedStation(null);
              setShowRoute(false);
              setRouteInfo(null);
            }}
            onVerifyRealTime={handleVerifyRealTime}
            isVerifying={isVerifying}
            onToggleRoute={() => setShowRoute(!showRoute)}
            showRoute={showRoute}
            routeInfo={routeInfo}
          />
        )}

        {/* Global Connection Quality Ribbon */}
        <div className="absolute top-4 right-4 pointer-events-auto flex items-center gap-2 px-3 py-1.5 bg-slate-900/90 backdrop-blur border border-slate-800 rounded-full shadow-2xl">
          <Activity className={`w-3.5 h-3.5 ${isDemo ? 'text-amber-400' : 'text-green-400 animate-pulse'}`} />
          <span className="text-[10px] font-bold font-mono tracking-wide text-slate-300">
            {isDemo ? 'OFFLINE SIMULATOR' : 'LIVE API SYNCED'}
          </span>
          {isDemo && hasValidKey && (
            <button
              onClick={() => setIsDemo(false)}
              className="text-[9px] bg-slate-800 hover:bg-slate-750 px-2 py-0.5 rounded border border-slate-700 text-white font-bold ml-1 transition"
            >
              Go Live
            </button>
          )}
        </div>
      </div>

      {/* Mobile Bottom Navigation Bar (only visible on mobile) */}
      <div className="md:hidden bg-slate-900/95 backdrop-blur-md border-t border-slate-800 h-16 flex items-center justify-around px-6 pb-safe z-30 shrink-0">
        <button
          onClick={() => setMobileActiveTab('map')}
          className={`flex flex-col items-center justify-center flex-1 h-full py-1 text-xs font-semibold gap-1 transition-all cursor-pointer ${
            mobileActiveTab === 'map' ? 'text-blue-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Map className="w-5 h-5" />
          <span>Map View</span>
        </button>
        
        <button
          onClick={handleRefreshAll}
          disabled={isRefreshing}
          className="flex flex-col items-center justify-center -mt-6 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-full w-14 h-14 shadow-lg shadow-blue-500/30 transition border-4 border-slate-950 active:scale-95 cursor-pointer disabled:opacity-50"
          title="Refresh All Stations"
        >
          <RefreshCw className={`w-5 h-5 ${isRefreshing ? 'animate-spin' : ''}`} />
        </button>

        <button
          onClick={() => setMobileActiveTab('list')}
          className={`flex flex-col items-center justify-center flex-1 h-full py-1 text-xs font-semibold gap-1 transition-all cursor-pointer ${
            mobileActiveTab === 'list' ? 'text-blue-400' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <List className="w-5 h-5" />
          <span>Stations ({filteredStations.length})</span>
        </button>
      </div>
    </div>
  );

  if (!loggedInUser) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  if (isDemo || !hasValidKey) {
    // Render the workspace directly in demo mode (with rich vector SVG city simulation)
    return appWorkspace;
  }

  // Wrap in API provider for live Google Maps rendering
  return (
    <APIProvider apiKey={API_KEY} version="weekly">
      {appWorkspace}
    </APIProvider>
  );
}
