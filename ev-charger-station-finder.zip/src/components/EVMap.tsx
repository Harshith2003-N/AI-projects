/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { Map, AdvancedMarker, Pin, useMap, useMapsLibrary } from '@vis.gl/react-google-maps';
import { EVStation } from '../types';
import { Compass, Plus, Minus } from 'lucide-react';

interface EVMapProps {
  isDemo: boolean;
  userLocation: { lat: number; lng: number };
  stations: EVStation[];
  selectedStation: EVStation | null;
  onSelectStation: (station: EVStation | null) => void;
  showRouteToStation: boolean;
  onRouteLoaded: (info: { distance: string; duration: string } | null) => void;
}

// Subcomponent to handle Google Maps Routing (using modern Route.computeRoutes as required by CF7 & CF13)
function RouteDisplay({
  origin,
  destination,
  onRouteLoaded
}: {
  origin: google.maps.LatLngLiteral;
  destination: google.maps.LatLngLiteral;
  onRouteLoaded: (info: { distance: string; duration: string } | null) => void;
}) {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<google.maps.Polyline[]>([]);

  useEffect(() => {
    if (!routesLib || !map || !origin || !destination) return;

    // Clear previous routes
    polylinesRef.current.forEach((p) => p.setMap(null));
    polylinesRef.current = [];

    routesLib.Route.computeRoutes({
      origin,
      destination,
      travelMode: 'DRIVING',
      fields: ['path', 'distanceMeters', 'durationMillis', 'viewport'],
    })
      .then(({ routes }) => {
        if (routes?.[0]) {
          const newPolylines = routes[0].createPolylines();
          newPolylines.forEach((polyline) => {
            // Style the polyline to look premium (neon blue)
            polyline.setOptions({
              strokeColor: '#3b82f6',
              strokeOpacity: 0.8,
              strokeWeight: 6,
            });
            polyline.setMap(map);
          });
          polylinesRef.current = newPolylines;

          // Format distance and duration for UI
          const distKm = ((routes[0].distanceMeters || 0) / 1000).toFixed(1);
          const durMins = Math.round((parseInt(String(routes[0].durationMillis || '0'), 10) || 0) / 60000);
          onRouteLoaded({
            distance: `${distKm} km`,
            duration: `${durMins} mins`
          });

          // Fit bounds to display the whole route nicely
          if (routes[0].viewport) {
            map.fitBounds(routes[0].viewport);
          }
        }
      })
      .catch((err) => {
        console.error('Error computing routes:', err);
        onRouteLoaded(null);
      });

    return () => {
      polylinesRef.current.forEach((p) => p.setMap(null));
      polylinesRef.current = [];
    };
  }, [routesLib, map, origin, destination]);

  return null;
}

// Color theme mapping based on station availability
function getStatusColors(status: EVStation['status']): { bg: string; border: string; glyph: string } {
  switch (status) {
    case 'Available':
      return { bg: '#22c55e', border: '#15803d', glyph: '#ffffff' }; // Green
    case 'Busy':
      return { bg: '#eab308', border: '#a16207', glyph: '#ffffff' }; // Orange
    case 'Offline':
    default:
      return { bg: '#64748b', border: '#475569', glyph: '#ffffff' }; // Slate
  }
}

// Subcomponent for Google Map (safe to use useMap / @vis.gl/react-google-maps hooks inside this wrapper)
function LiveGoogleMap({
  userLocation,
  stations,
  selectedStation,
  onSelectStation,
  showRouteToStation,
  onRouteLoaded
}: Omit<EVMapProps, 'isDemo'>) {
  const mapInstance = useMap();

  // Handle zooming / panning to selected station on google map
  useEffect(() => {
    if (mapInstance && selectedStation && !showRouteToStation) {
      mapInstance.panTo({ lat: selectedStation.lat, lng: selectedStation.lng });
      mapInstance.setZoom(15);
    }
  }, [selectedStation, mapInstance, showRouteToStation]);

  // Handle panning back to user location
  const handleRecenter = () => {
    if (mapInstance) {
      mapInstance.panTo(userLocation);
      mapInstance.setZoom(14);
    }
  };

  return (
    <div className="w-full h-full relative" id="live-google-map-container">
      <Map
        defaultCenter={userLocation}
        defaultZoom={14}
        mapId="DEMO_MAP_ID"
        gestureHandling="cooperative"
        disableDefaultUI={false}
        zoomControl={true}
        mapTypeControl={false}
        streetViewControl={false}
        fullscreenControl={false}
        internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        style={{ width: '100%', height: '100%' }}
      >
        {/* User Location Pulsing Dot */}
        <AdvancedMarker position={userLocation} title="You are here">
          <div className="relative flex items-center justify-center w-6 h-6">
            <span className="absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75 animate-ping"></span>
            <span className="relative rounded-full h-4 w-4 bg-blue-600 border-2 border-white shadow-md"></span>
          </div>
        </AdvancedMarker>

        {/* EV Charger Markers */}
        {stations.map((station) => {
          const colors = getStatusColors(station.status);
          const isSelected = selectedStation?.id === station.id;
          return (
            <AdvancedMarker
              key={station.id}
              position={{ lat: station.lat, lng: station.lng }}
              title={station.name}
              onClick={() => onSelectStation(station)}
            >
              <div className={`transition-transform duration-200 ${isSelected ? 'scale-125 z-50' : 'hover:scale-110'}`}>
                <Pin
                  background={colors.bg}
                  borderColor={colors.border}
                  glyphColor={colors.glyph}
                  scale={isSelected ? 1.2 : 1.0}
                >
                  <div className="flex items-center justify-center text-[10px] font-bold text-white leading-none">
                    ⚡
                  </div>
                </Pin>
              </div>
            </AdvancedMarker>
          );
        })}

        {/* Render polyline route if selected and directions requested */}
        {showRouteToStation && selectedStation && (
          <RouteDisplay
            origin={userLocation}
            destination={{ lat: selectedStation.lat, lng: selectedStation.lng }}
            onRouteLoaded={onRouteLoaded}
          />
        )}
      </Map>

      {/* Floating controls */}
      <div className="absolute bottom-6 right-6 flex flex-col gap-2 z-10">
        <button
          onClick={handleRecenter}
          id="recenter-btn"
          className="flex items-center justify-center w-12 h-12 rounded-full bg-white text-gray-800 shadow-xl border border-gray-100 hover:bg-gray-50 hover:text-blue-600 transition active:scale-95"
          title="Recenter to My Location"
        >
          <Compass className="w-6 h-6 animate-spin-slow" />
        </button>
      </div>
    </div>
  );
}

// Subcomponent for simulated SVG offline Map (completely safe from useMap requirements)
function SvgSimulatedMap({
  userLocation,
  stations,
  selectedStation,
  onSelectStation,
  showRouteToStation,
  onRouteLoaded
}: Omit<EVMapProps, 'isDemo'>) {
  // --- INTERACTIVE SVG VECTOR MAP (For Demo / Sandbox mode) ---
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  const [zoomScale, setZoomScale] = useState(1);

  const containerRef = useRef<HTMLDivElement>(null);

  // Convert coordinate degrees into pixel offsets on our 1000x1000 SVG canvas
  const getSvgCoordinates = (lat: number, lng: number) => {
    const dLat = lat - userLocation.lat;
    const dLng = lng - userLocation.lng;

    // Scale factor to make cluster look comfortable
    const centerX = 500;
    const centerY = 500;

    // Lat/lng translation to pixels (lng is X, lat is Y flipped)
    const x = centerX + dLng * 40000;
    const y = centerY - dLat * 40000;

    return { x, y };
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPanOffset({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent) => {
    setZoomScale((prev) => {
      const delta = e.deltaY < 0 ? 0.1 : -0.1;
      const next = prev + delta;
      return Math.max(0.5, Math.min(3, next));
    });
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      const touch = e.touches[0];
      setDragStart({ x: touch.clientX - panOffset.x, y: touch.clientY - panOffset.y });
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (isDragging && e.touches.length === 1) {
      const touch = e.touches[0];
      setPanOffset({
        x: touch.clientX - dragStart.x,
        y: touch.clientY - dragStart.y
      });
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  const handleZoom = (direction: 'in' | 'out') => {
    setZoomScale((prev) => {
      const step = 0.2;
      const next = direction === 'in' ? prev + step : prev - step;
      return Math.max(0.5, Math.min(3, next));
    });
  };

  const handleRecenter = () => {
    setPanOffset({ x: 0, y: 0 });
    setZoomScale(1);
  };

  // If directions are requested in SVG demo mode, calculate and display route simulation
  useEffect(() => {
    if (selectedStation && showRouteToStation) {
      const dist = selectedStation.distanceKm
        ? `${selectedStation.distanceKm} km`
        : '1.2 km';
      const mins = selectedStation.distanceKm
        ? `${Math.round(selectedStation.distanceKm * 2.5 + 2)} mins`
        : '5 mins';
      onRouteLoaded({ distance: dist, duration: mins });
    } else if (!selectedStation) {
      onRouteLoaded(null);
    }
  }, [selectedStation, showRouteToStation, onRouteLoaded]);

  const userSvgPos = getSvgCoordinates(userLocation.lat, userLocation.lng);
  const selectedSvgPos = selectedStation ? getSvgCoordinates(selectedStation.lat, selectedStation.lng) : null;

  return (
    <div
      ref={containerRef}
      className="w-full h-full relative overflow-hidden bg-slate-950 select-none cursor-grab active:cursor-grabbing"
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onWheel={handleWheel}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      id="svg-demo-map-container"
    >
      {/* Dynamic grid backdrop representing city coordinate space */}
      <svg
        className="w-full h-full absolute inset-0 transition-transform duration-75 pointer-events-none"
        style={{
          transform: `translate(${panOffset.x}px, ${panOffset.y}px) scale(${zoomScale})`,
          transformOrigin: 'center center'
        }}
      >
        <defs>
          <pattern id="city-grid" width="100" height="100" patternUnits="userSpaceOnUse">
            <path d="M 100 0 L 0 0 0 100" fill="none" stroke="rgba(30, 41, 59, 0.5)" strokeWidth="1" />
          </pattern>
        </defs>

        {/* Dark City Layout Background */}
        <rect width="2000" height="2000" x="-500" y="-500" fill="#030712" />
        <rect width="2000" height="2000" x="-500" y="-500" fill="url(#city-grid)" />

        {/* Scenic Features: Water Body (Blue Shoreline / Bay representation) */}
        <path
          d="M -300 -300 Q 200 -100 100 1200 T 1500 1500 L 1500 -300 Z"
          fill="#0c1d36"
          opacity="0.8"
        />

        {/* Large City Park (Green area representation) */}
        <rect x="250" y="200" width="180" height="300" rx="20" fill="#062f1e" opacity="0.6" />
        <text x="340" y="350" fill="#10b981" fontSize="14" opacity="0.4" fontFamily="monospace" textAnchor="middle">
          GREENFIELD PARK
        </text>

        {/* Waterfront Marina district */}
        <rect x="-100" y="600" width="150" height="200" rx="10" fill="#0f172a" stroke="rgba(51, 65, 85, 0.4)" strokeWidth="2" />
        <text x="-25" y="700" fill="#64748b" fontSize="12" opacity="0.4" fontFamily="monospace" textAnchor="middle">
          BAY MARINA
        </text>

        {/* Grid-based Streets & Highways */}
        {/* Main Highway running north-south */}
        <line x1="150" y1="-500" x2="150" y2="1500" stroke="#1e293b" strokeWidth="24" opacity="0.7" />
        <line x1="150" y1="-500" x2="150" y2="1500" stroke="#334155" strokeWidth="2" strokeDasharray="8,8" />

        {/* Diagonal Freeway */}
        <path d="M -500 1000 L 1500 -200" stroke="#1e293b" strokeWidth="18" opacity="0.6" />
        <path d="M -500 1000 L 1500 -200" stroke="#475569" strokeWidth="1" strokeDasharray="12,12" />

        {/* Major city blocks grid streets */}
        <line x1="-500" y1="400" x2="1500" y2="400" stroke="#111827" strokeWidth="12" />
        <line x1="-500" y1="800" x2="1500" y2="800" stroke="#111827" strokeWidth="12" />
        <line x1="500" y1="-500" x2="500" y2="1500" stroke="#111827" strokeWidth="12" />
        <line x1="850" y1="-500" x2="850" y2="1500" stroke="#111827" strokeWidth="12" />

        {/* Route visualization path if active */}
        {showRouteToStation && selectedSvgPos && (
          <g>
            {/* Pulsing route line */}
            <path
              d={`M ${userSvgPos.x} ${userSvgPos.y} Q ${(userSvgPos.x + selectedSvgPos.x) / 2} ${userSvgPos.y - 40} ${selectedSvgPos.x} ${selectedSvgPos.y}`}
              fill="none"
              stroke="#3b82f6"
              strokeWidth="6"
              strokeLinecap="round"
              className="animate-pulse"
              opacity="0.8"
            />
            {/* Overlay moving particles representing electricity flows */}
            <path
              d={`M ${userSvgPos.x} ${userSvgPos.y} Q ${(userSvgPos.x + selectedSvgPos.x) / 2} ${userSvgPos.y - 40} ${selectedSvgPos.x} ${selectedSvgPos.y}`}
              fill="none"
              stroke="#60a5fa"
              strokeWidth="2"
              strokeLinecap="round"
              strokeDasharray="10, 40"
              style={{
                animation: 'dash 1.5s linear infinite'
              }}
            />
          </g>
        )}

        {/* User Location Pulsing Dot on SVG Map */}
        <g transform={`translate(${userSvgPos.x}, ${userSvgPos.y})`}>
          <circle r="22" fill="#2563eb" opacity="0.15" className="animate-ping" />
          <circle r="12" fill="#3b82f6" opacity="0.3" className="animate-pulse" />
          <circle r="6" fill="#60a5fa" stroke="#ffffff" strokeWidth="2" />
        </g>

        {/* EV Charger Pins */}
        {stations.map((station) => {
          const pos = getSvgCoordinates(station.lat, station.lng);
          const isSelected = selectedStation?.id === station.id;

          let markerColor = '#22c55e'; // Green
          if (station.status === 'Busy') markerColor = '#eab308'; // Orange
          if (station.status === 'Offline') markerColor = '#64748b'; // Slate

          return (
            <g
              key={station.id}
              transform={`translate(${pos.x}, ${pos.y})`}
              className="cursor-pointer group pointer-events-auto"
              onClick={(e) => {
                e.stopPropagation();
                onSelectStation(station);
              }}
            >
              {/* Highlight background circle on selection/hover */}
              <circle
                r="24"
                fill={markerColor}
                opacity={isSelected ? 0.25 : 0}
                className="transition-all duration-300 group-hover:opacity-15"
              />

              {/* Advanced pin pin-head shape */}
              <g transform="translate(-16, -34)">
                <path
                  d="M16,0 C7.16,0 0,7.16 0,16 C0,27.35 14.18,39.11 15.12,39.87 C15.64,40.29 16.36,40.29 16.88,39.87 C17.82,39.11 32,27.35 32,16 C32,7.16 24.84,0 16,0 Z"
                  fill={markerColor}
                  stroke="#ffffff"
                  strokeWidth="1.5"
                  className="filter drop-shadow-md transition-all duration-300"
                />
                <text x="16" y="22" fill="#ffffff" fontSize="12" fontWeight="bold" textAnchor="middle">
                  ⚡
                </text>
              </g>

              {/* Floating label if selected */}
              {isSelected && (
                <g transform="translate(0, -48)">
                  <rect
                    x="-80"
                    y="-30"
                    width="160"
                    height="26"
                    rx="6"
                    fill="#1e293b"
                    stroke="#475569"
                    strokeWidth="1"
                    className="filter drop-shadow-lg"
                  />
                  <text
                    x="0"
                    y="-13"
                    fill="#f8fafc"
                    fontSize="10"
                    fontWeight="bold"
                    textAnchor="middle"
                    className="truncate max-w-[140px]"
                    fontFamily="sans-serif"
                  >
                    {station.name.length > 20 ? `${station.name.substring(0, 18)}...` : station.name}
                  </text>
                  <polygon points="0,0 -5,-4 5,-4" fill="#1e293b" />
                </g>
              )}
            </g>
          );
        })}
      </svg>

      {/* Styled Neon CSS Animation style tags for vector path flows */}
      <style>{`
        @keyframes dash {
          to {
            stroke-dashoffset: -50;
          }
        }
        .animate-spin-slow {
          animation: spin 8s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>

      {/* Map UI overlays */}
      <div className="absolute top-4 left-4 p-3 bg-slate-900/90 backdrop-blur border border-slate-800 rounded-xl max-w-sm pointer-events-none shadow-2xl">
        <div className="flex items-center gap-2 text-xs font-semibold text-blue-400 font-mono mb-1">
          <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
          OFFLINE SANDBOX MODE
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          Panned around mock city hub. Drag to explore, pinch or scroll to zoom. Real-time availability simulation active.
        </p>
      </div>

      <div className="absolute bottom-6 right-6 flex flex-col gap-2 z-10">
        <button
          onClick={() => handleZoom('in')}
          className="flex items-center justify-center w-10 h-10 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 shadow-xl hover:bg-slate-800 hover:text-white transition active:scale-95"
          title="Zoom In"
        >
          <Plus className="w-5 h-5" />
        </button>
        <button
          onClick={() => handleZoom('out')}
          className="flex items-center justify-center w-10 h-10 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 shadow-xl hover:bg-slate-800 hover:text-white transition active:scale-95"
          title="Zoom Out"
        >
          <Minus className="w-5 h-5" />
        </button>
        <button
          onClick={handleRecenter}
          className="flex items-center justify-center w-10 h-10 rounded-lg bg-blue-600 text-white shadow-xl hover:bg-blue-500 transition active:scale-95"
          title="Recenter"
        >
          <Compass className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}

export default function EVMap(props: EVMapProps) {
  const API_KEY =
    (typeof process !== 'undefined' ? process.env?.GOOGLE_MAPS_PLATFORM_KEY : '') ||
    (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
    (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
    '';

  const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

  if (!props.isDemo && hasValidKey) {
    return (
      <LiveGoogleMap
        userLocation={props.userLocation}
        stations={props.stations}
        selectedStation={props.selectedStation}
        onSelectStation={props.onSelectStation}
        showRouteToStation={props.showRouteToStation}
        onRouteLoaded={props.onRouteLoaded}
      />
    );
  }

  return (
    <SvgSimulatedMap
      userLocation={props.userLocation}
      stations={props.stations}
      selectedStation={props.selectedStation}
      onSelectStation={props.onSelectStation}
      showRouteToStation={props.showRouteToStation}
      onRouteLoaded={props.onRouteLoaded}
    />
  );
}
