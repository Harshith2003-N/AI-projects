import React, { useState, useEffect, useRef } from 'react';
import { Phone, Lock, ArrowRight, ShieldCheck, RefreshCw, ChevronLeft, CheckCircle, Zap } from 'lucide-react';

interface LoginProps {
  onLoginSuccess: (phoneNumber: string) => void;
}

const COUNTRY_CODES = [
  { code: '+91', country: 'India', flag: '🇮🇳' },
  { code: '+1', country: 'USA/Canada', flag: '🇺🇸' },
  { code: '+44', country: 'UK', flag: '🇬🇧' },
  { code: '+971', country: 'UAE', flag: '🇦🇪' },
  { code: '+65', country: 'Singapore', flag: '🇸🇬' },
];

export default function Login({ onLoginSuccess }: LoginProps) {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [countryCode, setCountryCode] = useState('+91');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  
  // OTP simulation states
  const [otpValues, setOtpValues] = useState<string[]>(['', '', '', '']);
  const [generatedOtp, setGeneratedOtp] = useState<string>('');
  const [isSubmittingPhone, setIsSubmittingPhone] = useState(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [countdown, setCountdown] = useState(45);
  const [otpError, setOtpError] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [showNotification, setShowNotification] = useState(false);
  const [isSuccessState, setIsSuccessState] = useState(false);

  const otpRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  // OTP Countdown timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (step === 'otp' && countdown > 0) {
      timer = setInterval(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [step, countdown]);

  // Generate a random 4 digit OTP code
  const triggerOtpGeneration = () => {
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(code);
    setShowNotification(true);
    // Auto hide simulated notification after 8 seconds
    setTimeout(() => {
      setShowNotification(false);
    }, 8000);
  };

  // Handle phone submission
  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneError('');

    // Clean up phone number to check length
    const cleanNum = phoneNumber.replace(/\D/g, '');
    if (cleanNum.length !== 10) {
      setPhoneError('Please enter a valid 10-digit mobile number');
      return;
    }

    setIsSubmittingPhone(true);

    // Simulate short server lag
    setTimeout(() => {
      setIsSubmittingPhone(false);
      setStep('otp');
      setCountdown(45);
      setOtpValues(['', '', '', '']);
      setOtpError('');
      triggerOtpGeneration();
    }, 1200);
  };

  // Handle OTP digit entry
  const handleOtpChange = (index: number, value: string) => {
    const cleanVal = value.replace(/\D/g, '').slice(-1);
    const newOtpValues = [...otpValues];
    newOtpValues[index] = cleanVal;
    setOtpValues(newOtpValues);
    setOtpError('');

    // Shift focus to next input if filled
    if (cleanVal && index < 3) {
      otpRefs[index + 1].current?.focus();
    }
  };

  // Handle backspace navigation in OTP fields
  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otpValues[index] && index > 0) {
      otpRefs[index - 1].current?.focus();
    }
  };

  // Resend code handler
  const handleResendOtp = () => {
    if (countdown > 0) return;
    setCountdown(45);
    setOtpValues(['', '', '', '']);
    setOtpError('');
    triggerOtpGeneration();
  };

  // Handle OTP verification
  const handleVerifyOtp = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setOtpError('');

    const typedOtp = otpValues.join('');
    if (typedOtp.length < 4) {
      setOtpError('Please fill in all 4 digits');
      return;
    }

    setIsVerifyingOtp(true);

    setTimeout(() => {
      if (typedOtp === generatedOtp || typedOtp === '1234') {
        setIsVerifyingOtp(false);
        setIsSuccessState(true);
        // Delightful delay for transition
        setTimeout(() => {
          onLoginSuccess(`${countryCode} ${phoneNumber}`);
        }, 1200);
      } else {
        setIsVerifyingOtp(false);
        setOtpError('Invalid verification code. Please try again.');
        // Highlight inputs with error shake
        setOtpValues(['', '', '', '']);
        otpRefs[0].current?.focus();
      }
    }, 1500);
  };

  // Automatically trigger verify when last digit is entered
  useEffect(() => {
    if (otpValues.join('').length === 4) {
      handleVerifyOtp();
    }
  }, [otpValues]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-center items-center p-6 relative overflow-hidden font-sans">
      {/* Decorative ambient background glows */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-green-500/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Brand logo at top */}
      <div className="mb-8 flex flex-col items-center gap-2 select-none z-10 animate-fadeIn">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-green-500 to-emerald-400 p-[1px] shadow-lg shadow-green-500/10">
          <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center text-green-400">
            <Zap className="w-6 h-6 fill-current animate-pulse" />
          </div>
        </div>
        <h2 className="text-xl font-bold tracking-tight text-white mt-1">VoltFinder</h2>
        <p className="text-xs text-slate-400">EV Smart Charging Network</p>
      </div>

      {/* Main Login Card */}
      <div className="w-full max-w-[420px] bg-slate-900/80 backdrop-blur-md border border-slate-800 rounded-3xl p-8 relative shadow-2xl z-10 flex flex-col transition-all duration-300">
        
        {/* SUCCESS STATE */}
        {isSuccessState ? (
          <div className="flex flex-col items-center justify-center py-8 text-center animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-green-500/10 border border-green-500/20 flex items-center justify-center text-green-400 mb-6 shadow-lg shadow-green-500/10 animate-bounce">
              <CheckCircle className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Login Verified!</h3>
            <p className="text-sm text-slate-400 max-w-xs">
              Welcome back to VoltFinder. Setting up your live charging dashboard...
            </p>
            
            <div className="mt-8 flex items-center gap-2 text-xs font-mono text-slate-500">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-green-400" />
              <span>Initializing secure session</span>
            </div>
          </div>
        ) : (
          <>
            {/* STEP 1: ENTER PHONE NUMBER */}
            {step === 'phone' && (
              <div className="space-y-6 animate-fadeIn">
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-white">Let's Get Started</h3>
                  <p className="text-sm text-slate-400">
                    Sign in or create an account with your mobile number to view real-time station slot booking and routes.
                  </p>
                </div>

                <form onSubmit={handlePhoneSubmit} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
                      Mobile Number
                    </label>
                    <div className="flex gap-2">
                      {/* Country Code Select */}
                      <div className="relative">
                        <select
                          value={countryCode}
                          onChange={(e) => setCountryCode(e.target.value)}
                          className="appearance-none bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-200 text-sm font-semibold rounded-2xl px-3.5 py-3 pr-8 focus:outline-none focus:ring-2 focus:ring-blue-500/40 transition cursor-pointer h-full"
                        >
                          {COUNTRY_CODES.map((c) => (
                            <option key={c.code} value={c.code}>
                              {c.flag} {c.code}
                            </option>
                          ))}
                        </select>
                        <div className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-slate-400 text-xs">
                          ▼
                        </div>
                      </div>

                      {/* Phone Input Box */}
                      <div className="relative flex-1">
                        <span className="absolute inset-y-0 left-4 flex items-center text-slate-500 pointer-events-none">
                          <Phone className="w-4 h-4" />
                        </span>
                        <input
                          type="tel"
                          required
                          maxLength={10}
                          placeholder="10-digit mobile number"
                          value={phoneNumber}
                          onChange={(e) => {
                            setPhoneNumber(e.target.value.replace(/\D/g, '').slice(0, 10));
                            setPhoneError('');
                          }}
                          className="w-full bg-slate-950 border border-slate-800 hover:border-slate-700 focus:border-blue-500 text-slate-100 text-sm rounded-2xl pl-11 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/40 transition font-mono font-medium tracking-wide h-full"
                        />
                      </div>
                    </div>
                    {phoneError && (
                      <p className="text-xs text-rose-500 font-medium mt-1 pl-1 flex items-center gap-1">
                        <span>⚠️</span> {phoneError}
                      </p>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmittingPhone || !phoneNumber}
                    className="w-full py-3.5 px-5 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white font-bold rounded-2xl text-sm transition hover:scale-[1.01] active:scale-95 disabled:opacity-50 disabled:scale-100 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-green-500/10 cursor-pointer mt-2"
                  >
                    {isSubmittingPhone ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Sending Verification Code...</span>
                      </>
                    ) : (
                      <>
                        <span>Get Verification OTP</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>

                <div className="pt-2 text-center">
                  <button
                    onClick={() => onLoginSuccess('Guest User')}
                    className="text-xs font-semibold text-slate-400 hover:text-blue-400 transition underline underline-offset-4 cursor-pointer"
                  >
                    Explore app as a Guest
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2: ENTER OTP */}
            {step === 'otp' && (
              <div className="space-y-6 animate-fadeIn">
                <div className="space-y-2">
                  <button
                    onClick={() => setStep('phone')}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-slate-400 hover:text-white transition -ml-1"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" /> Back to Phone
                  </button>
                  <h3 className="text-xl font-bold text-white mt-2">Enter Verification Code</h3>
                  <p className="text-sm text-slate-400">
                    We've sent a 4-digit verification code to <span className="font-mono font-bold text-slate-200">{countryCode} {phoneNumber}</span>
                  </p>
                </div>

                <form onSubmit={(e) => { e.preventDefault(); handleVerifyOtp(); }} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono block text-center">
                      4-Digit OTP Code
                    </label>
                    <div className="flex justify-center gap-3.5 py-1">
                      {otpValues.map((val, idx) => (
                        <input
                          key={idx}
                          ref={otpRefs[idx]}
                          type="text"
                          pattern="[0-9]*"
                          inputMode="numeric"
                          maxLength={1}
                          required
                          value={val}
                          onChange={(e) => handleOtpChange(idx, e.target.value)}
                          onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                          className="w-14 h-14 bg-slate-950 border border-slate-800 hover:border-slate-700 focus:border-green-500 text-center text-xl font-bold font-mono text-slate-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-green-500/40 transition"
                        />
                      ))}
                    </div>
                    {otpError && (
                      <p className="text-xs text-rose-500 font-medium text-center mt-1 flex items-center justify-center gap-1">
                        <span>⚠️</span> {otpError}
                      </p>
                    )}
                  </div>

                  <div className="space-y-3">
                    <button
                      type="submit"
                      disabled={isVerifyingOtp || otpValues.join('').length < 4}
                      className="w-full py-3.5 px-5 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white font-bold rounded-2xl text-sm transition hover:scale-[1.01] active:scale-95 disabled:opacity-50 disabled:scale-100 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-green-500/10 cursor-pointer"
                    >
                      {isVerifyingOtp ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Verifying Passcode...</span>
                        </>
                      ) : (
                        <>
                          <ShieldCheck className="w-4 h-4 text-green-300" />
                          <span>Verify & Sign In</span>
                        </>
                      )}
                    </button>

                    <div className="text-center">
                      {countdown > 0 ? (
                        <p className="text-xs text-slate-550 font-medium font-mono">
                          Resend code in <span className="text-slate-300 font-bold">{countdown}s</span>
                        </p>
                      ) : (
                        <button
                          type="button"
                          onClick={handleResendOtp}
                          className="inline-flex items-center gap-1 text-xs font-semibold text-green-400 hover:text-green-300 transition cursor-pointer hover:underline"
                        >
                          <RefreshCw className="w-3 h-3" /> Resend verification code
                        </button>
                      )}
                    </div>
                  </div>
                </form>
              </div>
            )}
          </>
        )}
      </div>

      {/* Simulated SMS Toast / Notification */}
      {showNotification && generatedOtp && (
        <div className="fixed bottom-6 right-6 max-w-[340px] bg-slate-900 border border-green-500/30 rounded-2xl p-4 shadow-2xl z-50 animate-slideIn flex gap-3 items-start">
          <div className="p-2 bg-green-500/10 text-green-400 rounded-xl border border-green-500/20">
            <Phone className="w-5 h-5" />
          </div>
          <div className="flex-1 text-left">
            <div className="flex justify-between items-center mb-0.5">
              <span className="text-[10px] font-bold text-green-400 font-mono uppercase tracking-wider">SMS Simulator</span>
              <span className="text-[9px] text-slate-500 font-mono">Just now</span>
            </div>
            <p className="text-xs font-medium text-slate-200 leading-relaxed">
              Your VoltFinder verification code is <strong className="text-green-400 font-mono text-sm bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800 ml-1">{generatedOtp}</strong>
            </p>
            <p className="text-[9px] text-slate-400 mt-1 leading-snug">
              Note: You can also use code <code className="text-slate-300 bg-slate-950 px-1 rounded">1234</code> to log in instantly.
            </p>
          </div>
        </div>
      )}

      {/* Security note footer */}
      <div className="mt-8 text-center text-[11px] text-slate-600 max-w-xs leading-relaxed z-10">
        By continuing, you agree to secure SMS authentication. Standard message rates do not apply as this is a secure client-side sandbox environment.
      </div>
    </div>
  );
}
