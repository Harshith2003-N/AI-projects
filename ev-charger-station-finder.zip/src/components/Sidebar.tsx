/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { EVStation, EVConnectorType, FilterState } from '../types';
import { Search, Filter, RefreshCw, Star, MapPin, Zap, Power, Layers, User, LogOut } from 'lucide-react';
import { fallbackCityHubs } from '../utils';

interface SidebarProps {
  stations: EVStation[];
  selectedStation: EVStation | null;
  onSelectStation: (station: EVStation | null) => void;
  filters: FilterState;
  onUpdateFilters: (filters: FilterState) => void;
  currentCityName: string;
  onSelectCityHub: (cityName: 'Bengaluru' | 'Mumbai' | 'Delhi' | 'Hyderabad') => void;
  onRefreshAll: () => void;
  isRefreshing: boolean;
  loggedInUser?: string | null;
  onLogout?: () => void;
  onLocateMe?: () => void;
  geolocationStatus?: 'idle' | 'detecting' | 'granted' | 'denied' | 'error';
  geolocationErrorMsg?: string;
}

export default function Sidebar({
  stations,
  selectedStation,
  onSelectStation,
  filters,
  onUpdateFilters,
  currentCityName,
  onSelectCityHub,
  onRefreshAll,
  isRefreshing,
  loggedInUser,
  onLogout,
  onLocateMe,
  geolocationStatus = 'idle',
  geolocationErrorMsg = ''
}: SidebarProps) {
  const [showFilters, setShowFilters] = useState(false);

  // Handle toggling of connector type filters
  const handleToggleConnector = (type: EVConnectorType) => {
    const isAlreadyFiltered = filters.connectorTypes.includes(type);
    const updated = isAlreadyFiltered
      ? filters.connectorTypes.filter((t) => t !== type)
      : [...filters.connectorTypes, type];
    onUpdateFilters({ ...filters, connectorTypes: updated });
  };

  // Handle toggling of EV charging networks
  const handleToggleNetwork = (network: string) => {
    const isAlreadyFiltered = filters.networks.includes(network);
    const updated = isAlreadyFiltered
      ? filters.networks.filter((n) => n !== network)
      : [...filters.networks, network];
    onUpdateFilters({ ...filters, networks: updated });
  };

  // List of networks to display in filter panel
  const allAvailableNetworks = ['Tata Power', 'Zeon Charging', 'Jio-bp pulse', 'Fortum Charge', 'Ather Grid', 'Bolt.earth', 'Independent'];

  return (
    <div className="w-full md:w-[420px] bg-slate-900 border-r border-slate-800 flex flex-col h-full text-slate-100 shadow-2xl" id="sidebar-panel">
      {/* App Header */}
      <div className="p-5 border-b border-slate-800 bg-slate-950/40">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-green-500/10 border border-green-500/20 flex items-center justify-center text-green-400">
              <Zap className="w-5 h-5 fill-current animate-pulse" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-white leading-tight">VoltFinder</h1>
              <p className="text-xs text-slate-400">EV Station Network</p>
            </div>
          </div>

          <button
            onClick={onRefreshAll}
            disabled={isRefreshing}
            id="refresh-all-btn"
            className="p-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-300 hover:text-white rounded-lg border border-slate-700 transition active:scale-95 cursor-pointer"
            title="Scan for live availability nearby"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-green-400' : ''}`} />
          </button>
        </div>

        {/* User Profile Info Row */}
        {loggedInUser && (
          <div className="mb-4 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-2.5 flex items-center justify-between shadow-inner" id="user-profile-badge">
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <div className="w-8 h-8 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
                  <User className="w-4 h-4" />
                </div>
                <span className="absolute bottom-0 right-0 block h-2 w-2 rounded-full bg-green-400 ring-2 ring-slate-900 animate-pulse" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] uppercase font-bold tracking-wider text-slate-500 font-mono">Signed In As</p>
                <p className="text-xs font-semibold text-slate-200 truncate">{loggedInUser}</p>
              </div>
            </div>
            {onLogout && (
              <button
                onClick={onLogout}
                className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-rose-400 rounded-lg transition active:scale-95 cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        {/* Quick Hub Selector */}
        <div className="mb-4">
          <div className="flex justify-between items-center mb-1.5">
            <label className="text-[10px] font-bold tracking-wider text-slate-500 uppercase block font-mono">
              Active Charging Hub
            </label>
            
            {onLocateMe && (
              <button
                onClick={onLocateMe}
                disabled={geolocationStatus === 'detecting'}
                className="text-[11px] font-bold text-blue-400 hover:text-blue-300 transition flex items-center gap-1 cursor-pointer disabled:opacity-50"
                title="Request current coordinate"
                id="detect-location-btn"
              >
                {geolocationStatus === 'detecting' ? (
                  <>
                    <RefreshCw className="w-3 h-3 animate-spin text-blue-400" />
                    <span>Locating...</span>
                  </>
                ) : (
                  <>
                    <MapPin className="w-3 h-3 text-blue-400" />
                    <span>Detect My Location</span>
                  </>
                )}
              </button>
            )}
          </div>
          <div className="grid grid-cols-4 gap-1.5 mb-2" id="city-selector">
            {(Object.keys(fallbackCityHubs) as Array<keyof typeof fallbackCityHubs>).map((city) => {
              const isActive = currentCityName === city;
              return (
                <button
                  key={city}
                  onClick={() => onSelectCityHub(city)}
                  className={`py-1.5 px-2 text-xs font-semibold rounded-lg text-center transition truncate cursor-pointer border ${
                    isActive
                      ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-500/20 font-bold'
                      : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750 hover:border-slate-650'
                  }`}
                >
                  {city.split(' ')[0]}
                </button>
              );
            })}
          </div>

          {/* Geolocation Success Status Notification */}
          {geolocationStatus === 'granted' && (
            <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-2.5 text-xs text-emerald-400 flex items-start gap-2 mt-2 animate-fadeIn" id="geolocation-success-badge">
              <span className="mt-0.5 text-sm">📍</span>
              <div>
                <p className="font-semibold">Using Live Location</p>
                <p className="text-[10px] text-slate-400">Map and chargers are centered on your current real-time GPS coordinate.</p>
              </div>
            </div>
          )}

          {/* Geolocation Trouble Shooting Help Diagnostic Block */}
          {geolocationErrorMsg && (
            <div className="bg-rose-500/10 border border-rose-500/25 rounded-xl p-3 text-xs text-rose-400 flex flex-col gap-1.5 mt-2 animate-fadeIn" id="geolocation-error-badge">
              <div className="flex items-start gap-2">
                <span className="mt-0.5 text-sm">⚠️</span>
                <div className="flex-1 text-left">
                  <p className="font-bold">Geolocation Issue</p>
                  <p className="text-[10px] text-slate-350 leading-relaxed">{geolocationErrorMsg}</p>
                </div>
              </div>
              <div className="text-[10px] bg-slate-950/60 p-2 rounded-lg border border-slate-800 text-slate-400 space-y-1 text-left">
                <p className="font-semibold text-slate-300">Quick troubleshooting steps:</p>
                <p>1. Check if the browser lock or block icon in your address bar is blocking location access.</p>
                <p>2. Allow location permissions for this application, and click <strong className="text-blue-400">"Detect My Location"</strong> above.</p>
              </div>
            </div>
          )}
        </div>

        {/* Search Input Bar */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-450" />
            <input
              type="text"
              placeholder="Search station or address..."
              value={filters.searchQuery}
              onChange={(e) => onUpdateFilters({ ...filters, searchQuery: e.target.value })}
              id="station-search-input"
              className="w-full bg-slate-800/80 border border-slate-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-450 outline-none transition"
            />
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            id="filters-toggle-btn"
            className={`px-3.5 rounded-xl border flex items-center justify-center transition active:scale-95 cursor-pointer ${
              showFilters || filters.connectorTypes.length > 0 || filters.minPowerKw > 0 || filters.networks.length > 0
                ? 'bg-blue-600 border-blue-500 text-white font-semibold'
                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
            }`}
            title="Filter options"
          >
            <Filter className="w-4 h-4" />
          </button>
        </div>

        {/* Expandable Filter Panel */}
        {showFilters && (
          <div className="mt-4 pt-4 border-t border-slate-800/80 space-y-4 animate-fadeIn" id="filters-panel">
            {/* Filter 1: Connector Types */}
            <div>
              <h3 className="text-xs font-bold text-slate-400 tracking-wider font-mono uppercase mb-2">
                Connector Types
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(EVConnectorType).map(([key, value]) => {
                  const isSelected = filters.connectorTypes.includes(value);
                  return (
                    <button
                      key={key}
                      onClick={() => handleToggleConnector(value)}
                      className={`py-1.5 px-3 text-xs rounded-lg border transition cursor-pointer ${
                        isSelected
                          ? 'bg-green-600/20 border-green-500 text-green-300 font-medium'
                          : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                    >
                      {key.replace('_', ' ')}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Filter 2: Minimum Charging Power */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <h3 className="text-xs font-bold text-slate-400 tracking-wider font-mono uppercase">
                  Min Power Rate
                </h3>
                <span className="text-xs font-bold font-mono text-blue-400">
                  {filters.minPowerKw === 0 ? 'Any Power' : `${filters.minPowerKw} kW+`}
                </span>
              </div>
              <div className="flex gap-2">
                {[0, 11, 50, 150, 250].map((kw) => (
                  <button
                    key={kw}
                    onClick={() => onUpdateFilters({ ...filters, minPowerKw: kw })}
                    className={`flex-1 py-1 px-1.5 text-[10px] font-bold font-mono rounded-md border transition cursor-pointer text-center ${
                      filters.minPowerKw === kw
                        ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                        : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:bg-slate-850 hover:text-slate-200'
                    }`}
                  >
                    {kw === 0 ? 'All' : `${kw}k`}
                  </button>
                ))}
              </div>
            </div>

            {/* Filter 3: Charging Networks */}
            <div>
              <h3 className="text-xs font-bold text-slate-400 tracking-wider font-mono uppercase mb-2">
                Provider Networks
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {allAvailableNetworks.map((net) => {
                  const isSelected = filters.networks.includes(net);
                  return (
                    <button
                      key={net}
                      onClick={() => handleToggleNetwork(net)}
                      className={`py-1.5 px-3 text-xs rounded-lg border transition cursor-pointer ${
                        isSelected
                          ? 'bg-blue-600/20 border-blue-500 text-blue-300 font-medium'
                          : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                      }`}
                    >
                      {net}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Reset Filters button */}
            <div className="flex justify-end">
              <button
                onClick={() =>
                  onUpdateFilters({
                    connectorTypes: [],
                    minPowerKw: 0,
                    networks: [],
                    status: [],
                    searchQuery: ''
                  })
                }
                className="text-xs text-slate-400 hover:text-white underline cursor-pointer font-medium"
              >
                Clear all filters
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Stations List Container */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-800/60 custom-scrollbar" id="stations-list">
        {stations.length === 0 ? (
          <div className="p-8 text-center text-slate-500">
            <Layers className="w-10 h-10 mx-auto mb-3 stroke-1 text-slate-650" />
            <p className="text-sm font-semibold">No stations found</p>
            <p className="text-xs mt-1 text-slate-650">Try broadening your search filters or centering in another location.</p>
          </div>
        ) : (
          stations.map((station) => {
            const isSelected = selectedStation?.id === station.id;
            
            // Calculate total free slots vs total slots
            const totalSlots = station.connectors.reduce((acc, c) => acc + c.count, 0);
            const freeSlots = station.connectors.reduce((acc, c) => acc + c.availableCount, 0);

            // Determine speed badge
            const maxKw = Math.max(...station.connectors.map((c) => c.maxChargeRateKw), 0);
            const isDcFast = maxKw >= 50;

            return (
              <div
                key={station.id}
                onClick={() => onSelectStation(station)}
                id={`station-card-${station.id}`}
                className={`p-4 transition-all duration-150 cursor-pointer hover:bg-slate-800/40 relative flex flex-col gap-2.5 border-l-4 ${
                  isSelected
                    ? 'bg-blue-950/25 border-blue-500'
                    : 'border-transparent'
                }`}
              >
                {/* Header row with Network and Proximity */}
                <div className="flex items-center justify-between">
                  <span className={`text-[10px] font-bold uppercase tracking-wider font-mono py-0.5 px-2 rounded ${
                    station.network === 'Tata Power'
                      ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/10'
                      : station.network === 'Zeon Charging'
                      ? 'bg-blue-500/10 text-blue-400 border border-blue-500/10'
                      : station.network === 'Jio-bp pulse'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/10'
                      : station.network === 'Fortum Charge'
                      ? 'bg-teal-500/10 text-teal-400 border border-teal-500/10'
                      : station.network === 'Ather Grid'
                      ? 'bg-green-500/10 text-green-400 border border-green-500/10'
                      : station.network === 'Bolt.earth'
                      ? 'bg-amber-500/10 text-amber-450 border border-amber-500/10'
                      : 'bg-slate-800 text-slate-400 border border-slate-700/50'
                  }`}>
                    {station.network}
                  </span>
                  
                  {station.distanceKm !== null && (
                    <span className="text-xs font-semibold text-slate-400 flex items-center gap-1 font-mono">
                      <MapPin className="w-3.5 h-3.5 text-slate-500" />
                      {station.distanceKm} km
                    </span>
                  )}
                </div>

                {/* Station Name & Rating */}
                <div>
                  <h3 className={`text-sm font-bold tracking-tight text-white leading-snug ${isSelected ? 'text-blue-400' : ''}`}>
                    {station.name}
                  </h3>
                  <p className="text-xs text-slate-450 mt-0.5 truncate">{station.address}</p>
                </div>

                {/* Charger Slots Info & Charger Tech Specs */}
                <div className="flex items-center justify-between mt-0.5">
                  {/* Real-time Ports free status banner */}
                  <div className="flex items-center gap-1.5">
                    {station.status === 'Available' ? (
                      <span className="flex h-2 w-2 relative">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                      </span>
                    ) : station.status === 'Busy' ? (
                      <span className="h-2 w-2 rounded-full bg-yellow-500 inline-block"></span>
                    ) : (
                      <span className="h-2 w-2 rounded-full bg-slate-500 inline-block"></span>
                    )}

                    <span className={`text-xs font-semibold ${
                      station.status === 'Available'
                        ? 'text-green-400'
                        : station.status === 'Busy'
                        ? 'text-yellow-500'
                        : 'text-slate-500'
                    }`}>
                      {station.status === 'Available'
                        ? `${freeSlots} of ${totalSlots} ports available`
                        : station.status === 'Busy'
                        ? 'Fully occupied'
                        : 'Offline / Maintenance'}
                    </span>
                  </div>

                  {/* Speed level banner */}
                  <div className="flex gap-1">
                    <span className={`text-[10px] font-bold py-0.5 px-1.5 rounded flex items-center gap-0.5 font-mono ${
                      isDcFast
                        ? 'bg-blue-600/15 text-blue-300 border border-blue-500/10'
                        : 'bg-emerald-600/15 text-emerald-300 border border-emerald-500/10'
                    }`}>
                      <Power className="w-2.5 h-2.5" />
                      {isDcFast ? 'DC FAST' : 'LVL 2'}
                    </span>

                    {/* Peak output */}
                    <span className="text-[10px] font-bold font-mono py-0.5 px-1.5 bg-slate-800 text-slate-300 rounded border border-slate-700/50">
                      {maxKw} kW
                    </span>
                  </div>
                </div>

                {/* Rating details & live-update status indicators */}
                <div className="flex justify-between items-center text-xs text-slate-400 pt-1 border-t border-slate-800/40">
                  {station.rating ? (
                    <div className="flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 fill-yellow-500 stroke-yellow-500" />
                      <span className="font-bold text-slate-300">{station.rating}</span>
                      <span className="text-slate-500">({station.userRatingCount})</span>
                    </div>
                  ) : (
                    <span className="text-slate-500">No reviews</span>
                  )}

                  {station.isRealTimeVerified && station.lastUpdated ? (
                    <span className="text-[10px] text-green-400 font-mono flex items-center gap-1 font-semibold">
                      <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
                      Verified {station.lastUpdated}
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-500 font-mono">
                      Cached availability
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Sticky footer info */}
      <div className="p-3 bg-slate-950/80 border-t border-slate-800 text-[10px] text-slate-500 text-center font-mono flex items-center justify-center gap-1.5">
        <span>© VoltFinder Engine</span>
        <span>•</span>
        <span className="flex items-center gap-0.5">
          <Zap className="w-3 h-3 text-green-500" /> Real-time active simulation
        </span>
      </div>
    </div>
  );
}
