/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { EVStation, EVConnectorType } from '../types';
import { X, Zap, MapPin, Globe, Phone, Star, Navigation, ShieldCheck, Clock, RefreshCw } from 'lucide-react';
import { generateHourlyBusyData } from '../utils';

interface StationDetailProps {
  station: EVStation;
  onClose: () => void;
  onVerifyRealTime: (stationId: string) => void;
  isVerifying: boolean;
  onToggleRoute: () => void;
  showRoute: boolean;
  routeInfo: { distance: string; duration: string } | null;
}

export default function StationDetail({
  station,
  onClose,
  onVerifyRealTime,
  isVerifying,
  onToggleRoute,
  showRoute,
  routeInfo
}: StationDetailProps) {
  // Generate stable mock hourly busy data for this station
  const [busyData] = useState(() => generateHourlyBusyData());

  const totalSlots = station.connectors.reduce((acc, c) => acc + c.count, 0);
  const freeSlots = station.connectors.reduce((acc, c) => acc + c.availableCount, 0);

  // Return friendly names for connectors
  const getConnectorLabel = (type: EVConnectorType): string => {
    switch (type) {
      case EVConnectorType.NACS: return 'Tesla (NACS)';
      case EVConnectorType.CCS_1: return 'CCS Combo 1';
      case EVConnectorType.CCS_2: return 'CCS Combo 2';
      case EVConnectorType.CHADEMO: return 'CHAdeMO Fast';
      case EVConnectorType.J1772: return 'J1772 Level 2';
      case EVConnectorType.TYPE_2: return 'Mennekes Type 2';
      case EVConnectorType.WALL_OUTLET: return 'Wall Outlet';
      default: return 'Standard plug';
    }
  };

  // Helper to generate individual port statuses for a rich subgrid display
  const renderIndividualPorts = (connectorCount: number, availableCount: number, outOfServiceCount: number) => {
    const ports = [];
    let remainingAvailable = availableCount;
    let remainingOutOfService = outOfServiceCount;

    for (let i = 1; i <= connectorCount; i++) {
      let portStatus: 'available' | 'busy' | 'offline' = 'busy';
      if (remainingOutOfService > 0) {
        portStatus = 'offline';
        remainingOutOfService--;
      } else if (remainingAvailable > 0) {
        portStatus = 'available';
        remainingAvailable--;
      }

      ports.push({ id: i, status: portStatus });
    }

    return (
      <div className="grid grid-cols-6 gap-1.5 mt-2.5">
        {ports.map((p) => (
          <div
            key={p.id}
            className={`py-1 text-[10px] font-bold text-center rounded border font-mono transition-colors ${
              p.status === 'available'
                ? 'bg-green-500/10 border-green-500/20 text-green-400'
                : p.status === 'offline'
                ? 'bg-slate-800 border-slate-700/60 text-slate-500 line-through'
                : 'bg-yellow-500/10 border-yellow-500/20 text-yellow-500'
            }`}
            title={`Port ${p.id}: ${p.status}`}
          >
            P{p.id}
          </div>
        ))}
      </div>
    );
  };

  // Beautiful SVG Render for charging occupancy hourly trend (prevents heavy charts imports)
  const renderBusyChart = () => {
    const maxVal = Math.max(...busyData.map((d) => d.occupancy));
    const chartHeight = 80;
    
    // Highlight peak hours (17:00 is 5pm, 18:00 is 6pm, etc.)
    const peakHours = ['5 PM', '6 PM', '7 PM', '8 PM', '8 AM', '9 AM'];

    return (
      <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 mt-3">
        <div className="flex justify-between items-center mb-4">
          <span className="text-xs font-bold text-slate-400 font-mono tracking-wider uppercase flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-slate-400" /> Hourly Station Busy Index
          </span>
          <span className="text-[10px] bg-red-500/10 text-red-400 border border-red-500/15 font-bold font-mono px-2 py-0.5 rounded">
            Peak: 5 PM - 8 PM
          </span>
        </div>

        {/* Custom SVG Bar Chart */}
        <div className="relative w-full overflow-x-auto custom-scrollbar pt-2 pb-1">
          <div className="min-w-[460px] h-28 flex items-end gap-1.5 px-1">
            {busyData.map((d, idx) => {
              const height = (d.occupancy / maxVal) * chartHeight;
              const isPeak = peakHours.includes(d.hour);
              const isCurrentHour = idx === new Date().getHours();

              return (
                <div key={d.hour} className="flex-1 flex flex-col items-center group">
                  {/* Tooltip bar on hover */}
                  <div className="absolute opacity-0 group-hover:opacity-100 bg-slate-900 border border-slate-700 text-[10px] text-white py-0.5 px-1.5 rounded-md -translate-y-9 transition-opacity shadow-xl z-20 pointer-events-none font-mono">
                    {d.occupancy}% Busy
                  </div>

                  {/* SVG styled Column bar */}
                  <div
                    className={`w-full rounded-t-sm transition-all duration-300 relative ${
                      isCurrentHour
                        ? 'bg-blue-500 shadow-lg shadow-blue-500/20'
                        : isPeak
                        ? 'bg-cyan-500/80'
                        : 'bg-slate-700 hover:bg-slate-600'
                    }`}
                    style={{ height: `${Math.max(4, height)}px` }}
                  />

                  {/* Hourly Label (show every 3 hours for clean layout) */}
                  <span className={`text-[9px] font-bold font-mono mt-1.5 ${
                    isCurrentHour ? 'text-blue-400 font-extrabold' : 'text-slate-550'
                  }`}>
                    {idx % 3 === 0 ? d.hour.replace(' ', '') : '•'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div
      className="absolute bottom-0 left-0 right-0 md:top-4 md:bottom-4 md:right-4 md:left-auto md:w-[380px] bg-slate-900/95 backdrop-blur-md border border-slate-800 rounded-t-3xl md:rounded-2xl flex flex-col shadow-2xl z-20 animate-slideIn select-none max-h-[75vh] md:max-h-none"
      id="station-detail-panel"
    >
      {/* Drawer drag handle for mobile */}
      <div className="md:hidden flex justify-center py-2.5 bg-slate-950/40 rounded-t-3xl">
        <div className="w-12 h-1 bg-slate-700/80 rounded-full" />
      </div>

      {/* Detail Header */}
      <div className="p-4 border-b border-slate-800 flex items-start justify-between bg-slate-950/40 rounded-t-none md:rounded-t-2xl">
        <div className="flex-1 pr-3">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-blue-600/10 text-blue-300 border border-blue-500/10">
              {station.network}
            </span>
            {station.rating && (
              <div className="flex items-center gap-0.5 text-xs font-bold text-yellow-500">
                <Star className="w-3.5 h-3.5 fill-yellow-500 stroke-yellow-500" />
                <span>{station.rating}</span>
              </div>
            )}
          </div>
          <h2 className="text-base font-bold text-white tracking-tight leading-snug">{station.name}</h2>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed flex items-start gap-1">
            <MapPin className="w-3.5 h-3.5 mt-0.5 text-slate-500 flex-shrink-0" />
            {station.address}
          </p>
        </div>

        <button
          onClick={onClose}
          id="close-detail-btn"
          className="p-1.5 bg-slate-850 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition active:scale-95 cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Detail Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
        
        {/* Real-Time Live Scan Verification trigger box */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-xl p-4 shadow-inner flex flex-col gap-3">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-xs font-bold text-slate-400 font-mono tracking-wider uppercase">
                Real-Time Status
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {station.isRealTimeVerified && station.lastUpdated ? (
                  <span className="text-green-400 font-mono flex items-center gap-1 font-semibold mt-1">
                    <ShieldCheck className="w-4 h-4 text-green-400" /> Checked {station.lastUpdated}
                  </span>
                ) : (
                  <span className="text-slate-500 mt-1 block italic text-[11px]">
                    Status updated periodically. Scan for live check.
                  </span>
                )}
              </p>
            </div>

            <div className="text-right">
              <span className={`inline-block py-1 px-2.5 rounded-full text-xs font-bold ${
                station.status === 'Available'
                  ? 'bg-green-500/10 text-green-400 border border-green-500/15'
                  : station.status === 'Busy'
                  ? 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/15'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}>
                {station.status === 'Available' ? `${freeSlots}/${totalSlots} Plugs Free` : station.status}
              </span>
            </div>
          </div>

          <button
            onClick={() => onVerifyRealTime(station.id)}
            disabled={isVerifying}
            id="verify-status-btn"
            className="w-full py-2 px-4 rounded-xl font-bold text-xs bg-green-500 hover:bg-green-400 text-slate-950 flex items-center justify-center gap-2 transition disabled:opacity-50 active:scale-95 cursor-pointer shadow-lg shadow-green-500/10"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isVerifying ? 'animate-spin' : ''}`} />
            {isVerifying ? 'Scanning ports network...' : 'Verify Port Occupancy'}
          </button>
        </div>

        {/* Detailed Connectors Specifications Grid */}
        <div className="space-y-2.5">
          <h3 className="text-xs font-bold text-slate-450 tracking-wider font-mono uppercase">
            Plugs Config & Power Rates
          </h3>
          <div className="grid grid-cols-1 gap-3">
            {station.connectors.map((conn, idx) => {
              const isFast = conn.maxChargeRateKw >= 50;
              return (
                <div key={idx} className="bg-slate-950/40 border border-slate-800 p-3 rounded-xl flex flex-col">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Zap className={`w-4 h-4 ${isFast ? 'text-blue-400' : 'text-emerald-400'}`} />
                      <span className="text-sm font-bold text-slate-100">{getConnectorLabel(conn.type)}</span>
                    </div>
                    <span className="text-xs font-bold font-mono text-slate-300">
                      {conn.maxChargeRateKw} kW Max
                    </span>
                  </div>

                  {/* Occupancy metrics */}
                  <div className="flex justify-between items-center mt-2 text-xs text-slate-400">
                    <span className="font-semibold text-[11px] text-slate-450 font-mono">
                      PLUG STATUS:
                    </span>
                    <span className={conn.availableCount > 0 ? 'text-green-400 font-bold' : 'text-slate-500'}>
                      {conn.availableCount} of {conn.count} available
                    </span>
                  </div>

                  {/* Subgrid showing simulated individual outlets */}
                  {renderIndividualPorts(conn.count, conn.availableCount, conn.outOfServiceCount)}
                </div>
              );
            })}
          </div>
        </div>

        {/* Static Pricing, Hours, Contact details */}
        <div className="bg-slate-950/40 border border-slate-800/80 rounded-xl p-3 text-xs space-y-2.5">
          <div className="flex justify-between py-1 border-b border-slate-800/40">
            <span className="text-slate-500 font-medium">Estimated Pricing</span>
            <span className="text-slate-200 font-bold font-mono">{station.pricing}</span>
          </div>
          <div className="flex justify-between py-1 border-b border-slate-800/40">
            <span className="text-slate-500 font-medium">Access Hours</span>
            <span className="text-slate-200 font-bold">24 / 7 Public Access</span>
          </div>
          {station.phoneNumber && (
            <div className="flex items-center justify-between py-1 border-b border-slate-800/40">
              <span className="text-slate-500 font-medium">Phone Support</span>
              <a href={`tel:${station.phoneNumber}`} className="text-blue-400 hover:underline flex items-center gap-1 font-semibold font-mono">
                <Phone className="w-3.5 h-3.5" /> {station.phoneNumber}
              </a>
            </div>
          )}
          {station.website && (
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-500 font-medium">Web link</span>
              <a href={station.website} target="_blank" rel="noreferrer" className="text-blue-400 hover:underline flex items-center gap-1 font-semibold truncate max-w-[180px]">
                <Globe className="w-3.5 h-3.5" /> Portal link
              </a>
            </div>
          )}
        </div>

        {/* Navigation Directions Trigger block */}
        <div className="bg-slate-950/40 border border-slate-800/80 rounded-xl p-3 flex flex-col gap-2.5">
          <div className="flex justify-between items-center">
            <div>
              <h4 className="text-xs font-bold text-slate-100 flex items-center gap-1.5">
                <Navigation className="w-4 h-4 text-blue-500 fill-current" /> Driving Directions
              </h4>
              <p className="text-[11px] text-slate-450 mt-0.5">Calculates high-accuracy routes on the map</p>
            </div>
            {showRoute && routeInfo && (
              <div className="text-right">
                <div className="text-xs font-bold text-blue-400 font-mono">{routeInfo.duration}</div>
                <div className="text-[10px] text-slate-450 font-mono">{routeInfo.distance}</div>
              </div>
            )}
          </div>

          <button
            onClick={onToggleRoute}
            id="toggle-route-directions-btn"
            className={`w-full py-2 px-4 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer border ${
              showRoute
                ? 'bg-red-500/10 border-red-500/20 text-red-400 hover:bg-red-500/20'
                : 'bg-blue-600 hover:bg-blue-500 border-blue-500 text-white shadow-lg shadow-blue-500/10'
            }`}
          >
            <Navigation className="w-3.5 h-3.5" />
            {showRoute ? 'Clear Route Path' : 'Show Route to Charger'}
          </button>
        </div>

        {/* Daily Busy trends (glowing custom bars chart) */}
        {renderBusyChart()}

        {/* Driver Reviews Feed */}
        {station.reviews && station.reviews.length > 0 && (
          <div className="space-y-2.5">
            <h3 className="text-xs font-bold text-slate-450 tracking-wider font-mono uppercase">
              Driver Reviews
            </h3>
            <div className="space-y-2.5">
              {station.reviews.map((rev, index) => (
                <div key={index} className="bg-slate-950/40 border border-slate-800 p-3 rounded-xl text-xs">
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="font-bold text-slate-200">{rev.author}</span>
                    <span className="text-[10px] text-slate-500 font-mono">{rev.relativeTime}</span>
                  </div>
                  <div className="flex items-center gap-0.5 mb-1.5 text-yellow-500">
                    {Array.from({ length: rev.rating }).map((_, i) => (
                      <Star key={i} className="w-3 h-3 fill-yellow-500 stroke-yellow-500" />
                    ))}
                  </div>
                  <p className="text-slate-300 leading-relaxed italic">"{rev.text}"</p>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
