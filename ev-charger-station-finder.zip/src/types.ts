/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum EVConnectorType {
  NACS = 'NACS', // Tesla
  CCS_1 = 'CCS_COMBO_1', // North America DC Fast
  CCS_2 = 'CCS_COMBO_2', // Europe DC Fast
  CHADEMO = 'CHADEMO', // Japanese / Older DC Fast
  J1772 = 'J1772', // Level 2 AC
  TYPE_2 = 'TYPE_2', // Europe Level 2 AC
  WALL_OUTLET = 'UNSPECIFIED_WALL_OUTLET',
  OTHER = 'OTHER'
}

export interface EVConnector {
  type: EVConnectorType;
  count: number;
  maxChargeRateKw: number;
  availableCount: number;
  outOfServiceCount: number;
}

export interface Review {
  author: string;
  text: string;
  rating: number;
  relativeTime: string;
}

export interface EVStation {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  distanceKm: number | null; // distance from user location in Km
  connectorCount: number;
  connectors: EVConnector[];
  rating?: number;
  userRatingCount?: number;
  network: string; // ChargePoint, Electrify America, EVgo, Tesla, etc.
  pricing: string; // e.g. "$0.42 / kWh", "Free", etc.
  status: 'Available' | 'Busy' | 'Offline' | 'Checking';
  isRealTimeVerified: boolean;
  lastUpdated: string | null;
  phoneNumber?: string;
  website?: string;
  reviews?: Review[];
}

export interface FilterState {
  connectorTypes: EVConnectorType[];
  minPowerKw: number;
  networks: string[];
  status: ('Available' | 'Busy' | 'Offline')[];
  searchQuery: string;
}
