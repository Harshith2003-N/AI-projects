/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { EVStation, EVConnector, EVConnectorType, Review } from './types';

// Calculate distance between two coordinates in kilometers (Haversine formula)
export function calculateDistance(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371; // Radius of the Earth in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return parseFloat((R * c).toFixed(1));
}

// Detect EV network from name
export function detectNetwork(name: string): string {
  const lowerName = name.toLowerCase();
  if (lowerName.includes('tata power') || lowerName.includes('ez charge')) return 'Tata Power';
  if (lowerName.includes('zeon')) return 'Zeon Charging';
  if (lowerName.includes('jio') || lowerName.includes('bp')) return 'Jio-bp pulse';
  if (lowerName.includes('fortum')) return 'Fortum Charge';
  if (lowerName.includes('ather')) return 'Ather Grid';
  if (lowerName.includes('bolt')) return 'Bolt.earth';
  return 'Independent';
}

// Generates typical pricing based on network
export function getPricingForNetwork(network: string): string {
  switch (network) {
    case 'Tata Power':
      return '₹18.0 - ₹22.0 / kWh';
    case 'Zeon Charging':
      return '₹20.0 - ₹24.0 / kWh';
    case 'Fortum Charge':
      return '₹19.0 - ₹23.0 / kWh';
    case 'Ather Grid':
      return '₹15.0 / kWh';
    case 'Bolt.earth':
      return '₹10.0 - ₹12.0 / kWh';
    case 'Jio-bp pulse':
      return '₹16.0 - ₹21.0 / kWh';
    case 'Independent':
      return Math.random() > 0.3 ? 'Free / Courtesy' : '₹12.0 / kWh';
    default:
      return '₹15.0 - ₹20.0 / kWh';
  }
}

// Generate realistic connectors based on station name/network
export function generateConnectorsForStation(network: string, customCount?: number): EVConnector[] {
  const connectors: EVConnector[] = [];
  const totalCount = customCount || Math.floor(Math.random() * 4) + 3; // 3 to 7 plugs

  if (network === 'Tata Power' || network === 'Zeon Charging' || network === 'Fortum Charge' || network === 'Jio-bp pulse') {
    // Premium Indian fast charging stations (CCS-2 + Type-2)
    const splitCount = Math.floor(totalCount / 2);
    const ccsPower = Math.random() > 0.5 ? 120 : 60; // 60 kW or 120 kW are standard in India
    const ccsCount = splitCount > 0 ? splitCount : 2;
    const ccsOutOfService = Math.random() > 0.9 ? 1 : 0;
    const ccsAvailable = Math.max(0, ccsCount - ccsOutOfService - Math.floor(Math.random() * ccsCount));
    
    connectors.push({
      type: EVConnectorType.CCS_2,
      count: ccsCount,
      maxChargeRateKw: ccsPower,
      availableCount: ccsAvailable,
      outOfServiceCount: ccsOutOfService
    });

    const acCount = totalCount - ccsCount;
    if (acCount > 0) {
      const acOutOfService = Math.random() > 0.95 ? 1 : 0;
      const acAvailable = Math.max(0, acCount - acOutOfService - Math.floor(Math.random() * acCount));
      
      connectors.push({
        type: EVConnectorType.TYPE_2,
        count: acCount,
        maxChargeRateKw: 22,
        availableCount: acAvailable,
        outOfServiceCount: acOutOfService
      });
    }
  } else if (network === 'Ather Grid') {
    // Ather Grid fast/slow chargers for 2-wheelers
    const outOfService = Math.random() > 0.95 ? 1 : 0;
    const available = Math.max(0, totalCount - outOfService - Math.floor(Math.random() * totalCount));
    connectors.push({
      type: EVConnectorType.OTHER,
      count: totalCount,
      maxChargeRateKw: 22,
      availableCount: available,
      outOfServiceCount: outOfService
    });
  } else if (network === 'Bolt.earth') {
    // Smart 15A wall socket points and Type-2
    const splitCount = Math.floor(totalCount / 2);
    const wallCount = splitCount > 0 ? splitCount : 2;
    const wallOutOfService = Math.random() > 0.9 ? 1 : 0;
    const wallAvailable = Math.max(0, wallCount - wallOutOfService - Math.floor(Math.random() * wallCount));

    connectors.push({
      type: EVConnectorType.WALL_OUTLET,
      count: wallCount,
      maxChargeRateKw: 3.3, // 15A 230V socket
      availableCount: wallAvailable,
      outOfServiceCount: wallOutOfService
    });

    const type2Count = totalCount - wallCount;
    if (type2Count > 0) {
      const type2OutOfService = Math.random() > 0.95 ? 1 : 0;
      const type2Available = Math.max(0, type2Count - type2OutOfService - Math.floor(Math.random() * type2Count));
      connectors.push({
        type: EVConnectorType.TYPE_2,
        count: type2Count,
        maxChargeRateKw: 7.4,
        availableCount: type2Available,
        outOfServiceCount: type2OutOfService
      });
    }
  } else {
    // General Indian AC & DC public charging points
    const ccsCount = Math.max(1, Math.floor(totalCount / 2));
    const ccsAvailable = Math.max(0, ccsCount - Math.floor(Math.random() * (ccsCount + 1)));
    connectors.push({
      type: EVConnectorType.CCS_2,
      count: ccsCount,
      maxChargeRateKw: 50,
      availableCount: ccsAvailable,
      outOfServiceCount: 0
    });
    
    const type2Count = totalCount - ccsCount;
    if (type2Count > 0) {
      const type2Available = Math.max(0, type2Count - Math.floor(Math.random() * (type2Count + 1)));
      connectors.push({
        type: EVConnectorType.TYPE_2,
        count: type2Count,
        maxChargeRateKw: 11,
        availableCount: type2Available,
        outOfServiceCount: 0
      });
    }
  }

  return connectors;
}

// Generate realistic busy-hour profile (24 points for each hour)
export function generateHourlyBusyData(): { hour: string; occupancy: number }[] {
  const data = [];
  const hours = [
    '12 AM', '1 AM', '2 AM', '3 AM', '4 AM', '5 AM', '6 AM', '7 AM', '8 AM', '9 AM', '10 AM', '11 AM',
    '12 PM', '1 PM', '2 PM', '3 PM', '4 PM', '5 PM', '6 PM', '7 PM', '8 PM', '9 PM', '10 PM', '11 PM'
  ];

  for (let i = 0; i < 24; i++) {
    // Peak hours: 8am-10am and 5pm-8pm
    let base = 20;
    if (i >= 7 && i <= 9) base = 75; // Morning rush
    else if (i >= 10 && i <= 15) base = 50; // Midday
    else if (i >= 16 && i <= 20) base = 85; // Evening rush
    else if (i >= 21 || i <= 6) base = 10; // Night
    
    // Add minor random noise
    const noise = Math.floor(Math.random() * 15) - 7;
    const occupancy = Math.max(0, Math.min(100, base + noise));
    
    data.push({
      hour: hours[i],
      occupancy
    });
  }
  return data;
}

// Map Google Places API Types to our internal EVConnectorType
export function mapGoogleConnectorType(gType: string): EVConnectorType {
  const cleaned = gType.toUpperCase();
  if (cleaned.includes('CCS_COMBO_1') || cleaned.includes('CCS1')) return EVConnectorType.CCS_1;
  if (cleaned.includes('CCS_COMBO_2') || cleaned.includes('CCS2')) return EVConnectorType.CCS_2;
  if (cleaned.includes('CHADEMO')) return EVConnectorType.CHADEMO;
  if (cleaned.includes('J1772')) return EVConnectorType.J1772;
  if (cleaned.includes('TESLA')) return EVConnectorType.NACS;
  if (cleaned.includes('NACS')) return EVConnectorType.NACS;
  if (cleaned.includes('TYPE_2') || cleaned.includes('MENNEKES')) return EVConnectorType.TYPE_2;
  if (cleaned.includes('WALL_OUTLET')) return EVConnectorType.WALL_OUTLET;
  return EVConnectorType.OTHER;
}

// Parse google.maps.places.Place and return augmented EVStation
export function parseAndAugmentStation(
  place: google.maps.places.Place,
  userLoc?: { lat: number; lng: number }
): EVStation {
  const id = place.id || Math.random().toString(36).substring(7);
  const name = place.displayName || 'EV Charging Station';
  const address = place.formattedAddress || 'Nearby Area';
  
  // Handle lat lng extraction
  const lat = place.location?.lat() || 37.7749;
  const lng = place.location?.lng() || -122.4194;
  
  const distanceKm = userLoc ? calculateDistance(userLoc.lat, userLoc.lng, lat, lng) : null;
  const network = detectNetwork(name);
  const pricing = getPricingForNetwork(network);

  // Extract connectors if available, otherwise generate them
  let connectors: EVConnector[] = [];
  let connectorCount = 0;

  const gEvOptions = (place as any).evChargeOptions;
  if (gEvOptions && gEvOptions.connectorCount > 0) {
    connectorCount = gEvOptions.connectorCount;
    if (gEvOptions.connectorAggregations && gEvOptions.connectorAggregations.length > 0) {
      connectors = gEvOptions.connectorAggregations.map((agg: any) => {
        const type = mapGoogleConnectorType(agg.type || '');
        const count = agg.count || 2;
        const outOfService = agg.outOfServiceCount || 0;
        
        // Google sometimes provides real-time available_count in some markets!
        let available = agg.availableCount;
        if (available === undefined || available === null) {
          // If no live data, simulate
          available = Math.max(0, count - outOfService - Math.floor(Math.random() * count));
        }

        return {
          type,
          count,
          maxChargeRateKw: agg.maxChargeRateKw || (type === EVConnectorType.NACS ? 250 : 150),
          availableCount: available,
          outOfServiceCount: outOfService
        };
      });
    } else {
      connectors = generateConnectorsForStation(network, connectorCount);
    }
  } else {
    // Mock connectors if Google doesn't provide them
    connectors = generateConnectorsForStation(network);
    connectorCount = connectors.reduce((acc, c) => acc + c.count, 0);
  }

  // Determine overall status based on connectors availability
  const totalAvailable = connectors.reduce((acc, c) => acc + c.availableCount, 0);
  const totalOutOfService = connectors.reduce((acc, c) => acc + c.outOfServiceCount, 0);
  let status: EVStation['status'] = 'Available';
  if (totalAvailable === 0) {
    if (totalOutOfService === connectorCount) {
      status = 'Offline';
    } else {
      status = 'Busy';
    }
  }

  // Map reviews
  const reviews: Review[] = (place.reviews || []).map((r: any) => ({
    author: r.authorAttribution?.displayName || 'EV Driver',
    text: r.text || '',
    rating: r.rating || 5,
    relativeTime: r.relativePublishTimeDescription || 'recently'
  }));

  return {
    id,
    name,
    address,
    lat,
    lng,
    distanceKm,
    connectorCount,
    connectors,
    rating: place.rating || undefined,
    userRatingCount: place.userRatingCount || undefined,
    network,
    pricing,
    status,
    isRealTimeVerified: false,
    lastUpdated: null,
    phoneNumber: place.nationalPhoneNumber || undefined,
    website: (place as any).websiteUri || (place as any).websiteURI || (place as any).website || undefined,
    reviews: reviews.length > 0 ? reviews : undefined
  };
}

// Simulated real-time check with elegant loading and random update states
export function simulateRealTimeCheck(station: EVStation): Promise<EVStation> {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Clone station and randomize connector states for live feedback feel
      const updatedConnectors = station.connectors.map((conn) => {
        const outOfService = Math.random() > 0.9 ? 1 : 0;
        // Randomize available count slightly to simulate real activity
        const availableCount = Math.max(
          0,
          Math.min(conn.count - outOfService, Math.floor(Math.random() * (conn.count + 1)))
        );
        return {
          ...conn,
          availableCount,
          outOfServiceCount: outOfService
        };
      });

      const totalAvailable = updatedConnectors.reduce((acc, c) => acc + c.availableCount, 0);
      const totalOutOfService = updatedConnectors.reduce((acc, c) => acc + c.outOfServiceCount, 0);
      
      let status: EVStation['status'] = 'Available';
      if (totalAvailable === 0) {
        if (totalOutOfService === station.connectorCount) {
          status = 'Offline';
        } else {
          status = 'Busy';
        }
      }

      const now = new Date();
      const lastUpdated = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

      resolve({
        ...station,
        connectors: updatedConnectors,
        status,
        isRealTimeVerified: true,
        lastUpdated
      });
    }, 1200); // 1.2 second simulated round-trip checking latency
  });
}

// Preset Fallback Mock Stations for major hubs
export const fallbackCityHubs = {
  'Bengaluru': { lat: 12.9716, lng: 77.5946 },
  'Mumbai': { lat: 19.0760, lng: 72.8777 },
  'Delhi': { lat: 28.6139, lng: 77.2090 },
  'Hyderabad': { lat: 17.3850, lng: 78.4867 }
};

export function getMockStationsForLocation(lat: number, lng: number): EVStation[] {
  // Generate 8 highly detailed mock EV stations clustered around the location
  const names = [
    'Tata Power EZ Charge - MG Road Plaza',
    'Zeon Fast Charger - Forum Mall Parking',
    'Jio-bp pulse - Highway Bypass Hub',
    'Fortum Charge & Drive - Metro Station Gateway',
    'Ather Grid - Commercial High Street',
    'Bolt.earth Smart Hub - Indiranagar Residential',
    'Tata Power EZ Charge - Tech Park Main Stalls',
    'Independent DC Charger - Airport Ring Road'
  ];

  const networks = [
    'Tata Power',
    'Zeon Charging',
    'Jio-bp pulse',
    'Fortum Charge',
    'Ather Grid',
    'Bolt.earth',
    'Tata Power',
    'Independent'
  ];

  const offsets = [
    { dLat: 0.003, dLng: -0.005 },
    { dLat: -0.004, dLng: 0.008 },
    { dLat: 0.009, dLng: 0.002 },
    { dLat: -0.007, dLng: -0.006 },
    { dLat: 0.005, dLng: 0.009 },
    { dLat: -0.002, dLng: -0.003 },
    { dLat: 0.006, dLng: -0.008 },
    { dLat: -0.008, dLng: 0.005 }
  ];

  const reviewsList: Review[][] = [
    [
      { author: 'Marcus V.', text: 'Super fast charging here, reached 250 kW. Easy pull-in stalls.', rating: 5, relativeTime: '3 days ago' },
      { author: 'Jane D.', text: 'Clean location, right next to coffee shops and dining.', rating: 4, relativeTime: '1 week ago' }
    ],
    [
      { author: 'Sarah L.', text: 'Level 2 charger worked perfectly for my afternoon top-off.', rating: 5, relativeTime: '2 days ago' },
      { author: 'David K.', text: 'One of the screens was cracked but charging started immediately via app.', rating: 4, relativeTime: '2 weeks ago' }
    ],
    [
      { author: 'ElectricRider', text: 'Excellent DC Fast charger. Got 80% in 25 mins. Highly recommend.', rating: 5, relativeTime: 'Yesterday' }
    ],
    [
      { author: 'Kev G.', text: 'Electrify America speed was high. 350 kW charger was available.', rating: 5, relativeTime: '4 days ago' },
      { author: 'Mona R.', text: 'Two chargers were offline but the remaining ones worked great.', rating: 3, relativeTime: '1 month ago' }
    ],
    [
      { author: 'Elon Fan', text: 'Tesla supercharger - works flawlessly as always. Fast speeds, clean stalls.', rating: 5, relativeTime: '3 hours ago' }
    ],
    [
      { author: 'Pioneer88', text: 'Slightly slower Level 2 speeds, but very convenient location.', rating: 4, relativeTime: '5 days ago' }
    ],
    [
      { author: 'EcoDriver', text: 'Free charging while shopping! Love this Volta station.', rating: 5, relativeTime: '2 days ago' }
    ],
    [
      { author: 'Clara S.', text: 'Very convenient location right off the highway. Prices are a bit higher.', rating: 4, relativeTime: '1 week ago' }
    ]
  ];

  return offsets.map((offset, index) => {
    const sLat = lat + offset.dLat;
    const sLng = lng + offset.dLng;
    const distanceKm = calculateDistance(lat, lng, sLat, sLng);
    const network = networks[index];
    const name = names[index];
    const pricing = getPricingForNetwork(network);

    const connectors = generateConnectorsForStation(network);
    const connectorCount = connectors.reduce((acc, c) => acc + c.count, 0);

    const totalAvailable = connectors.reduce((acc, c) => acc + c.availableCount, 0);
    const totalOutOfService = connectors.reduce((acc, c) => acc + c.outOfServiceCount, 0);
    
    let status: EVStation['status'] = 'Available';
    if (totalAvailable === 0) {
      if (totalOutOfService === connectorCount) {
        status = 'Offline';
      } else {
        status = 'Busy';
      }
    }

    return {
      id: `mock-station-${index}`,
      name,
      address: `${Math.floor(Math.random() * 800) + 100} Broadway Blvd, Local Center`,
      lat: sLat,
      lng: sLng,
      distanceKm,
      connectorCount,
      connectors,
      rating: parseFloat((4.0 + Math.random() * 0.9).toFixed(1)),
      userRatingCount: Math.floor(Math.random() * 200) + 15,
      network,
      pricing,
      status,
      isRealTimeVerified: false,
      lastUpdated: null,
      phoneNumber: `(555) 019-${1000 + index}`,
      website: `https://www.example.com/${network.toLowerCase().replace(' ', '')}`,
      reviews: reviewsList[index]
    };
  });
}
