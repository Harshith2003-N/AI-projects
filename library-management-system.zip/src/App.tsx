/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Book, Patron, Loan, ActivityLog } from './types';
import {
  INITIAL_BOOKS,
  INITIAL_PATRONS,
  INITIAL_LOANS,
  INITIAL_LOGS
} from './mockData';

// Component Imports
import Dashboard from './components/Dashboard';
import BookInventory from './components/BookInventory';
import LoanTracker from './components/LoanTracker';
import LoanModal from './components/LoanModal';
import PatronManager from './components/PatronManager';
import LoginPage from './components/LoginPage';
import StudentPortal from './components/StudentPortal';

// Icon Imports
import {
  LayoutDashboard,
  BookOpen,
  ArrowRightLeft,
  Users,
  Menu,
  X,
  RotateCcw,
  BookMarked,
  Sparkles,
  Info,
  CheckCircle,
  AlertTriangle,
  LogOut
} from 'lucide-react';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'info' | 'warning';
}

export default function App() {
  // Navigation Tab State
  const [activeTab, setActiveTab] = useState<'dashboard' | 'books' | 'loans' | 'patrons'>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Authentication State
  const [currentUser, setCurrentUser] = useState<{ role: 'ADMIN' | 'STUDENT'; patronId?: string; name: string } | null>(null);

  // UTC Dynamic Clock
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const hours = String(now.getUTCHours()).padStart(2, '0');
      const minutes = String(now.getUTCMinutes()).padStart(2, '0');
      const seconds = String(now.getUTCSeconds()).padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}:${seconds} UTC`);
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  // Core Database States
  const [books, setBooks] = useState<Book[]>([]);
  const [patrons, setPatrons] = useState<Patron[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);

  // Loan Modal Orchestrator
  const [checkoutBook, setCheckoutBook] = useState<Book | null>(null);

  // Toast System State
  const [toasts, setToasts] = useState<Toast[]>([]);

  // 1. Initialize State from LocalStorage or Fallbacks
  useEffect(() => {
    const storedBooks = localStorage.getItem('lib_books');
    const storedPatrons = localStorage.getItem('lib_patrons');
    const storedLoans = localStorage.getItem('lib_loans');
    const storedLogs = localStorage.getItem('lib_logs');
    const storedUser = localStorage.getItem('lib_current_user');

    let initialBooks = storedBooks ? JSON.parse(storedBooks) : INITIAL_BOOKS;
    let initialPatrons = storedPatrons ? JSON.parse(storedPatrons) : INITIAL_PATRONS;
    let initialLoans = storedLoans ? JSON.parse(storedLoans) : INITIAL_LOANS;
    let initialLogs = storedLogs ? JSON.parse(storedLogs) : INITIAL_LOGS;

    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }

    // Smart auto-detection of Overdue Loans upon startup!
    const todayStr = new Date().toISOString().split('T')[0];
    let updatedLoansCount = 0;

    const auditedLoans = initialLoans.map((loan: Loan) => {
      if (loan.status === 'ACTIVE' && loan.dueDate < todayStr) {
        updatedLoansCount++;
        return { ...loan, status: 'OVERDUE' };
      }
      return loan;
    });

    setBooks(initialBooks);
    setPatrons(initialPatrons);
    setLoans(auditedLoans);

    // If some loans were auto-flagged as overdue, log it and save
    if (updatedLoansCount > 0) {
      const auditLog: ActivityLog = {
        id: `log-audit-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: 'LOAN_RENEW',
        message: 'Circulation Audit Complete',
        details: `Identified and marked ${updatedLoansCount} loans as Overdue based on current date.`
      };
      const finalLogs = [auditLog, ...initialLogs];
      setActivityLogs(finalLogs);
      localStorage.setItem('lib_loans', JSON.stringify(auditedLoans));
      localStorage.setItem('lib_logs', JSON.stringify(finalLogs));
    } else {
      setActivityLogs(initialLogs);
    }
  }, []);

  // 2. Persistent Storage Sync
  const saveToStorage = (
    newBooks: Book[],
    newPatrons: Patron[],
    newLoans: Loan[],
    newLogs: ActivityLog[]
  ) => {
    localStorage.setItem('lib_books', JSON.stringify(newBooks));
    localStorage.setItem('lib_patrons', JSON.stringify(newPatrons));
    localStorage.setItem('lib_loans', JSON.stringify(newLoans));
    localStorage.setItem('lib_logs', JSON.stringify(newLogs));
  };

  // 3. Toast trigger helper
  const addToast = (message: string, type: 'success' | 'info' | 'warning' = 'success') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    // Auto-remove after 4 seconds
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const handleLogin = (user: { role: 'ADMIN' | 'STUDENT'; patronId?: string; name: string }) => {
    setCurrentUser(user);
    localStorage.setItem('lib_current_user', JSON.stringify(user));
    addToast(`Successfully logged in as ${user.name}!`);
  };

  const handleLogOut = () => {
    setCurrentUser(null);
    localStorage.removeItem('lib_current_user');
    addToast('Logged out of system session.', 'info');
  };

  // 4. Reset database to factory defaults
  const handleResetData = () => {
    if (window.confirm('Are you sure you want to reset all library data to factory defaults? Your current modifications will be lost.')) {
      setBooks(INITIAL_BOOKS);
      setPatrons(INITIAL_PATRONS);
      setLoans(INITIAL_LOANS);

      const resetLog: ActivityLog = {
        id: `log-reset-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: 'BOOK_ADD',
        message: 'Library Catalog Restored',
        details: 'All inventory indices, patrons, and circulation registers reset to system defaults.'
      };

      const newLogs = [resetLog, ...INITIAL_LOGS];
      setActivityLogs(newLogs);
      saveToStorage(INITIAL_BOOKS, INITIAL_PATRONS, INITIAL_LOANS, newLogs);
      addToast('Library database restored to original defaults!', 'info');
    }
  };

  // 5. Book Actions
  const handleAddBook = (bookFields: Omit<Book, 'id' | 'availableCopies'>) => {
    const newBook: Book = {
      ...bookFields,
      id: `book-${Date.now()}`,
      availableCopies: bookFields.totalCopies
    };

    const updatedBooks = [newBook, ...books];

    const log: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'BOOK_ADD',
      message: `Cataloged Book: "${newBook.title}"`,
      details: `Registered ISBN ${newBook.isbn} under category "${newBook.category}". Assigned to ${newBook.location}.`
    };

    const updatedLogs = [log, ...activityLogs];

    setBooks(updatedBooks);
    setActivityLogs(updatedLogs);
    saveToStorage(updatedBooks, patrons, loans, updatedLogs);
    addToast(`"${newBook.title}" added successfully to the catalog!`);
  };

  const handleEditBook = (editedBook: Book) => {
    const updatedBooks = books.map((b) => (b.id === editedBook.id ? editedBook : b));

    const log: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'BOOK_EDIT',
      message: `Updated Catalog: "${editedBook.title}"`,
      details: `Refined record variables. Current copies: ${editedBook.availableCopies}/${editedBook.totalCopies}. Location: ${editedBook.location}.`
    };

    const updatedLogs = [log, ...activityLogs];

    setBooks(updatedBooks);
    setActivityLogs(updatedLogs);
    saveToStorage(updatedBooks, patrons, loans, updatedLogs);
    addToast(`Updated record for "${editedBook.title}".`);
  };

  const handleDeleteBook = (id: string) => {
    const bookToDelete = books.find((b) => b.id === id);
    if (!bookToDelete) return;

    // Check if there are active loans for this book
    const hasActiveLoans = loans.some(
      (l) => l.bookId === id && (l.status === 'ACTIVE' || l.status === 'OVERDUE')
    );

    if (hasActiveLoans) {
      addToast(
        `Cannot delete "${bookToDelete.title}". There are copies currently checked out.`,
        'warning'
      );
      return;
    }

    if (
      window.confirm(
        `Are you sure you want to permanently delete "${bookToDelete.title}" from the catalog registry?`
      )
    ) {
      const updatedBooks = books.filter((b) => b.id !== id);

      const log: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: 'BOOK_DELETE',
        message: `Deregistered Book: "${bookToDelete.title}"`,
        details: `Removed all catalog registers for ISBN ${bookToDelete.isbn}.`
      };

      const updatedLogs = [log, ...activityLogs];

      setBooks(updatedBooks);
      setActivityLogs(updatedLogs);
      saveToStorage(updatedBooks, patrons, loans, updatedLogs);
      addToast(`"${bookToDelete.title}" removed from database.`, 'info');
    }
  };

  // 6. Circulation Actions (Loan / Return)
  const handleConfirmLoan = (bookId: string, patronId: string, dueDate: string, notes: string) => {
    const book = books.find((b) => b.id === bookId);
    const patron = patrons.find((p) => p.id === patronId);

    if (!book || !patron) return;

    if (book.availableCopies <= 0) {
      addToast('No physical copies available for circulation.', 'warning');
      return;
    }

    // Create loan object
    const newLoan: Loan = {
      id: `loan-${Date.now()}`,
      bookId,
      patronId,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate,
      returnDate: null,
      status: 'ACTIVE',
      notes: notes.trim() ? notes.trim() : null
    };

    // Decrement available copies
    const updatedBooks = books.map((b) =>
      b.id === bookId ? { ...b, availableCopies: b.availableCopies - 1 } : b
    );

    const updatedLoans = [newLoan, ...loans];

    const log: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'LOAN_ISSUE',
      message: `Checked Out: "${book.title}"`,
      details: `Circulation desk issued copy to member ${patron.name} (${patron.membershipId}) until ${dueDate}.`
    };

    const updatedLogs = [log, ...activityLogs];

    setBooks(updatedBooks);
    setLoans(updatedLoans);
    setActivityLogs(updatedLogs);
    saveToStorage(updatedBooks, patrons, updatedLoans, updatedLogs);
    addToast(`Book checked out successfully!`);
  };

  const handleReturnBook = (loanId: string) => {
    const loan = loans.find((l) => l.id === loanId);
    if (!loan) return;

    const book = books.find((b) => b.id === loan.bookId);
    const patron = patrons.find((p) => p.id === loan.patronId);

    const todayStr = new Date().toISOString().split('T')[0];

    // Mark loan as returned
    const updatedLoans = loans.map((l) =>
      l.id === loanId ? { ...l, status: 'RETURNED' as const, returnDate: todayStr } : l
    );

    // Increment available copies
    const updatedBooks = books.map((b) =>
      b.id === loan.bookId ? { ...b, availableCopies: Math.min(b.totalCopies, b.availableCopies + 1) } : b
    );

    const log: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'LOAN_RETURN',
      message: `Book Returned: "${book?.title || 'Unknown Book'}"`,
      details: `Returned by member ${patron?.name || 'Unknown'} (${patron?.membershipId || 'N/A'}) to circulation desks.`
    };

    const updatedLogs = [log, ...activityLogs];

    setBooks(updatedBooks);
    setLoans(updatedLoans);
    setActivityLogs(updatedLogs);
    saveToStorage(updatedBooks, patrons, updatedLoans, updatedLogs);
    addToast(`Book returned and inventory restocked!`);
  };

  const handleClearReturnedLoans = (patronId?: string) => {
    const confirmMessage = patronId
      ? 'Are you sure you want to clear your returned books history?'
      : 'Are you sure you want to permanently purge all inactive returned loans from the ledger?';

    if (window.confirm(confirmMessage)) {
      const updatedLoans = loans.filter((l) => {
        if (l.status !== 'RETURNED') return true;
        if (patronId && l.patronId !== patronId) return true;
        return false;
      });

      const log: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: 'LOAN_RETURN',
        message: patronId ? 'Cleared Student Reading Log' : 'Purged Inactive Loan Records',
        details: patronId
          ? `Student cleared returned books history from personal account.`
          : 'Staff purged returned circulation entries from central registers to optimize indexes.'
      };

      const updatedLogs = [log, ...activityLogs];
      setLoans(updatedLoans);
      setActivityLogs(updatedLogs);
      saveToStorage(books, patrons, updatedLoans, updatedLogs);
      addToast(patronId ? 'Returned books logs cleared!' : 'All inactive returned loans purged successfully!');
    }
  };

  const handleRenewLoan = (loanId: string, days: number) => {
    const loan = loans.find((l) => l.id === loanId);
    if (!loan) return;

    const book = books.find((b) => b.id === loan.bookId);
    const patron = patrons.find((p) => p.id === loan.patronId);

    // Calculate new extended due date
    const currentDue = new Date(loan.dueDate);
    currentDue.setDate(currentDue.getDate() + days);
    const newDueDateStr = currentDue.toISOString().split('T')[0];

    const updatedLoans = loans.map((l) =>
      l.id === loanId ? { ...l, dueDate: newDueDateStr, status: 'ACTIVE' as const } : l
    );

    const log: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'LOAN_RENEW',
      message: `Extended Loan: "${book?.title || 'Unknown Book'}"`,
      details: `Extended return due date by ${days} days for member ${patron?.name || 'Unknown'}. New deadline: ${newDueDateStr}.`
    };

    const updatedLogs = [log, ...activityLogs];

    setLoans(updatedLoans);
    setActivityLogs(updatedLogs);
    saveToStorage(books, patrons, updatedLoans, updatedLogs);
    addToast(`Extended checkout window for "${book?.title || 'Book'}"!`);
  };

  const handleSendOverdueReminder = (loanId: string) => {
    const loan = loans.find((l) => l.id === loanId);
    if (!loan) return;

    const patron = patrons.find((p) => p.id === loan.patronId);
    const book = books.find((b) => b.id === loan.bookId);

    if (!patron || !book) return;

    // Record activity
    const log: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'LOAN_RENEW',
      message: `Overdue Email Sent: "${book.title}"`,
      details: `Dispatched warning dispatch email to ${patron.email} for overdue book checkout.`
    };

    const updatedLogs = [log, ...activityLogs];
    setActivityLogs(updatedLogs);
    saveToStorage(books, patrons, loans, updatedLogs);
    addToast(`Dispatched warning email notice to ${patron.name}!`, 'info');
  };

  // 7. Patron Actions
  const handleAddPatron = (patronFields: Omit<Patron, 'id' | 'joinDate'>) => {
    const newPatron: Patron = {
      ...patronFields,
      id: `patron-${Date.now()}`,
      joinDate: new Date().toISOString().split('T')[0]
    };

    const updatedPatrons = [...patrons, newPatron];

    const log: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      type: 'PATRON_ADD',
      message: `Registered Patron: ${newPatron.name}`,
      details: `Created database account file. Assigned library ID ${newPatron.membershipId}.`
    };

    const updatedLogs = [log, ...activityLogs];

    setPatrons(updatedPatrons);
    setActivityLogs(updatedLogs);
    saveToStorage(books, updatedPatrons, loans, updatedLogs);
    addToast(`Registered library borrower card for "${newPatron.name}".`);
  };

  // If user is not authenticated, show the login page
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col font-sans">
        <LoginPage patrons={patrons} onLogin={handleLogin} currentTime={currentTime} />

        {/* Floating dynamic status toast announcements */}
        <div className="fixed bottom-5 right-5 space-y-2 z-50 max-w-sm pointer-events-none">
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className={`p-4 rounded-xl shadow-xl border flex items-start gap-3 pointer-events-auto bg-white transition-all duration-300 transform translate-y-0 ${
                toast.type === 'warning'
                  ? 'border-rose-100 text-rose-950 shadow-rose-100/10'
                  : toast.type === 'info'
                  ? 'border-sky-100 text-sky-950 shadow-sky-100/10'
                  : 'border-emerald-100 text-emerald-950 shadow-emerald-100/10'
              }`}
            >
              {toast.type === 'warning' ? (
                <AlertTriangle className="h-5 w-5 text-rose-500 shrink-0" />
              ) : toast.type === 'info' ? (
                <Info className="h-5 w-5 text-sky-500 shrink-0" />
              ) : (
                <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0" />
              )}
              <div className="text-xs font-semibold leading-normal">{toast.message}</div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // If user is logged in as student, show student portal
  if (currentUser.role === 'STUDENT') {
    return (
      <div className="min-h-screen bg-slate-50/70 flex flex-col font-sans">
        <StudentPortal
          books={books}
          loans={loans}
          patronId={currentUser.patronId!}
          patrons={patrons}
          onBorrowBook={(bookId) => {
            const dueDate = new Date();
            dueDate.setDate(dueDate.getDate() + 14);
            const dueDateStr = dueDate.toISOString().split('T')[0];
            handleConfirmLoan(bookId, currentUser.patronId!, dueDateStr, 'Self check-out via Student Portal');
          }}
          onRenewLoan={handleRenewLoan}
          onReturnBook={handleReturnBook}
          onClearReturnedLoans={handleClearReturnedLoans}
          onLogOut={handleLogOut}
          currentTime={currentTime}
        />

        {/* Floating dynamic status toast announcements */}
        <div className="fixed bottom-5 right-5 space-y-2 z-50 max-w-sm pointer-events-none">
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className={`p-4 rounded-xl shadow-xl border flex items-start gap-3 pointer-events-auto bg-white transition-all duration-300 transform translate-y-0 ${
                toast.type === 'warning'
                  ? 'border-rose-100 text-rose-950 shadow-rose-100/10'
                  : toast.type === 'info'
                  ? 'border-sky-100 text-sky-950 shadow-sky-100/10'
                  : 'border-emerald-100 text-emerald-950 shadow-emerald-100/10'
              }`}
            >
              {toast.type === 'warning' ? (
                <AlertTriangle className="h-5 w-5 text-rose-500 shrink-0" />
              ) : toast.type === 'info' ? (
                <Info className="h-5 w-5 text-sky-500 shrink-0" />
              ) : (
                <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0" />
              )}
              <div className="text-xs font-semibold leading-normal">{toast.message}</div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Render full librarian/staff portal with sticky top horizontal navigation menu bar
  return (
    <div className="min-h-screen bg-slate-50/70 text-slate-800 flex flex-col font-sans selection:bg-indigo-100">
      
      {/* Horizontal Sticky Top Menu Bar */}
      <header className="sticky top-0 z-40 w-full bg-slate-950 text-slate-200 border-b border-slate-800 shadow-md shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Brand Logo & Title */}
            <div className="flex items-center gap-3">
              <div className="p-1.5 bg-indigo-600 rounded-lg text-white">
                <BookMarked className="h-5 w-5" />
              </div>
              <div>
                <h1 className="font-bold text-white text-sm font-display tracking-tight leading-tight">BiblioShelf</h1>
                <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Staff Console</p>
              </div>
            </div>

            {/* Horizontal Navigation Menu Tabs (Desktop) */}
            <nav className="hidden md:flex items-center space-x-1.5">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'dashboard'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <LayoutDashboard className="h-4 w-4" /> Dashboard
              </button>

              <button
                onClick={() => setActiveTab('books')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'books'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <BookOpen className="h-4 w-4" /> Book Inventory
              </button>

              <button
                onClick={() => setActiveTab('loans')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'loans'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <ArrowRightLeft className="h-4 w-4" /> Circulation Desk
              </button>

              <button
                onClick={() => setActiveTab('patrons')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'patrons'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <Users className="h-4 w-4" /> Patron Registry
              </button>
            </nav>

            {/* Profile badge, clock, and logout */}
            <div className="hidden md:flex items-center gap-4">
              <div className="text-right">
                <p className="text-xs font-bold text-white leading-none">Admin Staff</p>
                <p className="text-[10px] font-mono text-slate-400 leading-none mt-1 font-bold">
                  Clearance Level 1
                </p>
              </div>

              <div className="h-8 w-px bg-slate-800" />

              <button
                onClick={handleLogOut}
                className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-900 rounded-lg transition-all duration-200 cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="h-4.5 w-4.5" />
              </button>
            </div>

            {/* Mobile hamburger button */}
            <div className="flex items-center md:hidden gap-3">
              <button
                onClick={handleLogOut}
                className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg cursor-pointer"
              >
                <LogOut className="h-4.5 w-4.5" />
              </button>
              <button
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="p-1.5 text-slate-400 hover:text-white bg-slate-900 rounded-lg cursor-pointer animate-fade-in"
              >
                {isSidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>

          </div>
        </div>

        {/* Mobile Navigation Dropdown Menu */}
        {isSidebarOpen && (
          <div className="md:hidden bg-slate-950 border-t border-slate-800/80 px-4 py-3 space-y-2">
            <button
              onClick={() => {
                setActiveTab('dashboard');
                setIsSidebarOpen(false);
              }}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 ${
                activeTab === 'dashboard' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <LayoutDashboard className="h-4 w-4" /> Dashboard
            </button>
            <button
              onClick={() => {
                setActiveTab('books');
                setIsSidebarOpen(false);
              }}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 ${
                activeTab === 'books' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <BookOpen className="h-4 w-4" /> Book Inventory
            </button>
            <button
              onClick={() => {
                setActiveTab('loans');
                setIsSidebarOpen(false);
              }}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 ${
                activeTab === 'loans' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <ArrowRightLeft className="h-4 w-4" /> Circulation Desk
            </button>
            <button
              onClick={() => {
                setActiveTab('patrons');
                setIsSidebarOpen(false);
              }}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 ${
                activeTab === 'patrons' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Users className="h-4 w-4" /> Patron Registry
            </button>
          </div>
        )}
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Top Navbar details */}
        <header className="bg-white border-b border-slate-200/55 px-6 py-4 flex justify-between items-center shrink-0 max-w-7xl w-full mx-auto">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
              Systems Console
            </span>
            <span className="text-slate-300 text-sm">/</span>
            <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider capitalize">
              {activeTab}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-slate-400 font-mono text-[11px] font-bold bg-slate-50 border border-slate-200/50 px-2.5 py-1.5 rounded-lg shrink-0">
              <span>Local Time:</span>
              <span className="text-slate-700">{currentTime || '14:20:00 UTC'}</span>
            </div>

            <button
              onClick={handleResetData}
              id="btn-factory-reset"
              className="flex items-center gap-1.5 px-3 py-1.5 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-200 rounded-lg text-xs font-bold text-slate-500 transition-all duration-200 cursor-pointer border border-slate-200"
              title="Reset Application"
            >
              <RotateCcw className="h-3.5 w-3.5" /> Factory Reset
            </button>
          </div>
        </header>

        {/* Central Content Panel */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <Dashboard
              books={books}
              patrons={patrons}
              loans={loans}
              logs={activityLogs}
              onNavigate={setActiveTab}
              onReturnBook={handleReturnBook}
            />
          )}

          {activeTab === 'books' && (
            <BookInventory
              books={books}
              onAddBook={handleAddBook}
              onEditBook={handleEditBook}
              onDeleteBook={handleDeleteBook}
              onIssueLoanClick={setCheckoutBook}
            />
          )}

          {activeTab === 'loans' && (
            <LoanTracker
              loans={loans}
              books={books}
              patrons={patrons}
              onReturnBook={handleReturnBook}
              onRenewLoan={handleRenewLoan}
              onSendOverdueReminder={handleSendOverdueReminder}
              onNavigateToBooks={() => setActiveTab('books')}
              onClearReturnedLoans={() => handleClearReturnedLoans()}
            />
          )}

          {activeTab === 'patrons' && (
            <PatronManager
              patrons={patrons}
              loans={loans}
              books={books}
              onAddPatron={handleAddPatron}
            />
          )}
        </div>
      </main>

      {/* Circulation checkout dialog modal */}
      {checkoutBook && (
        <LoanModal
          book={checkoutBook}
          patrons={patrons}
          onClose={() => setCheckoutBook(null)}
          onConfirmLoan={handleConfirmLoan}
        />
      )}

      {/* Floating dynamic status toast announcements */}
      <div className="fixed bottom-5 right-5 space-y-2 z-50 max-w-sm pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`p-4 rounded-xl shadow-xl border flex items-start gap-3 pointer-events-auto bg-white transition-all duration-300 transform translate-y-0 ${
              toast.type === 'warning'
                ? 'border-rose-100 text-rose-950 shadow-rose-100/10'
                : toast.type === 'info'
                ? 'border-sky-100 text-sky-950 shadow-sky-100/10'
                : 'border-emerald-100 text-emerald-950 shadow-emerald-100/10'
            }`}
          >
            {toast.type === 'warning' ? (
              <AlertTriangle className="h-5 w-5 text-rose-500 shrink-0" />
            ) : toast.type === 'info' ? (
              <Info className="h-5 w-5 text-sky-500 shrink-0" />
            ) : (
              <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0" />
            )}
            <div className="text-xs font-semibold leading-normal">{toast.message}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
