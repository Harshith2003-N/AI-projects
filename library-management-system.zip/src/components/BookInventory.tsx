import React, { useState } from 'react';
import { Book } from '../types';
import { CATEGORIES } from '../mockData';
import {
  Search,
  Filter,
  Plus,
  Edit,
  Trash2,
  MapPin,
  Barcode,
  CalendarDays,
  Sparkles,
  Info,
  BookOpen,
  ArrowRightLeft
} from 'lucide-react';

interface BookInventoryProps {
  books: Book[];
  onAddBook: (book: Omit<Book, 'id' | 'availableCopies'>) => void;
  onEditBook: (book: Book) => void;
  onDeleteBook: (id: string) => void;
  onIssueLoanClick: (book: Book) => void;
}

export default function BookInventory({
  books,
  onAddBook,
  onEditBook,
  onDeleteBook,
  onIssueLoanClick
}: BookInventoryProps) {
  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [availabilityFilter, setAvailabilityFilter] = useState<'ALL' | 'AVAILABLE'>('ALL');

  // Form states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);

  // Form fields
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [isbn, setIsbn] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [publishYear, setPublishYear] = useState<number>(2026);
  const [totalCopies, setTotalCopies] = useState<number>(3);
  const [location, setLocation] = useState('');
  const [coverUrl, setCoverUrl] = useState('');
  const [description, setDescription] = useState('');
  const [formError, setFormError] = useState('');

  // Handle open add form
  const handleOpenAdd = () => {
    setEditingBook(null);
    setTitle('');
    setAuthor('');
    setIsbn('');
    setCategory(CATEGORIES[0]);
    setPublishYear(new Date().getFullYear());
    setTotalCopies(3);
    setLocation('');
    setCoverUrl('');
    setDescription('');
    setFormError('');
    setIsFormOpen(true);
  };

  // Handle open edit form
  const handleOpenEdit = (book: Book) => {
    setEditingBook(book);
    setTitle(book.title);
    setAuthor(book.author);
    setIsbn(book.isbn);
    setCategory(book.category);
    setPublishYear(book.publishYear);
    setTotalCopies(book.totalCopies);
    setLocation(book.location);
    setCoverUrl(book.coverUrl);
    setDescription(book.description);
    setFormError('');
    setIsFormOpen(true);
  };

  // Handle submit form
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim() || !author.trim() || !isbn.trim() || !location.trim()) {
      setFormError('Please fill out all required fields (*).');
      return;
    }

    if (totalCopies <= 0) {
      setFormError('Total copies must be at least 1.');
      return;
    }

    // Assign default fallback book cover if empty
    const finalCoverUrl = coverUrl.trim()
      ? coverUrl.trim()
      : `https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=400`;

    if (editingBook) {
      // Calculate new available copies based on change in totalCopies
      const checkedOutCopies = editingBook.totalCopies - editingBook.availableCopies;
      const newAvailable = Math.max(0, totalCopies - checkedOutCopies);

      onEditBook({
        ...editingBook,
        title,
        author,
        isbn,
        category,
        publishYear,
        totalCopies,
        availableCopies: newAvailable,
        location,
        coverUrl: finalCoverUrl,
        description
      });
    } else {
      onAddBook({
        title,
        author,
        isbn,
        category,
        publishYear,
        totalCopies,
        location,
        coverUrl: finalCoverUrl,
        description
      });
    }

    setIsFormOpen(false);
  };

  // Filter logic
  const filteredBooks = books.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.isbn.includes(searchQuery) ||
      book.description.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'All' || book.category === selectedCategory;
    const matchesAvailability = availabilityFilter === 'ALL' || book.availableCopies > 0;

    return matchesSearch && matchesCategory && matchesAvailability;
  });

  const generateMockISBN = () => {
    const randomNum = Math.floor(1000000000000 + Math.random() * 9000000000000);
    setIsbn(randomNum.toString());
  };

  return (
    <div className="space-y-6">
      {/* Header and Add Button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 font-display">Book Catalog</h2>
          <p className="text-slate-500 text-sm">List, update, search, or checkout cataloged book items.</p>
        </div>
        <button
          onClick={handleOpenAdd}
          id="btn-add-book-catalog"
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-semibold transition-all duration-200 shadow-md shadow-indigo-600/10 flex items-center gap-1.5 cursor-pointer self-stretch sm:self-auto justify-center active:scale-95"
        >
          <Plus className="h-4.5 w-4.5" /> Catalog New Book
        </button>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200/50 flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by title, author, ISBN, details..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50/70 border border-slate-200 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 focus:bg-white transition-all duration-200"
          />
        </div>

        {/* Dropdown Filters */}
        <div className="flex flex-wrap gap-2">
          {/* Category Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5">
            <Filter className="h-3.5 w-3.5 text-slate-500" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-transparent border-none text-xs font-bold text-slate-700 focus:outline-hidden cursor-pointer"
            >
              <option value="All">All Categories</option>
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Availability Switch */}
          <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200">
            <button
              onClick={() => setAvailabilityFilter('ALL')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all duration-200 cursor-pointer ${
                availabilityFilter === 'ALL'
                  ? 'bg-white text-slate-800 shadow-xs'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Show All
            </button>
            <button
              onClick={() => setAvailabilityFilter('AVAILABLE')}
              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all duration-200 cursor-pointer ${
                availabilityFilter === 'AVAILABLE'
                  ? 'bg-white text-slate-800 shadow-xs'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Available Only
            </button>
          </div>
        </div>
      </div>

      {/* Books Card Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredBooks.map((book) => {
          const checkOutRate = book.totalCopies - book.availableCopies;
          const isOut = book.availableCopies === 0;
          const isLow = book.availableCopies > 0 && book.availableCopies <= 1;

          return (
            <div
              key={book.id}
              className="bg-white rounded-xl border border-slate-200/50 overflow-hidden shadow-xs hover:shadow-lg hover:border-slate-300/80 transition-all duration-300 flex flex-col group"
            >
              {/* Cover Image & Category Badge */}
              <div className="relative h-48 bg-slate-100 overflow-hidden shrink-0">
                <img
                  src={book.coverUrl}
                  alt={book.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <span className="absolute top-3 left-3 px-2.5 py-1 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold uppercase rounded-md tracking-wider">
                  {book.category}
                </span>

                {/* Shelf Location Code Overlay */}
                <div className="absolute bottom-3 left-3 flex items-center gap-1 text-white text-xs font-semibold">
                  <MapPin className="h-3.5 w-3.5 text-indigo-400" />
                  <span>{book.location}</span>
                </div>

                {/* Copies Pill */}
                <div className="absolute top-3 right-3">
                  {isOut ? (
                    <span className="px-2.5 py-1 bg-rose-600/90 backdrop-blur-xs text-white text-[9px] font-bold rounded-md uppercase tracking-wider font-mono">
                      Checked Out
                    </span>
                  ) : isLow ? (
                    <span className="px-2.5 py-1 bg-amber-500/90 backdrop-blur-xs text-white text-[9px] font-bold rounded-md uppercase tracking-wider font-mono">
                      1 Copy Left
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 bg-emerald-600/95 backdrop-blur-xs text-white text-[9px] font-bold rounded-md uppercase tracking-wider font-mono">
                      {book.availableCopies} Available
                    </span>
                  )}
                </div>
              </div>

              {/* Book Details */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-start gap-2">
                    <h3 className="font-bold text-slate-900 group-hover:text-indigo-600 transition-all duration-200 font-display line-clamp-1">
                      {book.title}
                    </h3>
                  </div>
                  <p className="text-slate-500 text-xs font-semibold">By {book.author}</p>
                  <p className="text-slate-600 text-xs leading-relaxed line-clamp-3">
                    {book.description || 'No description cataloged for this book volume.'}
                  </p>
                </div>

                {/* Shelf metadata & Actions */}
                <div className="space-y-3.5 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                    <span className="flex items-center gap-1">
                      <Barcode className="h-3.5 w-3.5 text-slate-300" /> {book.isbn}
                    </span>
                    <span className="flex items-center gap-1">
                      <CalendarDays className="h-3.5 w-3.5 text-slate-300" /> Pub {book.publishYear}
                    </span>
                  </div>

                  {/* Stock counter helper bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] text-slate-400 font-semibold uppercase tracking-wider font-mono">
                      <span>Utilization</span>
                      <span>
                        {checkOutRate} of {book.totalCopies} out
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-indigo-600 h-full rounded-full transition-all"
                        style={{ width: `${(checkOutRate / book.totalCopies) * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* Operational Buttons */}
                  <div className="flex justify-between items-center gap-2 pt-1">
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(book)}
                        title="Edit Book Details"
                        className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-50 border border-slate-200 rounded-lg transition-all duration-200 cursor-pointer active:scale-95"
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteBook(book.id)}
                        title="Deregister Book"
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 hover:border-rose-100 rounded-lg transition-all duration-200 cursor-pointer active:scale-95"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    <button
                      onClick={() => onIssueLoanClick(book)}
                      disabled={isOut}
                      className={`px-3 py-1.5 text-xs font-bold rounded-lg flex items-center gap-1 transition-all duration-200 ${
                        isOut
                          ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200/60'
                          : 'bg-indigo-50 hover:bg-indigo-600 text-indigo-700 hover:text-white border border-indigo-100 hover:border-indigo-600 cursor-pointer shadow-xs active:scale-95'
                      }`}
                    >
                      <ArrowRightLeft className="h-3.5 w-3.5" /> Issue Book
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {filteredBooks.length === 0 && (
          <div className="col-span-full bg-slate-50 border border-slate-200 border-dashed rounded-2xl py-16 text-center space-y-3">
            <BookOpen className="h-10 w-10 text-slate-400 mx-auto" />
            <h3 className="font-semibold text-slate-800">No matching books found</h3>
            <p className="text-slate-500 text-xs max-w-sm mx-auto">
              Adjust your search keywords, clear the filter chips, or add a brand new book to our shelves.
            </p>
            <button
              onClick={handleOpenAdd}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium transition cursor-pointer"
            >
              Catalog first book
            </button>
          </div>
        )}
      </div>

      {/* Book Form Dialog Overlay */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl w-full max-w-xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col my-8">
            {/* Form Title banner */}
            <div className="bg-slate-900 px-6 py-4 text-white flex justify-between items-center">
              <div>
                <h3 className="font-bold text-lg font-display">
                  {editingBook ? 'Modify Catalog Entry' : 'Catalog New Book Volume'}
                </h3>
                <p className="text-slate-400 text-xs mt-0.5">
                  {editingBook ? `Refining entry: ${editingBook.title}` : 'Input official bibliographic indicators'}
                </p>
              </div>
              <button
                onClick={() => setIsFormOpen(false)}
                className="text-slate-400 hover:text-white text-xl font-bold cursor-pointer transition"
              >
                &times;
              </button>
            </div>

            {/* Scrollable Form Body */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto max-h-[70vh]">
              {formError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-lg font-medium flex items-center gap-2">
                  <Info className="h-4 w-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Grid 1: Title & Author */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 block">Book Title *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sapiens"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 block">Author *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Yuval Noah Harari"
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                  />
                </div>
              </div>

              {/* Grid 2: ISBN & Category */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-semibold text-slate-700">ISBN Code *</label>
                    <button
                      type="button"
                      onClick={generateMockISBN}
                      className="text-[10px] font-semibold text-indigo-600 hover:text-indigo-500 flex items-center gap-0.5 cursor-pointer"
                    >
                      <Sparkles className="h-3 w-3" /> Auto ISBN
                    </button>
                  </div>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 9780062316097"
                    value={isbn}
                    onChange={(e) => setIsbn(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm font-mono text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 block">Category *</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition cursor-pointer"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Grid 3: Publish Year, Total Copies, Shelf Location */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 block">Publish Year</label>
                  <input
                    type="number"
                    min="1"
                    max="2030"
                    value={publishYear}
                    onChange={(e) => setPublishYear(parseInt(e.target.value) || 2026)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 block">Total Copies *</label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={totalCopies}
                    onChange={(e) => setTotalCopies(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 block">Shelf Location *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Shelf T-3"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                  />
                </div>
              </div>

              {/* Image URL Input */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 block">Cover Image URL (Optional)</label>
                <input
                  type="url"
                  placeholder="Paste cover art image url..."
                  value={coverUrl}
                  onChange={(e) => setCoverUrl(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                />
              </div>

              {/* Description Input */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 block">Description / Synopsis</label>
                <textarea
                  rows={3}
                  placeholder="Provide bibliographic description or a brief synopsis of the book content..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition resize-none"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 text-sm font-semibold rounded-lg transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="btn-save-book"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg transition cursor-pointer shadow-md"
                >
                  Save Book
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
