import React, { useState } from 'react';
import { Book, Patron, Loan, ActivityLog } from '../types';
import {
  BookOpen,
  Users,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Clock,
  ArrowRightLeft,
  ChevronRight,
  TrendingUp,
  FileText
} from 'lucide-react';

interface DashboardProps {
  books: Book[];
  patrons: Patron[];
  loans: Loan[];
  logs: ActivityLog[];
  onNavigate: (tab: string) => void;
  onReturnBook: (loanId: string) => void;
}

export default function Dashboard({
  books,
  patrons,
  loans,
  logs,
  onNavigate,
  onReturnBook
}: DashboardProps) {
  // Calculations
  const totalBooks = books.reduce((sum, b) => sum + b.totalCopies, 0);
  const distinctTitles = books.length;
  const activeLoans = loans.filter((l) => l.status === 'ACTIVE' || l.status === 'OVERDUE');
  const overdueLoans = loans.filter((l) => l.status === 'OVERDUE');
  const availableCopies = books.reduce((sum, b) => sum + b.availableCopies, 0);
  const totalPatrons = patrons.length;

  // Percentage stats
  const checkoutRate = totalBooks > 0 ? Math.round(((totalBooks - availableCopies) / totalBooks) * 100) : 0;
  const healthRate = activeLoans.length > 0 ? Math.round(((activeLoans.length - overdueLoans.length) / activeLoans.length) * 100) : 100;

  // Category breakdown
  const categoryStats = books.reduce((acc, book) => {
    acc[book.category] = (acc[book.category] || 0) + book.totalCopies;
    return acc;
  }, {} as Record<string, number>);

  const sortedCategories = Object.entries(categoryStats)
    .map(([name, count]) => ({ name, count, percent: totalBooks > 0 ? Math.round((count / totalBooks) * 100) : 0 }))
    .sort((a, b) => b.count - a.count);

  // List overdue or critical loans
  const criticalLoans = loans
    .filter((l) => l.status === 'OVERDUE')
    .map((l) => {
      const book = books.find((b) => b.id === l.bookId);
      const patron = patrons.find((p) => p.id === l.patronId);
      return {
        ...l,
        bookTitle: book?.title || 'Unknown Book',
        patronName: patron?.name || 'Unknown Member'
      };
    })
    .slice(0, 4);

  // Near due loans (active loans due in next 4 days)
  const today = new Date();
  const nearDueLoans = loans
    .filter((l) => {
      if (l.status !== 'ACTIVE') return false;
      const dueDate = new Date(l.dueDate);
      const diffTime = dueDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays >= 0 && diffDays <= 4;
    })
    .map((l) => {
      const book = books.find((b) => b.id === l.bookId);
      const patron = patrons.find((p) => p.id === l.patronId);
      const diffTime = new Date(l.dueDate).getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return {
        ...l,
        bookTitle: book?.title || 'Unknown Book',
        patronName: patron?.name || 'Unknown Member',
        daysLeft: diffDays
      };
    })
    .sort((a, b) => a.daysLeft - b.daysLeft);

  const formatTimeAgo = (timestampString: string) => {
    const time = new Date(timestampString).getTime();
    const now = Date.now();
    const diffSec = Math.floor((now - time) / 1000);
    if (diffSec < 60) return 'Just now';
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin}m ago`;
    const diffHr = Math.floor(diffMin / 60);
    if (diffHr < 24) return `${diffHr}h ago`;
    const diffDay = Math.floor(diffHr / 24);
    return `${diffDay}d ago`;
  };

  const getLogIcon = (type: string) => {
    switch (type) {
      case 'LOAN_ISSUE':
        return <ArrowRightLeft className="h-4 w-4 text-indigo-500" />;
      case 'LOAN_RETURN':
        return <CheckCircle className="h-4 w-4 text-emerald-500" />;
      case 'BOOK_ADD':
        return <BookOpen className="h-4 w-4 text-sky-500" />;
      case 'PATRON_ADD':
        return <Users className="h-4 w-4 text-amber-500" />;
      default:
        return <FileText className="h-4 w-4 text-slate-500" />;
    }
  };

  const getLogBg = (type: string) => {
    switch (type) {
      case 'LOAN_ISSUE':
        return 'bg-indigo-50 border-indigo-100';
      case 'LOAN_RETURN':
        return 'bg-emerald-50 border-emerald-100';
      case 'BOOK_ADD':
        return 'bg-sky-50 border-sky-100';
      case 'PATRON_ADD':
        return 'bg-amber-50 border-amber-100';
      default:
        return 'bg-slate-50 border-slate-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 p-6 md:p-8 rounded-2xl text-white shadow-lg border border-slate-800/80">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold font-display tracking-tight text-white">Library Central Dashboard</h1>
          <p className="text-slate-300 text-sm mt-1.5 max-w-2xl leading-relaxed">
            Real-time management of catalog inventory, active patron loans, and library circulation schedules.
          </p>
        </div>
        <div className="flex gap-2.5 shrink-0 self-stretch sm:self-auto">
          <button
            onClick={() => onNavigate('books')}
            id="db-btn-add-book"
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-semibold transition-all duration-200 shadow-md shadow-indigo-600/10 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
          >
            <BookOpen className="h-4 w-4" /> Manage Catalog
          </button>
          <button
            onClick={() => onNavigate('loans')}
            id="db-btn-issue-loan"
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-lg text-sm font-semibold transition-all duration-200 border border-slate-700 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
          >
            <ArrowRightLeft className="h-4 w-4" /> Circulation Desk
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="bg-white p-5 rounded-xl shadow-xs border border-slate-200/50 hover:shadow-md hover:border-slate-200 transition-all duration-300">
          <div className="flex justify-between items-start">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">Book Inventory</p>
            <div className="p-2.5 bg-indigo-50 border border-indigo-100/50 rounded-lg text-indigo-600">
              <BookOpen className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="mt-4">
            <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">{totalBooks}</h3>
            <p className="text-xs text-slate-500 mt-1.5 flex items-center gap-1">
              <span className="font-semibold text-indigo-600">{distinctTitles}</span> unique titles cataloged
            </p>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-white p-5 rounded-xl shadow-xs border border-slate-200/50 hover:shadow-md hover:border-slate-200 transition-all duration-300">
          <div className="flex justify-between items-start">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">Circulating (Active)</p>
            <div className="p-2.5 bg-sky-50 border border-sky-100/50 rounded-lg text-sky-600">
              <ArrowRightLeft className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="mt-4">
            <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">{activeLoans.length}</h3>
            <p className="text-xs text-slate-500 mt-1.5 flex items-center gap-1">
              <span className="font-semibold text-sky-600">{checkoutRate}%</span> copies checked out currently
            </p>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-white p-5 rounded-xl shadow-xs border border-slate-200/50 hover:shadow-md hover:border-slate-200 transition-all duration-300">
          <div className="flex justify-between items-start">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">Overdue Notices</p>
            <div className="p-2.5 bg-rose-50 border border-rose-100/50 rounded-lg text-rose-600">
              <AlertTriangle className={`h-4.5 w-4.5 ${overdueLoans.length > 0 ? 'text-rose-600 animate-pulse' : 'text-slate-400'}`} />
            </div>
          </div>
          <div className="mt-4">
            <h3 className={`text-3xl font-extrabold tracking-tight ${overdueLoans.length > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
              {overdueLoans.length}
            </h3>
            <p className="text-xs text-slate-500 mt-1.5 flex items-center gap-1">
              <span className={`font-semibold ${overdueLoans.length > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                {healthRate}%
              </span> loan health compliance rate
            </p>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-white p-5 rounded-xl shadow-xs border border-slate-200/50 hover:shadow-md hover:border-slate-200 transition-all duration-300">
          <div className="flex justify-between items-start">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">Active Patrons</p>
            <div className="p-2.5 bg-amber-50 border border-amber-100/50 rounded-lg text-amber-600">
              <Users className="h-4.5 w-4.5" />
            </div>
          </div>
          <div className="mt-4">
            <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">{totalPatrons}</h3>
            <p className="text-xs text-slate-500 mt-1.5">
              Registered library members in database
            </p>
          </div>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Left Columns (Inventory Categories & Alert Panels) */}
        <div className="xl:col-span-2 space-y-6">
          {/* Overdue Alert Panel */}
          {overdueLoans.length > 0 && (
            <div className="bg-rose-50/40 border border-rose-100 p-6 rounded-xl shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-rose-600 animate-bounce shrink-0" />
                <h3 className="font-bold text-rose-950 font-display">Action Required: Overdue Items Pending</h3>
              </div>
              <p className="text-rose-800 text-sm leading-relaxed">
                There are {overdueLoans.length} active loan agreements that have passed their return deadline. Immediate recovery processing is recommended.
              </p>
              <div className="divide-y divide-rose-100 mt-3 bg-white rounded-xl border border-rose-200/60 overflow-hidden shadow-xs">
                {criticalLoans.map((loan) => (
                  <div key={loan.id} className="p-4 flex justify-between items-center text-xs gap-4 hover:bg-rose-50/25 transition">
                    <div className="min-w-0">
                      <p className="font-bold text-slate-900 truncate">{loan.bookTitle}</p>
                      <p className="text-slate-500 mt-1">
                        Borrowed by <span className="font-semibold text-slate-700">{loan.patronName}</span> • Due on{' '}
                        <span className="font-bold text-rose-600 font-mono">{loan.dueDate}</span>
                      </p>
                    </div>
                    <button
                      onClick={() => onReturnBook(loan.id)}
                      className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold transition-all duration-200 cursor-pointer shadow-sm active:scale-95"
                    >
                      Process Return
                    </button>
                  </div>
                ))}
              </div>
              <div className="text-right pt-1">
                <button
                  onClick={() => onNavigate('loans')}
                  className="text-xs font-bold text-rose-700 hover:text-rose-600 inline-flex items-center gap-0.5"
                >
                  View all circulation logs <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* Near Due Notifications */}
          {nearDueLoans.length > 0 && (
            <div className="bg-amber-50/40 border border-amber-100 p-6 rounded-xl shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-amber-600 shrink-0" />
                <h3 className="font-bold text-amber-950 font-display">Attention: Loans Due within 96 Hours</h3>
              </div>
              <div className="divide-y divide-amber-100 bg-white rounded-xl border border-amber-200/60 overflow-hidden shadow-xs">
                {nearDueLoans.map((loan) => (
                  <div key={loan.id} className="p-4 flex justify-between items-center text-xs gap-4 hover:bg-amber-50/25 transition">
                    <div className="min-w-0">
                      <p className="font-bold text-slate-900 truncate">{loan.bookTitle}</p>
                      <p className="text-slate-500 mt-1">
                        Patron: <span className="font-semibold text-slate-700">{loan.patronName}</span> • Return date:{' '}
                        <span className="font-semibold text-slate-800 font-mono">{loan.dueDate}</span>
                      </p>
                    </div>
                    <span className="px-2.5 py-1 bg-amber-100 text-amber-800 font-bold rounded-full text-[10px] uppercase tracking-wider font-mono">
                      {loan.daysLeft === 0 ? 'Due Today' : `In ${loan.daysLeft} Day${loan.daysLeft > 1 ? 's' : ''}`}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Books Distribution by Category - Visual SVG Bars */}
          <div className="bg-white p-6 rounded-xl shadow-xs border border-slate-200/50">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h3 className="font-bold text-slate-900 text-lg font-display">Catalog Distribution</h3>
                <p className="text-slate-500 text-xs mt-0.5">Total volumes cataloged by specific literary genres.</p>
              </div>
              <span className="text-[10px] font-bold bg-indigo-50 border border-indigo-100/55 text-indigo-700 px-2.5 py-1 rounded-md uppercase tracking-wider font-mono flex items-center gap-1">
                <TrendingUp className="h-3 w-3" /> Live Ratio
              </span>
            </div>
            <div className="space-y-4">
              {sortedCategories.map((cat) => (
                <div key={cat.name} className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-700">{cat.name}</span>
                    <span className="text-slate-500 font-bold font-mono">
                      {cat.count} {cat.count === 1 ? 'copy' : 'copies'}{' '}
                      <span className="text-[11px] text-slate-400 font-normal font-sans">({cat.percent}%)</span>
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${cat.percent}%` }}
                    />
                  </div>
                </div>
              ))}
              {sortedCategories.length === 0 && (
                <div className="text-center py-6 text-slate-400 text-sm">
                  No books added yet. Go to catalog to populate shelves!
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column (Circulation Logs / Activities) */}
        <div className="bg-white p-6 rounded-2xl shadow-xs border border-slate-100 flex flex-col h-[600px] xl:h-auto">
          <div>
            <h3 className="font-bold text-slate-900 text-lg font-display">System Activities</h3>
            <p className="text-slate-500 text-xs mb-5">Latest desk transactions and book registrations.</p>
          </div>
          <div className="overflow-y-auto flex-1 space-y-4 pr-1">
            {logs.map((log) => (
              <div
                key={log.id}
                className={`p-3.5 rounded-xl border text-xs space-y-1.5 transition hover:shadow-xs ${getLogBg(
                  log.type
                )}`}
              >
                <div className="flex justify-between items-start gap-2">
                  <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                    {getLogIcon(log.type)}
                    <span className="truncate">{log.message}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-medium shrink-0">
                    {formatTimeAgo(log.timestamp)}
                  </span>
                </div>
                <p className="text-slate-600 leading-relaxed pl-5">{log.details}</p>
              </div>
            ))}
            {logs.length === 0 && (
              <div className="text-center py-12 text-slate-400 text-sm flex-1 flex flex-col justify-center">
                No recorded system transactions. Check out a book to start logging desk activity!
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
