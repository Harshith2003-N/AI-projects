import React, { useState } from 'react';
import { Book, Patron } from '../types';
import { Search, Calendar, Sparkles, BookMarked, UserCheck, AlertCircle } from 'lucide-react';

interface LoanModalProps {
  book: Book;
  patrons: Patron[];
  onClose: () => void;
  onConfirmLoan: (bookId: string, patronId: string, dueDate: string, notes: string) => void;
}

export default function LoanModal({ book, patrons, onClose, onConfirmLoan }: LoanModalProps) {
  const [selectedPatronId, setSelectedPatronId] = useState('');
  const [searchPatron, setSearchPatron] = useState('');

  // Default due date: 14 days in future
  const getFutureDateString = (days: number) => {
    const d = new Date();
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
  };

  const [dueDate, setDueDate] = useState(getFutureDateString(14));
  const [notes, setNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Filtered list of members for checkout selection
  const filteredPatrons = patrons.filter(
    (p) =>
      p.name.toLowerCase().includes(searchPatron.toLowerCase()) ||
      p.membershipId.toLowerCase().includes(searchPatron.toLowerCase()) ||
      p.email.toLowerCase().includes(searchPatron.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatronId) {
      setErrorMsg('Please select a library member (patron) to check out this book.');
      return;
    }

    const todayStr = new Date().toISOString().split('T')[0];
    if (dueDate < todayStr) {
      setErrorMsg('The due date cannot be in the past.');
      return;
    }

    onConfirmLoan(book.id, selectedPatronId, dueDate, notes);
    onClose();
  };

  const selectedPatron = patrons.find((p) => p.id === selectedPatronId);

  return (
    <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-white rounded-xl w-full max-w-2xl shadow-2xl border border-slate-200/60 overflow-hidden flex flex-col my-8">
        {/* Banner */}
        <div className="bg-slate-950 text-white px-6 py-4.5 flex justify-between items-center shrink-0 border-b border-slate-800">
          <div>
            <h3 className="font-bold text-lg font-display flex items-center gap-2">
              <BookMarked className="h-5 w-5 text-indigo-400" /> Book Circulation Desk
            </h3>
            <p className="text-slate-400 text-xs mt-0.5">Creating an active book loan authorization agreement</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xl font-bold cursor-pointer transition-all duration-200">
            &times;
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto max-h-[75vh]">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-lg font-medium flex items-center gap-2">
              <AlertCircle className="h-4.5 w-4.5 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Book Summary Card */}
          <div className="p-4 bg-slate-50/80 border border-slate-200 rounded-lg flex gap-4">
            <div className="h-16 w-12 bg-indigo-900 text-white font-bold text-xs rounded shadow-xs overflow-hidden shrink-0 flex items-center justify-center text-center p-1 leading-tight">
              {book.title.slice(0, 3).toUpperCase()}
            </div>
            <div>
              <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-100/50 px-2 py-0.5 rounded-sm uppercase tracking-wider">
                {book.category}
              </span>
              <h4 className="font-bold text-slate-900 text-sm mt-1">{book.title}</h4>
              <p className="text-xs text-slate-500">
                By {book.author} • <span className="font-mono text-slate-400">{book.isbn}</span>
              </p>
              <p className="text-xs text-emerald-600 font-bold mt-1">
                {book.availableCopies} of {book.totalCopies} copies available on shelf
              </p>
            </div>
          </div>

          {/* Grid: Member Selection and Due Date Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Left: Patron selection */}
            <div className="space-y-2.5 flex flex-col h-[280px]">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                1. Select Library Patron *
              </label>

              {/* Quick Filter Search */}
              <div className="relative shrink-0">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Filter members..."
                  value={searchPatron}
                  onChange={(e) => setSearchPatron(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 transition-all duration-200"
                />
              </div>

              {/* Members List Container */}
              <div className="flex-1 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-100 pr-1">
                {filteredPatrons.map((p) => {
                  const isSelected = selectedPatronId === p.id;
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => {
                        setSelectedPatronId(p.id);
                        setErrorMsg('');
                      }}
                      className={`w-full p-2.5 text-left text-xs transition cursor-pointer flex justify-between items-center ${
                        isSelected ? 'bg-indigo-50 text-indigo-900 font-bold' : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="min-w-0 pr-2">
                        <p className="truncate font-bold">{p.name}</p>
                        <p className="text-[10px] text-slate-400 truncate">{p.email}</p>
                      </div>
                      <span className="text-[9px] font-bold font-mono shrink-0 text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded-sm">
                        {p.membershipId}
                      </span>
                    </button>
                  );
                })}
                {filteredPatrons.length === 0 && (
                  <p className="p-4 text-center text-slate-400 text-xs italic">No registered members matched query.</p>
                )}
              </div>
            </div>

            {/* Right: Date selection & notes */}
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                  2. Choose Due Date *
                </label>
                <div className="flex gap-1.5 mb-2.5">
                  <button
                    type="button"
                    onClick={() => setDueDate(getFutureDateString(7))}
                    className="flex-1 py-1 px-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-md text-[11px] font-bold text-slate-600 transition-all duration-150 cursor-pointer active:scale-95"
                  >
                    7 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => setDueDate(getFutureDateString(14))}
                    className="flex-1 py-1 px-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-md text-[11px] font-bold text-slate-600 transition-all duration-150 cursor-pointer active:scale-95"
                  >
                    14 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => setDueDate(getFutureDateString(30))}
                    className="flex-1 py-1 px-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-md text-[11px] font-bold text-slate-600 transition-all duration-150 cursor-pointer active:scale-95"
                  >
                    30 Days
                  </button>
                </div>

                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 transition-all duration-200"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                  3. Add Loan Remarks
                </label>
                <textarea
                  rows={4}
                  placeholder="e.g. Returned in brand new sleeve, member is studying for finals..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 resize-none transition-all duration-200"
                />
              </div>
            </div>
          </div>

          {/* Form summary helper block */}
          {selectedPatron && (
            <div className="p-3 bg-indigo-50 border border-indigo-100 text-[11px] rounded-lg text-indigo-900 flex items-center gap-1.5 font-medium">
              <UserCheck className="h-4 w-4 text-indigo-600 shrink-0" />
              <span>
                Authorized to loan <strong>{book.title}</strong> to member <strong>{selectedPatron.name}</strong> until{' '}
                <strong>{dueDate}</strong>.
              </span>
            </div>
          )}

          {/* Modal Buttons */}
          <div className="flex justify-end gap-2 pt-4 border-t border-slate-100 shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 text-sm font-semibold rounded-lg transition-all duration-200 cursor-pointer active:scale-95"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="btn-confirm-checkout"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg transition-all duration-200 cursor-pointer shadow-md shadow-indigo-600/10 flex items-center gap-1 active:scale-95"
            >
              Confirm Checkout
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
