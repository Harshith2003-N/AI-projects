import React, { useState } from 'react';
import { Loan, Book, Patron } from '../types';
import {
  Clock,
  CheckCircle,
  AlertTriangle,
  Search,
  Calendar,
  Send,
  RotateCcw,
  RefreshCw,
  Plus,
  ArrowRightLeft,
  FileSpreadsheet,
  Trash2
} from 'lucide-react';

interface LoanTrackerProps {
  loans: Loan[];
  books: Book[];
  patrons: Patron[];
  onReturnBook: (loanId: string) => void;
  onRenewLoan: (loanId: string, days: number) => void;
  onSendOverdueReminder: (loanId: string) => void;
  onNavigateToBooks: () => void;
  onClearReturnedLoans: () => void;
}

export default function LoanTracker({
  loans,
  books,
  patrons,
  onReturnBook,
  onRenewLoan,
  onSendOverdueReminder,
  onNavigateToBooks,
  onClearReturnedLoans
}: LoanTrackerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<'ALL' | 'ACTIVE' | 'OVERDUE' | 'RETURNED'>('ALL');

  // Match objects for rendering
  const enrichedLoans = loans.map((loan) => {
    const book = books.find((b) => b.id === loan.bookId);
    const patron = patrons.find((p) => p.id === loan.patronId);
    return {
      ...loan,
      bookTitle: book?.title || 'Unknown Book',
      bookIsbn: book?.isbn || 'N/A',
      bookAuthor: book?.author || 'N/A',
      patronName: patron?.name || 'Unknown Member',
      patronEmail: patron?.email || 'N/A',
      patronPhone: patron?.phone || 'N/A',
      patronMemberId: patron?.membershipId || 'N/A'
    };
  });

  // Filter & Search
  const filteredLoans = enrichedLoans.filter((loan) => {
    const matchesSearch =
      loan.bookTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loan.patronName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loan.patronMemberId.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      selectedStatus === 'ALL' ||
      (selectedStatus === 'ACTIVE' && loan.status === 'ACTIVE') ||
      (selectedStatus === 'OVERDUE' && loan.status === 'OVERDUE') ||
      (selectedStatus === 'RETURNED' && loan.status === 'RETURNED');

    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'ACTIVE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-indigo-50 border border-indigo-100 text-indigo-700 text-xs font-semibold rounded-full uppercase">
            <Clock className="h-3 w-3" /> Active
          </span>
        );
      case 'OVERDUE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-50 border border-rose-100 text-rose-700 text-xs font-semibold rounded-full uppercase animate-pulse">
            <AlertTriangle className="h-3 w-3" /> Overdue
          </span>
        );
      case 'RETURNED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-semibold rounded-full uppercase">
            <CheckCircle className="h-3 w-3" /> Returned
          </span>
        );
      default:
        return null;
    }
  };

  const hasReturnedLoans = loans.some((l) => l.status === 'RETURNED');

  return (
    <div className="space-y-6">
      {/* Header section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 font-display">Circulation Ledger</h2>
          <p className="text-slate-500 text-sm">Issue, track, renew, and process book returns.</p>
        </div>
        <div className="flex items-center gap-2 self-stretch sm:self-auto">
          {hasReturnedLoans && (
            <button
              onClick={onClearReturnedLoans}
              className="px-4 py-2.5 hover:bg-rose-50 text-rose-600 border border-rose-200 rounded-lg text-sm font-semibold transition-all duration-200 flex items-center gap-1.5 cursor-pointer justify-center active:scale-95"
              title="Purge Inactive Returned Loans"
            >
              <Trash2 className="h-4 w-4" /> Purge Returned Loans
            </button>
          )}
          <button
            onClick={onNavigateToBooks}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-semibold transition-all duration-200 shadow-md shadow-indigo-600/10 flex items-center gap-1.5 cursor-pointer justify-center active:scale-95"
          >
            <Plus className="h-4.5 w-4.5" /> New Checkout
          </button>
        </div>
      </div>

      {/* Toolbar / Search & filter */}
      <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200/50 flex flex-col md:flex-row gap-3 justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search loans by book title, member name, membership ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50/70 border border-slate-200 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 focus:bg-white transition-all duration-200"
          />
        </div>

        {/* Status filters */}
        <div className="flex flex-wrap gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
          {(['ALL', 'ACTIVE', 'OVERDUE', 'RETURNED'] as const).map((status) => (
            <button
              key={status}
              onClick={() => setSelectedStatus(status)}
              className={`px-3.5 py-1.5 rounded-md text-xs font-bold transition-all duration-200 cursor-pointer capitalize ${
                selectedStatus === status
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {status.toLowerCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Loans Grid / Rows list */}
      <div className="space-y-4">
        {filteredLoans.map((loan) => {
          const isPending = loan.status === 'ACTIVE' || loan.status === 'OVERDUE';
          const isOverdue = loan.status === 'OVERDUE';

          return (
            <div
              key={loan.id}
              className={`bg-white rounded-xl border p-5 transition-all duration-300 hover:shadow-md ${
                isOverdue
                  ? 'border-rose-200 bg-gradient-to-r from-rose-50/10 to-transparent hover:border-rose-300'
                  : 'border-slate-200/50 hover:border-slate-300'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                {/* Book & Patron Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1">
                  {/* Book Block */}
                  <div className="flex gap-3">
                    <div className="h-14 w-10 bg-slate-100 rounded overflow-hidden shrink-0 shadow-xs border border-slate-200/50">
                      {/* Thumbnail helper */}
                      <div className="w-full h-full bg-indigo-900 flex items-center justify-center text-white text-[9px] font-bold uppercase text-center p-0.5 leading-tight">
                        {loan.bookTitle.slice(0, 3)}
                      </div>
                    </div>
                    <div className="min-w-0">
                      <p className="font-bold text-slate-900 text-sm truncate">{loan.bookTitle}</p>
                      <p className="text-slate-500 text-xs mt-0.5">By {loan.bookAuthor}</p>
                      <p className="text-[10px] text-slate-400 font-mono mt-1">ISBN {loan.bookIsbn}</p>
                    </div>
                  </div>

                  {/* Patron Block */}
                  <div className="border-t md:border-t-0 md:border-l border-slate-100 pt-3 md:pt-0 md:pl-4 space-y-1">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-slate-900 text-sm">{loan.patronName}</span>
                      <span className="text-[10px] font-bold font-mono text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded-sm">
                        {loan.patronMemberId}
                      </span>
                    </div>
                    <p className="text-slate-500 text-xs truncate">{loan.patronEmail}</p>
                    <p className="text-slate-400 text-[11px]">{loan.patronPhone}</p>
                  </div>
                </div>

                {/* Date tracking timeline block */}
                <div className="flex flex-wrap items-center gap-x-6 gap-y-2 border-t lg:border-t-0 border-slate-100 pt-3 lg:pt-0">
                  <div className="text-xs space-y-0.5">
                    <span className="text-slate-400 block font-bold uppercase tracking-wider text-[9px] font-mono">Issue Date</span>
                    <span className="font-semibold text-slate-800 flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5 text-indigo-500" /> {loan.issueDate}
                    </span>
                  </div>

                  <div className="text-xs space-y-0.5">
                    <span className="text-slate-400 block font-bold uppercase tracking-wider text-[9px] font-mono">Due Date</span>
                    <span
                      className={`font-semibold flex items-center gap-1 ${
                        isOverdue ? 'text-rose-600 font-bold' : 'text-slate-800'
                      }`}
                    >
                      <Calendar className="h-3.5 w-3.5" /> {loan.dueDate}
                    </span>
                  </div>

                  {loan.returnDate && (
                    <div className="text-xs space-y-0.5">
                      <span className="text-slate-400 block font-bold uppercase tracking-wider text-[9px] font-mono">Returned Date</span>
                      <span className="font-bold text-emerald-600 flex items-center gap-1">
                        <CheckCircle className="h-3.5 w-3.5" /> {loan.returnDate}
                      </span>
                    </div>
                  )}

                  <div className="lg:text-right shrink-0">{getStatusBadge(loan.status)}</div>
                </div>
              </div>

              {/* Notes & Actions footer segment */}
              <div className="mt-4 pt-3.5 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div className="text-xs text-slate-500 italic max-w-xl">
                  {loan.notes ? `“${loan.notes}”` : 'No additional notes documented.'}
                </div>

                {/* Operations */}
                {isPending && (
                  <div className="flex gap-2.5 shrink-0 self-stretch sm:self-auto justify-end">
                    {isOverdue && (
                      <button
                        onClick={() => onSendOverdueReminder(loan.id)}
                        className="p-2 text-rose-600 hover:bg-rose-50 border border-rose-100 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all duration-200 cursor-pointer active:scale-95"
                        title="Simulate Overdue Alert Email"
                      >
                        <Send className="h-3.5 w-3.5" /> Remind
                      </button>
                    )}

                    <button
                      onClick={() => onRenewLoan(loan.id, 7)}
                      className="px-3 py-2 text-indigo-700 hover:bg-indigo-50 border border-indigo-100 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all duration-200 cursor-pointer active:scale-95"
                    >
                      <RefreshCw className="h-3.5 w-3.5" /> Extend +7d
                    </button>

                    <button
                      onClick={() => onReturnBook(loan.id)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all duration-200 cursor-pointer shadow-md shadow-emerald-600/10 active:scale-95"
                    >
                      <RotateCcw className="h-3.5 w-3.5" /> Complete Return
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {filteredLoans.length === 0 && (
          <div className="bg-slate-50 border border-slate-200 border-dashed rounded-2xl py-16 text-center space-y-3">
            <FileSpreadsheet className="h-10 w-10 text-slate-400 mx-auto" />
            <h3 className="font-semibold text-slate-800">No loan records cataloged</h3>
            <p className="text-slate-500 text-xs max-w-sm mx-auto">
              No matching circulation registers could be located for your active status filters or keywords.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
