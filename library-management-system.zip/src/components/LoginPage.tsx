import React, { useState } from 'react';
import { Patron } from '../types';
import { BookOpen, Key, Users, BookMarked, ShieldAlert, ArrowRight, CheckCircle } from 'lucide-react';

interface LoginPageProps {
  patrons: Patron[];
  onLogin: (user: { role: 'ADMIN' | 'STUDENT'; patronId?: string; name: string }) => void;
  currentTime: string;
}

export default function LoginPage({ patrons, onLogin, currentTime }: LoginPageProps) {
  const [activeMode, setActiveMode] = useState<'STUDENT' | 'ADMIN'>('STUDENT');
  const [selectedPatronId, setSelectedPatronId] = useState('');
  const [typedMembershipId, setTypedMembershipId] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Handle student login submission
  const handleStudentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    // If they chose from the list
    if (selectedPatronId) {
      const patron = patrons.find((p) => p.id === selectedPatronId);
      if (patron) {
        onLogin({
          role: 'STUDENT',
          patronId: patron.id,
          name: patron.name
        });
        return;
      }
    }

    // If they typed manually
    if (typedMembershipId.trim()) {
      const trimmed = typedMembershipId.trim().toUpperCase();
      const patron = patrons.find(
        (p) => p.membershipId.toUpperCase() === trimmed || p.email.toLowerCase() === trimmed.toLowerCase()
      );

      if (patron) {
        onLogin({
          role: 'STUDENT',
          patronId: patron.id,
          name: patron.name
        });
      } else {
        setErrorMsg('Invalid Membership ID or Email. Please check or use the quick selection list below.');
      }
      return;
    }

    setErrorMsg('Please select a student profile or enter a Membership ID.');
  };

  // Handle admin quick login
  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin({
      role: 'ADMIN',
      name: 'Library Administrator'
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4 sm:p-6 md:p-12 font-sans selection:bg-indigo-900 selection:text-white">
      {/* Background radial glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(79,70,229,0.06)_0%,transparent_70%)] pointer-events-none" />

      {/* Main Container */}
      <div className="w-full max-w-5xl bg-slate-900 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 relative z-10 min-h-[580px]">
        
        {/* Left Column - Library Info Card (Large Screens Only) */}
        <div className="lg:col-span-5 bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 p-8 flex flex-col justify-between border-r border-slate-800">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-600 rounded-xl text-white shadow-lg shadow-indigo-600/20">
                <BookMarked className="h-6 w-6" />
              </div>
              <div>
                <h1 className="font-bold text-white text-lg font-display tracking-tight leading-tight">BiblioShelf</h1>
                <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider">Library Digital Hub</p>
              </div>
            </div>

            <div className="space-y-4 pt-4">
              <h2 className="text-xl sm:text-2xl font-bold font-display text-white tracking-tight leading-tight">
                Your portal to endless knowledge, cataloged with precision.
              </h2>
              <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                Log in to check out physical volumes, monitor your active borrow loans, extend checkout deadlines, and browse our live catalog inventory.
              </p>
            </div>
          </div>

          {/* Core metadata footer */}
          <div className="pt-6 border-t border-slate-800/80 space-y-3">
            <div className="flex justify-between text-xs text-slate-500">
              <span>Status</span>
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <span className="h-2 w-2 rounded-full bg-emerald-400 inline-block animate-pulse" />
                Systems Operational
              </span>
            </div>
            <div className="flex justify-between text-xs text-slate-500">
              <span>Local Time</span>
              <span className="font-mono text-slate-300 font-medium">{currentTime || '14:20:00 UTC'}</span>
            </div>
          </div>
        </div>

        {/* Right Column - Actual Authenticator Forms */}
        <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-center bg-slate-900/60 backdrop-blur-md">
          <div className="max-w-md w-full mx-auto space-y-6">
            
            {/* Form Header */}
            <div>
              <h2 className="text-2xl font-bold text-white font-display">System Authentication</h2>
              <p className="text-xs text-slate-400 mt-1">Select your access role below to enter the ledger</p>
            </div>

            {/* Selector Tabs */}
            <div className="grid grid-cols-2 p-1 bg-slate-950 rounded-xl border border-slate-800/80">
              <button
                type="button"
                onClick={() => {
                  setActiveMode('STUDENT');
                  setErrorMsg('');
                }}
                className={`py-2.5 text-xs font-bold rounded-lg transition-all duration-200 cursor-pointer flex items-center justify-center gap-1.5 ${
                  activeMode === 'STUDENT'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Users className="h-4 w-4" />
                Student Portal
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveMode('ADMIN');
                  setErrorMsg('');
                }}
                className={`py-2.5 text-xs font-bold rounded-lg transition-all duration-200 cursor-pointer flex items-center justify-center gap-1.5 ${
                  activeMode === 'ADMIN'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Key className="h-4 w-4" />
                Staff / Admin
              </button>
            </div>

            {/* Error messaging */}
            {errorMsg && (
              <div className="p-3 bg-rose-950/40 border border-rose-900 text-rose-200 text-xs rounded-lg font-medium flex items-start gap-2 animate-fade-in">
                <ShieldAlert className="h-4.5 w-4.5 text-rose-500 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* 1. STUDENT AUTHENTICATION FORM */}
            {activeMode === 'STUDENT' && (
              <form onSubmit={handleStudentSubmit} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-400 block uppercase tracking-wider">
                    Search & Select Pre-loaded Student
                  </label>
                  <select
                    value={selectedPatronId}
                    onChange={(e) => {
                      setSelectedPatronId(e.target.value);
                      if (e.target.value) {
                        setTypedMembershipId('');
                      }
                    }}
                    className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition cursor-pointer"
                  >
                    <option value="">-- Choose student profile for instant login --</option>
                    {patrons.map((patron) => (
                      <option key={patron.id} value={patron.id}>
                        {patron.name} ({patron.membershipId})
                      </option>
                    ))}
                  </select>
                  <span className="text-[10px] text-slate-500 block mt-1">
                    Select any pre-configured patron membership to bypass typing.
                  </span>
                </div>

                <div className="relative flex items-center py-2">
                  <div className="flex-grow border-t border-slate-800"></div>
                  <span className="flex-shrink mx-4 text-slate-500 text-[10px] font-bold uppercase tracking-widest">
                    Or Type Manually
                  </span>
                  <div className="flex-grow border-t border-slate-800"></div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-400 block uppercase tracking-wider">
                    Membership ID or Registered Email
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. PAT-2026-0001 or jane.doe@email.com"
                    value={typedMembershipId}
                    onChange={(e) => {
                      setTypedMembershipId(e.target.value);
                      if (e.target.value) {
                        setSelectedPatronId('');
                      }
                    }}
                    className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-200 placeholder-slate-600 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition-all font-mono"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg shadow-lg shadow-indigo-600/10 transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                >
                  Enter Student Portal <ArrowRight className="h-4 w-4" />
                </button>
              </form>
            )}

            {/* 2. ADMIN/STAFF AUTHENTICATION FORM */}
            {activeMode === 'ADMIN' && (
              <form onSubmit={handleAdminSubmit} className="space-y-4">
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                  <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
                    <CheckCircle className="h-4 w-4 text-indigo-500" />
                    Librarian Master Access
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    By accessing as Staff, you will gain full library administrative clearance. This includes modifying book quantities, deregistering books, checking in returns, sending email warning reminders, and registering new patron borrower accounts.
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg shadow-lg shadow-indigo-600/10 transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer active:scale-98 font-semibold"
                >
                  Quick Sign In as Librarian <ArrowRight className="h-4 w-4" />
                </button>
              </form>
            )}

          </div>
        </div>

      </div>
    </div>
  );
}
