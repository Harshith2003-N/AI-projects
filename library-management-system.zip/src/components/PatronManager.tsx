import React, { useState } from 'react';
import { Patron, Loan, Book } from '../types';
import {
  UserPlus,
  Mail,
  Phone,
  Calendar,
  Search,
  BookMarked,
  Clock,
  AlertTriangle,
  Users,
  CheckCircle,
  Hash
} from 'lucide-react';

interface PatronManagerProps {
  patrons: Patron[];
  loans: Loan[];
  books: Book[];
  onAddPatron: (patron: Omit<Patron, 'id' | 'joinDate'>) => void;
}

export default function PatronManager({ patrons, loans, books, onAddPatron }: PatronManagerProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);

  // Form Fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [membershipId, setMembershipId] = useState('');
  const [formError, setFormError] = useState('');

  // Handle open form
  const handleOpenAdd = () => {
    setName('');
    setEmail('');
    setPhone('');
    // Generate a beautiful, unique membership ID by default
    const randomSuffix = Math.floor(100 + Math.random() * 900);
    setMembershipId(`MEM-${new Date().getFullYear()}-${randomSuffix}`);
    setFormError('');
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim() || !email.trim() || !phone.trim() || !membershipId.trim()) {
      setFormError('Please fill out all required fields.');
      return;
    }

    // Check if membershipId is unique
    if (patrons.some((p) => p.membershipId === membershipId.trim())) {
      setFormError('This Membership ID is already registered.');
      return;
    }

    onAddPatron({
      name: name.trim(),
      email: email.trim(),
      phone: phone.trim(),
      membershipId: membershipId.trim()
    });

    setIsFormOpen(false);
  };

  // Filter Patrons
  const filteredPatrons = patrons.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.membershipId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.phone.includes(searchQuery)
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 font-display">Patron Registry</h2>
          <p className="text-slate-500 text-sm">Register library members, view contact info, and track account standing.</p>
        </div>
        <button
          onClick={handleOpenAdd}
          id="btn-add-patron-manager"
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-semibold transition-all duration-200 shadow-md shadow-indigo-600/10 flex items-center gap-1.5 cursor-pointer justify-center self-stretch sm:self-auto active:scale-95"
        >
          <UserPlus className="h-4.5 w-4.5" /> Register New Patron
        </button>
      </div>

      {/* Search Toolbar */}
      <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200/50 flex gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search patrons by name, email, member ID, phone..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50/70 border border-slate-200 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 focus:bg-white transition-all duration-200"
          />
        </div>
      </div>

      {/* Patrons Card List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredPatrons.map((patron) => {
          // Calculate specific member metrics
          const patronLoans = loans.filter((l) => l.patronId === patron.id);
          const activeCount = patronLoans.filter((l) => l.status === 'ACTIVE' || l.status === 'OVERDUE').length;
          const overdueCount = patronLoans.filter((l) => l.status === 'OVERDUE').length;
          const returnedCount = patronLoans.filter((l) => l.status === 'RETURNED').length;

          return (
            <div
              key={patron.id}
              className={`bg-white rounded-xl border p-5 space-y-4 hover:shadow-lg hover:border-slate-300 transition-all duration-300 relative overflow-hidden flex flex-col justify-between ${
                overdueCount > 0
                  ? 'border-rose-200 bg-gradient-to-tr from-rose-50/10 to-transparent hover:border-rose-300'
                  : 'border-slate-200/50 hover:border-slate-300'
              }`}
            >
              <div className="space-y-4">
                {/* Member identification tag */}
                <div className="flex justify-between items-start gap-2">
                  <div className="min-w-0">
                    <h3 className="font-bold text-slate-900 text-base font-display truncate">{patron.name}</h3>
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-mono mt-0.5 font-semibold">
                      <Hash className="h-3 w-3 text-slate-300" /> {patron.membershipId}
                    </div>
                  </div>

                  {overdueCount > 0 ? (
                    <span className="px-2.5 py-1 bg-rose-50 text-rose-700 text-[10px] font-bold rounded-md border border-rose-100/60 flex items-center gap-1 shrink-0 uppercase tracking-wider font-mono">
                      <AlertTriangle className="h-3.5 w-3.5 text-rose-500 animate-pulse" /> Overdue Block
                    </span>
                  ) : activeCount > 0 ? (
                    <span className="px-2.5 py-1 bg-indigo-50 text-indigo-700 text-[10px] font-bold rounded-md border border-indigo-100/60 flex items-center gap-1 shrink-0 uppercase tracking-wider font-mono">
                      <Clock className="h-3.5 w-3.5 text-indigo-500" /> Circulating
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-md border border-emerald-100/60 flex items-center gap-1 shrink-0 uppercase tracking-wider font-mono">
                      <CheckCircle className="h-3.5 w-3.5 text-emerald-500" /> Active
                    </span>
                  )}
                </div>

                {/* Contact info cards */}
                <div className="space-y-2 pt-1 text-xs text-slate-600 border-t border-slate-100">
                  <p className="flex items-center gap-2">
                    <Mail className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span className="truncate font-medium">{patron.email}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <Phone className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span className="font-medium">{patron.phone}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <Calendar className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                    <span className="font-semibold text-slate-400 font-mono">Registered {patron.joinDate}</span>
                  </p>
                </div>
              </div>

              {/* Grid with statistics */}
              <div className="grid grid-cols-3 gap-2 pt-4 border-t border-slate-100 text-center">
                <div className="bg-slate-50 border border-slate-100/60 p-2 rounded-lg">
                  <div className="text-sm font-bold text-slate-800 font-mono">{activeCount}</div>
                  <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider font-mono">Active</div>
                </div>
                <div className="bg-slate-50 border border-slate-100/60 p-2 rounded-lg">
                  <div className={`text-sm font-bold font-mono ${overdueCount > 0 ? 'text-rose-600 font-extrabold' : 'text-slate-800'}`}>
                    {overdueCount}
                  </div>
                  <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider font-mono">Overdue</div>
                </div>
                <div className="bg-slate-50 border border-slate-100/60 p-2 rounded-lg">
                  <div className="text-sm font-bold text-slate-800 font-mono">{returnedCount}</div>
                  <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider font-mono">Returned</div>
                </div>
              </div>
            </div>
          );
        })}

        {filteredPatrons.length === 0 && (
          <div className="col-span-full bg-slate-50 border border-slate-200 border-dashed rounded-2xl py-16 text-center space-y-3">
            <Users className="h-10 w-10 text-slate-400 mx-auto" />
            <h3 className="font-semibold text-slate-800">No members match search query</h3>
            <p className="text-slate-500 text-xs max-w-sm mx-auto">
              Refine your filters, clear the input or register a new patron to borrow library books.
            </p>
          </div>
        )}
      </div>

      {/* Patron Form Dialog */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-xl w-full max-w-md shadow-2xl border border-slate-200/60 overflow-hidden">
            {/* Header */}
            <div className="bg-slate-950 text-white px-6 py-4.5 flex justify-between items-center border-b border-slate-800">
              <div>
                <h3 className="font-bold text-lg font-display">Register Library Patron</h3>
                <p className="text-slate-400 text-xs mt-0.5">Add a new borrower profile to the database</p>
              </div>
              <button
                onClick={() => setIsFormOpen(false)}
                className="text-slate-400 hover:text-white text-xl font-bold cursor-pointer transition-all duration-200"
              >
                &times;
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {formError && (
                <div className="p-2.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-lg font-medium flex items-center gap-1.5">
                  <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block uppercase tracking-wider">Patron Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Jane Doe"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 transition-all duration-200"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block uppercase tracking-wider">Email Address *</label>
                <input
                  type="email"
                  required
                  placeholder="e.g. jane.doe@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 transition-all duration-200"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block uppercase tracking-wider">Phone Number *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. (555) 123-4567"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 transition-all duration-200"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 block uppercase tracking-wider font-sans">Generated Membership ID *</label>
                <input
                  type="text"
                  required
                  value={membershipId}
                  onChange={(e) => setMembershipId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm font-bold font-mono bg-slate-50 text-slate-600 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 transition-all duration-200"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-200 text-slate-700 hover:bg-slate-50 text-sm font-semibold rounded-lg transition-all duration-200 cursor-pointer active:scale-95"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="btn-save-patron"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-lg transition-all duration-200 cursor-pointer shadow-md shadow-indigo-600/10 active:scale-95"
                >
                  Register Patron
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
