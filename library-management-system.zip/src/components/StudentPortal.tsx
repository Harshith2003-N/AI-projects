import React, { useState } from 'react';
import { Book, Loan, Patron } from '../types';
import {
  BookOpen,
  Calendar,
  Clock,
  ArrowRightLeft,
  User,
  Barcode,
  Search,
  CheckCircle,
  AlertTriangle,
  RotateCcw,
  LogOut,
  MapPin,
  CalendarDays,
  Plus,
  BookMarked,
  Sparkles
} from 'lucide-react';

interface StudentPortalProps {
  books: Book[];
  loans: Loan[];
  patronId: string;
  patrons: Patron[];
  onBorrowBook: (bookId: string) => void;
  onRenewLoan: (loanId: string, days: number) => void;
  onReturnBook: (loanId: string) => void;
  onClearReturnedLoans?: (patronId?: string) => void;
  onLogOut: () => void;
  currentTime: string;
}

export default function StudentPortal({
  books,
  loans,
  patronId,
  patrons,
  onBorrowBook,
  onRenewLoan,
  onReturnBook,
  onClearReturnedLoans,
  onLogOut,
  currentTime
}: StudentPortalProps) {
  const [activeTab, setActiveTab] = useState<'catalog' | 'loans' | 'profile'>('catalog');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Find current student profile
  const currentStudent = patrons.find((p) => p.id === patronId);

  // Get current student's loans
  const studentLoans = loans.filter((l) => l.patronId === patronId);
  const activeLoans = studentLoans.filter((l) => l.status === 'ACTIVE' || l.status === 'OVERDUE');
  const returnedLoans = studentLoans.filter((l) => l.status === 'RETURNED');
  const overdueLoans = studentLoans.filter((l) => l.status === 'OVERDUE');

  // Categories helper
  const categories = ['All', ...Array.from(new Set(books.map((b) => b.category)))];

  // Helper function to check if student currently has this book checked out
  const getActiveLoanForBook = (bookId: string) => {
    return activeLoans.find((l) => l.bookId === bookId);
  };

  // Filtered books catalog
  const filteredBooks = books.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.isbn.includes(searchQuery) ||
      book.description.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'All' || book.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  // Calculate days remaining helper
  const getDaysRemainingText = (dueDateStr: string) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const due = new Date(dueDateStr);
    due.setHours(0, 0, 0, 0);
    
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return { text: `${Math.abs(diffDays)} days overdue`, isOverdue: true };
    } else if (diffDays === 0) {
      return { text: 'Due today', isOverdue: false, isWarning: true };
    } else if (diffDays === 1) {
      return { text: '1 day remaining', isOverdue: false, isWarning: true };
    } else {
      return { text: `${diffDays} days left`, isOverdue: false };
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/70 text-slate-800 flex flex-col font-sans selection:bg-indigo-100">
      
      {/* Top Header Menu Bar for Student */}
      <header className="sticky top-0 z-40 w-full bg-slate-950 text-slate-200 border-b border-slate-800 shadow-md shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Logo Brand */}
            <div className="flex items-center gap-3">
              <div className="p-1.5 bg-indigo-600 rounded-lg text-white">
                <BookMarked className="h-5 w-5" />
              </div>
              <div>
                <h1 className="font-bold text-white text-sm font-display tracking-tight leading-tight">BiblioShelf</h1>
                <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Student Portal</p>
              </div>
            </div>

            {/* Desktop Navigation Menus */}
            <nav className="hidden md:flex items-center space-x-1.5">
              <button
                onClick={() => setActiveTab('catalog')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'catalog'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <BookOpen className="h-4 w-4" /> Book Catalog
              </button>
              <button
                onClick={() => setActiveTab('loans')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer flex items-center gap-1.5 relative ${
                  activeTab === 'loans'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <ArrowRightLeft className="h-4 w-4" /> My Active Loans
                {activeLoans.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-indigo-500 text-white text-[9px] font-bold h-4 w-4 rounded-full flex items-center justify-center animate-pulse">
                    {activeLoans.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('profile')}
                className={`px-4 py-2 rounded-lg text-xs font-bold transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'profile'
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <User className="h-4 w-4" /> Library Card
              </button>
            </nav>

            {/* Profile badge & logout */}
            <div className="hidden md:flex items-center gap-4">
              <div className="text-right">
                <p className="text-xs font-bold text-white leading-none">{currentStudent?.name || 'Student'}</p>
                <p className="text-[10px] font-mono text-slate-400 leading-none mt-1 font-bold">
                  {currentStudent?.membershipId}
                </p>
              </div>

              <div className="h-8 w-px bg-slate-800" />

              <button
                onClick={onLogOut}
                className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-900 rounded-lg transition-all duration-200 cursor-pointer"
                title="Sign Out"
              >
                <LogOut className="h-4.5 w-4.5" />
              </button>
            </div>

            {/* Mobile Hamburger Trigger */}
            <div className="flex items-center md:hidden gap-3">
              <button
                onClick={onLogOut}
                className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg cursor-pointer"
              >
                <LogOut className="h-4.5 w-4.5" />
              </button>
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-1.5 text-slate-400 hover:text-white bg-slate-900 rounded-lg cursor-pointer"
              >
                <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  {isMobileMenuOpen ? (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  ) : (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                  )}
                </svg>
              </button>
            </div>

          </div>
        </div>

        {/* Mobile Navigation Dropdown Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-slate-950 border-t border-slate-800/80 px-4 py-3 space-y-2">
            <button
              onClick={() => {
                setActiveTab('catalog');
                setIsMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 ${
                activeTab === 'catalog' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <BookOpen className="h-4 w-4" /> Book Catalog
            </button>
            <button
              onClick={() => {
                setActiveTab('loans');
                setIsMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 ${
                activeTab === 'loans' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <ArrowRightLeft className="h-4 w-4" /> My Active Loans ({activeLoans.length})
            </button>
            <button
              onClick={() => {
                setActiveTab('profile');
                setIsMobileMenuOpen(false);
              }}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 ${
                activeTab === 'profile' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <User className="h-4 w-4" /> Library Card
            </button>
          </div>
        )}
      </header>

      {/* Main Student View Area */}
      <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 max-w-7xl w-full mx-auto space-y-6">
        
        {/* Subheader Banner */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-xl shadow-xs border border-slate-200/50">
          <div>
            <h2 className="text-lg font-bold text-slate-900 font-display">
              Welcome back, {currentStudent?.name || 'Reader'}!
            </h2>
            <p className="text-slate-500 text-xs mt-0.5">
              Browse academic volumes, manage active loans, and monitor return milestones.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-slate-400 font-mono text-[11px] font-bold bg-slate-50 border border-slate-200/50 px-2.5 py-1.5 rounded-lg shrink-0">
              <span>Clock:</span>
              <span className="text-slate-700">{currentTime || '14:20:00 UTC'}</span>
            </div>
          </div>
        </div>

        {/* 1. BOOK CATALOG VIEW */}
        {activeTab === 'catalog' && (
          <div className="space-y-6">
            {/* Toolbar Filter / Search */}
            <div className="bg-white p-4 rounded-xl shadow-xs border border-slate-200/50 flex flex-col md:flex-row gap-3 justify-between">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search books by title, author, description, ISBN..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50/70 border border-slate-200 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-indigo-500/15 focus:border-indigo-500 focus:bg-white transition-all duration-200"
                />
              </div>

              {/* Categories scrolling filter list */}
              <div className="flex gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none items-center">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all duration-200 shrink-0 cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-indigo-600 text-white shadow-md'
                        : 'bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Books Card Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredBooks.map((book) => {
                const activeLoan = getActiveLoanForBook(book.id);
                const isOut = book.availableCopies <= 0;
                const isLow = book.availableCopies === 1;

                return (
                  <div
                    key={book.id}
                    className="bg-white rounded-xl border border-slate-200/60 shadow-xs hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col group hover:border-slate-300"
                  >
                    {/* Cover art block */}
                    <div className="relative h-48 bg-slate-950 overflow-hidden shrink-0">
                      <img
                        src={book.coverUrl}
                        alt={book.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                      <span className="absolute top-3 left-3 px-2.5 py-1 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold uppercase rounded-md tracking-wider">
                        {book.category}
                      </span>

                      {/* Shelf location code overlay */}
                      <div className="absolute bottom-3 left-3 flex items-center gap-1 text-white text-xs font-semibold">
                        <MapPin className="h-3.5 w-3.5 text-indigo-400" />
                        <span>{book.location}</span>
                      </div>

                      {/* Stock availability status pill */}
                      <div className="absolute top-3 right-3">
                        {activeLoan ? (
                          <span className="px-2.5 py-1 bg-indigo-600 backdrop-blur-xs text-white text-[9px] font-bold rounded-md uppercase tracking-wider font-mono">
                            Borrowed By You
                          </span>
                        ) : isOut ? (
                          <span className="px-2.5 py-1 bg-rose-600/90 backdrop-blur-xs text-white text-[9px] font-bold rounded-md uppercase tracking-wider font-mono">
                            Out of Stock
                          </span>
                        ) : isLow ? (
                          <span className="px-2.5 py-1 bg-amber-500/90 backdrop-blur-xs text-white text-[9px] font-bold rounded-md uppercase tracking-wider font-mono">
                            1 Copy Left
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 bg-emerald-600/95 backdrop-blur-xs text-white text-[9px] font-bold rounded-md uppercase tracking-wider font-mono">
                            {book.availableCopies} Available
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Book Metadata & Actions */}
                    <div className="p-5 flex-grow flex flex-col justify-between space-y-4">
                      <div className="space-y-2">
                        <h3 className="font-bold text-slate-900 group-hover:text-indigo-600 transition-all duration-200 font-display line-clamp-1">
                          {book.title}
                        </h3>
                        <p className="text-slate-500 text-xs font-semibold">By {book.author}</p>
                        <p className="text-slate-600 text-xs leading-relaxed line-clamp-3">
                          {book.description || 'No description cataloged for this book volume.'}
                        </p>
                      </div>

                      <div className="space-y-3.5 pt-3 border-t border-slate-100">
                        <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                          <span className="flex items-center gap-1">
                            <Barcode className="h-3.5 w-3.5 text-slate-300" /> {book.isbn}
                          </span>
                          <span className="flex items-center gap-1">
                            <CalendarDays className="h-3.5 w-3.5 text-slate-300" /> Pub {book.publishYear}
                          </span>
                        </div>

                        {/* Interactive Borrow or Renew Options */}
                        <div className="pt-1">
                          {activeLoan ? (
                            <div className="flex flex-col gap-2">
                              <div className="p-2.5 bg-indigo-50 border border-indigo-100/50 rounded-lg text-xs font-medium text-indigo-900 text-center">
                                Checked out. Due on: <strong>{activeLoan.dueDate}</strong>
                              </div>
                              <button
                                onClick={() => onRenewLoan(activeLoan.id, 7)}
                                className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-all duration-200 flex items-center justify-center gap-1.5 active:scale-95 shadow-md shadow-indigo-600/10 cursor-pointer"
                              >
                                <RotateCcw className="h-3.5 w-3.5" /> Extend Loan +7 Days
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => onBorrowBook(book.id)}
                              disabled={isOut}
                              className={`w-full py-2.5 text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition-all duration-200 ${
                                isOut
                                  ? 'bg-slate-100 text-slate-400 border border-slate-200/60 cursor-not-allowed'
                                  : 'bg-indigo-50 hover:bg-indigo-600 text-indigo-700 hover:text-white border border-indigo-100 hover:border-indigo-600 active:scale-95 shadow-xs cursor-pointer'
                              }`}
                            >
                              <Plus className="h-4 w-4" />
                              {isOut ? 'Temporarily Out of Stock' : 'Self Check-out Book'}
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}

              {filteredBooks.length === 0 && (
                <div className="col-span-full bg-slate-50 border border-slate-200 border-dashed rounded-2xl py-16 text-center space-y-3">
                  <BookOpen className="h-10 w-10 text-slate-400 mx-auto animate-pulse" />
                  <h3 className="font-semibold text-slate-800">No matching library volumes found</h3>
                  <p className="text-slate-500 text-xs max-w-sm mx-auto">
                    Try adjusting your search terms, changing the category filters, or browsing the main catalog indexes.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* 2. MY ACTIVE LOANS VIEW */}
        {activeTab === 'loans' && (
          <div className="space-y-6">
            
            {/* Warning block for Overdue loans */}
            {overdueLoans.length > 0 && (
              <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-3.5 animate-pulse">
                <AlertTriangle className="h-5 w-5 text-rose-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="font-bold text-rose-900 text-sm">Action Required: Overdue Items Pending</h4>
                  <p className="text-xs text-rose-700 leading-relaxed">
                    You have <strong>{overdueLoans.length}</strong> checked-out volume(s) exceeding return deadlines. Please self-renew your check-outs below to clear warnings, or return physical books directly to catalog intake boxes.
                  </p>
                </div>
              </div>
            )}

            {/* Reading list stats ribbon */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white p-4 rounded-xl border border-slate-200/50 shadow-xs flex items-center gap-3">
                <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-lg">
                  <BookOpen className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400 font-bold uppercase tracking-wider font-mono">Currently Borrowed</div>
                  <div className="text-lg font-bold text-slate-800 font-mono">{activeLoans.length} books</div>
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-200/50 shadow-xs flex items-center gap-3">
                <div className="p-2.5 bg-rose-50 text-rose-600 rounded-lg">
                  <AlertTriangle className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400 font-bold uppercase tracking-wider font-mono">Overdue Notices</div>
                  <div className="text-lg font-bold text-slate-800 font-mono">
                    {overdueLoans.length === 0 ? '0 notices' : `${overdueLoans.length} warnings`}
                  </div>
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border border-slate-200/50 shadow-xs flex items-center gap-3">
                <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-lg">
                  <CheckCircle className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400 font-bold uppercase tracking-wider font-mono">Returned History</div>
                  <div className="text-lg font-bold text-slate-800 font-mono">{returnedLoans.length} volumes</div>
                </div>
              </div>
            </div>

            {/* Active Loans segment list */}
            <div className="space-y-4">
              <h3 className="font-bold text-slate-900 text-sm font-display flex items-center gap-2">
                <ArrowRightLeft className="h-4.5 w-4.5 text-indigo-500" /> Currently Circulating Assets
              </h3>

              {activeLoans.map((loan) => {
                const book = books.find((b) => b.id === loan.bookId);
                const { text, isOverdue, isWarning } = getDaysRemainingText(loan.dueDate);

                return (
                  <div
                    key={loan.id}
                    className={`bg-white rounded-xl border p-5 transition-all duration-300 hover:shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                      isOverdue
                        ? 'border-rose-200 bg-gradient-to-r from-rose-50/10 to-transparent'
                        : 'border-slate-200/50'
                    }`}
                  >
                    <div className="flex gap-4">
                      {/* Book Cover Fallback Icon */}
                      <div className="h-16 w-12 bg-indigo-950 text-white font-bold text-[9px] rounded shadow-xs shrink-0 flex items-center justify-center p-1 text-center leading-tight">
                        {book ? book.title.slice(0, 3).toUpperCase() : 'BKS'}
                      </div>

                      <div className="space-y-1">
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-500 text-[9px] font-mono rounded font-bold uppercase tracking-wider">
                          {book?.category || 'General'}
                        </span>
                        <h4 className="font-bold text-slate-900 text-sm mt-0.5">{book?.title || 'Unknown Volume'}</h4>
                        <p className="text-slate-500 text-xs">By {book?.author || 'Unknown'}</p>
                      </div>
                    </div>

                    {/* Loan timelines */}
                    <div className="flex flex-wrap items-center gap-x-6 gap-y-2 pt-3 md:pt-0 border-t md:border-0 border-slate-100">
                      
                      <div className="text-xs space-y-0.5">
                        <span className="text-slate-400 block font-bold uppercase tracking-wider text-[9px] font-mono">Issued On</span>
                        <span className="font-semibold text-slate-800 flex items-center gap-1">
                          <Calendar className="h-3.5 w-3.5 text-slate-400" /> {loan.issueDate}
                        </span>
                      </div>

                      <div className="text-xs space-y-0.5">
                        <span className="text-slate-400 block font-bold uppercase tracking-wider text-[9px] font-mono">Due Deadline</span>
                        <span className={`font-semibold flex items-center gap-1 ${isOverdue ? 'text-rose-600 font-bold' : 'text-slate-800'}`}>
                          <Clock className={`h-3.5 w-3.5 ${isOverdue ? 'text-rose-500' : 'text-slate-400'}`} /> {loan.dueDate}
                        </span>
                      </div>

                      <div className="text-xs space-y-0.5 min-w-32">
                        <span className="text-slate-400 block font-bold uppercase tracking-wider text-[9px] font-mono">Timeline Status</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono border ${
                            isOverdue
                              ? 'bg-rose-50 text-rose-700 border-rose-100'
                              : isWarning
                              ? 'bg-amber-50 text-amber-700 border-amber-100'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-100'
                          }`}
                        >
                          {text}
                        </span>
                      </div>

                      <div className="flex gap-2">
                        <button
                          onClick={() => onRenewLoan(loan.id, 7)}
                          className="py-2 px-3 text-xs font-bold text-indigo-700 hover:text-white bg-indigo-50 hover:bg-indigo-600 border border-indigo-100 hover:border-indigo-600 rounded-lg transition-all duration-200 cursor-pointer active:scale-95 flex items-center gap-1"
                        >
                          <RotateCcw className="h-3.5 w-3.5" /> Extend +7d
                        </button>

                        <button
                          onClick={() => onReturnBook(loan.id)}
                          className="py-2 px-3 text-xs font-bold text-emerald-700 hover:text-white bg-emerald-50 hover:bg-emerald-600 border border-emerald-100 hover:border-emerald-600 rounded-lg transition-all duration-200 cursor-pointer active:scale-95 flex items-center gap-1"
                        >
                          <CheckCircle className="h-3.5 w-3.5" /> Return Book
                        </button>
                      </div>

                    </div>
                  </div>
                );
              })}

              {activeLoans.length === 0 && (
                <div className="bg-slate-50 border border-slate-200 border-dashed rounded-2xl py-14 text-center space-y-3">
                  <CheckCircle className="h-10 w-10 text-emerald-500 mx-auto" />
                  <h3 className="font-semibold text-slate-800">Clear Records! No active loans</h3>
                  <p className="text-slate-500 text-xs max-w-xs mx-auto">
                    You have returned all borrowed volumes. Access the Book Catalog to self check-out assets.
                  </p>
                </div>
              )}
            </div>

            {/* Returned archives timeline */}
            {returnedLoans.length > 0 && (
              <div className="space-y-4 pt-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-slate-900 text-sm font-display flex items-center gap-2">
                    <CheckCircle className="h-4.5 w-4.5 text-emerald-500" /> Historic Reading Logs ({returnedLoans.length})
                  </h3>
                  {onClearReturnedLoans && (
                    <button
                      onClick={() => onClearReturnedLoans(patronId)}
                      className="text-xs text-rose-600 hover:text-rose-700 font-bold hover:underline cursor-pointer flex items-center gap-1 bg-rose-50 hover:bg-rose-100 border border-rose-100 px-2 py-1 rounded-md transition-all duration-150"
                    >
                      Clear Reading Logs
                    </button>
                  )}
                </div>

                <div className="bg-white rounded-xl border border-slate-200/50 shadow-xs divide-y divide-slate-100">
                  {returnedLoans.map((loan) => {
                    const book = books.find((b) => b.id === loan.bookId);

                    return (
                      <div key={loan.id} className="p-4 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3.5 min-w-0">
                          <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600 text-xs font-bold font-mono uppercase">
                            Ret
                          </div>
                          <div className="min-w-0">
                            <h4 className="font-semibold text-slate-800 text-sm truncate">{book?.title || 'Unknown Book'}</h4>
                            <p className="text-slate-400 text-xs">Returned back to archives on {loan.returnDate}</p>
                          </div>
                        </div>

                        <span className="text-[11px] font-mono text-slate-400 shrink-0">
                          ID: {loan.id.slice(5, 12)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

          </div>
        )}

        {/* 3. STUDENT PROFILE LIBRARY CARD */}
        {activeTab === 'profile' && (
          <div className="max-w-2xl mx-auto space-y-6">
            
            {/* Library Pass graphic card */}
            <div className="bg-gradient-to-tr from-slate-950 via-indigo-950 to-slate-900 text-white p-6 sm:p-8 rounded-2xl border border-slate-800 shadow-xl relative overflow-hidden">
              {/* Overlay graphics */}
              <div className="absolute -right-12 -bottom-12 h-44 w-44 rounded-full bg-indigo-600/10 blur-xl pointer-events-none" />
              <div className="absolute top-4 right-4 text-indigo-500/30">
                <BookMarked className="h-28 w-28" />
              </div>

              {/* Card Title */}
              <div className="flex justify-between items-start border-b border-slate-800 pb-5">
                <div>
                  <h3 className="text-lg font-bold font-display">BiblioShelf Reader Pass</h3>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Official Membership Card</p>
                </div>
                <span className="px-2.5 py-1 bg-indigo-600/25 border border-indigo-500/30 text-indigo-400 text-[10px] font-bold rounded-lg font-mono tracking-widest uppercase">
                  Class A Card
                </span>
              </div>

              {/* Patron Card Content */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-[9px] text-slate-500 block uppercase tracking-widest font-bold">Holder Name</label>
                    <span className="font-bold text-base text-white">{currentStudent?.name || 'Reader'}</span>
                  </div>

                  <div>
                    <label className="text-[9px] text-slate-500 block uppercase tracking-widest font-bold">Membership ID</label>
                    <span className="font-bold font-mono text-sm text-indigo-300">{currentStudent?.membershipId}</span>
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-[9px] text-slate-500 block uppercase tracking-widest font-bold">Registration Date</label>
                    <span className="font-bold text-sm text-white">{currentStudent?.joinDate || 'N/A'}</span>
                  </div>

                  <div>
                    <label className="text-[9px] text-slate-500 block uppercase tracking-widest font-bold">Status Clearance</label>
                    <span className="font-bold text-xs text-emerald-400 flex items-center gap-1">
                      <CheckCircle className="h-3.5 w-3.5 text-emerald-400" /> Authorized Circulator
                    </span>
                  </div>
                </div>
              </div>

              {/* Barcode line mock */}
              <div className="mt-8 pt-5 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex gap-0.5 bg-white p-1 rounded">
                    {/* Mock barcode lines */}
                    <div className="w-1 h-6 bg-slate-950" />
                    <div className="w-0.5 h-6 bg-slate-950" />
                    <div className="w-1.5 h-6 bg-slate-950" />
                    <div className="w-0.5 h-6 bg-slate-950" />
                    <div className="w-2 h-6 bg-slate-950" />
                    <div className="w-1 h-6 bg-slate-950" />
                    <div className="w-0.5 h-6 bg-slate-950" />
                    <div className="w-1.5 h-6 bg-slate-950" />
                    <div className="w-0.5 h-6 bg-slate-950" />
                    <div className="w-2 h-6 bg-slate-950" />
                    <div className="w-1 h-6 bg-slate-950" />
                  </div>
                  <span className="text-[8px] font-mono text-slate-500 text-center block">
                    {currentStudent?.membershipId}
                  </span>
                </div>

                <div className="text-[10px] text-slate-500 font-medium font-mono text-center sm:text-right">
                  Scan to authorize checkouts at kiosks
                </div>
              </div>

            </div>

            {/* Profile detailed metadata card */}
            <div className="bg-white p-5 rounded-xl border border-slate-200/50 shadow-xs space-y-4">
              <h4 className="font-bold text-slate-900 text-sm font-display">Contact & Core Profile Details</h4>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="space-y-1">
                  <span className="text-slate-400 block font-semibold uppercase tracking-wider text-[9px] font-mono">Email Address</span>
                  <span className="font-bold text-slate-800">{currentStudent?.email || 'N/A'}</span>
                </div>

                <div className="space-y-1">
                  <span className="text-slate-400 block font-semibold uppercase tracking-wider text-[9px] font-mono">Phone Number</span>
                  <span className="font-bold text-slate-800">{currentStudent?.phone || 'N/A'}</span>
                </div>
              </div>
            </div>

          </div>
        )}

      </main>
    </div>
  );
}
