import { Book, Patron, Loan, ActivityLog } from './types';

// Standard library categories
export const CATEGORIES = [
  'Fiction',
  'Technology',
  'Science Fiction',
  'History',
  'Philosophy',
  'Biography',
  'Self-Help'
];

// Generate dynamic dates relative to current time
const getPastDate = (daysAgo: number): string => {
  const date = new Date();
  date.setDate(date.getDate() - daysAgo);
  return date.toISOString().split('T')[0];
};

const getFutureDate = (daysInFuture: number): string => {
  const date = new Date();
  date.setDate(date.getDate() + daysInFuture);
  return date.toISOString().split('T')[0];
};

export const INITIAL_BOOKS: Book[] = [
  {
    id: 'book-1',
    title: 'The Great Gatsby',
    author: 'F. Scott Fitzgerald',
    isbn: '9780743273565',
    category: 'Fiction',
    publishYear: 1925,
    totalCopies: 5,
    availableCopies: 4,
    location: 'Shelf A-1',
    coverUrl: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&q=80&w=400',
    description: 'The story of the mysteriously wealthy Jay Gatsby and his love for the beautiful Daisy Buchanan, of lavish parties on Long Island at a time when The New York Times noted "gin was the national drink and sex the national obsession."'
  },
  {
    id: 'book-2',
    title: 'Clean Code: A Handbook of Agile Software Craftsmanship',
    author: 'Robert C. Martin',
    isbn: '9780132350884',
    category: 'Technology',
    publishYear: 2008,
    totalCopies: 3,
    availableCopies: 2,
    location: 'Shelf T-2',
    coverUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=400',
    description: 'Even bad code can function. But if code isn\'t clean, it can bring a development organization to its knees. Every year, countless hours and significant resources are lost because of poorly written code. But it doesn\'t have to be that way.'
  },
  {
    id: 'book-3',
    title: 'Designing Data-Intensive Applications',
    author: 'Martin Kleppmann',
    isbn: '9781449373320',
    category: 'Technology',
    publishYear: 2017,
    totalCopies: 4,
    availableCopies: 4,
    location: 'Shelf T-3',
    coverUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=400',
    description: 'Data is at the center of many challenges in system design today. Difficult issues need to be figured out, such as scalability, consistency, reliability, efficiency, and maintainability. In addition, we have an overwhelming variety of tools.'
  },
  {
    id: 'book-4',
    title: 'Dune',
    author: 'Frank Herbert',
    isbn: '9780441172719',
    category: 'Science Fiction',
    publishYear: 1965,
    totalCopies: 6,
    availableCopies: 5,
    location: 'Shelf S-2',
    coverUrl: 'https://images.unsplash.com/photo-1506880018603-83d5b814b5a6?auto=format&fit=crop&q=80&w=400',
    description: 'Set on the desert planet Arrakis, Dune is the story of the boy Paul Atreides, heir to a noble family tasked with ruling an inhospitable world where the only thing of value is the "spice" melange, a drug capable of extending life and enhancing consciousness.'
  },
  {
    id: 'book-5',
    title: 'Sapiens: A Brief History of Humankind',
    author: 'Yuval Noah Harari',
    isbn: '9780062316097',
    category: 'History',
    publishYear: 2011,
    totalCopies: 4,
    availableCopies: 3,
    location: 'Shelf H-1',
    coverUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=400',
    description: 'From a renowned historian comes a groundbreaking narrative of humanity’s creation and evolution—a #1 international bestseller—that explores the ways in which biology and history have defined us and enhanced our understanding of what it means to be "human."'
  },
  {
    id: 'book-6',
    title: 'Meditations',
    author: 'Marcus Aurelius',
    isbn: '9780812968255',
    category: 'Philosophy',
    publishYear: 180,
    totalCopies: 3,
    availableCopies: 3,
    location: 'Shelf P-1',
    coverUrl: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=400',
    description: 'A series of personal writings by Marcus Aurelius, Roman Emperor from AD 161 to 180, recording his private notes to himself and ideas on Stoic philosophy.'
  },
  {
    id: 'book-7',
    title: 'Atomic Habits',
    author: 'James Clear',
    isbn: '9780735211292',
    category: 'Self-Help',
    publishYear: 2018,
    totalCopies: 8,
    availableCopies: 7,
    location: 'Shelf SH-1',
    coverUrl: 'https://images.unsplash.com/photo-1541963463532-d68292c34b19?auto=format&fit=crop&q=80&w=400',
    description: 'No matter your goals, Atomic Habits offers a proven framework for improving—every day. James Clear, one of the world\'s leading experts on habit formation, reveals practical strategies that will teach you exactly how to form good habits, break bad ones, and master the tiny behaviors that lead to remarkable results.'
  },
  {
    id: 'book-8',
    title: 'Educated',
    author: 'Tara Westover',
    isbn: '9780399590504',
    category: 'Biography',
    publishYear: 2018,
    totalCopies: 3,
    availableCopies: 2,
    location: 'Shelf B-4',
    coverUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=400',
    description: 'An unforgettable memoir about a young girl who, kept out of school, leaves her survivalist family and goes on to earn a PhD from Cambridge University.'
  }
];

export const INITIAL_PATRONS: Patron[] = [
  {
    id: 'patron-1',
    name: 'Jane Doe',
    email: 'jane.doe@library.org',
    phone: '(555) 123-4567',
    membershipId: 'MEM-2026-010',
    joinDate: getPastDate(120)
  },
  {
    id: 'patron-2',
    name: 'John Smith',
    email: 'john.smith@gmail.com',
    phone: '(555) 987-6543',
    membershipId: 'MEM-2026-024',
    joinDate: getPastDate(90)
  },
  {
    id: 'patron-3',
    name: 'Alice Johnson',
    email: 'alice.j@edu.org',
    phone: '(555) 246-8135',
    membershipId: 'MEM-2026-041',
    joinDate: getPastDate(45)
  },
  {
    id: 'patron-4',
    name: 'Robert Lee',
    email: 'rlee.design@outlook.com',
    phone: '(555) 369-1470',
    membershipId: 'MEM-2026-052',
    joinDate: getPastDate(15)
  }
];

export const INITIAL_LOANS: Loan[] = [
  {
    id: 'loan-1',
    bookId: 'book-1', // The Great Gatsby
    patronId: 'patron-1', // Jane Doe
    issueDate: getPastDate(5),
    dueDate: getFutureDate(9),
    returnDate: null,
    status: 'ACTIVE',
    notes: 'In perfect condition. Member promised to return early.'
  },
  {
    id: 'loan-2',
    bookId: 'book-2', // Clean Code
    patronId: 'patron-2', // John Smith
    issueDate: getPastDate(12),
    dueDate: getPastDate(2), // Overdue by 2 days
    returnDate: null,
    status: 'OVERDUE',
    notes: 'Member was sent an automated overdue notification.'
  },
  {
    id: 'loan-3',
    bookId: 'book-7', // Atomic Habits
    patronId: 'patron-4', // Robert Lee
    issueDate: getPastDate(14),
    dueDate: getPastDate(0),
    returnDate: getPastDate(4), // Returned 4 days ago
    status: 'RETURNED',
    notes: 'Returned at front desk. Outer cover is slightly worn.'
  },
  {
    id: 'loan-4',
    bookId: 'book-5', // Sapiens
    patronId: 'patron-3', // Alice Johnson
    issueDate: getPastDate(8),
    dueDate: getFutureDate(6),
    returnDate: null,
    status: 'ACTIVE',
    notes: null
  },
  {
    id: 'loan-5',
    bookId: 'book-8', // Educated
    patronId: 'patron-1', // Jane Doe
    issueDate: getPastDate(10),
    dueDate: getFutureDate(4),
    returnDate: null,
    status: 'ACTIVE',
    notes: 'Needs to check CD companion next time.'
  }
];

export const INITIAL_LOGS: ActivityLog[] = [
  {
    id: 'log-1',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 hours ago
    type: 'LOAN_ISSUE',
    message: 'Book Checked Out: "The Great Gatsby"',
    details: 'Loaned to Jane Doe (MEM-2026-010) until ' + getFutureDate(9)
  },
  {
    id: 'log-2',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
    type: 'LOAN_RETURN',
    message: 'Book Returned: "Atomic Habits"',
    details: 'Returned by Robert Lee (MEM-2026-052) in clean condition'
  },
  {
    id: 'log-3',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(), // 2 days ago
    type: 'BOOK_ADD',
    message: 'New Book Added: "Atomic Habits"',
    details: '8 total copies cataloged on Shelf SH-1'
  },
  {
    id: 'log-4',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 120).toISOString(), // 5 days ago
    type: 'PATRON_ADD',
    message: 'New Member Registered: Robert Lee',
    details: 'Assigned membership ID MEM-2026-052'
  }
];
