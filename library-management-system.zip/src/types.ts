export interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  category: string;
  publishYear: number;
  totalCopies: number;
  availableCopies: number;
  location: string;
  coverUrl: string;
  description: string;
}

export interface Patron {
  id: string;
  name: string;
  email: string;
  phone: string;
  membershipId: string;
  joinDate: string;
}

export type LoanStatus = 'ACTIVE' | 'OVERDUE' | 'RETURNED';

export interface Loan {
  id: string;
  bookId: string;
  patronId: string;
  issueDate: string;
  dueDate: string;
  returnDate: string | null;
  status: LoanStatus;
  notes: string | null;
}

export type ActivityType =
  | 'BOOK_ADD'
  | 'BOOK_EDIT'
  | 'BOOK_DELETE'
  | 'LOAN_ISSUE'
  | 'LOAN_RETURN'
  | 'LOAN_RENEW'
  | 'PATRON_ADD';

export interface ActivityLog {
  id: string;
  timestamp: string;
  type: ActivityType;
  message: string;
  details: string;
}
