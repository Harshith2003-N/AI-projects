/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Doctor, Appointment, Review, HealthMetric, MedicalRecord, AppointmentStatus, PatientProfile, UserAccount } from './types';
import { 
  INITIAL_DOCTORS, 
  INITIAL_REVIEWS, 
  INITIAL_APPOINTMENTS, 
  INITIAL_HEALTH_METRICS, 
  INITIAL_MEDICAL_RECORDS 
} from './data';
import RoleSelector from './components/RoleSelector';
import DoctorList from './components/DoctorList';
import DoctorDetailModal from './components/DoctorDetailModal';
import PatientDashboard from './components/PatientDashboard';
import AdminPanel from './components/AdminPanel';
import LoginPortal from './components/LoginPortal';
import { 
  CalendarDays, 
  User, 
  Activity, 
  ShieldCheck, 
  HeartHandshake, 
  Clock, 
  MapPin, 
  HelpCircle,
  Mail,
  Heart,
  LogOut
} from 'lucide-react';

const DEFAULT_PATIENT_PROFILES: PatientProfile[] = [
  {
    id: 'p-1',
    name: 'John Doe',
    email: 'johndoe@example.com',
    phone: '+1 (555) 234-5678',
    age: 32,
    gender: 'Male',
    bloodGroup: 'O+',
    height: "5'11\"",
    relationship: 'Self'
  },
  {
    id: 'p-2',
    name: 'Jane Doe',
    email: 'janedoe@example.com',
    phone: '+1 (555) 876-5432',
    age: 30,
    gender: 'Female',
    bloodGroup: 'A+',
    height: "5'6\"",
    relationship: 'Spouse'
  },
  {
    id: 'p-3',
    name: 'Jimmy Doe',
    email: 'johndoe@example.com',
    phone: '+1 (555) 234-5678',
    age: 8,
    gender: 'Male',
    bloodGroup: 'O+',
    height: "4'2\"",
    relationship: 'Child'
  }
];

const DEFAULT_USER_ACCOUNTS: UserAccount[] = [
  {
    id: 'u-1',
    name: 'John Doe',
    email: 'johndoe@example.com',
    phone: '+1 (555) 234-5678',
    age: 32,
    gender: 'Male',
    bloodGroup: 'O+',
    height: "5'11\"",
    avatarColor: 'bg-brand-600'
  },
  {
    id: 'u-2',
    name: 'Sarah Jenkins',
    email: 'sarah.j@example.com',
    phone: '+1 (555) 765-4321',
    age: 28,
    gender: 'Female',
    bloodGroup: 'B-',
    height: "5'5\"",
    avatarColor: 'bg-indigo-600'
  },
  {
    id: 'u-3',
    name: 'Michael Chen',
    email: 'm.chen@example.com',
    phone: '+1 (555) 345-6789',
    age: 45,
    gender: 'Male',
    bloodGroup: 'AB+',
    height: "6'0\"",
    avatarColor: 'bg-rose-600'
  }
];

export default function App() {
  // --- ROLE AND VIEW STATES ---
  const [currentRole, setCurrentRole] = useState<'patient' | 'admin'>('patient');
  const [activePatientTab, setActivePatientTab] = useState<'browse' | 'dashboard'>('browse');
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('medibook_patient_authenticated') === 'true';
  });

  // --- CORE SYSTEM STATES (Synced with LocalStorage) ---
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);

  // --- MULTI-USER STATE ---
  const [userAccounts, setUserAccounts] = useState<UserAccount[]>([]);
  const [activeUserId, setActiveUserId] = useState<string>('u-1');

  // --- USER-SPECIFIC STATES ---
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [healthMetrics, setHealthMetrics] = useState<HealthMetric[]>([]);
  const [medicalRecords, setMedicalRecords] = useState<MedicalRecord[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<string[]>([]);
  const [patientProfiles, setPatientProfiles] = useState<PatientProfile[]>([]);

  // --- CROSS-USER AGGREGATED VIEW FOR ADMIN PANEL ---
  const adminAppointments = useMemo(() => {
    let allApts: Appointment[] = [];
    userAccounts.forEach(u => {
      const key = `medibook_appointments_${u.id}`;
      const saved = localStorage.getItem(key);
      if (saved) {
        try {
          const apts = JSON.parse(saved) as Appointment[];
          allApts = [...allApts, ...apts];
        } catch (e) {
          console.error(e);
        }
      } else if (u.id === 'u-1') {
        allApts = [...allApts, ...INITIAL_APPOINTMENTS];
      }
    });
    const uniqueApts: Appointment[] = [];
    const seenIds = new Set<string>();
    allApts.forEach(apt => {
      if (!seenIds.has(apt.id)) {
        seenIds.add(apt.id);
        uniqueApts.push(apt);
      }
    });
    return uniqueApts.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [userAccounts, appointments, activeUserId]);
  const [currentPatient, setCurrentPatient] = useState({
    name: 'John Doe',
    email: 'johndoe@example.com',
    phone: '+1 (555) 234-5678',
    age: 32,
    gender: 'Male',
    bloodGroup: 'O+',
    height: "5'11\""
  });

  // --- UI INTERACTIVE STATES ---
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);

  // --- 1. LOAD SYSTEM-WIDE GLOBAL DATA & USER DIRECTORY ONCE ---
  useEffect(() => {
    // Doctors
    const savedDocs = localStorage.getItem('medibook_doctors');
    if (savedDocs) {
      setDoctors(JSON.parse(savedDocs));
    } else {
      setDoctors(INITIAL_DOCTORS);
      localStorage.setItem('medibook_doctors', JSON.stringify(INITIAL_DOCTORS));
    }

    // Reviews
    const savedReviews = localStorage.getItem('medibook_reviews');
    if (savedReviews) {
      setReviews(JSON.parse(savedReviews));
    } else {
      setReviews(INITIAL_REVIEWS);
      localStorage.setItem('medibook_reviews', JSON.stringify(INITIAL_REVIEWS));
    }

    // User Directory
    const savedUserAccounts = localStorage.getItem('medibook_user_accounts');
    if (savedUserAccounts) {
      setUserAccounts(JSON.parse(savedUserAccounts));
    } else {
      setUserAccounts(DEFAULT_USER_ACCOUNTS);
      localStorage.setItem('medibook_user_accounts', JSON.stringify(DEFAULT_USER_ACCOUNTS));
    }

    // Active User ID
    const savedActiveUserId = localStorage.getItem('medibook_active_user_id');
    if (savedActiveUserId) {
      setActiveUserId(savedActiveUserId);
    } else {
      setActiveUserId('u-1');
      localStorage.setItem('medibook_active_user_id', 'u-1');
    }
  }, []);

  // --- 2. RE-SYNC USER DATA SPECIFIC TO ACTIVE PATIENT ACCOUNT ---
  useEffect(() => {
    if (!activeUserId || userAccounts.length === 0) return;

    const activeUser = userAccounts.find(u => u.id === activeUserId);
    if (!activeUser) return;

    // A. Sync currentPatient demographics
    setCurrentPatient({
      name: activeUser.name,
      email: activeUser.email,
      phone: activeUser.phone,
      age: activeUser.age,
      gender: activeUser.gender,
      bloodGroup: activeUser.bloodGroup,
      height: activeUser.height
    });

    // B. Sync Appointments
    const savedApts = localStorage.getItem(`medibook_appointments_${activeUserId}`);
    if (savedApts) {
      setAppointments(JSON.parse(savedApts));
    } else {
      const initialVal = activeUserId === 'u-1' ? INITIAL_APPOINTMENTS : [];
      setAppointments(initialVal);
      localStorage.setItem(`medibook_appointments_${activeUserId}`, JSON.stringify(initialVal));
    }

    // C. Sync Vitals / Health Metrics
    const savedVitals = localStorage.getItem(`medibook_vitals_${activeUserId}`);
    if (savedVitals) {
      setHealthMetrics(JSON.parse(savedVitals));
    } else {
      const initialVal = activeUserId === 'u-1' ? INITIAL_HEALTH_METRICS : [];
      setHealthMetrics(initialVal);
      localStorage.setItem(`medibook_vitals_${activeUserId}`, JSON.stringify(initialVal));
    }

    // D. Sync Medical Records
    const savedRecords = localStorage.getItem(`medibook_medical_records_${activeUserId}`);
    if (savedRecords) {
      setMedicalRecords(JSON.parse(savedRecords));
    } else {
      const initialVal = activeUserId === 'u-1' ? INITIAL_MEDICAL_RECORDS : [];
      setMedicalRecords(initialVal);
      localStorage.setItem(`medibook_medical_records_${activeUserId}`, JSON.stringify(initialVal));
    }

    // E. Sync Favorites
    const savedFavs = localStorage.getItem(`medibook_favorites_${activeUserId}`);
    if (savedFavs) {
      setFavoriteIds(JSON.parse(savedFavs));
    } else {
      setFavoriteIds([]);
      localStorage.setItem(`medibook_favorites_${activeUserId}`, JSON.stringify([]));
    }

    // F. Sync Family Dependents / Profiles
    const savedProfiles = localStorage.getItem(`medibook_patient_profiles_${activeUserId}`);
    if (savedProfiles) {
      setPatientProfiles(JSON.parse(savedProfiles));
    } else {
      const initialProfiles: PatientProfile[] = [
        {
          id: `self-${activeUserId}`,
          name: activeUser.name,
          email: activeUser.email,
          phone: activeUser.phone,
          age: activeUser.age,
          gender: activeUser.gender,
          bloodGroup: activeUser.bloodGroup,
          height: activeUser.height,
          relationship: 'Self'
        }
      ];

      // Give original John Doe (u-1) his default family dependents
      if (activeUserId === 'u-1') {
        initialProfiles.push(
          {
            id: 'p-2',
            name: 'Jane Doe',
            email: 'janedoe@example.com',
            phone: '+1 (555) 876-5432',
            age: 30,
            gender: 'Female',
            bloodGroup: 'A+',
            height: "5'6\"",
            relationship: 'Spouse'
          },
          {
            id: 'p-3',
            name: 'Jimmy Doe',
            email: 'johndoe@example.com',
            phone: '+1 (555) 234-5678',
            age: 8,
            gender: 'Male',
            bloodGroup: 'O+',
            height: "4'2\"",
            relationship: 'Child'
          }
        );
      }
      setPatientProfiles(initialProfiles);
      localStorage.setItem(`medibook_patient_profiles_${activeUserId}`, JSON.stringify(initialProfiles));
    }
  }, [activeUserId, userAccounts]);

  // --- PERSISTENCE TRIGGERS ON STATE CHANGES ---
  const saveDoctorsState = (newDocs: Doctor[]) => {
    setDoctors(newDocs);
    localStorage.setItem('medibook_doctors', JSON.stringify(newDocs));
  };

  const saveAppointmentsState = (newApts: Appointment[]) => {
    setAppointments(newApts);
    localStorage.setItem(`medibook_appointments_${activeUserId}`, JSON.stringify(newApts));
  };

  const saveVitalsState = (newVitals: HealthMetric[]) => {
    setHealthMetrics(newVitals);
    localStorage.setItem(`medibook_vitals_${activeUserId}`, JSON.stringify(newVitals));
  };

  const saveRecordsState = (newRecs: MedicalRecord[]) => {
    setMedicalRecords(newRecs);
    localStorage.setItem(`medibook_medical_records_${activeUserId}`, JSON.stringify(newRecs));
  };

  const savePatientState = (updatedPatient: typeof currentPatient) => {
    setCurrentPatient(updatedPatient);
    
    // Also update this user's demographic properties in the global userAccounts list
    const updatedUsers = userAccounts.map(u => {
      if (u.id === activeUserId) {
        return {
          ...u,
          name: updatedPatient.name,
          email: updatedPatient.email,
          phone: updatedPatient.phone,
          age: updatedPatient.age,
          gender: updatedPatient.gender,
          bloodGroup: updatedPatient.bloodGroup,
          height: updatedPatient.height
        };
      }
      return u;
    });
    setUserAccounts(updatedUsers);
    localStorage.setItem('medibook_user_accounts', JSON.stringify(updatedUsers));

    // Also update "Self" profile in the active user's patient profiles list
    const updatedProfiles = patientProfiles.map(p => {
      if (p.relationship === 'Self') {
        return {
          ...p,
          name: updatedPatient.name,
          email: updatedPatient.email,
          phone: updatedPatient.phone,
          age: updatedPatient.age,
          gender: updatedPatient.gender,
          bloodGroup: updatedPatient.bloodGroup,
          height: updatedPatient.height
        };
      }
      return p;
    });
    setPatientProfiles(updatedProfiles);
    localStorage.setItem(`medibook_patient_profiles_${activeUserId}`, JSON.stringify(updatedProfiles));
  };

  const savePatientProfilesState = (updatedProfiles: PatientProfile[]) => {
    setPatientProfiles(updatedProfiles);
    localStorage.setItem(`medibook_patient_profiles_${activeUserId}`, JSON.stringify(updatedProfiles));

    // If "Self" profile was modified in the profiles tab, keep currentPatient and userAccounts synced!
    const selfProfile = updatedProfiles.find(p => p.relationship === 'Self');
    if (selfProfile) {
      const updatedPatient = {
        name: selfProfile.name,
        email: selfProfile.email,
        phone: selfProfile.phone,
        age: selfProfile.age,
        gender: selfProfile.gender,
        bloodGroup: selfProfile.bloodGroup,
        height: selfProfile.height
      };
      setCurrentPatient(updatedPatient);

      const updatedUsers = userAccounts.map(u => {
        if (u.id === activeUserId) {
          return {
            ...u,
            ...updatedPatient
          };
        }
        return u;
      });
      setUserAccounts(updatedUsers);
      localStorage.setItem('medibook_user_accounts', JSON.stringify(updatedUsers));
    }
  };

  // --- MULTI-USER SYSTEM ACTION HANDLERS ---
  const handleLogin = (userId: string) => {
    setActiveUserId(userId);
    localStorage.setItem('medibook_active_user_id', userId);
    setIsAuthenticated(true);
    localStorage.setItem('medibook_patient_authenticated', 'true');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.setItem('medibook_patient_authenticated', 'false');
  };

  const handleSwitchUser = (userId: string) => {
    setActiveUserId(userId);
    localStorage.setItem('medibook_active_user_id', userId);
  };

  const handleAddUserAccount = (newUserData: Omit<UserAccount, 'id' | 'avatarColor'>) => {
    const colors = [
      'bg-brand-600',
      'bg-indigo-600',
      'bg-rose-600',
      'bg-teal-600',
      'bg-amber-600',
      'bg-violet-600',
      'bg-sky-600'
    ];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    const newId = `u-${Math.random().toString(36).substr(2, 9)}`;
    const newAccount: UserAccount = {
      ...newUserData,
      id: newId,
      avatarColor: randomColor
    };

    const updated = [...userAccounts, newAccount];
    setUserAccounts(updated);
    localStorage.setItem('medibook_user_accounts', JSON.stringify(updated));

    // Auto-login to new account
    setActiveUserId(newId);
    localStorage.setItem('medibook_active_user_id', newId);
    setIsAuthenticated(true);
    localStorage.setItem('medibook_patient_authenticated', 'true');
  };

  const handleDeleteUserAccount = (userIdToDelete: string) => {
    if (userAccounts.length <= 1) return;

    const updated = userAccounts.filter(u => u.id !== userIdToDelete);
    setUserAccounts(updated);
    localStorage.setItem('medibook_user_accounts', JSON.stringify(updated));

    // Clear garbage from localStorage
    localStorage.removeItem(`medibook_appointments_${userIdToDelete}`);
    localStorage.removeItem(`medibook_vitals_${userIdToDelete}`);
    localStorage.removeItem(`medibook_medical_records_${userIdToDelete}`);
    localStorage.removeItem(`medibook_favorites_${userIdToDelete}`);
    localStorage.removeItem(`medibook_patient_profiles_${userIdToDelete}`);

    if (activeUserId === userIdToDelete) {
      const remainingUser = updated[0];
      setActiveUserId(remainingUser.id);
      localStorage.setItem('medibook_active_user_id', remainingUser.id);
    }
  };

  // --- CALLBACK HANDLERS ---

  // Favorite toggle
  const handleToggleFavorite = (id: string) => {
    const updatedFavs = favoriteIds.includes(id)
      ? favoriteIds.filter(fId => fId !== id)
      : [...favoriteIds, id];
    setFavoriteIds(updatedFavs);
    localStorage.setItem(`medibook_favorites_${activeUserId}`, JSON.stringify(updatedFavs));
  };

  // Booking registration
  const handleBookAppointment = (aptData: Omit<Appointment, 'id' | 'createdDate'>) => {
    const newAppointment: Appointment = {
      ...aptData,
      id: `apt-${Math.random().toString(36).substr(2, 9)}`,
      createdDate: new Date().toISOString().split('T')[0]
    };
    const updatedList = [newAppointment, ...appointments];
    saveAppointmentsState(updatedList);

    // Increment doctor review and rating simulations (optional fun)
    const updatedDocs = doctors.map(doc => {
      if (doc.id === aptData.doctorId) {
        return {
          ...doc,
          reviewsCount: doc.reviewsCount + 1
        };
      }
      return doc;
    });
    saveDoctorsState(updatedDocs);
  };

  // Cancellation
  const handleCancelAppointment = (id: string) => {
    const updated = appointments.map(apt => {
      if (apt.id === id) {
        return { ...apt, status: 'cancelled' as const };
      }
      return apt;
    });
    saveAppointmentsState(updated);
  };

  // Rescheduling
  const handleRescheduleAppointment = (id: string, newDate: string, newTime: string) => {
    const updated = appointments.map(apt => {
      if (apt.id === id) {
        return { 
          ...apt, 
          date: newDate, 
          timeSlot: newTime,
          status: 'scheduled' as const // reset back to active
        };
      }
      return apt;
    });
    saveAppointmentsState(updated);
  };

  // Vitals log
  const handleAddHealthMetric = (metric: Omit<HealthMetric, 'id'>) => {
    const newMetric: HealthMetric = {
      ...metric,
      id: `m-${Math.random().toString(36).substr(2, 9)}`
    };
    const updatedList = [newMetric, ...healthMetrics];
    saveVitalsState(updatedList);
  };

  // Records upload
  const handleUploadMedicalRecord = (record: Omit<MedicalRecord, 'id'>) => {
    const newRecord: MedicalRecord = {
      ...record,
      id: `rec-${Math.random().toString(36).substr(2, 9)}`
    };
    const updatedList = [newRecord, ...medicalRecords];
    saveRecordsState(updatedList);
  };

  // Admin: Register Doctor
  const handleAddDoctor = (newDoc: Doctor) => {
    const updated = [newDoc, ...doctors];
    saveDoctorsState(updated);
  };

  // Admin: Update Doctor
  const handleUpdateDoctor = (updatedDoc: Doctor) => {
    const updated = doctors.map(d => d.id === updatedDoc.id ? updatedDoc : d);
    saveDoctorsState(updated);
  };

  // Admin: Delete Doctor
  const handleDeleteDoctor = (id: string) => {
    const updated = doctors.filter(d => d.id !== id);
    saveDoctorsState(updated);
  };

  // Admin: Update Appointment Status
  const handleUpdateAppointmentStatus = (id: string, status: AppointmentStatus) => {
    // 1. Update in the active state if it's currently loaded
    const updatedActiveList = appointments.map(apt => {
      if (apt.id === id) {
        return { ...apt, status };
      }
      return apt;
    });
    setAppointments(updatedActiveList);

    // 2. Locate which user account this appointment belongs to, and update it in their localStorage list
    userAccounts.forEach(u => {
      const key = `medibook_appointments_${u.id}`;
      const saved = localStorage.getItem(key);
      if (saved) {
        try {
          const apts = JSON.parse(saved) as Appointment[];
          const found = apts.some(a => a.id === id);
          if (found) {
            const updatedApts = apts.map(a => a.id === id ? { ...a, status } : a);
            localStorage.setItem(key, JSON.stringify(updatedApts));
            if (u.id === activeUserId) {
              setAppointments(updatedApts);
            }
          }
        } catch (e) {
          console.error(e);
        }
      } else if (u.id === 'u-1') {
        const found = INITIAL_APPOINTMENTS.some(a => a.id === id);
        if (found) {
          const updatedApts = INITIAL_APPOINTMENTS.map(a => a.id === id ? { ...a, status } : a);
          localStorage.setItem(key, JSON.stringify(updatedApts));
          if (activeUserId === 'u-1') {
            setAppointments(updatedApts);
          }
        }
      }
    });
  };

  return (
    <div className="min-h-screen bg-[#F1F5F9] flex flex-col justify-between">
      
      {/* 1. Global Interactive Sandbox Switcher */}
      <RoleSelector 
        currentRole={currentRole} 
        onChangeRole={(role) => {
          setCurrentRole(role);
          // Auto switch tab if moving to patient
          if (role === 'patient') setActivePatientTab('browse');
        }} 
        userAccounts={userAccounts}
        activeUserId={activeUserId}
        onSwitchUser={handleSwitchUser}
        onAddUser={handleAddUserAccount}
        onDeleteUser={handleDeleteUserAccount}
      />

      {/* ==================== PATIENT ROLE VIEWS ==================== */}
      {currentRole === 'patient' && (
        !isAuthenticated ? (
          <LoginPortal
            userAccounts={userAccounts}
            activeUserId={activeUserId}
            onLogin={handleLogin}
            onRegister={handleAddUserAccount}
            onSelectAdmin={() => setCurrentRole('admin')}
          />
        ) : (
          <div className="flex-1 flex flex-col">
            {/* Main Patient Header Menu */}
            <header id="patient-header" className="bg-white border-b border-slate-200 sticky top-[48px] z-40 shadow-xs">
              <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-slate-900 tracking-tight text-lg">
                    Medi<span className="text-brand-600">Book</span> Portal
                  </span>
                </div>

                <div className="flex items-center gap-4">
                  {/* Navigation Menu Tabs */}
                  <div className="flex gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200">
                    <button
                      id="nav-btn-browse"
                      onClick={() => setActivePatientTab('browse')}
                      className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        activePatientTab === 'browse'
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      <CalendarDays className="h-4 w-4 text-brand-600" />
                      Browse Doctors
                    </button>
                    <button
                      id="nav-btn-dashboard"
                      onClick={() => setActivePatientTab('dashboard')}
                      className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        activePatientTab === 'dashboard'
                          ? 'bg-white text-slate-900 shadow-xs'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      <User className="h-4 w-4 text-brand-600" />
                      My Patient Cockpit
                    </button>
                  </div>

                  <div className="h-6 w-[1px] bg-slate-200 hidden sm:block"></div>

                  <div className="flex items-center gap-2.5">
                    <div className="hidden sm:flex flex-col text-right">
                      <span className="text-xs font-bold text-slate-800 truncate max-w-[120px]">{currentPatient.name}</span>
                      <span className="text-[10px] text-brand-600 font-extrabold">Active</span>
                    </div>
                    <button
                      onClick={handleLogout}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold border border-slate-100 hover:border-rose-100"
                      title="Log Out Account"
                    >
                      <LogOut className="h-3.5 w-3.5 text-rose-500" />
                      <span className="hidden md:inline text-rose-600">Sign Out</span>
                    </button>
                  </div>
                </div>
              </div>
            </header>

            {/* Main Patient Content Canvas */}
            <main className="max-w-7xl mx-auto px-4 py-6 flex-1 w-full">
              {activePatientTab === 'browse' ? (
                <DoctorList 
                  doctors={doctors} 
                  favoriteIds={favoriteIds} 
                  onToggleFavorite={handleToggleFavorite} 
                  onSelectDoctor={(doc) => setSelectedDoctor(doc)}
                />
              ) : (
                <PatientDashboard 
                  appointments={appointments}
                  doctors={doctors}
                  healthMetrics={healthMetrics}
                  medicalRecords={medicalRecords}
                  favoriteIds={favoriteIds}
                  currentPatient={currentPatient}
                  onUpdatePatient={savePatientState}
                  onCancelAppointment={handleCancelAppointment}
                  onRescheduleAppointment={handleRescheduleAppointment}
                  onAddHealthMetric={handleAddHealthMetric}
                  onUploadMedicalRecord={handleUploadMedicalRecord}
                  onSelectDoctor={(doc) => {
                    setSelectedDoctor(doc);
                    setActivePatientTab('browse');
                  }}
                  patientProfiles={patientProfiles}
                  onUpdatePatientProfiles={savePatientProfilesState}
                  onBookAppointment={handleBookAppointment}
                />
              )}
            </main>
          </div>
        )
      )}

      {/* ==================== ADMIN ROLE VIEW ==================== */}
      {currentRole === 'admin' && (
        <div className="flex-1 flex flex-col">
          {/* Main Admin Header */}
          <header id="admin-header" className="bg-white border-b border-slate-200 sticky top-[48px] z-40 shadow-xs">
            <div className="max-w-7xl mx-auto px-4 py-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-800 tracking-tight text-lg flex items-center gap-1.5">
                  <ShieldCheck className="h-5 w-5 text-brand-600" />
                  MediBook Clinical Office Console
                </span>
              </div>
              <span className="text-[10px] uppercase font-bold text-brand-700 bg-brand-50 px-2.5 py-1 rounded-md border border-brand-200 font-mono">
                System Administrator
              </span>
            </div>
          </header>

          {/* Admin Canvas */}
          <main className="max-w-7xl mx-auto px-4 py-6 flex-1 w-full">
            <AdminPanel 
              doctors={doctors}
              appointments={adminAppointments}
              reviews={reviews}
              onAddDoctor={handleAddDoctor}
              onUpdateDoctor={handleUpdateDoctor}
              onUpdateAppointmentStatus={handleUpdateAppointmentStatus}
              onDeleteDoctor={handleDeleteDoctor}
            />
          </main>
        </div>
      )}

      {/* ==================== DOCTOR PROFILE & BOOKING OVERLAY MODAL ==================== */}
      {selectedDoctor && (
        <DoctorDetailModal 
          doctor={selectedDoctor} 
          reviews={reviews} 
          onClose={() => setSelectedDoctor(null)} 
          onBookAppointment={(apt) => {
            handleBookAppointment(apt);
            // Redirect patient directly to their cockpit so they can view the booking!
            setActivePatientTab('dashboard');
          }}
          currentPatient={currentPatient}
          patientProfiles={patientProfiles}
          onUpdatePatientProfiles={savePatientProfilesState}
        />
      )}

      {/* ==================== CLINIC SYSTEM FOOTER ==================== */}
      <footer className="bg-white border-t border-slate-200 py-6 mt-12 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-mono">
            © 2026 MediBook Appointment Systems. Continuous Clinical Synchronization.
          </p>
          <div className="flex items-center gap-4 text-[11px] font-semibold text-slate-500">
            <span className="flex items-center gap-1">
              <HeartHandshake className="h-3.5 w-3.5 text-brand-600" />
              HIPAA Cryptography
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <ShieldCheck className="h-3.5 w-3.5 text-brand-600" />
              SSL Layer Secure
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
