import React, { useState, useMemo } from 'react';
import { Doctor, Appointment, Review, AppointmentStatus } from '../types';
import { 
  Users, 
  DollarSign, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Plus, 
  Edit, 
  Search, 
  Building, 
  Award, 
  BookOpen, 
  TrendingUp, 
  MessageSquare, 
  Power,
  PowerOff,
  UserCheck,
  Calendar,
  Sparkles,
  Stethoscope,
  Heart
} from 'lucide-react';

interface AdminPanelProps {
  doctors: Doctor[];
  appointments: Appointment[];
  reviews: Review[];
  onAddDoctor: (newDoc: Doctor) => void;
  onUpdateDoctor: (updatedDoc: Doctor) => void;
  onUpdateAppointmentStatus: (id: string, status: AppointmentStatus) => void;
  onDeleteDoctor: (id: string) => void;
}

export default function AdminPanel({
  doctors,
  appointments,
  reviews,
  onAddDoctor,
  onUpdateDoctor,
  onUpdateAppointmentStatus,
  onDeleteDoctor
}: AdminPanelProps) {
  const [activeSubTab, setActiveSubTab] = useState<'dashboard' | 'appointments' | 'doctors' | 'reviews'>('dashboard');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const showToast = (message: string) => {
    setSuccessToast(message);
    setTimeout(() => {
      setSuccessToast(null);
    }, 4000);
  };

  // New Doctor Form State
  const [showAddForm, setShowAddForm] = useState(false);
  const [newDocName, setNewDocName] = useState('');
  const [newDocSpecialty, setNewDocSpecialty] = useState('General Medicine');
  const [newDocExp, setNewDocExp] = useState(5);
  const [newDocFees, setNewDocFees] = useState(100);
  const [newDocHospital, setNewDocHospital] = useState('City General Clinic');
  const [newDocEducation, setNewDocEducation] = useState('MD - Accredited Medical School');
  const [newDocBio, setNewDocBio] = useState('');
  const [newDocImg, setNewDocImg] = useState('');
  const [newDocDays, setNewDocDays] = useState<string[]>(['Mon', 'Wed', 'Fri']);
  const [newDocHours, setNewDocHours] = useState<string[]>(['09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM', '04:00 PM']);

  // Editing Doctor State
  const [editingDoctorId, setEditingDoctorId] = useState<string | null>(null);
  const [editFees, setEditFees] = useState(100);
  const [editHospital, setEditHospital] = useState('');
  const [editBio, setEditBio] = useState('');

  // Search & Filter States
  const [aptSearch, setAptSearch] = useState('');
  const [aptFilter, setAptFilter] = useState<'all' | AppointmentStatus>('all');
  const [docSearch, setDocSearch] = useState('');

  // --- CALC ADMIN KPI METRICS ---
  const kpis = useMemo(() => {
    const totalBookings = appointments.length;
    const completedApts = appointments.filter(a => a.status === 'completed');
    const activeStaff = doctors.filter(d => d.status === 'active').length;
    
    // Sum of fees for scheduled & completed appointments
    const grossRevenue = appointments
      .filter(a => a.status === 'completed' || a.status === 'scheduled')
      .reduce((sum, apt) => {
        const doc = doctors.find(d => d.id === apt.doctorId);
        return sum + (doc?.fees || 100);
      }, 0);

    // Avg satisfaction
    const avgRating = doctors.reduce((sum, d) => sum + d.rating, 0) / doctors.length || 4.8;

    return {
      totalBookings,
      activeStaff,
      grossRevenue,
      avgRating: avgRating.toFixed(1),
      completedCount: completedApts.length
    };
  }, [appointments, doctors]);

  // --- STATISTICS FOR SVG CHART ---
  // Distribution of bookings per specialty
  const specialtyDistribution = useMemo(() => {
    const counts: { [key: string]: number } = {};
    appointments.forEach(apt => {
      counts[apt.doctorSpecialty] = (counts[apt.doctorSpecialty] || 0) + 1;
    });

    // Convert to arrays
    return Object.keys(counts).map(spec => ({
      name: spec,
      count: counts[spec],
      percentage: (counts[spec] / appointments.length) * 100
    })).sort((a, b) => b.count - a.count);
  }, [appointments]);

  // --- HANDLERS ---
  const handleAddNewDoctor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocName || !newDocBio) return;

    const fallbackImg = newDocImg || 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&auto=format&fit=crop&q=80';

    const createdDoc: Doctor = {
      id: `doc-${Math.random().toString(36).substr(2, 9)}`,
      name: newDocName,
      specialty: newDocSpecialty,
      rating: 5.0,
      experience: Number(newDocExp),
      reviewsCount: 0,
      image: fallbackImg,
      availability: {
        days: newDocDays,
        hours: newDocHours
      },
      biography: newDocBio,
      fees: Number(newDocFees),
      hospital: newDocHospital,
      education: newDocEducation,
      status: 'active'
    };

    onAddDoctor(createdDoc);
    setShowAddForm(false);
    
    // Reset state
    setNewDocName('');
    setNewDocBio('');
    setNewDocImg('');
    showToast(`Doctor ${createdDoc.name} registered and activated successfully!`);
  };

  const handleSaveEditDoctor = (doc: Doctor) => {
    onUpdateDoctor({
      ...doc,
      fees: Number(editFees),
      hospital: editHospital,
      biography: editBio
    });
    setEditingDoctorId(null);
    showToast('Clinician qualifications and credentials synchronized.');
  };

  const handleToggleDocStatus = (doc: Doctor) => {
    const updatedStatus = doc.status === 'active' ? 'inactive' : 'active';
    onUpdateDoctor({
      ...doc,
      status: updatedStatus
    });
    showToast(`Practitioner status set to ${updatedStatus}.`);
  };

  // Filter appointments for table
  const filteredAppointments = useMemo(() => {
    return appointments.filter(apt => {
      const matchSearch = apt.patientName.toLowerCase().includes(aptSearch.toLowerCase()) || 
                          apt.doctorName.toLowerCase().includes(aptSearch.toLowerCase());
      const matchFilter = aptFilter === 'all' || apt.status === aptFilter;
      return matchSearch && matchFilter;
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [appointments, aptSearch, aptFilter]);

  // Filter doctors for roster list
  const filteredDoctors = useMemo(() => {
    return doctors.filter(doc => doc.name.toLowerCase().includes(docSearch.toLowerCase()) || doc.specialty.toLowerCase().includes(docSearch.toLowerCase()));
  }, [doctors, docSearch]);

  return (
    <div id="admin-panel-container" className="py-4 animate-fade-in text-slate-800 relative">
      {/* Toast Alert Feedback */}
      {successToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white text-xs font-extrabold px-4.5 py-3 rounded-2xl border border-slate-800 shadow-xl flex items-center gap-2.5 animate-scale-up">
          <span className="bg-brand-500/20 text-brand-400 p-1 rounded-full">
            <CheckCircle className="h-3 w-3" />
          </span>
          <span>{successToast}</span>
        </div>
      )}
      
      {/* Admin Sub-Tabs */}
      <div className="flex border-b border-slate-200 mb-6 gap-2">
        {[
          { id: 'dashboard', label: 'Overview Analytics', icon: TrendingUp },
          { id: 'appointments', label: 'Appointment Queues', icon: Calendar },
          { id: 'doctors', label: 'Clinician Roster', icon: Users },
          { id: 'reviews', label: 'Patient Testimonials', icon: MessageSquare },
        ].map((subTab) => {
          const Icon = subTab.icon;
          const isActive = activeSubTab === subTab.id;
          return (
            <button
              key={subTab.id}
              id={`tab-admin-${subTab.id}`}
              onClick={() => setActiveSubTab(subTab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-slate-900 text-white'
                  : 'bg-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Icon className="h-4 w-4" />
              {subTab.label}
            </button>
          );
        })}
      </div>

      {/* ==================== SUB-VIEW: OVERVIEW ANALYTICS ==================== */}
      {activeSubTab === 'dashboard' && (
        <div className="space-y-6">
          {/* Dashboard Summary Widgets */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* KPI 1 */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-extrabold uppercase block tracking-wider">Gross Est. Revenue</span>
                <span className="text-2xl font-extrabold text-slate-800 font-mono mt-1 block">
                  ${kpis.grossRevenue.toLocaleString()}
                </span>
                <span className="text-[10px] text-emerald-500 font-semibold block mt-1">▲ Simulated ledger balance</span>
              </div>
              <div className="bg-emerald-50 p-3.5 rounded-2xl border border-emerald-100 text-emerald-600">
                <DollarSign className="h-6 w-6 stroke-[2.5]" />
              </div>
            </div>

            {/* KPI 2 */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-extrabold uppercase block tracking-wider">Consultations</span>
                <span className="text-2xl font-extrabold text-slate-800 font-mono mt-1 block">
                  {kpis.totalBookings}
                </span>
                <span className="text-[10px] text-slate-400 font-semibold block mt-1">{kpis.completedCount} Completed consultations</span>
              </div>
              <div className="bg-brand-50 p-3.5 rounded-2xl border border-brand-100 text-brand-600">
                <CheckCircle className="h-6 w-6 stroke-[2.5]" />
              </div>
            </div>

            {/* KPI 3 */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-extrabold uppercase block tracking-wider">Active Staff</span>
                <span className="text-2xl font-extrabold text-slate-800 font-mono mt-1 block">
                  {kpis.activeStaff} <span className="text-xs font-normal text-slate-400">/ {doctors.length}</span>
                </span>
                <span className="text-[10px] text-teal-600 font-semibold block mt-1">● Currently in clinical rotation</span>
              </div>
              <div className="bg-teal-50 p-3.5 rounded-2xl border border-teal-100 text-teal-600">
                <Users className="h-6 w-6 stroke-[2.5]" />
              </div>
            </div>

            {/* KPI 4 */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-extrabold uppercase block tracking-wider">Avg Patient Satisfaction</span>
                <span className="text-2xl font-extrabold text-slate-800 font-mono mt-1 block">
                  {kpis.avgRating} <span className="text-xs font-normal text-slate-400">/ 5.0</span>
                </span>
                <span className="text-[10px] text-slate-400 font-semibold block mt-1">Based on {reviews.length} feedback reviews</span>
              </div>
              <div className="bg-amber-50 p-3.5 rounded-2xl border border-amber-100 text-amber-500">
                <Heart className="h-6 w-6 fill-amber-400 text-amber-400" />
              </div>
            </div>
          </div>

          {/* Graphical Analytics Row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* SVG Specialty distribution */}
            <div className="lg:col-span-2 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <h3 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider mb-5">Department Consultation Distributions</h3>
              
              {specialtyDistribution.length === 0 ? (
                <div className="p-12 text-center text-xs text-slate-400 italic">No bookings registered to generate distributions.</div>
              ) : (
                <div className="space-y-4">
                  {specialtyDistribution.map((spec, i) => (
                    <div key={spec.name} className="space-y-1.5 text-xs">
                      <div className="flex justify-between font-semibold text-slate-700">
                        <span>{spec.name}</span>
                        <span className="font-mono">{spec.count} consultations ({spec.percentage.toFixed(0)}%)</span>
                      </div>
                      
                      {/* Custom styled animated bar */}
                      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all duration-1000 ${
                            i === 0 ? 'bg-teal-600' : i === 1 ? 'bg-indigo-500' : 'bg-brand-500'
                          }`}
                          style={{ width: `${spec.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Actions Side desk */}
            <div className="lg:col-span-1 bg-gradient-to-br from-slate-900 to-slate-950 p-5 rounded-2xl text-white relative overflow-hidden shadow-md flex flex-col justify-between">
              <div className="absolute top-0 right-0 w-32 h-32 bg-brand-500/10 rounded-full blur-2xl"></div>
              <div>
                <span className="bg-brand-500/20 text-brand-200 border border-brand-500/30 text-[9px] px-2 py-0.5 rounded-md font-semibold uppercase tracking-wider inline-flex items-center gap-1.5 mb-2">
                  <Sparkles className="h-3 w-3" />
                  Clinic Management
                </span>
                <h4 className="font-extrabold text-base tracking-tight mb-2">Clinical Portal Actions</h4>
                <p className="text-[11px] text-slate-400 leading-normal mb-5">
                  Register new practitioners, review credential documents, adjust diagnostic fees, or verify patient consultation reports instantly.
                </p>
              </div>

              <div className="space-y-2.5">
                <button
                  id="admin-btn-add-doc"
                  onClick={() => {
                    setActiveSubTab('doctors');
                    setShowAddForm(true);
                  }}
                  className="w-full py-2.5 bg-brand-500 hover:bg-brand-600 text-slate-950 text-xs font-bold rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Plus className="h-4 w-4" />
                  Add New Doctor Profile
                </button>
                <button
                  onClick={() => setActiveSubTab('appointments')}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition-all border border-slate-700 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Calendar className="h-4 w-4" />
                  View Booking Queues
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== SUB-VIEW: APPOINTMENT QUEUE MANAGER ==================== */}
      {activeSubTab === 'appointments' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-100 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
            <h3 className="font-extrabold text-slate-800 text-sm">Appointment Queue Desk</h3>
            
            {/* Search & Filter bar */}
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-400" />
                <input
                  type="text"
                  value={aptSearch}
                  onChange={(e) => setAptSearch(e.target.value)}
                  placeholder="Patient or doctor name..."
                  className="text-xs pl-8 pr-3 py-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none w-full sm:w-48 text-slate-700"
                />
              </div>

              <select
                value={aptFilter}
                onChange={(e) => setAptFilter(e.target.value as any)}
                className="text-xs p-1.5 bg-white border border-slate-200 rounded-lg focus:outline-none text-slate-600"
              >
                <option value="all">All Booking Status</option>
                <option value="scheduled">Scheduled</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/50 border-b border-slate-100 font-bold text-slate-500 uppercase tracking-wider text-[10px]">
                  <th className="p-3">Ref ID</th>
                  <th className="p-3">Patient Profile</th>
                  <th className="p-3">Practitioner</th>
                  <th className="p-3">Consultation Date</th>
                  <th className="p-3">Format</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 text-right">Actions Desk</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredAppointments.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-12 text-center text-slate-400 italic">No bookings match the search filters.</td>
                  </tr>
                ) : (
                  filteredAppointments.map((apt) => (
                    <tr key={apt.id} className="hover:bg-slate-50/40">
                      <td className="p-3 font-mono font-bold text-slate-400 uppercase">#{apt.id.substring(4, 9)}</td>
                      <td className="p-3">
                        <div className="font-semibold text-slate-800">{apt.patientName}</div>
                        <div className="text-[10px] text-slate-400">Age: {apt.patientAge} • {apt.patientGender}</div>
                      </td>
                      <td className="p-3">
                        <div className="font-semibold text-slate-800">{apt.doctorName}</div>
                        <div className="text-[10px] text-slate-400">{apt.doctorSpecialty}</div>
                      </td>
                      <td className="p-3">
                        <div className="font-medium text-slate-700">{apt.date}</div>
                        <div className="text-[10px] text-slate-400">At {apt.timeSlot}</div>
                      </td>
                      <td className="p-3">
                        <span className="font-semibold text-slate-600">{apt.type}</span>
                      </td>
                      <td className="p-3 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                          apt.status === 'scheduled' 
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                            : apt.status === 'completed'
                            ? 'bg-slate-100 text-slate-600'
                            : apt.status === 'cancelled'
                            ? 'bg-rose-50 text-rose-600 border border-rose-100'
                            : 'bg-amber-50 text-amber-700 border border-amber-100'
                        }`}>
                          {apt.status}
                        </span>
                      </td>
                      <td className="p-3 text-right">
                        {apt.status === 'scheduled' && (
                          <div className="flex gap-1 justify-end">
                            <button
                              id={`admin-complete-${apt.id}`}
                              onClick={() => onUpdateAppointmentStatus(apt.id, 'completed')}
                              className="bg-teal-50 hover:bg-teal-100 text-teal-700 border border-teal-100 px-2 py-1 rounded-lg text-[10px] font-bold cursor-pointer"
                            >
                              Complete
                            </button>
                            <button
                              id={`admin-cancel-${apt.id}`}
                              onClick={() => onUpdateAppointmentStatus(apt.id, 'cancelled')}
                              className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-100 px-2 py-1 rounded-lg text-[10px] font-bold cursor-pointer"
                            >
                              Cancel
                            </button>
                          </div>
                        )}
                        {apt.status === 'pending' && (
                          <button
                            id={`admin-approve-${apt.id}`}
                            onClick={() => onUpdateAppointmentStatus(apt.id, 'scheduled')}
                            className="bg-brand-50 hover:bg-brand-100 text-brand-700 border border-brand-200 px-2 py-1 rounded-lg text-[10px] font-bold cursor-pointer"
                          >
                            Approve Slot
                          </button>
                        )}
                        {['completed', 'cancelled'].includes(apt.status) && (
                          <span className="text-[10px] text-slate-400 italic font-mono">Archived</span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================== SUB-VIEW: CLINIC DOCTORS MANAGEMENT ==================== */}
      {activeSubTab === 'doctors' && (
        <div className="space-y-6">
          {/* Top controllers */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-white p-4 rounded-2xl border border-slate-200">
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={docSearch}
                onChange={(e) => setDocSearch(e.target.value)}
                placeholder="Search clinician roster..."
                className="text-xs pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none w-full text-slate-700"
              />
            </div>
            <button
              id="admin-btn-toggle-add"
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="h-4 w-4" />
              {showAddForm ? 'Hide Registration Form' : 'Register New Practitioner'}
            </button>
          </div>

          {/* Form to Add New Doctor */}
          {showAddForm && (
            <form onSubmit={handleAddNewDoctor} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm animate-scale-up space-y-4">
              <h3 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider border-b border-slate-100 pb-2">Practitioner Clinical Registration</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-500">Full Practitioner Name</label>
                  <input
                    type="text"
                    required
                    value={newDocName}
                    onChange={(e) => setNewDocName(e.target.value)}
                    placeholder="E.g., Dr. Jane Miller"
                    className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-500">Medical Specialty</label>
                  <select
                    value={newDocSpecialty}
                    onChange={(e) => setNewDocSpecialty(e.target.value)}
                    className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  >
                    <option value="General Medicine">General Medicine</option>
                    <option value="Cardiology">Cardiology</option>
                    <option value="Pediatrics">Pediatrics</option>
                    <option value="Dermatology">Dermatology</option>
                    <option value="Orthopedics">Orthopedics</option>
                    <option value="Neurology">Neurology</option>
                  </select>
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-500">Experience (Years)</label>
                  <input
                    type="number"
                    required
                    value={newDocExp}
                    onChange={(e) => setNewDocExp(Number(e.target.value))}
                    className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-500">Consultation Fee ($)</label>
                  <input
                    type="number"
                    required
                    value={newDocFees}
                    onChange={(e) => setNewDocFees(Number(e.target.value))}
                    className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-500">Medical School / Education</label>
                  <input
                    type="text"
                    required
                    value={newDocEducation}
                    onChange={(e) => setNewDocEducation(e.target.value)}
                    placeholder="E.g., MD - Stanford Medical School"
                    className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-500">Clinical Facility Address</label>
                  <input
                    type="text"
                    required
                    value={newDocHospital}
                    onChange={(e) => setNewDocHospital(e.target.value)}
                    className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold text-slate-500">Profile Image URL (Optional)</label>
                <input
                  type="url"
                  value={newDocImg}
                  onChange={(e) => setNewDocImg(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold text-slate-500">Doctor Bio & Qualifications Overview</label>
                <textarea
                  required
                  value={newDocBio}
                  onChange={(e) => setNewDocBio(e.target.value)}
                  rows={3}
                  className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                  placeholder="Provide an overview of credentials, specialized training, and medical expertise..."
                />
              </div>

              <div className="flex gap-2 justify-end pt-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold rounded-xl transition-all shadow-sm"
                >
                  Submit Registration
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold rounded-xl transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          {/* Roster list */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredDoctors.map((doc) => {
              const isEditing = editingDoctorId === doc.id;
              return (
                <div key={doc.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-3xs flex flex-col justify-between hover:border-slate-300">
                  <div>
                    {/* Header profile info */}
                    <div className="flex gap-4 items-start pb-4 border-b border-slate-100">
                      <img src={doc.image} alt={doc.name} className="w-14 h-14 rounded-xl object-cover border" referrerPolicy="no-referrer" />
                      <div>
                        <span className="text-[9px] uppercase tracking-wider font-bold text-teal-700 bg-teal-50 border px-2 py-0.5 rounded-md">{doc.specialty}</span>
                        <h4 className="font-extrabold text-slate-800 text-sm mt-1">{doc.name}</h4>
                        <p className="text-[10px] text-slate-400 mt-0.5">{doc.education}</p>
                      </div>
                      <button
                        onClick={() => handleToggleDocStatus(doc)}
                        className={`ml-auto p-1.5 border rounded-lg transition-all ${
                          doc.status === 'active' 
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-600 hover:bg-emerald-100' 
                            : 'bg-slate-50 border-slate-200 text-slate-400 hover:bg-slate-100'
                        }`}
                        title={doc.status === 'active' ? 'Disable Clinician' : 'Activate Clinician'}
                      >
                        {doc.status === 'active' ? <Power className="h-4 w-4" /> : <PowerOff className="h-4 w-4" />}
                      </button>
                    </div>

                    {/* Qualifications view / Edit Form toggle */}
                    {!isEditing ? (
                      <div className="py-4 space-y-2 text-xs text-slate-600">
                        <p className="line-clamp-2 italic">"{doc.biography}"</p>
                        <div className="flex justify-between border-t border-slate-50 pt-2 text-[11px] font-mono">
                          <span>Clinic: <strong className="text-slate-800">{doc.hospital}</strong></span>
                          <span>Fee: <strong className="text-slate-800">${doc.fees}</strong></span>
                        </div>
                      </div>
                    ) : (
                      <div className="py-4 space-y-3">
                        <div className="flex flex-col gap-1">
                          <label className="text-[9px] font-bold text-slate-500 uppercase">Consultation Fees</label>
                          <input
                            type="number"
                            value={editFees}
                            onChange={(e) => setEditFees(Number(e.target.value))}
                            className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                          />
                        </div>
                        <div className="flex flex-col gap-1">
                          <label className="text-[9px] font-bold text-slate-500 uppercase">Facility Hospital</label>
                          <input
                            type="text"
                            value={editHospital}
                            onChange={(e) => setEditHospital(e.target.value)}
                            className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                          />
                        </div>
                        <div className="flex flex-col gap-1">
                          <label className="text-[9px] font-bold text-slate-500 uppercase">Biography</label>
                          <textarea
                            value={editBio}
                            onChange={(e) => setEditBio(e.target.value)}
                            rows={3}
                            className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Actions footer */}
                  <div className="border-t border-slate-100 pt-3 flex justify-between items-center text-xs">
                    <span className="text-[10px] font-mono text-slate-400">RATING: {doc.rating} ★ ({doc.reviewsCount} reviews)</span>
                    
                    {!isEditing ? (
                      <button
                        id={`edit-doc-${doc.id}`}
                        onClick={() => {
                          setEditingDoctorId(doc.id);
                          setEditFees(doc.fees);
                          setEditHospital(doc.hospital);
                          setEditBio(doc.biography);
                        }}
                        className="px-3.5 py-1.5 border border-slate-200 hover:bg-slate-50 rounded-lg text-slate-600 font-bold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Edit className="h-3.5 w-3.5" />
                        Modify Credentials
                      </button>
                    ) : (
                      <div className="flex gap-1.5">
                        <button
                          id={`save-doc-${doc.id}`}
                          onClick={() => handleSaveEditDoctor(doc)}
                          className="bg-brand-600 hover:bg-brand-700 text-white px-3 py-1.5 rounded-lg font-bold cursor-pointer"
                        >
                          Save
                        </button>
                        <button
                          id={`cancel-edit-${doc.id}`}
                          onClick={() => setEditingDoctorId(null)}
                          className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-3 py-1.5 rounded-lg font-bold cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ==================== SUB-VIEW: PATIENT TESTIMONIALS & CONTACT desk ==================== */}
      {activeSubTab === 'reviews' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-5">
          <h3 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider mb-4">Patient Reviews & Quality Auditing</h3>
          
          <div className="space-y-4">
            {reviews.map((rev) => {
              const matchedDoc = doctors.find(d => d.id === rev.doctorId);
              return (
                <div key={rev.id} className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row gap-4 justify-between items-start">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-bold text-slate-800">{rev.patientName}</span>
                      <span className="text-slate-400">•</span>
                      <span className="text-[10px] text-slate-400 font-mono">{rev.date}</span>
                      <span className="text-slate-400">•</span>
                      <span className="text-[11px] font-semibold text-brand-600">Review for {matchedDoc?.name || 'Dr.'}</span>
                    </div>

                    <p className="text-xs text-slate-600 italic">"{rev.comment}"</p>
                  </div>

                  <div className="flex items-center gap-1 shrink-0 self-end sm:self-auto">
                    {[...Array(5)].map((_, i) => (
                      <Heart 
                        key={i} 
                        className={`h-3.5 w-3.5 ${i < rev.rating ? 'fill-rose-500 text-rose-500' : 'text-slate-200'}`} 
                      />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
