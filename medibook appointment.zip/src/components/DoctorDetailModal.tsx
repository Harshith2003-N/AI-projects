import React, { useState, useMemo } from 'react';
import { Doctor, Appointment, Review, ConsultationType, PatientProfile } from '../types';
import { 
  X, 
  Star, 
  MapPin, 
  Calendar, 
  DollarSign, 
  Clock, 
  Check, 
  Video, 
  User, 
  FileText, 
  ArrowRight, 
  ChevronRight, 
  ShieldAlert,
  UserCheck
} from 'lucide-react';

interface DoctorDetailModalProps {
  doctor: Doctor;
  reviews: Review[];
  onClose: () => void;
  onBookAppointment: (appointment: Omit<Appointment, 'id' | 'createdDate'>) => void;
  currentPatient: {
    name: string;
    email: string;
    phone: string;
    age: number;
    gender: string;
  };
  patientProfiles?: PatientProfile[];
  onUpdatePatientProfiles?: (profiles: PatientProfile[]) => void;
}

export default function DoctorDetailModal({ 
  doctor, 
  reviews, 
  onClose, 
  onBookAppointment, 
  currentPatient,
  patientProfiles = [],
  onUpdatePatientProfiles
}: DoctorDetailModalProps) {
  const [activeTab, setActiveTab] = useState<'about' | 'reviews'>('about');
  
  // Booking Form State
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [consultType, setConsultType] = useState<ConsultationType>('In-Person');
  
  // Profile Selection State
  const [selectedProfileId, setSelectedProfileId] = useState<string>(patientProfiles[0]?.id || 'p-1');
  const [saveToProfiles, setSaveToProfiles] = useState(false);
  const [customRelationship, setCustomRelationship] = useState('Other');
  
  // Patient details state (initialized with current patient logged in)
  const [patientName, setPatientName] = useState(currentPatient.name);
  const [patientAge, setPatientAge] = useState(currentPatient.age);
  const [patientGender, setPatientGender] = useState(currentPatient.gender);
  const [patientEmail, setPatientEmail] = useState(currentPatient.email);
  const [patientPhone, setPatientPhone] = useState(currentPatient.phone);
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  
  // Handle profile click
  const handleSelectProfile = (profileId: string) => {
    setSelectedProfileId(profileId);
    if (profileId === 'custom') {
      setPatientName('');
      setPatientAge(30);
      setPatientGender('Male');
      setPatientEmail('');
      setPatientPhone('');
    } else {
      const selected = patientProfiles.find(p => p.id === profileId);
      if (selected) {
        setPatientName(selected.name);
        setPatientAge(selected.age);
        setPatientGender(selected.gender);
        setPatientEmail(selected.email);
        setPatientPhone(selected.phone);
      }
    }
  };
  
  // Workflow step
  const [bookingStep, setBookingStep] = useState<'info' | 'form' | 'success'>('info');
  const [createdAppointment, setCreatedAppointment] = useState<Appointment | null>(null);

  // Filter reviews specifically for this doctor
  const doctorReviews = useMemo(() => {
    return reviews.filter(rev => rev.doctorId === doctor.id);
  }, [reviews, doctor.id]);

  // Generate next 7 available dates
  const availableDates = useMemo(() => {
    const dates: { label: string; value: string; dayName: string }[] = [];
    const today = new Date();
    
    // Map of days to match doctor availability
    const dayMap: { [key: number]: string } = {
      0: 'Sun', 1: 'Mon', 2: 'Tue', 3: 'Wed', 4: 'Thu', 5: 'Fri', 6: 'Sat'
    };

    let count = 0;
    let dayOffset = 0;
    while (count < 7 && dayOffset < 30) {
      const nextDate = new Date();
      nextDate.setDate(today.getDate() + dayOffset);
      const dayName = dayMap[nextDate.getDay()];
      
      // If doctor is available on this day
      if (doctor.availability.days.includes(dayName)) {
        const year = nextDate.getFullYear();
        const month = String(nextDate.getMonth() + 1).padStart(2, '0');
        const day = String(nextDate.getDate()).padStart(2, '0');
        const formattedValue = `${year}-${month}-${day}`;

        const formattedLabel = nextDate.toLocaleDateString('en-US', { 
          month: 'short', 
          day: 'numeric' 
        });

        dates.push({
          label: formattedLabel,
          value: formattedValue,
          dayName: dayName
        });
        count++;
      }
      dayOffset++;
    }
    return dates;
  }, [doctor.availability.days]);

  // Set first date as default if available
  React.useEffect(() => {
    if (availableDates.length > 0 && !selectedDate) {
      setSelectedDate(availableDates[0].value);
    }
  }, [availableDates, selectedDate]);

  // Handle Form Submission
  const handleSubmitBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDate || !selectedTime) return;

    const newAppointmentData = {
      doctorId: doctor.id,
      doctorName: doctor.name,
      doctorSpecialty: doctor.specialty,
      doctorImage: doctor.image,
      patientName,
      patientAge: Number(patientAge),
      patientGender,
      patientEmail,
      patientPhone,
      date: selectedDate,
      timeSlot: selectedTime,
      type: consultType,
      reason,
      status: 'scheduled' as const,
      notes
    };

    // Trigger callback
    onBookAppointment(newAppointmentData);

    // Save custom profile if checked
    if (selectedProfileId === 'custom' && saveToProfiles && onUpdatePatientProfiles) {
      const newProfile: PatientProfile = {
        id: `p-${Math.random().toString(36).substr(2, 9)}`,
        name: patientName,
        email: patientEmail,
        phone: patientPhone,
        age: Number(patientAge),
        gender: patientGender,
        bloodGroup: 'Unknown',
        height: 'Unknown',
        relationship: customRelationship
      };
      onUpdatePatientProfiles([...patientProfiles, newProfile]);
    }
    
    // Generate simulated completed appointment state for success screen
    setCreatedAppointment({
      ...newAppointmentData,
      id: `apt-${Math.random().toString(36).substr(2, 9)}`,
      createdDate: new Date().toISOString().split('T')[0]
    });

    setBookingStep('success');
  };

  return (
    <div id="booking-modal-overlay" className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div 
        id="booking-modal-card" 
        className="bg-white rounded-3xl w-full max-w-5xl shadow-2xl overflow-hidden animate-scale-up border border-slate-100 flex flex-col md:flex-row my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* CLOSE BUTTON */}
        <button 
          id="close-booking-modal"
          onClick={onClose}
          className="absolute top-4 right-4 md:top-6 md:right-6 bg-slate-100 hover:bg-slate-200 p-2 rounded-full text-slate-500 hover:text-slate-800 transition-all z-20 cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>

        {/* ==================== LEFT SIDE: DOCTOR BIO & REVIEWS ==================== */}
        {bookingStep !== 'success' && (
          <div className="w-full md:w-1/2 bg-slate-50 p-6 md:p-8 border-r border-slate-100 flex flex-col justify-between">
            <div>
              {/* Doctor Header card */}
              <div className="flex gap-4 items-start mb-6">
                <img 
                  src={doctor.image} 
                  alt={doctor.name} 
                  className="w-20 h-20 rounded-2xl object-cover object-center border border-slate-200 bg-white shadow-sm"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider bg-brand-50 border border-brand-200 text-brand-700 px-2.5 py-1 rounded-md">
                    {doctor.specialty}
                  </span>
                  <h2 className="text-xl font-extrabold text-slate-800 mt-2">{doctor.name}</h2>
                  <p className="text-xs text-slate-500 font-medium mt-1">{doctor.education}</p>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex border-b border-slate-200 mb-5">
                <button
                  id="tab-btn-about"
                  onClick={() => setActiveTab('about')}
                  className={`pb-2.5 text-xs font-bold transition-all border-b-2 mr-6 cursor-pointer ${
                    activeTab === 'about' 
                      ? 'border-brand-600 text-brand-700 font-extrabold' 
                      : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  Biography & Qualifications
                </button>
                <button
                  id="tab-btn-reviews"
                  onClick={() => setActiveTab('reviews')}
                  className={`pb-2.5 text-xs font-bold transition-all border-b-2 cursor-pointer ${
                    activeTab === 'reviews' 
                      ? 'border-brand-600 text-brand-700 font-extrabold' 
                      : 'border-transparent text-slate-400 hover:text-slate-600'
                  }`}
                >
                  Patient Reviews ({doctorReviews.length})
                </button>
              </div>

              {/* Tab: About */}
              {activeTab === 'about' && (
                <div className="space-y-4 animate-fade-in text-xs text-slate-600 leading-relaxed">
                  <div>
                    <h4 className="font-bold text-slate-800 uppercase tracking-wider mb-1.5 text-[10px]">Professional Bio</h4>
                    <p>{doctor.biography}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div className="bg-white p-3 rounded-xl border border-slate-100 shadow-2xs">
                      <h5 className="font-bold text-slate-800 text-[10px] uppercase mb-1">Clinic Affiliation</h5>
                      <p className="text-slate-500 font-medium text-[11px] leading-snug">{doctor.hospital}</p>
                    </div>
                    <div className="bg-white p-3 rounded-xl border border-slate-100 shadow-2xs">
                      <h5 className="font-bold text-slate-800 text-[10px] uppercase mb-1">Standard Rates</h5>
                      <p className="text-slate-800 font-extrabold text-sm flex items-center">
                        <DollarSign className="h-3.5 w-3.5 text-slate-500" />
                        {doctor.fees} <span className="text-[10px] font-normal text-slate-400 ml-1">/ Consultation</span>
                      </p>
                    </div>
                  </div>

                  <div className="bg-brand-50/50 p-3 rounded-xl border border-brand-100 flex items-start gap-2">
                    <Clock className="h-4 w-4 text-brand-600 shrink-0 mt-0.5" />
                    <div>
                      <h5 className="font-bold text-brand-900 text-[10px] uppercase">Service Hours</h5>
                      <p className="text-[11px] text-brand-700 mt-0.5">
                        Available on <span className="font-semibold">{doctor.availability.days.join(', ')}</span> between <span className="font-semibold">{doctor.availability.hours[0]}</span> and <span className="font-semibold">{doctor.availability.hours[doctor.availability.hours.length - 1]}</span>.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab: Reviews */}
              {activeTab === 'reviews' && (
                <div className="space-y-3.5 max-h-72 overflow-y-auto pr-1.5 animate-fade-in">
                  {doctorReviews.length === 0 ? (
                    <p className="text-xs text-slate-400 italic py-6 text-center">No testimonials registered yet for this practitioner.</p>
                  ) : (
                    doctorReviews.map((rev) => (
                      <div key={rev.id} className="bg-white p-3.5 rounded-xl border border-slate-100 shadow-2xs flex flex-col gap-1.5">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-800 text-xs">{rev.patientName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">{rev.date}</span>
                        </div>
                        <div className="flex items-center gap-0.5">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`h-3 w-3 ${i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'}`} 
                            />
                          ))}
                        </div>
                        <p className="text-xs text-slate-600 italic leading-normal">"{rev.comment}"</p>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* Satisfaction / Info Metrics at bottom */}
            <div className="border-t border-slate-200 pt-4 mt-6 flex items-center justify-between text-xs text-slate-400">
              <span className="flex items-center gap-1">
                <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                <span className="font-bold text-slate-700">{doctor.rating}</span> ({doctor.reviewsCount} Rated Audits)
              </span>
              <span>100% HIPAA compliant</span>
            </div>
          </div>
        )}

        {/* ==================== RIGHT SIDE: APPOINTMENT SCHEDULER ENGINE ==================== */}
        {bookingStep !== 'success' && (
          <div className="w-full md:w-1/2 p-6 md:p-8 flex flex-col justify-between">
            {/* STEP 1: DATE & SLOT SELECTOR */}
            {bookingStep === 'info' && (
              <div className="animate-fade-in flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-base font-extrabold text-slate-800 mb-1 flex items-center gap-1.5">
                    <span className="bg-brand-100 text-brand-700 h-6 w-6 rounded-full flex items-center justify-center text-xs font-bold">1</span>
                    Select Date & Time
                  </h3>
                  <p className="text-xs text-slate-400 mb-5">Select from the doctor's weekly calendar slots below.</p>

                  {/* Date Grid */}
                  <div className="mb-5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">Available Dates</label>
                    {availableDates.length === 0 ? (
                      <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 text-amber-700 text-xs flex gap-2">
                        <ShieldAlert className="h-4 w-4 shrink-0" />
                        <p>No available slots in the upcoming 7 days. This doctor may be out of clinical rotation.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                        {availableDates.map((d) => (
                          <button
                            key={d.value}
                            id={`date-select-${d.value}`}
                            onClick={() => {
                              setSelectedDate(d.value);
                              setSelectedTime(''); // Reset time on date change
                            }}
                            className={`p-2.5 rounded-xl border flex flex-col items-center justify-center transition-all cursor-pointer ${
                              selectedDate === d.value
                                ? 'bg-brand-600 border-brand-600 text-white shadow-md shadow-brand-600/15'
                                : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300 hover:bg-slate-100'
                            }`}
                          >
                            <span className="text-[10px] uppercase font-bold tracking-tight block opacity-80">{d.dayName}</span>
                            <span className="text-xs font-extrabold mt-0.5">{d.label.split(' ')[1]}</span>
                            <span className="text-[9px] block uppercase opacity-70 mt-0.5">{d.label.split(' ')[0]}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Time Slots Grid */}
                  <div className="mb-5">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">Available Time Slots</label>
                    <div className="grid grid-cols-3 gap-2">
                      {doctor.availability.hours.map((hour) => (
                        <button
                          key={hour}
                          id={`time-select-${hour.replace(/[:\s]/g, '-')}`}
                          onClick={() => setSelectedTime(hour)}
                          className={`p-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            selectedTime === hour
                              ? 'bg-brand-600 border-brand-600 text-white shadow-md shadow-brand-600/15'
                              : 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300 hover:bg-slate-100'
                          }`}
                        >
                          <Clock className="h-3.5 w-3.5 opacity-75" />
                          {hour}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Consultation Format Type */}
                  <div className="mb-6 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2.5">Consultation Format</label>
                    <div className="flex gap-3">
                      <button
                        id="consult-type-inperson"
                        onClick={() => setConsultType('In-Person')}
                        className={`flex-1 p-3 rounded-xl border flex items-center justify-center gap-2 font-bold text-xs transition-all cursor-pointer ${
                          consultType === 'In-Person'
                            ? 'bg-white border-brand-600 text-brand-700 shadow-sm'
                            : 'bg-transparent border-slate-200 text-slate-500 hover:text-slate-700'
                        }`}
                      >
                        <MapPin className="h-4 w-4" />
                        In-Person Clinic Visit
                      </button>
                      <button
                        id="consult-type-video"
                        onClick={() => setConsultType('Video')}
                        className={`flex-1 p-3 rounded-xl border flex items-center justify-center gap-2 font-bold text-xs transition-all cursor-pointer ${
                          consultType === 'Video'
                            ? 'bg-white border-brand-600 text-brand-700 shadow-sm'
                            : 'bg-transparent border-slate-200 text-slate-500 hover:text-slate-700'
                        }`}
                      >
                        <Video className="h-4 w-4" />
                        Video Consultation
                      </button>
                    </div>
                    <p className="text-[10px] text-slate-400 mt-2 text-center">
                      {consultType === 'Video' 
                        ? '🔐 A secure encrypted video link will be sent to your dashboard 15 mins before your time.' 
                        : `📍 Consultation takes place at: ${doctor.hospital}`}
                    </p>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div className="text-slate-400 text-xs">
                    Date: <span className="font-bold text-slate-700">{selectedDate || 'Not selected'}</span>
                    <br />
                    Time: <span className="font-bold text-slate-700">{selectedTime || 'Not selected'}</span>
                  </div>
                  <button
                    id="booking-step-next"
                    disabled={!selectedDate || !selectedTime}
                    onClick={() => setBookingStep('form')}
                    className={`flex items-center gap-1.5 px-6 py-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      selectedDate && selectedTime
                        ? 'bg-brand-600 text-white hover:bg-brand-700 shadow-md shadow-brand-600/15'
                        : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    }`}
                  >
                    Provide Details
                    <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2: PATIENT DETAIL INFORMATION FORM */}
            {bookingStep === 'form' && (
              <form onSubmit={handleSubmitBooking} className="animate-fade-in flex-1 flex flex-col justify-between">
                <div className="space-y-4 max-h-[420px] overflow-y-auto pr-1 mb-4">
                  <h3 className="text-base font-extrabold text-slate-800 flex items-center gap-1.5">
                    <span className="bg-brand-100 text-brand-700 h-6 w-6 rounded-full flex items-center justify-center text-xs font-bold">2</span>
                    Patient & Medical Details
                  </h3>
                  
                  {/* Summary of Choice */}
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-600 flex justify-between items-center">
                    <div>
                      <p className="font-semibold text-slate-800">Booking: {doctor.name}</p>
                      <p className="text-[11px] text-slate-400">{selectedDate} at {selectedTime} • {consultType}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setBookingStep('info')}
                      className="text-brand-600 font-bold hover:underline cursor-pointer"
                    >
                      Change
                    </button>
                  </div>

                  {/* Who is this consultation for? Selector */}
                  <div className="bg-slate-50 p-4.5 rounded-2xl border border-slate-200">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-2.5">
                      Who is this consultation for? (Select Profile or Add Custom)
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {patientProfiles.map((prof) => (
                        <button
                          key={prof.id}
                          type="button"
                          onClick={() => handleSelectProfile(prof.id)}
                          className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 cursor-pointer ${
                            selectedProfileId === prof.id
                              ? 'bg-brand-600 border-brand-600 text-slate-950 shadow-md shadow-brand-600/15'
                              : 'bg-white border-slate-200 text-slate-700 hover:border-slate-350 hover:bg-slate-100'
                          }`}
                        >
                          <span className={`w-2 h-2 rounded-full ${selectedProfileId === prof.id ? 'bg-slate-950' : 'bg-brand-500'}`}></span>
                          {prof.name} 
                          <span className="text-[9px] opacity-75 font-normal">({prof.relationship})</span>
                        </button>
                      ))}
                      <button
                        type="button"
                        onClick={() => handleSelectProfile('custom')}
                        className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 cursor-pointer ${
                          selectedProfileId === 'custom'
                            ? 'bg-brand-600 border-brand-600 text-slate-950 shadow-md'
                            : 'bg-white border-slate-200 text-slate-700 hover:border-slate-350 hover:bg-slate-100'
                        }`}
                      >
                        <span>+ Custom / New Patient</span>
                      </button>
                    </div>

                    {selectedProfileId === 'custom' && (
                      <div className="bg-white border border-slate-200 p-3 rounded-xl space-y-2 mt-3.5 animate-fade-in text-xs">
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            id="save-custom-profile-checkbox"
                            checked={saveToProfiles}
                            onChange={(e) => setSaveToProfiles(e.target.checked)}
                            className="w-4 h-4 rounded text-brand-600 focus:ring-brand-500 border-slate-300"
                          />
                          <label htmlFor="save-custom-profile-checkbox" className="font-semibold text-slate-700 cursor-pointer">
                            Save to my Patient Directory for future bookings
                          </label>
                        </div>

                        {saveToProfiles && (
                          <div className="flex items-center gap-2 mt-1.5 animate-fade-in pl-6">
                            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Relationship:</label>
                            <select
                              value={customRelationship}
                              onChange={(e) => setCustomRelationship(e.target.value)}
                              className="p-1 bg-white border border-slate-250 rounded-lg text-xs font-medium focus:ring-1 focus:ring-brand-500 focus:outline-none"
                            >
                              <option value="Spouse">Spouse</option>
                              <option value="Child">Child</option>
                              <option value="Parent">Parent</option>
                              <option value="Sibling">Sibling</option>
                              <option value="Other">Other Dependents</option>
                            </select>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Patient Name */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-bold text-slate-500 uppercase">Patient Name</label>
                      <input
                        type="text"
                        required
                        value={patientName}
                        onChange={(e) => setPatientName(e.target.value)}
                        className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-brand-500 focus:bg-white text-slate-800"
                        placeholder="John Doe"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-bold text-slate-500 uppercase">Age</label>
                      <input
                        type="number"
                        required
                        min="1"
                        max="120"
                        value={patientAge}
                        onChange={(e) => setPatientAge(Number(e.target.value))}
                        className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-brand-500 focus:bg-white text-slate-800"
                        placeholder="32"
                      />
                    </div>
                  </div>

                  {/* Gender Selector */}
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Gender</label>
                    <div className="flex gap-2">
                      {['Male', 'Female', 'Other'].map((g) => (
                        <button
                          key={g}
                          type="button"
                          onClick={() => setPatientGender(g)}
                          className={`flex-1 py-1.5 rounded-lg border text-xs font-semibold cursor-pointer transition-all ${
                            patientGender === g
                              ? 'bg-brand-500 border-brand-500 text-slate-950'
                              : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {g}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Email & Phone */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-bold text-slate-500 uppercase">Email Address</label>
                      <input
                        type="email"
                        required
                        value={patientEmail}
                        onChange={(e) => setPatientEmail(e.target.value)}
                        className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-brand-500 focus:bg-white text-slate-800"
                        placeholder="johndoe@example.com"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-bold text-slate-500 uppercase">Phone Number</label>
                      <input
                        type="tel"
                        required
                        value={patientPhone}
                        onChange={(e) => setPatientPhone(e.target.value)}
                        className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-brand-500 focus:bg-white text-slate-800"
                        placeholder="+1 (555) 000-0000"
                      />
                    </div>
                  </div>

                  {/* Symptoms / Reason for Visit */}
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Primary Reason for Visit / Symptoms</label>
                    <textarea
                      required
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      rows={2}
                      className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-brand-500 focus:bg-white text-slate-800 resize-none"
                      placeholder="E.g., Seeking annual cardiac physical, chest pains after climbing stairs..."
                    />
                  </div>

                  {/* Optional notes */}
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Pre-visit Notes / History (Optional)</label>
                    <textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={1}
                      className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-brand-500 focus:bg-white text-slate-800 resize-none"
                      placeholder="E.g., Patient takes daily multivitamin, allergic to penicillin..."
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setBookingStep('info')}
                    className="px-5 py-2.5 rounded-xl text-xs font-bold bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 transition-all cursor-pointer"
                  >
                    Back
                  </button>
                  <button
                    id="submit-booking-form"
                    type="submit"
                    className="flex items-center gap-1.5 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-md shadow-emerald-600/15 cursor-pointer"
                  >
                    Confirm & Schedule Appointment
                    <UserCheck className="h-4 w-4" />
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* ==================== SCREEN 3: BOOKING SUCCESS RECEIPT CARD ==================== */}
        {bookingStep === 'success' && createdAppointment && (
          <div className="w-full p-8 md:p-12 text-center flex flex-col items-center justify-center animate-fade-in bg-slate-50">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-5 border border-emerald-200 animate-bounce">
              <Check className="h-8 w-8 stroke-[3]" />
            </div>

            <h2 className="text-2xl font-extrabold text-slate-800 mb-2">Appointment Secured Successfully!</h2>
            <p className="text-xs text-slate-500 max-w-md mx-auto mb-8">
              Your appointment with {doctor.name} has been added to our scheduling queues and locked onto the clinician calendar.
            </p>

            {/* Structured Receipt Box */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 w-full max-w-lg text-left shadow-sm mb-8 space-y-4 font-sans text-slate-600 text-xs">
              <div className="flex justify-between border-b border-slate-100 pb-3">
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block">RESERVATION ID</span>
                  <span className="font-mono font-bold text-slate-800 uppercase">{createdAppointment.id}</span>
                </div>
                <div className="text-right">
                  <span className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block">CONFIRMED DATE</span>
                  <span className="font-bold text-slate-800">{createdAppointment.createdDate}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pb-2 border-b border-slate-100">
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">PRACTITIONER</span>
                  <p className="font-extrabold text-slate-800">{doctor.name}</p>
                  <p className="text-[11px] text-slate-400">{doctor.specialty}</p>
                </div>
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">PATIENT</span>
                  <p className="font-bold text-slate-800">{createdAppointment.patientName}</p>
                  <p className="text-[11px] text-slate-400">Age: {createdAppointment.patientAge} • {createdAppointment.patientGender}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pb-2 border-b border-slate-100">
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">CONSULTATION SLOT</span>
                  <p className="font-bold text-slate-800">{createdAppointment.date}</p>
                  <p className="text-[11px] text-slate-400">At {createdAppointment.timeSlot}</p>
                </div>
                <div>
                  <span className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">FORMAT & PRICE</span>
                  <p className="font-bold text-slate-800">{createdAppointment.type}</p>
                  <p className="text-[11px] text-emerald-600 font-bold">${doctor.fees} Paid (Simulated)</p>
                </div>
              </div>

              <div>
                <span className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">REASON FOR VISIT</span>
                <p className="text-slate-700 leading-normal italic bg-slate-50 p-2.5 rounded-lg">"{createdAppointment.reason}"</p>
              </div>

              <div className="text-[10px] text-slate-400 flex items-start gap-1.5 bg-brand-50 p-3 rounded-lg border border-brand-100 text-brand-700">
                <FileText className="h-4 w-4 shrink-0 mt-0.5" />
                <p>
                  <strong>Preparation:</strong> If this is a clinical visit, please arrive 10 minutes early with valid identification. If this is a video consultation, your link will reside on your Dashboard.
                </p>
              </div>
            </div>

            <button
              id="success-close-btn"
              onClick={onClose}
              className="px-8 py-3 bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold rounded-xl transition-all shadow-md shadow-brand-600/15 cursor-pointer"
            >
              Return to Listings
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
