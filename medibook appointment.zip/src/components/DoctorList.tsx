import React, { useState, useMemo } from 'react';
import { Doctor } from '../types';
import { SPECIALTIES } from '../data';
import { 
  Search, 
  Star, 
  MapPin, 
  Calendar, 
  DollarSign, 
  Clock, 
  Heart, 
  Award, 
  Filter, 
  Stethoscope, 
  HeartHandshake, 
  ChevronRight 
} from 'lucide-react';

interface DoctorListProps {
  doctors: Doctor[];
  favoriteIds: string[];
  onToggleFavorite: (id: string) => void;
  onSelectDoctor: (doctor: Doctor) => void;
}

export default function DoctorList({ doctors, favoriteIds, onToggleFavorite, onSelectDoctor }: DoctorListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');
  const [priceRange, setPriceRange] = useState<'all' | 'under100' | '100to150' | 'over150'>('all');
  const [sortBy, setSortBy] = useState<'rating' | 'experience' | 'priceLow' | 'priceHigh'>('rating');

  // Filter & Sort Doctors
  const filteredAndSortedDoctors = useMemo(() => {
    return doctors
      .filter((doc) => doc.status === 'active')
      .filter((doc) => {
        // Search filter
        const matchSearch = 
          doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          doc.specialty.toLowerCase().includes(searchTerm.toLowerCase()) ||
          doc.biography.toLowerCase().includes(searchTerm.toLowerCase());
        
        // Specialty filter
        const matchSpecialty = 
          selectedSpecialty === 'all' || 
          doc.specialty.toLowerCase() === selectedSpecialty.toLowerCase() ||
          (selectedSpecialty === 'general' && doc.specialty.toLowerCase() === 'general medicine');

        // Price range filter
        let matchPrice = true;
        if (priceRange === 'under100') matchPrice = doc.fees < 100;
        else if (priceRange === '100to150') matchPrice = doc.fees >= 100 && doc.fees <= 150;
        else if (priceRange === 'over150') matchPrice = doc.fees > 150;

        return matchSearch && matchSpecialty && matchPrice;
      })
      .sort((a, b) => {
        if (sortBy === 'rating') return b.rating - a.rating;
        if (sortBy === 'experience') return b.experience - a.experience;
        if (sortBy === 'priceLow') return a.fees - b.fees;
        if (sortBy === 'priceHigh') return b.fees - a.fees;
        return 0;
      });
  }, [doctors, searchTerm, selectedSpecialty, priceRange, sortBy]);

  // Map specialty icon names to components
  const renderSpecialtyIcon = (iconName: string) => {
    switch (iconName) {
      case 'Heart': return <Heart className="h-5 w-5 text-rose-500" />;
      case 'Baby': return <Award className="h-5 w-5 text-amber-500" />; // Custom representation
      case 'Activity': return <ActivityIcon className="h-5 w-5 text-emerald-500" />;
      case 'Brain': return <ActivityIcon className="h-5 w-5 text-indigo-500" />; // Re-used for mental health/neurons
      default: return <Stethoscope className="h-5 w-5 text-teal-600" />;
    }
  };

  return (
    <div id="doctor-listings-panel" className="py-6 animate-fade-in">
      {/* Hero Header in Bento Style */}
      <div className="bg-white rounded-[2rem] border border-slate-200 p-8 md:p-10 mb-8 text-slate-950 relative overflow-hidden shadow-xs flex flex-col justify-center">
        <div className="max-w-2xl relative z-10">
          <span className="bg-brand-50 text-brand-600 border border-brand-100 text-[10px] px-3.5 py-1.5 rounded-full font-extrabold uppercase tracking-wider inline-flex items-center gap-1.5 mb-4">
            <HeartHandshake className="h-3 w-3 text-brand-600" />
            Verified Medical Practitioners
          </span>
          <h1 className="text-3xl md:text-5xl font-black text-slate-900 mt-2 leading-tight tracking-tight">
            Book your next <br className="hidden md:inline" />
            <span className="text-brand-600">health specialist</span> today.
          </h1>
          <p className="text-slate-500 mt-4 text-sm md:text-base leading-relaxed max-w-lg">
            Connect with board-certified clinical professionals across 60+ specialties. View verified patient ratings, historical logs, and request instant slot scheduling.
          </p>
        </div>
        {/* Decorative abstract pattern matching Bento Grid Design */}
        <div className="absolute -right-20 -bottom-20 w-96 h-96 bg-brand-50 rounded-full opacity-60 blur-3xl"></div>
      </div>

      {/* Specialty Pill Quick Selector */}
      <div className="mb-6">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
          <span>Filter by Specialties</span>
          <span className="h-px bg-slate-200 flex-1"></span>
        </h3>
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {SPECIALTIES.map((spec) => {
            const isActive = selectedSpecialty === spec.id;
            return (
              <button
                key={spec.id}
                onClick={() => setSelectedSpecialty(spec.id)}
                className={`px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all border flex items-center gap-2 cursor-pointer ${
                  isActive
                    ? 'bg-brand-600 text-white border-brand-600 shadow-md shadow-brand-600/15'
                    : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                {isActive && <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>}
                {spec.name}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* Advanced Filter Panel in Bento style */}
        <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-xs flex flex-col gap-5 lg:col-span-1">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-extrabold text-slate-800 flex items-center gap-2">
              <Filter className="h-4 w-4 text-brand-600" />
              Advanced Filters
            </h2>
            {(searchTerm || selectedSpecialty !== 'all' || priceRange !== 'all' || sortBy !== 'rating') && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedSpecialty('all');
                  setPriceRange('all');
                  setSortBy('rating');
                }}
                className="text-xs text-brand-600 hover:text-brand-700 font-bold cursor-pointer"
              >
                Clear all
              </button>
            )}
          </div>

          <div className="h-px bg-slate-100"></div>

          {/* Search Bar */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Search Doctor</label>
            <div className="relative">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Name, specialty, keywords..."
                className="w-full text-xs pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:border-brand-500 focus:bg-white transition-all text-slate-800 font-medium"
              />
            </div>
          </div>

          {/* Price Range */}
          <div className="flex flex-col gap-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Consultation Fee</label>
            <div className="flex flex-col gap-1.5">
              {[
                { id: 'all', label: 'Any Fee' },
                { id: 'under100', label: 'Under $100' },
                { id: '100to150', label: '$100 - $150' },
                { id: 'over150', label: 'Over $150' },
              ].map((range) => (
                <label key={range.id} className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer hover:text-slate-900">
                  <input
                    type="radio"
                    name="priceRange"
                    checked={priceRange === range.id}
                    onChange={() => setPriceRange(range.id as any)}
                    className="h-3.5 w-3.5 text-brand-600 border-slate-300 focus:ring-brand-500"
                  />
                  {range.label}
                </label>
              ))}
            </div>
          </div>

          {/* Sort By */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Sort Results By</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:border-brand-500 text-slate-700 font-bold"
            >
              <option value="rating">Highest Rated</option>
              <option value="experience">Years of Experience</option>
              <option value="priceLow">Fees: Low to High</option>
              <option value="priceHigh">Fees: High to Low</option>
            </select>
          </div>
        </div>

        {/* Doctor Grid (Right Panel, taking 3 columns) */}
        <div className="lg:col-span-3 flex flex-col gap-4">
          {/* Header Stats */}
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 font-extrabold font-mono uppercase tracking-wider">
              Showing {filteredAndSortedDoctors.length} verified doctors
            </span>
          </div>

          {filteredAndSortedDoctors.length === 0 ? (
            <div className="bg-white rounded-[2rem] border border-slate-200 p-12 text-center shadow-xs">
              <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-slate-100">
                <Search className="h-6 w-6 text-slate-400" />
              </div>
              <h3 className="text-base font-extrabold text-slate-800 mb-1">No doctors found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4 font-medium">
                We couldn't find any medical practitioners matching your filters. Try clearing some constraints or modifying your search keywords.
              </p>
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedSpecialty('all');
                  setPriceRange('all');
                  setSortBy('rating');
                }}
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-2xl transition-all cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredAndSortedDoctors.map((doc) => {
                const isFavorite = favoriteIds.includes(doc.id);
                return (
                  <div
                    key={doc.id}
                    id={`doc-card-${doc.id}`}
                    className="bg-white rounded-[2rem] border border-slate-200 hover:border-brand-500/40 p-5 shadow-xs hover:shadow-sm transition-all flex flex-col justify-between group relative overflow-hidden"
                  >
                    {/* Favorite Button Overlay */}
                    <button
                      id={`fav-btn-${doc.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(doc.id);
                      }}
                      className="absolute top-4 right-4 p-2 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-100 transition-all z-10 group/fav cursor-pointer"
                    >
                      <Heart
                        className={`h-4 w-4 transition-all ${
                          isFavorite 
                            ? 'fill-rose-500 text-rose-500 scale-110' 
                            : 'text-slate-400 group-hover/fav:text-rose-500'
                        }`}
                      />
                    </button>

                    <div>
                      {/* Doctor Info Section */}
                      <div className="flex gap-4 items-start mb-4">
                        <img
                          src={doc.image}
                          alt={doc.name}
                          className="w-16 h-16 rounded-2xl object-cover object-center bg-slate-100 border border-slate-200 shadow-xs"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <span className="text-[10px] uppercase tracking-wider font-extrabold bg-brand-50 text-brand-600 border border-brand-100 px-2.5 py-1 rounded-xl">
                            {doc.specialty}
                          </span>
                          <h3 className="text-base font-black text-slate-800 mt-2 leading-tight group-hover:text-brand-600 transition-colors">
                            {doc.name}
                          </h3>
                          <div className="flex items-center gap-1 mt-1 text-xs">
                            <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                            <span className="font-extrabold text-slate-700">{doc.rating}</span>
                            <span className="text-slate-400">({doc.reviewsCount} reviews)</span>
                          </div>
                        </div>
                      </div>

                      {/* Doctor Credentials */}
                      <div className="space-y-2.5 py-4 border-t border-b border-slate-100 text-xs text-slate-600 mb-4">
                        <div className="flex items-center gap-2">
                          <Award className="h-3.5 w-3.5 text-brand-600" />
                          <span className="font-medium text-slate-700">{doc.experience} Years of Clinical Experience</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                          <span className="truncate text-slate-500 font-medium">{doc.hospital}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="h-3.5 w-3.5 text-slate-400" />
                          <span className="text-slate-500 font-medium">Availability: <span className="font-bold text-slate-700">{doc.availability.days.join(', ')}</span></span>
                        </div>
                      </div>
                    </div>

                    {/* Pricing and Action Section */}
                    <div className="flex items-center justify-between pt-1">
                      <div>
                        <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider block">CONSULTATION FEE</span>
                        <span className="text-base font-black text-slate-900 flex items-center">
                          <DollarSign className="h-4 w-4 text-slate-400 -mr-0.5" />
                          {doc.fees}
                        </span>
                      </div>
                      
                      <button
                        id={`book-btn-${doc.id}`}
                        onClick={() => onSelectDoctor(doc)}
                        className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold px-4 py-3 rounded-2xl transition-all shadow-sm cursor-pointer"
                      >
                        Book Appointment
                        <ChevronRight className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Simple ActivityIcon utility since lucide-react might map differently
function ActivityIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
    </svg>
  );
}
