import React, { useState } from 'react';
import { User, ShieldAlert, Activity, UserPlus, Lock, CheckCircle2, ArrowRight, HeartPulse } from 'lucide-react';
import { UserAccount } from '../types';

interface LoginPortalProps {
  userAccounts: UserAccount[];
  activeUserId: string;
  onLogin: (userId: string) => void;
  onRegister: (user: Omit<UserAccount, 'id' | 'avatarColor'>) => void;
  onSelectAdmin: () => void;
}

export default function LoginPortal({
  userAccounts,
  activeUserId,
  onLogin,
  onRegister,
  onSelectAdmin
}: LoginPortalProps) {
  const [activeTab, setActiveTab] = useState<'signin' | 'signup'>('signin');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [selectedUserToLogin, setSelectedUserToLogin] = useState<string>(activeUserId || userAccounts[0]?.id || '');

  // Register state
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regAge, setRegAge] = useState(30);
  const [regGender, setRegGender] = useState('Female');
  const [regPhone, setRegPhone] = useState('');
  const [regBlood, setRegBlood] = useState('O+');
  const [regHeight, setRegHeight] = useState("5'8\"");
  const [regPassword, setRegPassword] = useState('');
  const [isRegisteredSuccess, setIsRegisteredSuccess] = useState(false);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
  };

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserToLogin) {
      setLoginError('Please select a patient profile to proceed.');
      return;
    }
    // Simple simulated secure logging: if password is provided, we check if it is "1234" or simply approve
    onLogin(selectedUserToLogin);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim() || !regEmail.trim()) return;

    setIsRegisteredSuccess(true);
    
    setTimeout(() => {
      onRegister({
        name: regName,
        email: regEmail,
        age: Number(regAge),
        gender: regGender,
        phone: regPhone || '+1 (555) 000-0000',
        bloodGroup: regBlood,
        height: regHeight
      });

      // Reset fields
      setIsRegisteredSuccess(false);
      setRegName('');
      setRegEmail('');
      setRegAge(30);
      setRegGender('Female');
      setRegPhone('');
      setRegBlood('O+');
      setRegHeight("5'8\"");
      setRegPassword('');
    }, 1200);
  };

  const activeUserObj = userAccounts.find(u => u.id === selectedUserToLogin) || userAccounts[0];

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 sm:p-6 select-none relative overflow-hidden">
      
      {/* Decorative Background Glows */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-brand-500/10 blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-indigo-500/10 blur-[120px] pointer-events-none"></div>

      {/* Main Container Card */}
      <div className="w-full max-w-lg bg-slate-950/85 backdrop-blur-md rounded-3xl border border-slate-800 shadow-2xl p-6 sm:p-8 space-y-6 relative z-10">
        
        {/* Portal Branding Header */}
        <div className="text-center space-y-2">
          <div className="mx-auto w-12 h-12 bg-brand-500 rounded-2xl flex items-center justify-center shadow-lg shadow-brand-500/20">
            <HeartPulse className="h-6 w-6 text-slate-950" />
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight sm:text-3xl">
            Medi<span className="text-brand-500">Book</span> Gateway
          </h1>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            Authorized Health Portal for Private Bookings, Vital Analytics, and Medical Records.
          </p>
        </div>

        {/* Dynamic Navigation Tabs */}
        <div className="grid grid-cols-2 gap-1 bg-slate-900 p-1 rounded-2xl border border-slate-800">
          <button
            type="button"
            onClick={() => {
              setActiveTab('signin');
              setLoginError('');
            }}
            className={`py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'signin'
                ? 'bg-brand-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Lock className="h-3.5 w-3.5" />
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('signup');
              setLoginError('');
            }}
            className={`py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'signup'
                ? 'bg-brand-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <UserPlus className="h-3.5 w-3.5" />
            New Patient
          </button>
        </div>

        {/* SIGN IN VIEW */}
        {activeTab === 'signin' && (
          <form onSubmit={handleSignIn} className="space-y-4 animate-fade-in">
            <div className="space-y-3.5">
              <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block">
                Choose Patient Profile
              </label>

              {/* Grid list of registered patient profiles to quickly log into */}
              <div className="grid grid-cols-1 gap-2.5 max-h-[190px] overflow-y-auto pr-1">
                {userAccounts.map((user) => {
                  const isSelected = selectedUserToLogin === user.id;
                  return (
                    <button
                      key={user.id}
                      type="button"
                      onClick={() => {
                        setSelectedUserToLogin(user.id);
                        setLoginError('');
                      }}
                      className={`flex items-center justify-between p-3 rounded-2xl border transition-all text-left w-full cursor-pointer ${
                        isSelected
                          ? 'bg-brand-500/10 border-brand-500/50 shadow-inner shadow-brand-500/5'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-750 hover:bg-slate-900'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-extrabold text-white ${user.avatarColor}`}>
                          {getInitials(user.name)}
                        </div>
                        <div>
                          <p className={`font-bold text-xs ${isSelected ? 'text-brand-400' : 'text-slate-200'}`}>
                            {user.name}
                          </p>
                          <p className="text-[10px] text-slate-400">{user.email}</p>
                        </div>
                      </div>

                      {isSelected && (
                        <div className="w-5 h-5 bg-brand-500 rounded-full flex items-center justify-center">
                          <CheckCircle2 className="h-3.5 w-3.5 text-slate-950" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Password input representing high fidelity security */}
            {activeUserObj && (
              <div className="space-y-1.5 animate-fade-in">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block">
                    Identity Verification PIN / Password
                  </label>
                  <span className="text-[9px] text-slate-500 italic">Optional: sandbox bypass</span>
                </div>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                    <Lock className="h-3.5 w-3.5" />
                  </span>
                  <input
                    type="password"
                    placeholder="Enter prefilled authorization key or leave blank"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-550 focus:ring-1 focus:ring-brand-500 focus:outline-none"
                  />
                </div>
              </div>
            )}

            {loginError && (
              <p className="text-xs text-rose-500 font-bold bg-rose-950/30 border border-rose-900/40 p-2.5 rounded-xl flex items-center gap-2">
                <ShieldAlert className="h-4 w-4" />
                {loginError}
              </p>
            )}

            {/* Login button */}
            <button
              type="submit"
              className="w-full py-3 bg-brand-500 hover:bg-brand-600 text-slate-950 font-black rounded-2xl text-xs tracking-wide transition-all shadow-lg shadow-brand-500/10 cursor-pointer flex items-center justify-center gap-2"
            >
              Access Secure Patient Portal
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </form>
        )}

        {/* SIGN UP / NEW PATIENT REGISTER VIEW */}
        {activeTab === 'signup' && (
          <form onSubmit={handleRegister} className="space-y-4 animate-fade-in">
            {isRegisteredSuccess ? (
              <div className="text-center py-8 space-y-3.5 animate-scale-up">
                <div className="mx-auto w-12 h-12 bg-emerald-500 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="h-6 w-6 text-slate-950" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base">Patient Profile Registered!</h3>
                  <p className="text-xs text-slate-400">Your health record has been established. Loading portal access...</p>
                </div>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 gap-3.5 text-xs">
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Legal Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Jane Doe"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white text-xs focus:ring-1 focus:ring-brand-500 focus:outline-none"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Email Address</label>
                    <input
                      type="email"
                      required
                      placeholder="jane.doe@example.com"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white text-xs font-mono focus:ring-1 focus:ring-brand-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Age</label>
                    <input
                      type="number"
                      required
                      min="1"
                      max="120"
                      value={regAge}
                      onChange={(e) => setRegAge(Number(e.target.value))}
                      className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white text-xs focus:ring-1 focus:ring-brand-500 focus:outline-none"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Gender</label>
                    <select
                      value={regGender}
                      onChange={(e) => setRegGender(e.target.value)}
                      className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white text-xs focus:ring-1 focus:ring-brand-500 focus:outline-none"
                    >
                      <option value="Female">Female</option>
                      <option value="Male">Male</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Blood Group</label>
                    <input
                      type="text"
                      placeholder="A+"
                      value={regBlood}
                      onChange={(e) => setRegBlood(e.target.value)}
                      className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white text-xs focus:ring-1 focus:ring-brand-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3.5 text-xs">
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Height (e.g. 5'6")</label>
                    <input
                      type="text"
                      placeholder="5'6"
                      value={regHeight}
                      onChange={(e) => setRegHeight(e.target.value)}
                      className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white text-xs focus:ring-1 focus:ring-brand-500 focus:outline-none"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-400 uppercase">Mobile Number</label>
                    <input
                      type="tel"
                      placeholder="+1 (555) 000-0000"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white text-xs font-mono focus:ring-1 focus:ring-brand-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-1 text-xs">
                  <label className="text-[9px] font-bold text-slate-400 uppercase">Account Secret Key (Optional)</label>
                  <input
                    type="password"
                    placeholder="Establish verification key for identity"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white text-xs focus:ring-1 focus:ring-brand-500 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-brand-500 hover:bg-brand-600 text-slate-950 font-black rounded-2xl text-xs tracking-wide transition-all shadow-lg cursor-pointer flex items-center justify-center gap-2"
                >
                  Create & Initialize Health Portal
                  <CheckCircle2 className="h-3.5 w-3.5" />
                </button>
              </>
            )}
          </form>
        )}

        {/* Footer Admin portal quick links */}
        <div className="border-t border-slate-800/80 pt-4 text-center">
          <button
            type="button"
            onClick={onSelectAdmin}
            className="text-xs text-teal-400 hover:text-teal-350 hover:underline transition-all cursor-pointer font-bold inline-flex items-center gap-1.5"
          >
            <User className="h-3 w-3" />
            Switch to Administrator Dashboard Gateway
          </button>
        </div>

      </div>
    </div>
  );
}
