import React, { useState, useMemo } from 'react';
import { Appointment, Doctor, HealthMetric, MedicalRecord, Review, PatientProfile } from '../types';
import { 
  User, 
  Calendar, 
  History, 
  Heart, 
  Upload, 
  Trash2, 
  Settings, 
  Activity, 
  FileText, 
  Video, 
  Check, 
  Info, 
  Droplet, 
  Scale, 
  HeartCrack, 
  TrendingUp, 
  Plus, 
  Stethoscope, 
  CheckCircle,
  Eye,
  AlertCircle,
  CalendarDays,
  FileSpreadsheet,
  Bell,
  Volume2,
  Clock,
  Sparkles
} from 'lucide-react';

interface PatientDashboardProps {
  appointments: Appointment[];
  doctors: Doctor[];
  healthMetrics: HealthMetric[];
  medicalRecords: MedicalRecord[];
  favoriteIds: string[];
  currentPatient: {
    name: string;
    email: string;
    phone: string;
    age: number;
    gender: string;
    bloodGroup: string;
    height: string;
  };
  onUpdatePatient: (updatedPatient: any) => void;
  onCancelAppointment: (id: string) => void;
  onRescheduleAppointment: (id: string, newDate: string, newTime: string) => void;
  onAddHealthMetric: (metric: Omit<HealthMetric, 'id'>) => void;
  onUploadMedicalRecord: (record: Omit<MedicalRecord, 'id'>) => void;
  onSelectDoctor: (doctor: Doctor) => void;
  patientProfiles?: PatientProfile[];
  onUpdatePatientProfiles?: (profiles: PatientProfile[]) => void;
  onBookAppointment?: (aptData: Omit<Appointment, 'id' | 'createdDate'>) => void;
}

export default function PatientDashboard({
  appointments,
  doctors,
  healthMetrics,
  medicalRecords,
  favoriteIds,
  currentPatient,
  onUpdatePatient,
  onCancelAppointment,
  onRescheduleAppointment,
  onAddHealthMetric,
  onUploadMedicalRecord,
  onSelectDoctor,
  patientProfiles = [],
  onUpdatePatientProfiles,
  onBookAppointment
}: PatientDashboardProps) {
  const [activeTab, setActiveTab] = useState<'appointments' | 'vitals' | 'records' | 'favorites' | 'profile'>('appointments');
  const [editingProfile, setEditingProfile] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Upcoming Appointment Alerts State
  const [isMuted, setIsMuted] = useState(() => {
    return localStorage.getItem('medibook_alerts_muted') === 'true';
  });
  const [systemCheckStatus, setSystemCheckStatus] = useState<'idle' | 'testing' | 'success'>('idle');

  const handleToggleMute = () => {
    const newValue = !isMuted;
    setIsMuted(newValue);
    localStorage.setItem('medibook_alerts_muted', String(newValue));
    showToast(newValue ? 'Notification alerts muted.' : 'Notification alerts activated.');
  };

  const handleRunSystemCheck = () => {
    setSystemCheckStatus('testing');
    setTimeout(() => {
      setSystemCheckStatus('success');
      setTimeout(() => setSystemCheckStatus('idle'), 3000);
    }, 1500);
  };

  // Safe datetime parsing for appointments
  const parseAptTime = (dateStr: string, timeSlotStr: string): Date => {
    const [year, month, day] = dateStr.split('-').map(Number);
    let hours = 9;
    let minutes = 0;
    
    const timeMatch = timeSlotStr.match(/(\d+):(\d+)\s*(AM|PM)/i);
    if (timeMatch) {
      hours = Number(timeMatch[1]);
      minutes = Number(timeMatch[2]);
      const ampm = timeMatch[3].toUpperCase();
      if (ampm === 'PM' && hours < 12) {
        hours += 12;
      } else if (ampm === 'AM' && hours === 12) {
        hours = 0;
      }
    }
    return new Date(year, month - 1, day, hours, minutes);
  };

  // Find appointments within the next 24 hours
  const urgentApts = useMemo(() => {
    const now = new Date();
    const twentyFourHoursFromNow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    
    return appointments
      .filter(apt => apt.status === 'scheduled' || apt.status === 'pending')
      .map(apt => {
        const aptTime = parseAptTime(apt.date, apt.timeSlot);
        const diffMs = aptTime.getTime() - now.getTime();
        const diffHours = diffMs / (1000 * 60 * 60);
        return {
          apt,
          aptTime,
          diffHours,
          isWithin: diffHours >= 0 && diffHours <= 24
        };
      })
      .filter(item => item.isWithin)
      .sort((a, b) => a.aptTime.getTime() - b.aptTime.getTime());
  }, [appointments]);

  const getCountdownString = (diffHours: number) => {
    if (diffHours < 0) return 'Passed / Started';
    const hours = Math.floor(diffHours);
    const minutes = Math.round((diffHours - hours) * 60);
    if (hours === 0) {
      return `${minutes} minute${minutes !== 1 ? 's' : ''}`;
    }
    return `${hours} hour${hours !== 1 ? 's' : ''} and ${minutes} minute${minutes !== 1 ? 's' : ''}`;
  };

  const handleInjectSimulatedAppointment = () => {
    if (!onBookAppointment) return;
    
    const now = new Date();
    // Set simulated appointment in 2 hours
    const simTime = new Date(now.getTime() + 2 * 60 * 60 * 1000);
    
    const yyyy = simTime.getFullYear();
    const mm = String(simTime.getMonth() + 1).padStart(2, '0');
    const dd = String(simTime.getDate()).padStart(2, '0');
    const dateStr = `${yyyy}-${mm}-${dd}`;
    
    let hr = simTime.getHours();
    const ampm = hr >= 12 ? 'PM' : 'AM';
    hr = hr % 12;
    if (hr === 0) hr = 12;
    const hrStr = String(hr).padStart(2, '0');
    const timeSlotStr = `${hrStr}:00 ${ampm}`;
    
    const targetDoc = doctors.find(d => d.id === 'doc-1') || doctors[0] || {
      id: 'doc-1',
      name: 'Dr. Aris Thorne',
      specialty: 'Cardiology',
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&auto=format&fit=crop&q=80'
    };
    
    onBookAppointment({
      doctorId: targetDoc.id,
      doctorName: targetDoc.name,
      doctorSpecialty: targetDoc.specialty,
      doctorImage: targetDoc.image,
      patientName: currentPatient.name,
      patientAge: currentPatient.age,
      patientGender: currentPatient.gender,
      patientEmail: currentPatient.email,
      patientPhone: currentPatient.phone || '+1 (555) 000-0000',
      date: dateStr,
      timeSlot: timeSlotStr,
      type: 'Video',
      reason: 'Urgent medical tracking to inspect dynamic cardiovascular telemetry performance.',
      status: 'scheduled'
    });
    
    showToast(`Visual alert simulated! Booking established for ${timeSlotStr} today.`);
  };

  const showToast = (message: string) => {
    setSuccessToast(message);
    setTimeout(() => {
      setSuccessToast(null);
    }, 4000);
  };

  // Profile Edit fields
  const [profileName, setProfileName] = useState(currentPatient.name);
  const [profileEmail, setProfileEmail] = useState(currentPatient.email);
  const [profilePhone, setProfilePhone] = useState(currentPatient.phone);
  const [profileAge, setProfileAge] = useState(currentPatient.age);
  const [profileGender, setProfileGender] = useState(currentPatient.gender);
  const [profileBloodGroup, setProfileBloodGroup] = useState(currentPatient.bloodGroup);
  const [profileHeight, setProfileHeight] = useState(currentPatient.height);

  // Vitals form fields
  const [bpSys, setBpSys] = useState('120');
  const [bpDia, setBpDia] = useState('80');
  const [weight, setWeight] = useState('78');
  const [heartRate, setHeartRate] = useState('72');
  const [temp, setTemp] = useState('36.6');
  const [sugar, setSugar] = useState('95');
  const [vitalNotes, setVitalNotes] = useState('');

  // Reschedule Form state
  const [reschedulingId, setReschedulingId] = useState<string | null>(null);
  const [rescheduleDate, setRescheduleDate] = useState('');
  const [rescheduleTime, setRescheduleTime] = useState('');

  // Simulation Calls state
  const [activeCallId, setActiveCallId] = useState<string | null>(null);

  // Family members management state
  const [showAddFamilyForm, setShowAddFamilyForm] = useState(false);
  const [newFamName, setNewFamName] = useState('');
  const [newFamRelation, setNewFamRelation] = useState('Spouse');
  const [newFamAge, setNewFamAge] = useState<number>(30);
  const [newFamGender, setNewFamGender] = useState('Female');
  const [newFamEmail, setNewFamEmail] = useState('');
  const [newFamPhone, setNewFamPhone] = useState('');
  const [newFamBloodGroup, setNewFamBloodGroup] = useState('O+');
  const [newFamHeight, setNewFamHeight] = useState("5'6\"");

  const handleAddFamilyMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFamName.trim()) return;

    const newProfile: PatientProfile = {
      id: `p-${Math.random().toString(36).substr(2, 9)}`,
      name: newFamName,
      email: newFamEmail || currentPatient.email,
      phone: newFamPhone || currentPatient.phone,
      age: Number(newFamAge),
      gender: newFamGender,
      bloodGroup: newFamBloodGroup,
      height: newFamHeight,
      relationship: newFamRelation
    };

    if (onUpdatePatientProfiles) {
      onUpdatePatientProfiles([...patientProfiles, newProfile]);
      showToast(`${newFamName} added to patient profiles successfully!`);
    }

    // Reset Form
    setNewFamName('');
    setNewFamRelation('Spouse');
    setNewFamAge(30);
    setNewFamGender('Female');
    setNewFamEmail('');
    setNewFamPhone('');
    setNewFamBloodGroup('O+');
    setNewFamHeight("5'6\"");
    setShowAddFamilyForm(false);
  };

  const handleDeleteFamilyMember = (id: string, name: string) => {
    if (onUpdatePatientProfiles) {
      const updated = patientProfiles.filter(p => p.id !== id);
      onUpdatePatientProfiles(updated);
      showToast(`${name} removed from patient profiles.`);
    }
  };

  // Document Upload States
  const [dragActive, setDragActive] = useState(false);
  const [newDiagnosis, setNewDiagnosis] = useState('');
  const [newDoctor, setNewDoctor] = useState('');
  const [newSpecialty, setNewSpecialty] = useState('');
  const [uploadedRecords, setUploadedRecords] = useState<Array<{ name: string; size: string; date: string }>>([]);

  // Calculate upcoming and past appointments specifically for this client
  const { upcomingApts, pastApts } = useMemo(() => {
    const sorted = [...appointments].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    const upcoming = sorted.filter(apt => apt.status === 'scheduled' || apt.status === 'pending');
    const past = sorted.filter(apt => apt.status === 'completed' || apt.status === 'cancelled');
    return { upcomingApts: upcoming, pastApts: past };
  }, [appointments]);

  // Find favorite doctors
  const favoriteDoctors = useMemo(() => {
    return doctors.filter(doc => favoriteIds.includes(doc.id));
  }, [doctors, favoriteIds]);

  // Handle Profile Update Save
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdatePatient({
      name: profileName,
      email: profileEmail,
      phone: profilePhone,
      age: Number(profileAge),
      gender: profileGender,
      bloodGroup: profileBloodGroup,
      height: profileHeight,
    });
    setEditingProfile(false);
  };

  // Handle Vital Submission
  const handleAddVitals = (e: React.FormEvent) => {
    e.preventDefault();
    onAddHealthMetric({
      date: new Date().toISOString().split('T')[0],
      bloodPressure: `${bpSys}/${bpDia}`,
      weight: Number(weight),
      heartRate: Number(heartRate),
      temperature: Number(temp),
      bloodSugar: Number(sugar),
      notes: vitalNotes || 'Self-logged'
    });
    setVitalNotes('');
    showToast('Health metrics registered in system logs.');
  };

  // Simulated Document Upload
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      const newFile = {
        name: file.name,
        size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
        date: new Date().toISOString().split('T')[0]
      };
      setUploadedRecords([newFile, ...uploadedRecords]);
    }
  };

  const handleManualRecordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDiagnosis || !newDoctor) return;
    onUploadMedicalRecord({
      date: new Date().toISOString().split('T')[0],
      doctorName: newDoctor,
      specialty: newSpecialty || 'General Practitioner',
      diagnosis: newDiagnosis,
      prescription: 'Added by Patient Profile vault'
    });
    setNewDiagnosis('');
    setNewDoctor('');
    setNewSpecialty('');
    showToast('Medical diagnostics report added to vault.');
  };

  // Custom SVG Trend Line Chart Data
  // Let's generate points for BP Systolic and Heart Rate based on metrics
  const chartCoordinates = useMemo(() => {
    const list = [...healthMetrics].reverse(); // oldest to newest
    if (list.length < 2) return null;

    const maxHr = Math.max(...list.map(m => m.heartRate), 100);
    const minHr = Math.min(...list.map(m => m.heartRate), 50);
    const hrRange = maxHr - minHr || 1;

    // Get Systolic BP value
    const listBP = list.map(m => {
      const sys = Number(m.bloodPressure.split('/')[0]) || 120;
      return sys;
    });
    const maxBP = Math.max(...listBP, 140);
    const minBP = Math.min(...listBP, 90);
    const bpRange = maxBP - minBP || 1;

    // Map to width 500, height 120
    const w = 500;
    const h = 120;
    const padding = 15;

    const hrPoints = list.map((m, idx) => {
      const x = padding + (idx / (list.length - 1)) * (w - padding * 2);
      const y = h - padding - ((m.heartRate - minHr) / hrRange) * (h - padding * 2);
      return `${x},${y}`;
    }).join(' ');

    const bpPoints = list.map((m, idx) => {
      const x = padding + (idx / (list.length - 1)) * (w - padding * 2);
      const sys = Number(m.bloodPressure.split('/')[0]) || 120;
      const y = h - padding - ((sys - minBP) / bpRange) * (h - padding * 2);
      return `${x},${y}`;
    }).join(' ');

    return { hrPoints, bpPoints, list, maxHr, minHr, maxBP, minBP };
  }, [healthMetrics]);

  return (
    <div id="patient-dashboard-panel" className="py-4 animate-fade-in text-slate-800 relative">
      {/* Toast Alert Feedback */}
      {successToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white text-xs font-extrabold px-4.5 py-3 rounded-2xl border border-slate-800 shadow-xl flex items-center gap-2.5 animate-scale-up">
          <span className="bg-emerald-500/20 text-emerald-400 p-1 rounded-full">
            <Check className="h-3 w-3" />
          </span>
          <span>{successToast}</span>
        </div>
      )}

      {/* Dynamic Vitals Summary Header */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-brand-600 rounded-[2rem] p-5 text-white flex flex-col justify-between shadow-xs">
          <div>
            <span className="text-[10px] tracking-wider uppercase font-extrabold text-brand-200">Active Patient</span>
            <h2 className="text-lg font-extrabold mt-1">{currentPatient.name}</h2>
            <p className="text-xs text-brand-100 mt-1">Age: {currentPatient.age} • Gender: {currentPatient.gender}</p>
          </div>
          <div className="mt-4 pt-3 border-t border-brand-500 flex justify-between text-xs text-brand-100 font-mono">
            <span>Blood: <strong className="text-white">{currentPatient.bloodGroup}</strong></span>
            <span>Height: <strong className="text-white">{currentPatient.height}</strong></span>
          </div>
        </div>

        {/* BP Widget */}
        <div className="bg-white rounded-[2rem] p-5 border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="bg-rose-50 p-3.5 rounded-2xl border border-rose-100 text-rose-600">
            <Droplet className="h-6 w-6 stroke-[2.5]" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-extrabold uppercase block tracking-wider">Blood Pressure</span>
            <span className="text-xl font-extrabold text-slate-800">
              {healthMetrics[0]?.bloodPressure || '120/80'}
            </span>
            <span className="text-[10px] text-emerald-500 font-bold block mt-0.5">mmHg • Normal Range</span>
          </div>
        </div>

        {/* Heart Rate Widget */}
        <div className="bg-white rounded-[2rem] p-5 border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="bg-brand-50 p-3.5 rounded-2xl border border-brand-100 text-brand-600">
            <Activity className="h-6 w-6 stroke-[2.5]" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-extrabold uppercase block tracking-wider">Resting Heart Rate</span>
            <span className="text-xl font-extrabold text-slate-800">
              {healthMetrics[0]?.heartRate || 72} <span className="text-xs font-normal text-slate-400">BPM</span>
            </span>
            <span className="text-[10px] text-brand-600 font-bold block mt-0.5">● Regular Rhythm</span>
          </div>
        </div>

        {/* Weight Widget */}
        <div className="bg-white rounded-[2rem] p-5 border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="bg-indigo-50 p-3.5 rounded-2xl border border-indigo-100 text-indigo-600">
            <Scale className="h-6 w-6 stroke-[2.5]" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-extrabold uppercase block tracking-wider">Body Weight</span>
            <span className="text-xl font-extrabold text-slate-800">
              {healthMetrics[0]?.weight || 78} <span className="text-xs font-normal text-slate-400">kg</span>
            </span>
            <span className="text-[10px] text-slate-500 font-bold block mt-0.5">BMI: 23.4 (Ideal)</span>
          </div>
        </div>
      </div>

      {/* ==================== UPCOMING APPOINTMENT ALERT NOTIFICATION BANNER ==================== */}
      {urgentApts.length > 0 && (
        <div 
          id="upcoming-appointment-alert-banner" 
          className={`mb-6 rounded-[2rem] p-5 border transition-all duration-300 relative overflow-hidden ${
            isMuted 
              ? 'bg-slate-50 border-slate-200' 
              : 'bg-gradient-to-r from-amber-50 to-orange-50/70 border-amber-200 shadow-sm shadow-amber-500/5'
          }`}
        >
          {/* Decorative pulsating radar ring in background */}
          {!isMuted && (
            <div className="absolute right-6 top-1/2 -translate-y-1/2 opacity-10 pointer-events-none">
              <div className="w-24 h-24 rounded-full border border-amber-500 animate-ping" />
            </div>
          )}

          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5 relative z-10">
            <div className="flex items-start gap-4 flex-1">
              {/* Pulsating Icon Header */}
              <div className={`p-3 rounded-2xl shrink-0 border ${
                isMuted 
                  ? 'bg-slate-100 border-slate-200 text-slate-500' 
                  : 'bg-amber-100 border-amber-200 text-amber-600 animate-bounce'
              }`}>
                <Bell className="h-6 w-6 stroke-[2.5]" />
              </div>

              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`text-[10px] tracking-wider uppercase font-extrabold px-2 py-0.5 rounded-md ${
                    isMuted 
                      ? 'bg-slate-200 text-slate-600' 
                      : 'bg-amber-100 text-amber-800 border border-amber-250/50'
                  }`}>
                    System Alert: Upcoming consultation
                  </span>
                  {!isMuted && (
                    <span className="flex items-center gap-1 text-[10px] font-bold text-red-500">
                      <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping" />
                      Live in {getCountdownString(urgentApts[0].diffHours)}
                    </span>
                  )}
                </div>

                <h3 className="text-sm font-extrabold text-slate-800 mt-2">
                  Medical session scheduled with <strong className="text-amber-800">{urgentApts[0].apt.doctorName}</strong> ({urgentApts[0].apt.doctorSpecialty})
                </h3>
                
                <p className="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-x-2 gap-y-1">
                  <span className="flex items-center gap-1 font-semibold text-slate-700">
                    <Clock className="h-3.5 w-3.5 text-slate-400" />
                    Today • {urgentApts[0].apt.timeSlot}
                  </span>
                  <span>•</span>
                  <span className="italic">Reason: "{urgentApts[0].apt.reason}"</span>
                </p>

                {/* System Check Status Feed */}
                {systemCheckStatus !== 'idle' && (
                  <div className="mt-3 text-xs bg-white/60 border border-amber-100 rounded-xl p-2.5 max-w-md animate-scale-up">
                    {systemCheckStatus === 'testing' ? (
                      <span className="flex items-center gap-2 text-indigo-600 font-bold">
                        <span className="w-2.5 h-2.5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                        Analyzing camera, microphone latency and secure WebRTC socket channels...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2 text-emerald-600 font-bold">
                        <CheckCircle className="h-4 w-4" />
                        Diagnostic pass: Bandwidth optimal. Camera and microphone ready for live video.
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Quick Action Buttons on Alert Banner */}
            <div className="flex flex-wrap sm:flex-nowrap items-center gap-2.5 w-full md:w-auto shrink-0 md:border-l md:border-slate-200/60 md:pl-5">
              {urgentApts[0].apt.type === 'Video' ? (
                <>
                  <button
                    id="banner-system-check-btn"
                    onClick={handleRunSystemCheck}
                    disabled={systemCheckStatus === 'testing'}
                    className="flex-1 sm:flex-initial text-center text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 px-4 py-2.5 rounded-xl transition-all shadow-xs cursor-pointer disabled:opacity-50"
                  >
                    Run System Check
                  </button>
                  <button
                    id="banner-launch-call-btn"
                    onClick={() => setActiveCallId(urgentApts[0].apt.id)}
                    className="flex-1 sm:flex-initial text-center text-xs font-extrabold text-white bg-amber-600 hover:bg-amber-700 px-4 py-2.5 rounded-xl transition-all shadow-xs shadow-amber-600/10 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Video className="h-4 w-4" />
                    Join Video Consultation
                  </button>
                </>
              ) : (
                <>
                  <button
                    id="banner-directions-btn"
                    onClick={() => alert(`Directions to ${urgentApts[0].apt.doctorName}'s clinic:\nLocation: ${doctors.find(d => d.name === urgentApts[0].apt.doctorName)?.hospital || 'Main Medical Center, Wing B'}\nPlease arrive 10 minutes prior to your time Slot.`)}
                    className="flex-1 sm:flex-initial text-center text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 px-4 py-2.5 rounded-xl transition-all shadow-xs cursor-pointer"
                  >
                    Get Clinic Directions
                  </button>
                  <button
                    id="banner-pre-log-vitals-btn"
                    onClick={() => setActiveTab('vitals')}
                    className="flex-1 sm:flex-initial text-center text-xs font-extrabold text-white bg-amber-600 hover:bg-amber-700 px-4 py-2.5 rounded-xl transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <TrendingUp className="h-4 w-4" />
                    Pre-Register Vitals
                  </button>
                </>
              )}

              {/* Mute toggle button */}
              <button
                id="banner-mute-toggle"
                onClick={handleToggleMute}
                className="p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                title={isMuted ? "Unmute local alerts" : "Mute local alerts"}
              >
                {isMuted ? <Volume2 className="h-4 w-4 text-emerald-500" /> : <Volume2 className="h-4 w-4" />}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== DEMO NOTIFICATION SANDBOX PANEL ==================== */}
      <div className="mb-6 bg-slate-50 rounded-[2rem] p-5 border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-indigo-50 border border-indigo-100 text-indigo-600 rounded-xl shrink-0 mt-0.5">
            <Sparkles className="h-5 w-5" />
          </div>
          <div>
            <h4 className="text-xs font-extrabold text-slate-800">Notification Alert Sandbox</h4>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Test upcoming appointment alerts within the next 24 hours. Injecting a simulated booking activates visual badges, counting indicators, and live countdown banners.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0 w-full md:w-auto">
          {onBookAppointment ? (
            <button
              id="sandbox-inject-booking-btn"
              onClick={handleInjectSimulatedAppointment}
              className="w-full md:w-auto text-center text-xs font-extrabold text-white bg-indigo-600 hover:bg-indigo-700 px-4.5 py-2.5 rounded-xl transition-all shadow-xs shadow-indigo-600/10 flex items-center justify-center gap-1.5 cursor-pointer hover:scale-[1.02]"
            >
              <Plus className="h-4 w-4" />
              Simulate Booking in 2 Hours
            </button>
          ) : (
            <span className="text-[10px] text-rose-500 font-bold bg-rose-50 px-2 py-1 rounded-lg border border-rose-100">
              Booking unavailable
            </span>
          )}
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex border-b border-slate-200 mb-6 overflow-x-auto pb-1 scrollbar-none gap-2">
        {[
          { id: 'appointments', label: 'My Bookings', icon: CalendarDays },
          { id: 'vitals', label: 'Vitals & Metrics', icon: TrendingUp },
          { id: 'records', label: 'Medical History', icon: FileSpreadsheet },
          { id: 'favorites', label: 'Favorites', icon: Heart },
          { id: 'profile', label: 'Profile Settings', icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`tab-patient-${tab.id}`}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer relative ${
                isActive
                  ? 'bg-slate-900 text-white'
                  : 'bg-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
              {tab.id === 'appointments' && urgentApts.length > 0 && (
                <span className="ml-1.5 flex items-center gap-1 shrink-0">
                  <span className={`h-1.5 w-1.5 rounded-full ${isMuted ? 'bg-slate-400' : 'bg-rose-500 animate-pulse'}`} />
                  <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-extrabold ${isActive ? 'bg-white/20 text-white' : 'bg-rose-50 text-rose-600'}`}>
                    {urgentApts.length}
                  </span>
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ==================== SUB-VIEW: APPOINTMENTS ==================== */}
      {activeTab === 'appointments' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in items-start">
          {/* Upcoming Consultations */}
          <div className="lg:col-span-2 flex flex-col gap-4">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span>
              Upcoming Consultation Schedule
            </h3>

            {upcomingApts.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center shadow-xs">
                <p className="text-xs text-slate-400 italic mb-3">No pending or upcoming medical bookings locked.</p>
                <p className="text-[11px] text-slate-400 max-w-xs mx-auto">Visit the Doctor Listings tab in the top portal menu to secure a clinical consultation.</p>
              </div>
            ) : (
              upcomingApts.map((apt) => (
                <div 
                  key={apt.id} 
                  id={`apt-card-${apt.id}`}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col sm:flex-row items-start justify-between gap-4 hover:border-slate-300 transition-all relative overflow-hidden"
                >
                  <div className="flex gap-4 items-start flex-1">
                    <img 
                      src={apt.doctorImage} 
                      alt={apt.doctorName} 
                      className="w-12 h-12 rounded-xl object-cover object-center border border-slate-100 bg-slate-50 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <span className="text-[9px] uppercase tracking-wider font-extrabold text-brand-700 bg-brand-50 px-2 py-0.5 rounded-md border border-brand-100">
                        {apt.doctorSpecialty}
                      </span>
                      <h4 className="font-extrabold text-slate-800 text-sm mt-1">{apt.doctorName}</h4>
                      <p className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {apt.date} • {apt.timeSlot}
                      </p>
                      
                      <div className="mt-2.5 text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        <span className="font-bold text-[10px] text-slate-400 block uppercase mb-0.5">Symptom Log</span>
                        <p className="italic">"{apt.reason}"</p>
                      </div>

                      {/* Display Consultation Link if Video format */}
                      {apt.type === 'Video' && (
                        <div className="mt-3 flex items-center gap-2">
                          <button
                            id={`launch-call-${apt.id}`}
                            onClick={() => setActiveCallId(apt.id)}
                            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg shadow-sm transition-all cursor-pointer"
                          >
                            <Video className="h-3.5 w-3.5" />
                            Launch Video Consultation (Call Room)
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Booking action tools */}
                  <div className="flex flex-col gap-2 items-end shrink-0 w-full sm:w-auto">
                    <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-100 text-center self-start sm:self-auto">
                      {apt.status === 'scheduled' ? 'Confirmed' : 'Pending Verification'}
                    </span>
                    
                    {reschedulingId !== apt.id ? (
                      <div className="flex gap-1.5 w-full sm:w-auto">
                        <button
                          id={`resched-trigger-${apt.id}`}
                          onClick={() => {
                            setReschedulingId(apt.id);
                            setRescheduleDate(apt.date);
                            setRescheduleTime(apt.timeSlot);
                          }}
                          className="flex-1 sm:flex-none text-center text-[10px] font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg transition-all border border-slate-200 cursor-pointer"
                        >
                          Reschedule
                        </button>
                        <button
                          id={`cancel-apt-${apt.id}`}
                          onClick={() => {
                            if (window.confirm('Are you sure you want to cancel this appointment?')) {
                              onCancelAppointment(apt.id);
                            }
                          }}
                          className="flex-1 sm:flex-none text-center text-[10px] font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 px-3 py-1.5 rounded-lg transition-all border border-rose-100 cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex flex-col gap-2 w-full max-w-xs animate-scale-up">
                        <span className="text-[9px] font-bold text-slate-500 uppercase">Select New Slot</span>
                        <div className="space-y-1.5">
                          <input 
                            type="date" 
                            value={rescheduleDate}
                            onChange={(e) => setRescheduleDate(e.target.value)}
                            className="w-full text-[11px] p-1.5 border border-slate-200 bg-white rounded-lg focus:outline-none"
                          />
                          <select 
                            value={rescheduleTime}
                            onChange={(e) => setRescheduleTime(e.target.value)}
                            className="w-full text-[11px] p-1.5 border border-slate-200 bg-white rounded-lg focus:outline-none"
                          >
                            <option value="09:00 AM">09:00 AM</option>
                            <option value="10:00 AM">10:00 AM</option>
                            <option value="11:00 AM">11:00 AM</option>
                            <option value="02:00 PM">02:00 PM</option>
                            <option value="03:00 PM">03:00 PM</option>
                            <option value="04:00 PM">04:00 PM</option>
                          </select>
                        </div>
                        <div className="flex gap-1.5 mt-1">
                          <button
                            id={`save-reschedule-${apt.id}`}
                            type="button"
                            onClick={() => {
                              onRescheduleAppointment(apt.id, rescheduleDate, rescheduleTime);
                              setReschedulingId(null);
                            }}
                            className="flex-1 text-[10px] font-bold bg-brand-600 text-white py-1 rounded-lg hover:bg-brand-700 cursor-pointer"
                          >
                            Save
                          </button>
                          <button
                            id={`cancel-reschedule-${apt.id}`}
                            type="button"
                            onClick={() => setReschedulingId(null)}
                            className="flex-1 text-[10px] font-bold bg-slate-200 text-slate-600 py-1 rounded-lg hover:bg-slate-300 cursor-pointer"
                          >
                            Exit
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Past History & Invoices */}
          <div className="lg:col-span-1 flex flex-col gap-4">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <History className="h-4 w-4 text-slate-400" />
              Past Consultations ({pastApts.length})
            </h3>

            {pastApts.length === 0 ? (
              <p className="text-xs text-slate-400 italic p-4 bg-white border border-slate-200 rounded-2xl">No history on file.</p>
            ) : (
              <div className="space-y-3">
                {pastApts.map((apt) => (
                  <div key={apt.id} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-3xs flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-xs text-slate-800">{apt.doctorName}</span>
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-md ${
                        apt.status === 'completed' 
                          ? 'bg-slate-100 text-slate-600' 
                          : 'bg-rose-50 text-rose-600'
                      }`}>
                        {apt.status === 'completed' ? 'Completed' : 'Cancelled'}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400">{apt.date} • {apt.timeSlot}</p>
                    <p className="text-xs text-slate-500 italic bg-slate-50 p-2 rounded-lg leading-normal">
                      Reason: "{apt.reason}"
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==================== SUB-VIEW: HEALTH VITALS & DYNAMIC LOGGING ==================== */}
      {activeTab === 'vitals' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in items-start">
          {/* Trend Charts */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                    <TrendingUp className="h-4.5 w-4.5 text-brand-600" />
                    Biomedical Trend Logs
                  </h3>
                  <p className="text-[10px] text-slate-400">Continuous health telemetry visualization based on logged parameters.</p>
                </div>
                <div className="flex items-center gap-3 text-[10px] font-semibold">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-1 bg-brand-500 rounded-full"></span>
                    Systolic BP
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-1 bg-rose-500 rounded-full"></span>
                    Heart Rate
                  </span>
                </div>
              </div>

              {chartCoordinates ? (
                <div className="relative pt-2">
                  <svg viewBox="0 0 500 120" className="w-full h-36 overflow-visible">
                    {/* Grid lines */}
                    <line x1="0" y1="15" x2="500" y2="15" stroke="#f1f5f9" strokeWidth="1" />
                    <line x1="0" y1="60" x2="500" y2="60" stroke="#f1f5f9" strokeWidth="1" />
                    <line x1="0" y1="105" x2="500" y2="105" stroke="#f1f5f9" strokeWidth="1" />

                    {/* Gradient backing */}
                    <path
                      d={`M 15 105 L ${chartCoordinates.bpPoints} L 485 105 Z`}
                      fill="url(#teal-grad)"
                      opacity="0.08"
                    />

                    {/* Systolic BP Path */}
                    <polyline
                      fill="none"
                      stroke="#2563eb"
                      strokeWidth="2.5"
                      points={chartCoordinates.bpPoints}
                      strokeLinecap="round"
                    />

                    {/* Heart Rate Path */}
                    <polyline
                      fill="none"
                      stroke="#f43f5e"
                      strokeWidth="2"
                      points={chartCoordinates.hrPoints}
                      strokeLinecap="round"
                      strokeDasharray="4 2"
                    />

                    {/* Defs */}
                    <defs>
                      <linearGradient id="teal-grad" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#2563eb" />
                        <stop offset="100%" stopColor="#ffffff" />
                      </linearGradient>
                    </defs>
                  </svg>

                  {/* Dates / labels */}
                  <div className="flex justify-between text-[9px] text-slate-400 font-mono mt-2 border-t border-slate-100 pt-2">
                    {chartCoordinates.list.map((m, idx) => (
                      <span key={m.id}>{m.date}</span>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-10 text-center text-xs text-slate-400 italic">
                  Not enough datapoints to generate line trends (requires at least 2 logs).
                </div>
              )}
            </div>

            {/* Historic Vitals Logs Table */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                <h4 className="font-bold text-slate-800 text-xs">Vitals Audit Ledger</h4>
                <span className="text-[10px] font-mono font-bold text-slate-400">RECORDS: {healthMetrics.length}</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-100 font-bold text-slate-500 uppercase tracking-wider text-[10px]">
                      <th className="p-3">Log Date</th>
                      <th className="p-3">BP (Sys/Dia)</th>
                      <th className="p-3">Heart Rate</th>
                      <th className="p-3">Weight</th>
                      <th className="p-3">Temperature</th>
                      <th className="p-3">Glucose</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {healthMetrics.map((m) => (
                      <tr key={m.id} className="hover:bg-slate-50/50">
                        <td className="p-3 font-semibold text-slate-800 font-mono">{m.date}</td>
                        <td className="p-3 text-slate-700 font-mono">{m.bloodPressure}</td>
                        <td className="p-3 text-slate-700 font-mono">{m.heartRate} BPM</td>
                        <td className="p-3 text-slate-700 font-mono">{m.weight} kg</td>
                        <td className="p-3 text-slate-700 font-mono">{m.temperature}°C</td>
                        <td className="p-3 text-slate-700 font-mono">{m.bloodSugar || '--'} mg/dL</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Vitals Form Logger */}
          <div className="lg:col-span-1">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <h3 className="text-xs font-extrabold text-slate-500 uppercase tracking-wider mb-4 flex items-center gap-1.5">
                <Plus className="h-4 w-4 text-brand-600" />
                Log Today's Vitals
              </h3>
              
              <form onSubmit={handleAddVitals} className="space-y-4">
                {/* BP Double input */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500">Systolic BP (mmHg)</label>
                    <input 
                      type="number" 
                      required 
                      value={bpSys} 
                      onChange={(e) => setBpSys(e.target.value)}
                      className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500">Diastolic BP (mmHg)</label>
                    <input 
                      type="number" 
                      required 
                      value={bpDia} 
                      onChange={(e) => setBpDia(e.target.value)}
                      className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {/* Heart Rate */}
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500">Pulse (BPM)</label>
                    <input 
                      type="number" 
                      required 
                      value={heartRate} 
                      onChange={(e) => setHeartRate(e.target.value)}
                      className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono"
                    />
                  </div>
                  {/* Weight */}
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500">Weight (kg)</label>
                    <input 
                      type="number" 
                      step="0.1"
                      required 
                      value={weight} 
                      onChange={(e) => setWeight(e.target.value)}
                      className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  {/* Temperature */}
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500">Body Temp (°C)</label>
                    <input 
                      type="number" 
                      step="0.1"
                      required 
                      value={temp} 
                      onChange={(e) => setTemp(e.target.value)}
                      className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono"
                    />
                  </div>
                  {/* Blood Glucose */}
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500">Fasting Glucose (mg/dL)</label>
                    <input 
                      type="number" 
                      value={sugar} 
                      onChange={(e) => setSugar(e.target.value)}
                      className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono"
                      placeholder="Optional"
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-1">
                  <label className="text-[10px] font-bold text-slate-500">Activity/Symptom Notes</label>
                  <textarea 
                    value={vitalNotes}
                    onChange={(e) => setVitalNotes(e.target.value)}
                    rows={2}
                    placeholder="E.g., Felt slightly dizzy at noon..."
                    className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs resize-none"
                  />
                </div>

                <button
                  id="add-vitals-btn"
                  type="submit"
                  className="w-full py-2.5 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs rounded-xl transition-all shadow-sm shadow-brand-600/15 cursor-pointer"
                >
                  Record Telemetry Log
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* ==================== SUB-VIEW: RECORDS & PRESCRIPTIONS ==================== */}
      {activeTab === 'records' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in items-start">
          {/* Main Vault list */}
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <FileSpreadsheet className="h-4.5 w-4.5 text-slate-400" />
              Prescription & Diagnosis Records
            </h3>

            {medicalRecords.length === 0 ? (
              <p className="text-xs text-slate-400 italic p-6 bg-white rounded-2xl border">No prescription reports recorded in system files.</p>
            ) : (
              <div className="space-y-3">
                {medicalRecords.map((rec) => (
                  <div key={rec.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-3xs flex flex-col sm:flex-row gap-4 justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-semibold text-slate-800">{rec.doctorName}</span>
                        <span className="text-slate-400">•</span>
                        <span className="text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md text-[10px] font-semibold">{rec.specialty}</span>
                        <span className="text-slate-400 font-mono ml-auto sm:ml-0 text-[10px]">{rec.date}</span>
                      </div>
                      
                      <div className="mt-3">
                        <span className="text-[10px] uppercase font-bold text-slate-400">Clinical Diagnosis</span>
                        <p className="text-xs font-semibold text-slate-800 leading-normal mt-0.5">{rec.diagnosis}</p>
                      </div>

                      <div className="mt-2.5">
                        <span className="text-[10px] uppercase font-bold text-slate-400">Prescribed Therapeutics</span>
                        <p className="text-xs text-slate-600 italic bg-slate-50 p-2.5 rounded-lg border border-slate-100 mt-1 leading-normal font-mono">
                          {rec.prescription}
                        </p>
                      </div>
                    </div>

                    <button 
                      onClick={() => alert(`Prescription printed and forwarded: ${rec.diagnosis}`)}
                      className="text-[11px] font-bold text-brand-600 hover:underline shrink-0 flex items-center gap-1 self-end sm:self-auto cursor-pointer"
                    >
                      <Eye className="h-3.5 w-3.5" />
                      View Full Details
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Dynamic Uploaded Reports Section */}
            {uploadedRecords.length > 0 && (
              <div className="mt-6 pt-6 border-t border-slate-200">
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Self-Uploaded Records</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {uploadedRecords.map((f, i) => (
                    <div key={i} className="bg-slate-50 border border-slate-200 p-3 rounded-xl flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-indigo-500 shrink-0" />
                        <div className="truncate">
                          <p className="font-semibold text-slate-800 truncate max-w-[150px]">{f.name}</p>
                          <p className="text-[10px] text-slate-400">{f.size} • Uploaded {f.date}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => setUploadedRecords(uploadedRecords.filter((_, idx) => idx !== i))}
                        className="text-rose-500 hover:text-rose-600 p-1 bg-white border rounded-lg hover:bg-rose-50 transition-colors"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Simulated File uploader & manual diary entry */}
          <div className="lg:col-span-1 space-y-4">
            {/* Drag & Drop simulated uploader */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Upload Laboratory Reports</h4>
              
              <div
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                className={`p-6 rounded-2xl border-2 border-dashed text-center transition-all flex flex-col items-center justify-center cursor-pointer ${
                  dragActive 
                    ? 'border-brand-500 bg-brand-50/50' 
                    : 'border-slate-200 hover:border-slate-300 bg-slate-50'
                }`}
              >
                <Upload className="h-8 w-8 text-slate-400 mb-2 animate-pulse" />
                <p className="text-xs font-bold text-slate-700">Drag files here to upload</p>
                <p className="text-[10px] text-slate-400 mt-1">Accepts PDF, JPG, PNG formats up to 10MB</p>
                <div className="relative mt-3">
                  <input
                    type="file"
                    className="absolute inset-0 opacity-0 cursor-pointer"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        const file = e.target.files[0];
                        setUploadedRecords([{
                          name: file.name,
                          size: `${(file.size / (1024 * 1024)).toFixed(2)} MB`,
                          date: new Date().toISOString().split('T')[0]
                        }, ...uploadedRecords]);
                      }
                    }}
                  />
                  <button type="button" className="bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-[10px] font-bold px-3 py-1.5 rounded-lg shadow-2xs">
                    Choose File manually
                  </button>
                </div>
              </div>
            </div>

            {/* Manual history entry diary */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Add Consultation Log</h4>
              <form onSubmit={handleManualRecordSubmit} className="space-y-3">
                <div className="flex flex-col gap-1">
                  <label className="text-[9px] font-bold text-slate-500">Doctor Name</label>
                  <input
                    type="text"
                    required
                    value={newDoctor}
                    onChange={(e) => setNewDoctor(e.target.value)}
                    placeholder="E.g., Dr. Jane Miller"
                    className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[9px] font-bold text-slate-500">Specialty</label>
                  <input
                    type="text"
                    value={newSpecialty}
                    onChange={(e) => setNewSpecialty(e.target.value)}
                    placeholder="E.g., Dermatology, General"
                    className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none"
                  />
                </div>
                <div className="flex flex-col gap-1">
                  <label className="text-[9px] font-bold text-slate-500">Diagnosis Overview</label>
                  <textarea
                    required
                    value={newDiagnosis}
                    onChange={(e) => setNewDiagnosis(e.target.value)}
                    rows={2}
                    placeholder="E.g., Prescribed drops for dry eyes, diagnostic test clear..."
                    className="p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none resize-none"
                  />
                </div>
                <button type="submit" className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer">
                  Log Diagnosis
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* ==================== SUB-VIEW: FAVORITES ==================== */}
      {activeTab === 'favorites' && (
        <div className="animate-fade-in">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4">
            <Heart className="h-4.5 w-4.5 text-rose-500 fill-rose-500" />
            Favorited Practitioners ({favoriteDoctors.length})
          </h3>

          {favoriteDoctors.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center shadow-xs">
              <p className="text-xs text-slate-400 italic mb-2">No practitioners added to favorites list yet.</p>
              <p className="text-[11px] text-slate-400 max-w-sm mx-auto">Toggle the heart icon overlay on any doctor profile card in listings to access them quickly here.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {favoriteDoctors.map((doc) => (
                <div key={doc.id} className="bg-white border border-slate-200 p-4 rounded-2xl shadow-3xs flex flex-col justify-between hover:border-slate-300">
                  <div className="flex gap-3 items-start">
                    <img src={doc.image} alt={doc.name} className="w-12 h-12 rounded-xl object-cover border shrink-0" referrerPolicy="no-referrer" />
                    <div>
                      <span className="text-[9px] uppercase tracking-wider font-bold text-brand-600">{doc.specialty}</span>
                      <h4 className="font-extrabold text-slate-800 text-sm mt-0.5">{doc.name}</h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">{doc.hospital}</p>
                    </div>
                  </div>
                  <div className="border-t border-slate-100 pt-3 mt-3 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">${doc.fees}</span>
                    <button 
                      onClick={() => onSelectDoctor(doc)}
                      className="px-3 py-1.5 bg-brand-600 text-white text-[10px] font-bold rounded-lg hover:bg-brand-700 transition-colors"
                    >
                      Book Now
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ==================== SUB-VIEW: SETTINGS / PROFILE ==================== */}
      {activeTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          {/* LEFT COLUMN: PRIMARY ACCOUNT PROFILE */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs animate-fade-in">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-sm font-bold text-slate-800">Primary Patient Profile</h3>
                <p className="text-[10px] text-slate-400">Update pre-filled clinical inputs used during consultation bookings.</p>
              </div>
              {!editingProfile && (
                <button
                  onClick={() => setEditingProfile(true)}
                  className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-xs font-bold rounded-xl transition-all cursor-pointer"
                >
                  Modify Settings
                </button>
              )}
            </div>

            {!editingProfile ? (
              <div className="space-y-4 text-xs">
                <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 block mb-0.5">PATIENT REGISTERED NAME</span>
                    <p className="font-bold text-slate-800">{currentPatient.name}</p>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 block mb-0.5">AGE / GENDER</span>
                    <p className="font-bold text-slate-800">{currentPatient.age} Years Old • {currentPatient.gender}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 block mb-0.5">CONTACT EMAIL</span>
                    <p className="font-bold text-slate-800 font-mono">{currentPatient.email}</p>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 block mb-0.5">PHONE CONTACT</span>
                    <p className="font-bold text-slate-800 font-mono">{currentPatient.phone}</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 block mb-0.5">BLOOD GROUP</span>
                    <p className="font-extrabold text-rose-600 text-sm flex items-center gap-1">
                      <Droplet className="h-4.5 w-4.5" />
                      {currentPatient.bloodGroup}
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 block mb-0.5">HEIGHT RANGE</span>
                    <p className="font-bold text-slate-800">{currentPatient.height}</p>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 block mb-0.5">LATEST WEIGHT</span>
                    <p className="font-bold text-slate-800">{healthMetrics[0]?.weight || 78} kg</p>
                  </div>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Full Legal Name</label>
                    <input
                      type="text"
                      required
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Email Address</label>
                    <input
                      type="email"
                      required
                      value={profileEmail}
                      onChange={(e) => setProfileEmail(e.target.value)}
                      className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Age</label>
                    <input
                      type="number"
                      required
                      value={profileAge}
                      onChange={(e) => setProfileAge(Number(e.target.value))}
                      className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Gender</label>
                    <select
                      value={profileGender}
                      onChange={(e) => setProfileGender(e.target.value)}
                      className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Blood Group</label>
                    <input
                      type="text"
                      required
                      value={profileBloodGroup}
                      onChange={(e) => setProfileBloodGroup(e.target.value)}
                      className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Height (e.g., 5'10")</label>
                    <input
                      type="text"
                      required
                      value={profileHeight}
                      onChange={(e) => setProfileHeight(e.target.value)}
                      className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Mobile Phone</label>
                    <input
                      type="tel"
                      required
                      value={profilePhone}
                      onChange={(e) => setProfilePhone(e.target.value)}
                      className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold rounded-xl transition-all cursor-pointer"
                  >
                    Save Profile Settings
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingProfile(false)}
                    className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold rounded-xl transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* RIGHT COLUMN: FAMILY & DEPENDENTS DIRECTORY HUB */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs animate-fade-in space-y-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-800">Family & Dependents Directory</h3>
                <p className="text-[10px] text-slate-400">Manage profiles to enable quick booking options for family dependents.</p>
              </div>
              {!showAddFamilyForm && (
                <button
                  onClick={() => setShowAddFamilyForm(true)}
                  className="px-3 py-1.5 bg-brand-600 hover:bg-brand-700 text-white text-[11px] font-bold rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="h-3 w-3" />
                  Add Dependent
                </button>
              )}
            </div>

            {/* Inline Add Form */}
            {showAddFamilyForm && (
              <form onSubmit={handleAddFamilyMember} className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3.5 animate-fade-in text-xs">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2 mb-1">
                  <span className="font-extrabold text-slate-700 uppercase text-[10px] tracking-wider">New Patient Profile Registration</span>
                  <button 
                    type="button" 
                    onClick={() => setShowAddFamilyForm(false)}
                    className="text-slate-400 hover:text-slate-600 font-bold"
                  >
                    Cancel
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-500 uppercase">Patient Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Jane Doe"
                      value={newFamName}
                      onChange={(e) => setNewFamName(e.target.value)}
                      className="p-2 bg-white border border-slate-250 rounded-lg text-xs"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-500 uppercase">Relationship</label>
                    <select
                      value={newFamRelation}
                      onChange={(e) => setNewFamRelation(e.target.value)}
                      className="p-2 bg-white border border-slate-250 rounded-lg text-xs"
                    >
                      <option value="Spouse">Spouse</option>
                      <option value="Child">Child</option>
                      <option value="Parent">Parent</option>
                      <option value="Sibling">Sibling</option>
                      <option value="Other">Other Dependent</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-500 uppercase">Age</label>
                    <input
                      type="number"
                      required
                      min="1"
                      max="120"
                      value={newFamAge}
                      onChange={(e) => setNewFamAge(Number(e.target.value))}
                      className="p-2 bg-white border border-slate-250 rounded-lg text-xs"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-500 uppercase">Gender</label>
                    <select
                      value={newFamGender}
                      onChange={(e) => setNewFamGender(e.target.value)}
                      className="p-2 bg-white border border-slate-250 rounded-lg text-xs"
                    >
                      <option value="Female">Female</option>
                      <option value="Male">Male</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-500 uppercase">Blood Group</label>
                    <input
                      type="text"
                      placeholder="O+"
                      value={newFamBloodGroup}
                      onChange={(e) => setNewFamBloodGroup(e.target.value)}
                      className="p-2 bg-white border border-slate-250 rounded-lg text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-500 uppercase">Email</label>
                    <input
                      type="email"
                      placeholder="optional@example.com"
                      value={newFamEmail}
                      onChange={(e) => setNewFamEmail(e.target.value)}
                      className="p-2 bg-white border border-slate-250 rounded-lg text-xs"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-[9px] font-bold text-slate-500 uppercase">Phone Number</label>
                    <input
                      type="tel"
                      placeholder="+1 (555) 000-0000"
                      value={newFamPhone}
                      onChange={(e) => setNewFamPhone(e.target.value)}
                      className="p-2 bg-white border border-slate-250 rounded-lg text-xs"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-brand-600 hover:bg-brand-700 text-slate-950 font-bold rounded-xl text-xs transition-all shadow-md shadow-brand-600/10 cursor-pointer"
                >
                  Register Profile Member
                </button>
              </form>
            )}

            {/* List of saved family members */}
            <div className="space-y-3.5 max-h-[380px] overflow-y-auto pr-1">
              {patientProfiles.length <= 1 ? (
                <p className="text-xs text-slate-400 italic py-6 text-center">No additional patient profiles configured yet.</p>
              ) : (
                patientProfiles.map((p) => {
                  if (p.relationship === 'Self') return null;
                  return (
                    <div key={p.id} className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex justify-between items-start text-xs hover:border-slate-350 transition-all">
                      <div className="space-y-1.5 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-800">{p.name}</span>
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase bg-emerald-100 text-emerald-800 border border-emerald-200">
                            {p.relationship}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-slate-500 text-[11px]">
                          <p>Age: <strong className="text-slate-700">{p.age}</strong> • Gender: <strong className="text-slate-700">{p.gender}</strong></p>
                          <p>Blood Group: <strong className="text-slate-700">{p.bloodGroup || 'O+'}</strong></p>
                          <p className="col-span-2">Email: <strong className="text-slate-700 font-mono">{p.email}</strong></p>
                          {p.phone && <p className="col-span-2">Phone: <strong className="text-slate-700 font-mono">{p.phone}</strong></p>}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleDeleteFamilyMember(p.id, p.name)}
                        className="p-1.5 text-slate-400 hover:text-red-500 rounded-lg hover:bg-red-50 transition-all cursor-pointer"
                        title="Delete Profile"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* ==================== ENCRYPTED VIDEO CALL SIMULATOR MODAL ==================== */}
      {activeCallId && (
        <div className="fixed inset-0 bg-slate-950/90 flex items-center justify-center p-4 z-50 overflow-y-auto animate-scale-up">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col justify-between aspect-video relative">
            
            {/* Top status bar */}
            <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-10 text-xs">
              <span className="bg-red-600 text-white px-2.5 py-1 rounded-full font-bold flex items-center gap-1.5 animate-pulse">
                <span className="w-1.5 h-1.5 bg-white rounded-full"></span>
                LIVE CALL • ENCRYPTED
              </span>
              <span className="bg-slate-800/80 text-slate-200 px-3 py-1 rounded-full font-mono">
                Room ID: MB-V-{activeCallId.substring(4, 9).toUpperCase()}
              </span>
            </div>

            {/* Doctor/Patient screens simulation */}
            <div className="flex-1 flex flex-col md:flex-row bg-slate-950 gap-1.5 relative p-4 pt-16">
              {/* Doctor Main screen */}
              <div className="flex-1 rounded-2xl overflow-hidden relative border border-slate-800 bg-slate-800/20 flex flex-col items-center justify-center">
                <div className="text-center p-4 space-y-3">
                  <div className="w-20 h-20 bg-slate-700 rounded-full mx-auto flex items-center justify-center border-4 border-slate-600 animate-pulse">
                    <User className="h-10 w-10 text-slate-400" />
                  </div>
                  <h4 className="font-extrabold text-white text-sm">Waiting for Doctor to Connect...</h4>
                  <p className="text-[10px] text-slate-400 max-w-xs mx-auto">
                    Securing safe P2P medical channels. Your microphone and camera are fully encrypted.
                  </p>
                </div>
              </div>

              {/* Patient Feed (Miniature pip) */}
              <div className="w-full md:w-44 h-32 md:h-auto rounded-xl border border-slate-800 bg-slate-900 p-3 flex flex-col items-center justify-center text-center">
                <Activity className="h-6 w-6 text-brand-500 animate-bounce mb-1" />
                <span className="text-[10px] font-bold text-white block">Camera Feed Active</span>
                <span className="text-[9px] text-slate-500 block font-mono">My IP: Authorized</span>
              </div>
            </div>

            {/* In-Call controls */}
            <div className="bg-slate-950 py-4 px-6 border-t border-slate-850 flex items-center justify-between">
              <span className="text-xs text-slate-400 font-mono">00:14 / Unlimited</span>
              <button
                onClick={() => setActiveCallId(null)}
                className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs px-6 py-2 rounded-xl transition-all cursor-pointer"
              >
                Disconnect Call
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
