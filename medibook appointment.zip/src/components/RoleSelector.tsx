import React, { useState, useRef, useEffect } from 'react';
import { User, ShieldCheck, RefreshCw, Activity, ChevronDown, Plus, Trash2, Check, UserPlus } from 'lucide-react';
import { UserAccount } from '../types';

interface RoleSelectorProps {
  currentRole: 'patient' | 'admin';
  onChangeRole: (role: 'patient' | 'admin') => void;
  userAccounts: UserAccount[];
  activeUserId: string;
  onSwitchUser: (userId: string) => void;
  onAddUser: (user: Omit<UserAccount, 'id' | 'avatarColor'>) => void;
  onDeleteUser: (userId: string) => void;
}

export default function RoleSelector({ 
  currentRole, 
  onChangeRole, 
  userAccounts, 
  activeUserId, 
  onSwitchUser, 
  onAddUser, 
  onDeleteUser 
}: RoleSelectorProps) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  
  // New User Form State
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newAge, setNewAge] = useState(30);
  const [newGender, setNewGender] = useState('Male');
  const [newPhone, setNewPhone] = useState('');

  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
        setShowAddForm(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const activeUser = userAccounts.find(u => u.id === activeUserId) || userAccounts[0];

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newEmail.trim()) return;

    onAddUser({
      name: newName,
      email: newEmail,
      age: Number(newAge),
      gender: newGender,
      phone: newPhone || '+1 (555) 000-0000',
      bloodGroup: 'O+',
      height: "5'9\""
    });

    // Reset fields
    setNewName('');
    setNewEmail('');
    setNewAge(30);
    setNewGender('Male');
    setNewPhone('');
    setShowAddForm(false);
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
  };

  return (
    <div id="role-selector-container" className="bg-slate-900 text-white py-2 px-4 shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-sm">
        <div className="flex items-center gap-2">
          <div className="bg-brand-500 p-1.5 rounded-lg flex items-center justify-center animate-pulse">
            <Activity className="h-4 w-4 text-slate-900" />
          </div>
          <span className="font-bold tracking-tight text-white flex items-center gap-1.5">
            MediBook <span className="text-[10px] bg-slate-800 text-brand-400 px-2 py-0.5 rounded-full border border-slate-700 font-mono">v1.3 PRO</span>
          </span>
          <p className="text-xs text-slate-400 hidden md:inline-block">
            • Multi-Account Patient Ecosystem
          </p>
        </div>

        <div className="flex items-center gap-4 relative" ref={dropdownRef}>
          <div className="flex bg-slate-800 p-0.5 rounded-xl border border-slate-700 items-center">
            
            {/* Multi-User Trigger Selector */}
            <div className="relative">
              <button
                id="user-account-trigger"
                onClick={() => {
                  if (currentRole !== 'patient') {
                    onChangeRole('patient');
                  }
                  setDropdownOpen(!dropdownOpen);
                }}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                  currentRole === 'patient'
                    ? 'bg-brand-500 text-slate-950 shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                <div className={`w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-extrabold text-white ${activeUser?.avatarColor || 'bg-brand-600'}`}>
                  {getInitials(activeUser?.name || 'JD')}
                </div>
                <span>Patient: <strong className="font-black">{activeUser?.name || 'Guest'}</strong></span>
                <ChevronDown className={`h-3 w-3 transition-transform ${dropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              {/* DROPDOWN MENU */}
              {dropdownOpen && (
                <div className="absolute left-0 mt-2.5 w-76 bg-white rounded-2xl border border-slate-200 shadow-xl text-slate-800 p-3.5 z-50 animate-scale-up space-y-3">
                  <div className="border-b border-slate-100 pb-2.5 flex items-center justify-between">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block">
                      Switch User Account ({userAccounts.length})
                    </span>
                    {!showAddForm && (
                      <button
                        onClick={() => setShowAddForm(true)}
                        className="text-[11px] font-bold text-brand-600 hover:text-brand-700 flex items-center gap-1 cursor-pointer"
                      >
                        <UserPlus className="h-3 w-3" />
                        Add New
                      </button>
                    )}
                  </div>

                  {/* ACCOUNT CREATION FORM */}
                  {showAddForm ? (
                    <form onSubmit={handleAddSubmit} className="space-y-3 p-2 bg-slate-50 rounded-xl border border-slate-200 animate-fade-in text-xs">
                      <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                        <span className="font-extrabold text-slate-700 text-[10px] uppercase">New Account Details</span>
                        <button 
                          type="button" 
                          onClick={() => setShowAddForm(false)}
                          className="text-[11px] text-slate-400 hover:text-slate-600 font-bold"
                        >
                          Cancel
                        </button>
                      </div>
                      <div className="space-y-2">
                        <div>
                          <label className="text-[9px] font-bold text-slate-400 block mb-0.5">FULL LEGAL NAME</label>
                          <input
                            type="text"
                            required
                            placeholder="Sarah Jenkins"
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                            className="w-full p-1.5 bg-white border border-slate-250 rounded-lg text-xs"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-bold text-slate-400 block mb-0.5">EMAIL ADDRESS</label>
                          <input
                            type="email"
                            required
                            placeholder="sarah.j@example.com"
                            value={newEmail}
                            onChange={(e) => setNewEmail(e.target.value)}
                            className="w-full p-1.5 bg-white border border-slate-250 rounded-lg text-xs font-mono"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-[9px] font-bold text-slate-400 block mb-0.5">AGE</label>
                            <input
                              type="number"
                              required
                              min="1"
                              value={newAge}
                              onChange={(e) => setNewAge(Number(e.target.value))}
                              className="w-full p-1.5 bg-white border border-slate-250 rounded-lg text-xs"
                            />
                          </div>
                          <div>
                            <label className="text-[9px] font-bold text-slate-400 block mb-0.5">GENDER</label>
                            <select
                              value={newGender}
                              onChange={(e) => setNewGender(e.target.value)}
                              className="w-full p-1.5 bg-white border border-slate-250 rounded-lg text-xs"
                            >
                              <option value="Female">Female</option>
                              <option value="Male">Male</option>
                              <option value="Other">Other</option>
                            </select>
                          </div>
                        </div>
                        <div>
                          <label className="text-[9px] font-bold text-slate-400 block mb-0.5">MOBILE PHONE</label>
                          <input
                            type="tel"
                            placeholder="+1 (555) 555-5555"
                            value={newPhone}
                            onChange={(e) => setNewPhone(e.target.value)}
                            className="w-full p-1.5 bg-white border border-slate-250 rounded-lg text-xs font-mono"
                          />
                        </div>
                      </div>
                      <button
                        type="submit"
                        className="w-full py-1.5 bg-brand-600 hover:bg-brand-700 text-slate-950 font-bold rounded-lg text-xs cursor-pointer shadow-sm"
                      >
                        Create & Login
                      </button>
                    </form>
                  ) : (
                    <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-1">
                      {userAccounts.map((user) => (
                        <div 
                          key={user.id}
                          className={`flex items-center justify-between p-2 rounded-xl transition-all ${
                            user.id === activeUserId 
                              ? 'bg-slate-100 border border-slate-200' 
                              : 'hover:bg-slate-50 border border-transparent'
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() => {
                              onSwitchUser(user.id);
                              setDropdownOpen(false);
                            }}
                            className="flex items-center gap-2.5 text-left flex-1 cursor-pointer"
                          >
                            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-extrabold text-white ${user.avatarColor}`}>
                              {getInitials(user.name)}
                            </div>
                            <div className="truncate">
                              <p className="font-bold text-slate-800 text-xs truncate flex items-center gap-1.5">
                                {user.name}
                                {user.id === activeUserId && <span className="text-[9px] bg-brand-200 text-slate-950 px-1 rounded-sm">Active</span>}
                              </p>
                              <p className="text-[10px] text-slate-400 truncate">{user.email}</p>
                            </div>
                          </button>

                          {userAccounts.length > 1 && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onDeleteUser(user.id);
                              }}
                              className="p-1 text-slate-300 hover:text-red-500 rounded-md hover:bg-red-50 transition-colors cursor-pointer"
                              title="Delete Account"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Admin Selector Button */}
            <button
              id="role-select-admin"
              onClick={() => {
                onChangeRole('admin');
                setDropdownOpen(false);
              }}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                currentRole === 'admin'
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <ShieldCheck className="h-3.5 w-3.5" />
              Admin Panel
            </button>
          </div>

          <div className="hidden lg:flex items-center gap-1 text-[11px] text-slate-400 font-mono bg-slate-950 px-2 py-1 rounded-md border border-slate-800">
            <RefreshCw className="h-3 w-3 animate-spin text-brand-500" />
            <span>Multi-User Sync</span>
          </div>
        </div>
      </div>
    </div>
  );
}

