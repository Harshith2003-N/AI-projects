import { Doctor, Appointment, Review, HealthMetric, MedicalRecord } from './types';

export const SPECIALTIES = [
  { id: 'all', name: 'All Specialties', count: 6 },
  { id: 'general', name: 'General Medicine', count: 1, icon: 'Stethoscope', description: 'Primary care, physicals, and common ailments' },
  { id: 'cardiology', name: 'Cardiology', count: 1, icon: 'Heart', description: 'Heart and blood vessel disorders' },
  { id: 'pediatrics', name: 'Pediatrics', count: 1, icon: 'Baby', description: 'Child healthcare and development' },
  { id: 'dermatology', name: 'Dermatology', count: 1, icon: 'Sparkles', description: 'Skin, hair, and nail health' },
  { id: 'orthopedics', name: 'Orthopedics', count: 1, icon: 'Activity', description: 'Bone, joint, and muscle care' },
  { id: 'neurology', name: 'Neurology', count: 1, icon: 'Brain', description: 'Brain, spinal cord, and nerve treatments' }
];

export const INITIAL_DOCTORS: Doctor[] = [
  {
    id: 'doc-1',
    name: 'Dr. Aris Thorne',
    specialty: 'Cardiology',
    rating: 4.9,
    experience: 15,
    reviewsCount: 124,
    image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&auto=format&fit=crop&q=80',
    availability: {
      days: ['Mon', 'Tue', 'Wed', 'Thu'],
      hours: ['09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM', '04:00 PM']
    },
    biography: 'Dr. Aris Thorne is a board-certified cardiologist with over 15 years of experience specializing in preventive cardiology, cardiovascular diagnostics, and heart failure management. He is dedicated to helping patients live longer, heart-healthy lives through state-of-the-art care and lifestyle optimizations.',
    fees: 150,
    hospital: 'Metro Cardiac Institute, Wing A',
    education: 'MD - Harvard Medical School, Residency in Cardiology - Johns Hopkins Hospital',
    status: 'active'
  },
  {
    id: 'doc-2',
    name: 'Dr. Sarah Jenkins',
    specialty: 'Pediatrics',
    rating: 4.8,
    experience: 10,
    reviewsCount: 98,
    image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&auto=format&fit=crop&q=80',
    availability: {
      days: ['Mon', 'Wed', 'Fri'],
      hours: ['08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM', '01:00 PM', '02:00 PM', '03:00 PM']
    },
    biography: 'Dr. Sarah Jenkins is a passionate pediatrician who strives to provide compassionate, comprehensive medical care to infants, children, and adolescents. She believes in working closely with parents to support the physical, mental, and developmental well-being of every child.',
    fees: 120,
    hospital: 'St. Jude Children Hospital',
    education: 'MD - Stanford School of Medicine, Board Certified in Pediatrics',
    status: 'active'
  },
  {
    id: 'doc-3',
    name: 'Dr. Marcus Chen',
    specialty: 'Orthopedics',
    rating: 4.7,
    experience: 12,
    reviewsCount: 84,
    image: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&auto=format&fit=crop&q=80',
    availability: {
      days: ['Tue', 'Thu', 'Fri'],
      hours: ['10:00 AM', '11:00 AM', '12:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM']
    },
    biography: 'Dr. Marcus Chen is a leading orthopedic surgeon specializing in joint replacement, sports medicine, and minimally invasive bone/joint treatments. He has successfully treated thousands of athletes and patient communities, restoring peak mobility and dynamic comfort.',
    fees: 140,
    hospital: 'City Orthopedic & Joint Center',
    education: 'MD - Columbia College of Physicians and Surgeons, Fellowship in Sports Medicine',
    status: 'active'
  },
  {
    id: 'doc-4',
    name: 'Dr. Elena Rostova',
    specialty: 'Dermatology',
    rating: 4.9,
    experience: 8,
    reviewsCount: 112,
    image: 'https://images.unsplash.com/photo-1594824813573-246434de83fb?w=400&auto=format&fit=crop&q=80',
    availability: {
      days: ['Mon', 'Tue', 'Thu'],
      hours: ['09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM', '04:00 PM']
    },
    biography: 'Dr. Elena Rostova offers top-tier dermatological diagnostics and therapeutics. From medical dermatology (skin cancer, acne, eczema) to advanced aesthetic skin health procedures, she focuses on delivering radiant, healthy results personalized for each patient.',
    fees: 130,
    hospital: 'DermaCare Skin & Laser Clinic',
    education: 'MD - Yale School of Medicine, Residency in Dermatology - UCSF Medical Center',
    status: 'active'
  },
  {
    id: 'doc-5',
    name: 'Dr. David Kim',
    specialty: 'Neurology',
    rating: 4.6,
    experience: 18,
    reviewsCount: 76,
    image: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=400&auto=format&fit=crop&q=80',
    availability: {
      days: ['Wed', 'Thu'],
      hours: ['01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM']
    },
    biography: 'Dr. David Kim is a highly accomplished neurologist targeting complex neuromuscular conditions, headaches, stroke recovery, and sleep disorders. He approaches patient care from an integrative perspective, blending pharmacology with modern neurological rehabilitation.',
    fees: 180,
    hospital: 'Neurological Sciences Center, Suite 402',
    education: 'MD - University of Chicago, Fellowship in Neurophysiology - Mayo Clinic',
    status: 'active'
  },
  {
    id: 'doc-6',
    name: 'Dr. Aisha Rahman',
    specialty: 'General Medicine',
    rating: 4.9,
    experience: 14,
    reviewsCount: 215,
    image: 'https://images.unsplash.com/photo-1591604021695-0c69b7c05981?w=400&auto=format&fit=crop&q=80',
    availability: {
      days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
      hours: ['09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '02:00 PM', '03:00 PM', '04:00 PM']
    },
    biography: 'Dr. Aisha Rahman is an experienced primary care physician focused on holistic medicine, preventative wellness checks, chronic disease management, and family health. She believes primary care should be accessible, empowering, and centered around deep patient-provider communication.',
    fees: 95,
    hospital: 'Community Family Clinic',
    education: 'MD - University of Washington School of Medicine, Board Certified in Family Medicine',
    status: 'active'
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    doctorId: 'doc-1',
    patientName: 'Robert Vance',
    rating: 5,
    comment: 'Dr. Thorne is incredible. He took the time to explain my cholesterol figures and set up an actionable, easy-to-follow cardiac fitness program.',
    date: '2026-06-25'
  },
  {
    id: 'rev-2',
    doctorId: 'doc-1',
    patientName: 'Emma Watson',
    rating: 5,
    comment: 'Highly professional. The cardiovascular checkup was thorough and his bedside manner made me feel completely at ease.',
    date: '2026-07-02'
  },
  {
    id: 'rev-3',
    doctorId: 'doc-2',
    patientName: 'Clara Oswald',
    rating: 5,
    comment: 'Dr. Sarah was wonderful with my 4-year-old. She is gentle, funny, and instantly calmed my child before administering vaccines.',
    date: '2026-06-18'
  },
  {
    id: 'rev-4',
    doctorId: 'doc-4',
    patientName: 'Liam Neeson',
    rating: 5,
    comment: 'Struggled with severe adult acne for years, and Dr. Rostova solved it in three visits. Her treatment regimen works wonders!',
    date: '2026-07-04'
  }
];

export const INITIAL_APPOINTMENTS: Appointment[] = [
  {
    id: 'apt-1',
    doctorId: 'doc-1',
    doctorName: 'Dr. Aris Thorne',
    doctorSpecialty: 'Cardiology',
    doctorImage: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&auto=format&fit=crop&q=80',
    patientName: 'John Doe',
    patientAge: 32,
    patientGender: 'Male',
    patientEmail: 'johndoe@example.com',
    patientPhone: '+1 (555) 234-5678',
    date: '2026-07-12',
    timeSlot: '10:00 AM',
    type: 'In-Person',
    reason: 'Routine cardiovascular screening and follow-up on resting heart rate elevations.',
    status: 'scheduled',
    notes: 'Please bring recent blood panel reports.',
    createdDate: '2026-07-08'
  },
  {
    id: 'apt-2',
    doctorId: 'doc-4',
    doctorName: 'Dr. Elena Rostova',
    doctorSpecialty: 'Dermatology',
    doctorImage: 'https://images.unsplash.com/photo-1594824813573-246434de83fb?w=400&auto=format&fit=crop&q=80',
    patientName: 'John Doe',
    patientAge: 32,
    patientGender: 'Male',
    patientEmail: 'johndoe@example.com',
    patientPhone: '+1 (555) 234-5678',
    date: '2026-07-15',
    timeSlot: '02:00 PM',
    type: 'Video',
    reason: 'Follow-up consultation on prescription dermatological ointment efficacy.',
    status: 'scheduled',
    notes: 'Lighting needs to be clear for the camera check.',
    createdDate: '2026-07-09'
  },
  {
    id: 'apt-3',
    doctorId: 'doc-6',
    doctorName: 'Dr. Aisha Rahman',
    doctorSpecialty: 'General Medicine',
    doctorImage: 'https://images.unsplash.com/photo-1591604021695-0c69b7c05981?w=400&auto=format&fit=crop&q=80',
    patientName: 'John Doe',
    patientAge: 32,
    patientGender: 'Male',
    patientEmail: 'johndoe@example.com',
    patientPhone: '+1 (555) 234-5678',
    date: '2026-06-20',
    timeSlot: '09:00 AM',
    type: 'In-Person',
    reason: 'Annual physical examination and blood pressure medication renewal.',
    status: 'completed',
    notes: 'Renewed Amlodipine prescription.',
    createdDate: '2026-06-15'
  }
];

export const INITIAL_HEALTH_METRICS: HealthMetric[] = [
  {
    id: 'm-1',
    date: '2026-07-08',
    bloodPressure: '122/81',
    weight: 78.5,
    heartRate: 72,
    temperature: 36.6,
    bloodSugar: 98,
    notes: 'Recorded in morning post-fast.'
  },
  {
    id: 'm-2',
    date: '2026-07-01',
    bloodPressure: '124/83',
    weight: 79.1,
    heartRate: 74,
    temperature: 36.7,
    bloodSugar: 104,
    notes: 'After light workout.'
  },
  {
    id: 'm-3',
    date: '2026-06-20',
    bloodPressure: '121/80',
    weight: 79.4,
    heartRate: 68,
    temperature: 36.5,
    bloodSugar: 95,
    notes: 'Recorded during annual general exam at community clinic.'
  }
];

export const INITIAL_MEDICAL_RECORDS: MedicalRecord[] = [
  {
    id: 'rec-1',
    date: '2026-06-20',
    doctorName: 'Dr. Aisha Rahman',
    specialty: 'General Medicine',
    diagnosis: 'Mild hypertension & seasonal allergies',
    prescription: 'Amlodipine 5mg (once daily), Cetirizine 10mg (at bedtime as needed)'
  }
];
