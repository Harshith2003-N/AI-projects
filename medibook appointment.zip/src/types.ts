export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  rating: number;
  experience: number;
  reviewsCount: number;
  image: string;
  availability: {
    days: string[]; // e.g. ["Mon", "Tue", "Wed", "Thu", "Fri"]
    hours: string[]; // e.g. ["09:00 AM", "10:00 AM", ...]
  };
  biography: string;
  fees: number;
  hospital: string;
  education: string;
  status: 'active' | 'inactive';
}

export type AppointmentStatus = 'scheduled' | 'completed' | 'cancelled' | 'pending';
export type ConsultationType = 'In-Person' | 'Video';

export interface Appointment {
  id: string;
  doctorId: string;
  doctorName: string;
  doctorSpecialty: string;
  doctorImage: string;
  patientName: string;
  patientAge: number;
  patientGender: string;
  patientEmail: string;
  patientPhone: string;
  date: string; // YYYY-MM-DD
  timeSlot: string;
  type: ConsultationType;
  reason: string;
  status: AppointmentStatus;
  notes?: string;
  createdDate: string;
}

export interface Review {
  id: string;
  doctorId: string;
  patientName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface HealthMetric {
  id: string;
  date: string;
  bloodPressure: string; // e.g. "120/80"
  weight: number; // kg
  heartRate: number; // bpm
  temperature: number; // °C
  bloodSugar?: number; // mg/dL
  notes?: string;
}

export interface MedicalRecord {
  id: string;
  date: string;
  doctorName: string;
  specialty: string;
  diagnosis: string;
  prescription: string;
  attachments?: string[];
}

export interface ContactQuery {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  date: string;
  replied: boolean;
}

export interface PatientProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  age: number;
  gender: string;
  bloodGroup: string;
  height: string;
  relationship: string; // e.g. "Self", "Spouse", "Child", "Parent", "Other"
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  phone: string;
  age: number;
  gender: string;
  bloodGroup: string;
  height: string;
  avatarColor: string;
}


