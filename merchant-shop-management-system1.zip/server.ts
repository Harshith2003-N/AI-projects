import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization of Gemini API Client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not defined. Please add it in your Secrets Settings.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// 1. API: Auto-generate Product Description
app.post("/api/ai/generate-description", async (req, res) => {
  try {
    const { name, category, brand, keyFeatures } = req.body;
    if (!name) {
      return res.status(400).json({ error: "Product name is required" });
    }
    
    const ai = getGeminiClient();
    const prompt = `Write a compelling, professional, and SEO-friendly product description for a retail inventory.
Product Name: ${name}
Category: ${category || "General"}
Brand: ${brand || "Generic"}
Key Features/Keywords: ${keyFeatures || "None specified"}

Keep it concise (around 2-3 sentences), engaging, and focused on customer benefits. Do not use markdown headers, just return the plain text description.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });
    
    res.json({ description: response.text?.trim() });
  } catch (error: any) {
    console.error("Gemini description error:", error);
    res.status(500).json({ error: error.message || "Failed to generate description" });
  }
});

// 2. API: Financial / Sales Analysis
app.post("/api/ai/analyze-sales", async (req, res) => {
  try {
    const { sales, products, activeShop } = req.body;
    if (!sales || !Array.isArray(sales)) {
      return res.status(400).json({ error: "Sales history is required" });
    }
    
    const ai = getGeminiClient();
    const prompt = `You are an expert retail financial analyst. Analyze the following sales and inventory data for the merchant shop: "${activeShop?.name || "All Shops"}".
    
Data Provided:
- Total Sales Recorded: ${sales.length}
- Total Products Configured: ${products?.length || 0}
- Raw Transactions (JSON-like summary of recent sales):
${JSON.stringify(sales.slice(-15).map(s => ({ amount: s.total, itemsCount: s.items?.length, date: s.date, paymentMethod: s.paymentMethod })))}

Provide a concise, highly strategic financial report. Detail:
1. Revenue & profit takeaways (identify trends if any).
2. Pricing optimization ideas (how to increase average order value).
3. 2 key actionable business tips for this merchant to improve overall shop performance.

Keep it very structured, professional, and readable. Use markdown formatting with bullet points. Avoid robotic greetings, jump straight to the points.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });
    
    res.json({ analysis: response.text?.trim() });
  } catch (error: any) {
    console.error("Gemini sales analysis error:", error);
    res.status(500).json({ error: error.message || "Failed to generate sales report" });
  }
});

// 3. API: Inventory & Restock Optimization
app.post("/api/ai/forecast-inventory", async (req, res) => {
  try {
    const { products, activeShop } = req.body;
    if (!products || !Array.isArray(products)) {
      return res.status(400).json({ error: "Products list is required" });
    }
    
    // Filter stock products or critical items
    const inventoryList = products.map(p => ({
      name: p.name,
      sku: p.sku,
      category: p.category,
      stock: p.stockQuantity,
      threshold: p.lowStockThreshold || 5,
      costPrice: p.costPrice,
      sellingPrice: p.sellingPrice
    }));
    
    const ai = getGeminiClient();
    const prompt = `You are an expert supply chain and inventory manager. Review the merchant's current inventory stock levels:
${JSON.stringify(inventoryList)}

For the shop: "${activeShop?.name || "All Shops"}", provide a concise, professional Restock Optimization advisory. Specify:
1. Critical Alert: Highlight products that are dangerously low (stock <= threshold) or completely out of stock.
2. Suggested Order Strategy: Give custom stock recommendations (exact quantity or batch orders) for these products, factoring in their cost-to-margin ratio.
3. Procurement tips: How to optimize supplier management and reduce inventory holding costs.

Avoid introductory talk. Format with beautiful, easy-to-read markdown.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });
    
    res.json({ forecast: response.text?.trim() });
  } catch (error: any) {
    console.error("Gemini inventory forecast error:", error);
    res.status(500).json({ error: error.message || "Failed to generate restock forecast" });
  }
});

// 4. API: Smart Merchant Chatbot Assistant
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { messages, context } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Chat messages history is required" });
    }
    
    const ai = getGeminiClient();
    
    // Inject merchant context into system instructions
    const systemInstruction = `You are 'MerchantBot', a highly experienced retail store operations manager and financial consultant. Your job is to help the merchant user manage their shops, optimize inventory, increase sales, configure product margins, and answer general business queries.
    
Current Merchant State:
- Active Shop: ${context?.activeShopName || "All Shops"}
- Total Products: ${context?.productCount || 0}
- Total Transactions: ${context?.transactionCount || 0}
- Out of Stock / Low Stock Items Count: ${context?.lowStockCount || 0}

Refer directly to these numbers if the user asks about their shop, inventory, or sales. Keep your responses highly practical, friendly, professional, and clear. Avoid overly technical jargon. Use bullet points and clean structure.`;

    const formattedContents = messages.map((m: any) => ({
      role: m.role === "user" ? "user" : "model",
      parts: [{ text: m.content }]
    }));

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedContents,
      config: {
        systemInstruction,
      }
    });
    
    res.json({ reply: response.text?.trim() });
  } catch (error: any) {
    console.error("Gemini Chatbot error:", error);
    res.status(500).json({ error: error.message || "Failed to process chat" });
  }
});

// Vite dev server vs production static asset server setup
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Merchant Shop Management Server listening at http://localhost:${PORT}`);
  });
}

setupServer();
