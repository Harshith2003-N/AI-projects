import React, { useState, useMemo } from "react";
import { Shop, Product, Supplier, Transaction, StockLog } from "./types";
import { 
  INITIAL_SHOPS, 
  INITIAL_PRODUCTS, 
  INITIAL_SUPPLIERS, 
  INITIAL_TRANSACTIONS, 
  INITIAL_STOCK_LOGS 
} from "./data";

// Components
import Dashboard from "./components/Dashboard";
import ShopsTab from "./components/ShopsTab";
import CatalogTab from "./components/CatalogTab";
import POSTab from "./components/POSTab";
import InventoryTab from "./components/InventoryTab";
import LedgerTab from "./components/LedgerTab";
import SuppliersTab from "./components/SuppliersTab";
import ChatbotTab from "./components/ChatbotTab";

import { 
  LayoutDashboard, 
  Store, 
  Tag, 
  Receipt, 
  Package, 
  FileText, 
  Users, 
  Bot, 
  ChevronRight, 
  Menu, 
  X,
  Sparkles,
  Info
} from "lucide-react";

export default function App() {
  // Central application state engines
  const [shops, setShops] = useState<Shop[]>(INITIAL_SHOPS);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [suppliers, setSuppliers] = useState<Supplier[]>(INITIAL_SUPPLIERS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [stockLogs, setStockLogs] = useState<StockLog[]>(INITIAL_STOCK_LOGS);

  // Filter state configs
  const [activeShopId, setActiveShopId] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Keep track of the last processed transaction to trigger a beautiful invoice popup in POS
  const [lastProcessedTx, setLastProcessedTx] = useState<Transaction | null>(null);

  // ---------------------------------------------------------------------------
  // CALLBAK MUTATORS (CRUD STATE FLOWS)
  // ---------------------------------------------------------------------------

  // 1. Shops Mutators
  const handleAddShop = (newShop: Omit<Shop, "id" | "isActive">) => {
    const shop: Shop = {
      ...newShop,
      id: `shop-${Date.now()}`,
      isActive: true
    };
    setShops(prev => [...prev, shop]);
  };

  const handleUpdateShop = (updatedShop: Shop) => {
    setShops(prev => prev.map(s => s.id === updatedShop.id ? updatedShop : s));
  };

  const handleDeleteShop = (id: string) => {
    setShops(prev => prev.filter(s => s.id !== id));
    // fallback global active context
    if (activeShopId === id) {
      setActiveShopId("all");
    }
  };

  // 2. Product Mutators
  const handleAddProduct = (newProduct: Omit<Product, "id">) => {
    const product: Product = {
      ...newProduct,
      id: `prod-${Date.now()}`
    };
    setProducts(prev => [...prev, product]);
  };

  const handleUpdateProduct = (updatedProduct: Product) => {
    setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
  };

  const handleDeleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  // 3. Supplier Mutators
  const handleAddSupplier = (newSupplier: Omit<Supplier, "id">) => {
    const supplier: Supplier = {
      ...newSupplier,
      id: `sup-${Date.now()}`
    };
    setSuppliers(prev => [...prev, supplier]);
  };

  const handleUpdateSupplier = (updatedSupplier: Supplier) => {
    setSuppliers(prev => prev.map(s => s.id === updatedSupplier.id ? updatedSupplier : s));
  };

  const handleDeleteSupplier = (id: string) => {
    setSuppliers(prev => prev.filter(s => s.id !== id));
  };

  // 4. POS Checkout Invoicing Process
  const handleProcessTransaction = (txPayload: Omit<Transaction, "id" | "invoiceNumber" | "date">) => {
    const invoiceNumber = `INV-${Math.floor(100000 + Math.random() * 900000)}`;
    const newTx: Transaction = {
      ...txPayload,
      id: `tx-${Date.now()}`,
      invoiceNumber,
      date: new Date().toISOString()
    };

    // 1. Log Transaction
    setTransactions(prev => [...prev, newTx]);

    // 2. Subtract inventory levels physically
    setProducts(prev => {
      return prev.map(p => {
        const matchingItem = txPayload.items.find(item => item.productId === p.id);
        if (matchingItem) {
          return {
            ...p,
            stockQuantity: Math.max(0, p.stockQuantity - matchingItem.quantity)
          };
        }
        return p;
      });
    });

    // 3. Log stock depletion log sheets
    const newLogs: StockLog[] = txPayload.items.map(item => ({
      id: `log-${Date.now()}-${item.productId}`,
      productId: item.productId,
      productName: item.productName,
      quantity: -item.quantity,
      type: "Adjustment",
      date: new Date().toISOString(),
      note: `Checkout Item. Invoice: ${invoiceNumber}`
    }));
    setStockLogs(prev => [...prev, ...newLogs]);

    // 4. Display receipt modal
    setLastProcessedTx(newTx);
  };

  // 5. Stock Level Audits (Inventory replenishment adjustments)
  const handleUpdateProductStock = (id: string, qty: number, logType: StockLog["type"], note: string) => {
    const prod = products.find(p => p.id === id);
    if (!prod) return;

    // Adjust product quantity
    setProducts(prev => {
      return prev.map(p => {
        if (p.id === id) {
          return {
            ...p,
            stockQuantity: Math.max(0, p.stockQuantity + qty)
          };
        }
        return p;
      });
    });

    // Append log history
    const log: StockLog = {
      id: `log-${Date.now()}`,
      productId: id,
      productName: prod.name,
      quantity: qty,
      type: logType,
      date: new Date().toISOString(),
      note
    };
    setStockLogs(prev => [...prev, log]);
  };

  // Menu bar items list
  const MENU_ITEMS = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "pos", label: "POS Checkout", icon: Receipt, badge: "Terminal" },
    { id: "catalog", label: "Products Catalog", icon: Tag },
    { id: "inventory", label: "Inventory sheet", icon: Package },
    { id: "ledger", label: "Sales Ledger", icon: FileText },
    { id: "suppliers", label: "Suppliers", icon: Users },
    { id: "shops", label: "Outlets Config", icon: Store },
    { id: "chat", label: "Copilot Assistant", icon: Bot, isAi: true }
  ];

  const activeShop = useMemo(() => {
    return shops.find(s => s.id === activeShopId);
  }, [shops, activeShopId]);

  return (
    <div className="min-h-screen bg-dark-bg flex flex-col md:flex-row font-sans text-dark-text animate-fade-in" id="merchant-app-root">
      {/* ---------------------------------------------------------------------------
          DESKTOP SIDEBAR PANEL
         --------------------------------------------------------------------------- */}
      <aside className="hidden md:flex flex-col w-64 bg-dark-card text-dark-text shrink-0 border-r border-dark-border h-screen sticky top-0">
        {/* Brand Banner */}
        <div className="p-6 border-b border-dark-border flex items-center gap-3">
          <div className="p-2 bg-gold/10 border border-gold/30 rounded-xl flex items-center justify-center shadow-xs">
            <Store className="w-5 h-5 text-gold" />
          </div>
          <div>
            <h1 className="font-extrabold text-base tracking-tight text-white">MerchantOS</h1>
            <span className="text-[10px] text-dark-muted font-mono uppercase tracking-wider block">Enterprise Hub</span>
          </div>
        </div>

        {/* Global Shop context Selector */}
        <div className="px-4 py-4 border-b border-dark-border space-y-2">
          <label className="block text-[10px] font-bold text-dark-muted uppercase tracking-wider pl-1">
            Active Workspace:
          </label>
          <select
            value={activeShopId}
            onChange={(e) => setActiveShopId(e.target.value)}
            className="w-full bg-dark-input border border-dark-border text-dark-text rounded-lg px-3 py-2 text-xs font-semibold focus:outline-hidden focus:border-gold cursor-pointer"
          >
            <option value="all" className="bg-dark-card">All Outlets Combined</option>
            {shops.map(s => (
              <option key={s.id} value={s.id} className="bg-dark-card">{s.name}</option>
            ))}
          </select>
        </div>

        {/* Sidebar Nav links */}
        <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto">
          {MENU_ITEMS.map((item) => {
            const Icon = item.icon;
            const isSelected = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between p-3 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer group ${
                  isSelected 
                    ? "bg-gold text-dark-bg font-bold border border-gold/30 shadow-md" 
                    : "text-dark-muted hover:bg-dark-input hover:text-dark-text"
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-105 ${
                    isSelected ? "text-dark-bg" : "text-dark-muted"
                  }`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-xs font-bold uppercase ${
                    isSelected ? "bg-dark-bg/20 text-dark-bg" : "bg-dark-input text-gold border border-gold/20"
                  }`}>
                    {item.badge}
                  </span>
                )}
                {item.isAi && !isSelected && (
                  <Sparkles className="w-3.5 h-3.5 text-gold animate-pulse shrink-0" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer info brand */}
        <div className="p-4 border-t border-dark-border text-[10px] text-dark-dim flex flex-col gap-1">
          <span>Active Outlet: <strong className="text-dark-muted">{activeShop ? activeShop.name : "Consolidated"}</strong></span>
          <span>Currency System: <strong className="text-dark-muted">{activeShop ? activeShop.currency : "Universal"}</strong></span>
        </div>
      </aside>

      {/* ---------------------------------------------------------------------------
          MOBILE NAVBAR BAR
         --------------------------------------------------------------------------- */}
      <header className="md:hidden bg-dark-card text-dark-text px-5 py-4 flex justify-between items-center shrink-0 border-b border-dark-border sticky top-0 z-40">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-gold/10 border border-gold/30 rounded-lg">
            <Store className="w-4 h-4 text-gold" />
          </div>
          <h1 className="font-extrabold text-sm tracking-tight text-white">MerchantOS</h1>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick shop select */}
          <select
            value={activeShopId}
            onChange={(e) => setActiveShopId(e.target.value)}
            className="bg-dark-input border border-dark-border text-dark-text rounded-lg px-2 py-1 text-[10px] font-semibold focus:outline-hidden"
          >
            <option value="all" className="bg-dark-card">Combined</option>
            {shops.map(s => (
              <option key={s.id} value={s.id} className="bg-dark-card">{s.name}</option>
            ))}
          </select>

          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-1.5 hover:bg-dark-input rounded-lg text-dark-muted hover:text-dark-text"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Mobile Drawer Menu Overlays */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-x-0 top-[60px] bg-dark-card z-30 border-b border-dark-border shadow-2xl p-4 space-y-1 animate-fade-in">
          {MENU_ITEMS.map((item) => {
            const Icon = item.icon;
            const isSelected = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-2.5 p-3 rounded-lg text-xs font-semibold ${
                  isSelected 
                    ? "bg-gold text-dark-bg font-bold border border-gold/30" 
                    : "text-dark-muted hover:bg-dark-input hover:text-dark-text"
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isSelected ? "text-dark-bg" : "text-dark-muted"}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-sm ml-auto font-bold uppercase ${
                    isSelected ? "bg-dark-bg/20 text-dark-bg" : "bg-dark-input text-gold border border-gold/20"
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* ---------------------------------------------------------------------------
          MAIN DYNAMIC CONTAINER VIEWPORTS
         --------------------------------------------------------------------------- */}
      <main className="flex-1 p-6 md:p-10 space-y-8 max-w-7xl mx-auto w-full overflow-hidden">
        {/* Dynamic header summary bar */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-dark-card border border-dark-border p-4 rounded-xl shadow-xs shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-gold animate-pulse" />
            <p className="text-xs text-dark-muted font-medium font-sans">
              Viewing Workspace: <strong className="font-extrabold text-gold">{activeShop ? activeShop.name : "All Integrated Outlets"}</strong>
            </p>
          </div>

          <div className="text-[10px] text-dark-muted font-mono uppercase tracking-wider font-semibold">
            EST. TAX VAT: {activeShop ? `${activeShop.taxRate}%` : "Combined Outlets"}
          </div>
        </div>

        {/* Core switch render */}
        <div className="w-full">
          {activeTab === "dashboard" && (
            <Dashboard 
              shops={shops}
              products={products}
              transactions={transactions}
              activeShopId={activeShopId}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === "pos" && (
            <POSTab 
              products={products}
              shops={shops}
              activeShopId={activeShopId}
              onProcessTransaction={handleProcessTransaction}
              lastProcessedTransaction={lastProcessedTx}
              clearLastProcessed={() => setLastProcessedTx(null)}
            />
          )}

          {activeTab === "catalog" && (
            <CatalogTab 
              products={products}
              shops={shops}
              suppliers={suppliers}
              activeShopId={activeShopId}
              onAddProduct={handleAddProduct}
              onUpdateProduct={handleUpdateProduct}
              onDeleteProduct={handleDeleteProduct}
            />
          )}

          {activeTab === "inventory" && (
            <InventoryTab 
              products={products}
              shops={shops}
              suppliers={suppliers}
              stockLogs={stockLogs}
              activeShopId={activeShopId}
              onUpdateProductStock={handleUpdateProductStock}
            />
          )}

          {activeTab === "ledger" && (
            <LedgerTab 
              transactions={transactions}
              shops={shops}
              products={products}
              activeShopId={activeShopId}
            />
          )}

          {activeTab === "suppliers" && (
            <SuppliersTab 
              suppliers={suppliers}
              onAddSupplier={handleAddSupplier}
              onUpdateSupplier={handleUpdateSupplier}
              onDeleteSupplier={handleDeleteSupplier}
            />
          )}

          {activeTab === "shops" && (
            <ShopsTab 
              shops={shops}
              onAddShop={handleAddShop}
              onUpdateShop={handleUpdateShop}
              onDeleteShop={handleDeleteShop}
            />
          )}

          {activeTab === "chat" && (
            <ChatbotTab 
              shops={shops}
              products={products}
              transactions={transactions}
              activeShopId={activeShopId}
            />
          )}
        </div>
      </main>
    </div>
  );
}
