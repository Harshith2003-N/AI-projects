import React, { useState, useMemo } from "react";
import { Product, Shop, Supplier } from "../types";
import { Plus, Search, Tag, Sparkles, Trash2, Edit2, X, Percent, Check, Loader2, Store } from "lucide-react";

interface CatalogTabProps {
  products: Product[];
  shops: Shop[];
  suppliers: Supplier[];
  activeShopId: string;
  onAddProduct: (product: Omit<Product, "id">) => void;
  onUpdateProduct: (product: Product) => void;
  onDeleteProduct: (id: string) => void;
}

export default function CatalogTab({ 
  products, 
  shops, 
  suppliers, 
  activeShopId, 
  onAddProduct, 
  onUpdateProduct, 
  onDeleteProduct 
}: CatalogTabProps) {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Filter/Search states
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedShopFilter, setSelectedShopFilter] = useState("all");

  // Form states
  const [sku, setSku] = useState("");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [costPrice, setCostPrice] = useState(0);
  const [sellingPrice, setSellingPrice] = useState(0);
  const [stockQuantity, setStockQuantity] = useState(0);
  const [lowStockThreshold, setLowStockThreshold] = useState(5);
  const [shopId, setShopId] = useState("");
  const [supplierId, setSupplierId] = useState("");
  const [status, setStatus] = useState<"Active" | "Inactive">("Active");

  // AI copywriting loader state
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Deduplicated list of categories
  const categories = useMemo(() => {
    const set = new Set(products.map(p => p.category));
    return Array.from(set);
  }, [products]);

  // Handle active shop context filtering + search filters
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      // 1. Filter by top-level active shop selector (if it is locked to a specific shop)
      if (activeShopId !== "all" && p.shopId !== activeShopId) return false;

      // 2. Filter by tab-specific shop dropdown selector
      if (selectedShopFilter !== "all" && p.shopId !== selectedShopFilter) return false;

      // 3. Filter by category
      if (selectedCategory !== "all" && p.category !== selectedCategory) return false;

      // 4. Search query matching
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return (
          p.name.toLowerCase().includes(query) ||
          p.sku.toLowerCase().includes(query) ||
          p.category.toLowerCase().includes(query)
        );
      }

      return true;
    });
  }, [products, activeShopId, selectedShopFilter, selectedCategory, searchQuery]);

  const openAddForm = () => {
    setEditingProduct(null);
    setSku(`SKU-${Math.floor(100000 + Math.random() * 900000)}`);
    setName("");
    setDescription("");
    setCategory(categories[0] || "General");
    setCostPrice(0);
    setSellingPrice(0);
    setStockQuantity(10);
    setLowStockThreshold(5);
    setShopId(activeShopId === "all" ? (shops[0]?.id || "") : activeShopId);
    setSupplierId(suppliers[0]?.id || "");
    setStatus("Active");
    setIsFormOpen(true);
  };

  const openEditForm = (prod: Product) => {
    setEditingProduct(prod);
    setSku(prod.sku);
    setName(prod.name);
    setDescription(prod.description);
    setCategory(prod.category);
    setCostPrice(prod.costPrice);
    setSellingPrice(prod.sellingPrice);
    setStockQuantity(prod.stockQuantity);
    setLowStockThreshold(prod.lowStockThreshold);
    setShopId(prod.shopId);
    setSupplierId(prod.supplierId);
    setStatus(prod.status);
    setIsFormOpen(true);
  };

  // AI copywriting feature calling backend
  const handleAiDescription = async () => {
    if (!name.trim()) return alert("Please enter the product name first to let AI write a description.");
    setIsAiLoading(true);
    try {
      const response = await fetch("/api/ai/generate-description", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          category: category,
          brand: suppliers.find(s => s.id === supplierId)?.name || "",
        })
      });
      const data = await response.json();
      if (data.description) {
        setDescription(data.description);
      } else if (data.error) {
        alert("AI Assistant error: " + data.error);
      }
    } catch (e) {
      console.error(e);
      alert("Failed to write description. Check server connections.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !sku.trim()) return;

    const payload = {
      sku: sku.trim().toUpperCase(),
      name: name.trim(),
      description: description.trim(),
      category: category.trim(),
      costPrice: Number(costPrice),
      sellingPrice: Number(sellingPrice),
      stockQuantity: Number(stockQuantity),
      lowStockThreshold: Number(lowStockThreshold),
      shopId,
      supplierId,
      status,
    };

    if (editingProduct) {
      onUpdateProduct({
        ...editingProduct,
        ...payload,
      });
    } else {
      onAddProduct(payload);
    }

    setIsFormOpen(false);
  };

  return (
    <div className="space-y-6" id="catalog-tab">
      {/* Header and Add button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-white">Product Inventory & Catalog</h2>
          <p className="text-xs text-dark-muted">Add catalog items, edit prices, calculate margins, and trigger AI descriptions.</p>
        </div>
        <button 
          onClick={openAddForm}
          className="flex items-center gap-1.5 bg-gold hover:bg-gold-hover text-dark-bg font-bold px-4 py-2 rounded-lg text-xs transition-colors shadow-md cursor-pointer"
          id="btn-add-product"
        >
          <Plus className="w-4 h-4" />
          Add Product
        </button>
      </div>

      {/* Filter and search bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 bg-dark-card p-4 rounded-xl border border-dark-border shadow-xs">
        {/* Search */}
        <div className="relative col-span-1 sm:col-span-2">
          <Search className="w-4 h-4 text-dark-muted absolute left-3 top-3" />
          <input 
            type="text" 
            placeholder="Search by SKU, item name or tags..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-dark-input border border-dark-border rounded-lg text-xs text-white placeholder-dark-muted focus:outline-hidden focus:border-gold"
          />
        </div>

        {/* Shop selector filter (only shows if top selector is set to "all") */}
        {activeShopId === "all" ? (
          <div>
            <select
              value={selectedShopFilter}
              onChange={(e) => setSelectedShopFilter(e.target.value)}
              className="w-full bg-dark-input border border-dark-border text-white rounded-lg px-3 py-2 text-xs focus:outline-hidden focus:border-gold cursor-pointer"
            >
              <option value="all" className="bg-dark-card">All Stores</option>
              {shops.map(s => (
                <option key={s.id} value={s.id} className="bg-dark-card">{s.name}</option>
              ))}
            </select>
          </div>
        ) : (
          <div className="hidden md:block"></div> /* spacing placeholder */
        )}

        {/* Category filter */}
        <div>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full bg-dark-input border border-dark-border text-white rounded-lg px-3 py-2 text-xs focus:outline-hidden focus:border-gold cursor-pointer"
          >
            <option value="all" className="bg-dark-card">All Categories</option>
            {categories.map(cat => (
              <option key={cat} value={cat} className="bg-dark-card">{cat}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Products list table */}
      <div className="bg-dark-card border border-dark-border rounded-xl shadow-xs overflow-hidden">
        {filteredProducts.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-dark-input border-b border-dark-border text-dark-muted font-semibold uppercase tracking-wider">
                  <th className="p-4">SKU / Item</th>
                  <th className="p-4">Category</th>
                  <th className="p-4 text-right">Cost</th>
                  <th className="p-4 text-right">Selling Price</th>
                  <th className="p-4 text-center">Margin</th>
                  <th className="p-4 text-center">Stock Level</th>
                  <th className="p-4 text-center">Store location</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dark-border/40">
                {filteredProducts.map((p) => {
                  const shop = shops.find(s => s.id === p.shopId);
                  const markup = p.sellingPrice - p.costPrice;
                  const marginPct = p.sellingPrice > 0 ? (markup / p.sellingPrice) * 100 : 0;
                  
                  // Color codes for stock
                  const isOutOfStock = p.stockQuantity <= 0;
                  const isLowStock = p.stockQuantity <= p.lowStockThreshold;

                  return (
                    <tr key={p.id} className="hover:bg-dark-input/30 transition-colors">
                      {/* SKU / Name */}
                      <td className="p-4">
                        <div className="max-w-xs">
                          <span className="font-bold text-white text-sm block">{p.name}</span>
                          <span className="text-[10px] text-dark-muted font-mono tracking-wide mt-0.5 block">{p.sku}</span>
                        </div>
                      </td>
                      
                      {/* Category */}
                      <td className="p-4 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 text-[10px] font-semibold bg-gold/5 border border-gold/20 text-gold px-2 py-0.5 rounded-full uppercase">
                          <Tag className="w-3 h-3" />
                          {p.category}
                        </span>
                      </td>

                      {/* Cost */}
                      <td className="p-4 text-right font-mono text-dark-muted">
                        {shop?.currency || "$"}{p.costPrice.toFixed(2)}
                      </td>

                      {/* Selling */}
                      <td className="p-4 text-right font-mono font-semibold text-white">
                        {shop?.currency || "$"}{p.sellingPrice.toFixed(2)}
                      </td>

                      {/* Margin */}
                      <td className="p-4 text-center">
                        <span className={`inline-flex items-center gap-0.5 font-semibold text-[10px] px-2 py-0.5 rounded border ${
                          marginPct >= 50 
                            ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" 
                            : marginPct >= 30 
                              ? "bg-gold/10 text-gold border-gold/20" 
                              : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                        }`}>
                          <Percent className="w-3 h-3 shrink-0" />
                          {marginPct.toFixed(0)}%
                        </span>
                      </td>

                      {/* Stock Level */}
                      <td className="p-4 text-center">
                        <span className={`inline-flex items-center font-bold font-mono px-2.5 py-1 rounded text-xs border ${
                          isOutOfStock 
                            ? "bg-red-500/10 text-red-400 border-red-500/20" 
                            : isLowStock 
                              ? "bg-amber-500/10 text-amber-400 border-amber-500/20" 
                              : "bg-dark-input text-dark-muted border-dark-border"
                        }`}>
                          {p.stockQuantity}
                          {isOutOfStock && " (Out)"}
                          {!isOutOfStock && isLowStock && " (Low)"}
                        </span>
                      </td>

                      {/* Store */}
                      <td className="p-4 text-center">
                        <span 
                          className="inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-current/30"
                          style={{ backgroundColor: `${shop?.color}10`, color: shop?.color }}
                        >
                          <Store className="w-3 h-3" />
                          {shop?.name || "Unassigned"}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button 
                            onClick={() => openEditForm(p)}
                            className="p-1.5 hover:bg-dark-input text-dark-muted hover:text-white rounded-lg transition-colors cursor-pointer"
                            title="Edit Product"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            onClick={() => onDeleteProduct(p.id)}
                            className="p-1.5 hover:bg-red-950/30 text-dark-muted hover:text-red-400 rounded-lg transition-colors cursor-pointer"
                            title="Delete Product"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-20 text-center text-dark-muted">
            <Tag className="w-12 h-12 stroke-1 mx-auto text-dark-dim mb-3 animate-pulse" />
            <h3 className="font-bold text-white text-sm">No Catalog Items Found</h3>
            <p className="text-xs text-dark-muted mt-1 max-w-sm mx-auto">
              No products match your current search criteria. Try adjusting filters or create a new product.
            </p>
          </div>
        )}
      </div>

      {/* Add / Edit Product Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-[#000000]/75 backdrop-blur-xs flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-dark-card rounded-2xl w-full max-w-lg border border-dark-border shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 my-8 text-white">
            {/* Header */}
            <div className="flex justify-between items-center px-6 py-4 border-b border-dark-border bg-dark-input">
              <h3 className="font-bold text-white text-base">
                {editingProduct ? "Edit Product Specifications" : "Launch New Product"}
              </h3>
              <button 
                onClick={() => setIsFormOpen(false)}
                className="p-1 hover:bg-dark-card text-dark-muted hover:text-white rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-dark-muted uppercase tracking-wider mb-1.5">
                    Product Code (SKU) *
                  </label>
                  <input 
                    type="text" 
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    required
                    placeholder="e.g. GRO-MILK-001"
                    className="w-full bg-dark-input border border-dark-border rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-gold uppercase"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-dark-muted uppercase tracking-wider mb-1.5">
                    Product Category *
                  </label>
                  <input 
                    type="text" 
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    required
                    placeholder="e.g. Dairy, Apparel, Beverages"
                    className="w-full bg-dark-input border border-dark-border rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-gold"
                    list="category-options"
                  />
                  <datalist id="category-options">
                    {categories.map(cat => (
                      <option key={cat} value={cat} />
                    ))}
                  </datalist>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-dark-muted uppercase tracking-wider mb-1.5">
                  Product Name *
                </label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  placeholder="e.g. Organic Whole Milk (1 Gallon)"
                  className="w-full bg-dark-input border border-dark-border rounded-lg px-3.5 py-2 text-sm font-semibold text-white focus:outline-hidden focus:border-gold"
                />
              </div>

              {/* Description + AI Assistant Row */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-xs font-semibold text-dark-muted uppercase tracking-wider">
                    Copywrite Description
                  </label>
                  <button
                    type="button"
                    onClick={handleAiDescription}
                    disabled={isAiLoading}
                    className="flex items-center gap-1 text-[10px] font-bold text-gold hover:text-gold-hover bg-gold/10 hover:bg-gold/20 border border-gold/20 disabled:bg-dark-input disabled:text-dark-dim px-2 py-1 rounded-sm transition-all cursor-pointer"
                  >
                    {isAiLoading ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        AI Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        AI Auto-Writer
                      </>
                    )}
                  </button>
                </div>
                <textarea 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide an overview of the product or click AI Auto-Writer to draft copywriting instantly..."
                  rows={2}
                  className="w-full bg-dark-input border border-dark-border rounded-lg px-3.5 py-2 text-xs text-white placeholder-dark-muted focus:outline-hidden focus:border-gold"
                />
              </div>

              {/* Margins pricing cards calculator */}
              <div className="grid grid-cols-2 gap-4 bg-dark-input p-3.5 rounded-xl border border-dark-border">
                <div>
                  <label className="block text-[10px] font-bold text-dark-muted uppercase tracking-wider mb-1">
                    Cost Price ($)
                  </label>
                  <input 
                    type="number" 
                    step="0.01"
                    min="0"
                    value={costPrice}
                    onChange={(e) => setCostPrice(Number(e.target.value))}
                    required
                    className="w-full bg-dark-card border border-dark-border rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:outline-hidden focus:border-gold"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-dark-muted uppercase tracking-wider mb-1">
                    Selling Price ($)
                  </label>
                  <input 
                    type="number" 
                    step="0.01"
                    min="0"
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(Number(e.target.value))}
                    required
                    className="w-full bg-dark-card border border-dark-border rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:outline-hidden focus:border-gold"
                  />
                </div>

                <div className="col-span-2 flex justify-between items-center text-[10px] font-semibold text-dark-muted border-t border-dark-border/40 pt-2">
                  <span>Gross Margin Breakdown:</span>
                  <span className="font-mono text-gold font-bold">
                    Markup: ${((sellingPrice - costPrice)).toFixed(2)} (
                    {sellingPrice > 0 
                      ? (((sellingPrice - costPrice) / sellingPrice) * 100).toFixed(0) 
                      : 0}% Margin)
                  </span>
                </div>
              </div>

              {/* Stock controls */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-dark-muted uppercase tracking-wider mb-1.5">
                    Opening Stock Qty
                  </label>
                  <input 
                    type="number" 
                    min="0"
                    value={stockQuantity}
                    onChange={(e) => setStockQuantity(Number(e.target.value))}
                    required
                    className="w-full bg-dark-input border border-dark-border rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-gold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-dark-muted uppercase tracking-wider mb-1.5">
                    Low Stock Threshold
                  </label>
                  <input 
                    type="number" 
                    min="1"
                    value={lowStockThreshold}
                    onChange={(e) => setLowStockThreshold(Number(e.target.value))}
                    required
                    className="w-full bg-dark-input border border-dark-border rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-gold"
                  />
                </div>
              </div>

              {/* Assignment select menus */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-dark-muted uppercase tracking-wider mb-1.5">
                    Assign Store *
                  </label>
                  <select 
                    value={shopId}
                    onChange={(e) => setShopId(e.target.value)}
                    required
                    className="w-full bg-dark-input border border-dark-border text-white rounded-lg px-3 py-2 text-xs focus:outline-hidden focus:border-gold cursor-pointer font-semibold"
                  >
                    {shops.map(s => (
                      <option key={s.id} value={s.id} className="bg-dark-card">{s.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-dark-muted uppercase tracking-wider mb-1.5">
                    Assign Supplier *
                  </label>
                  <select 
                    value={supplierId}
                    onChange={(e) => setSupplierId(e.target.value)}
                    required
                    className="w-full bg-dark-input border border-dark-border text-white rounded-lg px-3 py-2 text-xs focus:outline-hidden focus:border-gold cursor-pointer font-semibold"
                  >
                    {suppliers.map(sup => (
                      <option key={sup.id} value={sup.id} className="bg-dark-card">{sup.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-dark-muted uppercase tracking-wider mb-1.5">
                  Publishing Status
                </label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-1.5 text-xs font-medium text-dark-muted cursor-pointer">
                    <input 
                      type="radio" 
                      name="status" 
                      checked={status === "Active"}
                      onChange={() => setStatus("Active")}
                      className="accent-gold"
                    />
                    Active (Shelf stockable)
                  </label>
                  <label className="flex items-center gap-1.5 text-xs font-medium text-dark-muted cursor-pointer">
                    <input 
                      type="radio" 
                      name="status" 
                      checked={status === "Inactive"}
                      onChange={() => setStatus("Inactive")}
                      className="accent-gold"
                    />
                    Inactive (Archived / Draft)
                  </label>
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-dark-border">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="flex-1 bg-dark-input hover:bg-dark-input/80 border border-dark-border text-dark-muted font-bold px-4 py-2 rounded-lg text-xs transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-gold hover:bg-gold-hover text-dark-bg font-bold px-4 py-2 rounded-lg text-xs transition-colors cursor-pointer shadow-md"
                >
                  {editingProduct ? "Apply Modifications" : "Launch Product"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
