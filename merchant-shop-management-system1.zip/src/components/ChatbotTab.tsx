import React, { useState, useRef, useEffect, useMemo } from "react";
import { Shop, Product, Transaction } from "../types";
import ReactMarkdown from "react-markdown";
import { Bot, Send, User, Loader2, Sparkles, Store, TrendingUp, AlertTriangle } from "lucide-react";

interface ChatbotTabProps {
  shops: Shop[];
  products: Product[];
  transactions: Transaction[];
  activeShopId: string;
}

interface Message {
  role: "user" | "model";
  content: string;
}

export default function ChatbotTab({
  shops,
  products,
  transactions,
  activeShopId
}: ChatbotTabProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "model",
      content: "Hello! I am **MerchantBot**, your AI Retail Strategist. I have analyzed your shops' stock sheets and ledger books.\n\nAsk me anything about your business performance, pricing optimization, restock strategies, or request dynamic customer discount plans!"
    }
  ]);
  const [userInput, setUserInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll to bottom of chats
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Active shop helper
  const activeShop = useMemo(() => {
    return shops.find(s => s.id === activeShopId);
  }, [shops, activeShopId]);

  // Count metrics for system context injection
  const contextStats = useMemo(() => {
    const shopProducts = activeShopId === "all" ? products : products.filter(p => p.shopId === activeShopId);
    const shopTx = activeShopId === "all" ? transactions : transactions.filter(t => t.shopId === activeShopId);
    
    let lowStockCount = 0;
    shopProducts.forEach(p => {
      if (p.stockQuantity <= p.lowStockThreshold) {
        lowStockCount++;
      }
    });

    return {
      activeShopName: activeShop ? activeShop.name : "All Stores",
      productCount: shopProducts.length,
      transactionCount: shopTx.length,
      lowStockCount
    };
  }, [products, transactions, activeShopId, activeShop]);

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = customPrompt || userInput;
    if (!textToSend.trim() || isLoading) return;

    const newMessages = [...messages, { role: "user" as const, content: textToSend }];
    setMessages(newMessages);
    setUserInput("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: newMessages,
          context: contextStats
        })
      });

      const data = await response.json();
      if (data.reply) {
        setMessages(prev => [...prev, { role: "model" as const, content: data.reply }]);
      } else if (data.error) {
        setMessages(prev => [...prev, { role: "model" as const, content: `**Error:** ${data.error}` }]);
      }
    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { role: "model" as const, content: "**Network Error:** Failed to speak with copilot. Please ensure your backend container is compiled successfully." }]);
    } finally {
      setIsLoading(false);
    }
  };

  // Quick prompt triggers
  const SUGGESTION_CHIPS = [
    { label: "Check Shop Performance", icon: TrendingUp, prompt: "Give me an overview of my current store performance and major takeaways." },
    { label: "List Low Stock Products", icon: AlertTriangle, prompt: "Which of my items are dangerously low or out of stock? Suggest some reordering quantities." },
    { label: "Suggest discount ideas", icon: Sparkles, prompt: "Recommend some clever seasonal marketing discount campaigns to lift slow products." }
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] min-h-[480px] bg-white border border-slate-100 rounded-2xl shadow-xs overflow-hidden" id="chatbot-tab">
      {/* Bot Chat Header */}
      <div className="bg-slate-900 p-4 text-white flex justify-between items-center shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-indigo-600 rounded-xl">
            <Bot className="w-5 h-5 text-indigo-100" />
          </div>
          <div>
            <h2 className="font-bold text-sm tracking-wide">MerchantBot Terminal</h2>
            <span className="text-[10px] text-indigo-300 font-semibold uppercase flex items-center gap-1">
              <Store className="w-3 h-3" />
              Assigned Context: {contextStats.activeShopName}
            </span>
          </div>
        </div>
        
        {/* Indicators */}
        <div className="text-[10px] bg-slate-800 text-slate-300 font-mono font-medium px-3 py-1 rounded-full shrink-0">
          Products Audited: {contextStats.productCount}
        </div>
      </div>

      {/* Messages dialogue stream */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/50">
        {messages.map((m, idx) => {
          const isBot = m.role === "model";
          return (
            <div 
              key={idx} 
              className={`flex items-start gap-3 max-w-3xl ${isBot ? "mr-auto" : "ml-auto flex-row-reverse"}`}
            >
              {/* Avatar icon */}
              <div className={`p-2.5 rounded-xl shrink-0 ${isBot ? "bg-indigo-600 text-white" : "bg-slate-200 text-slate-700"}`}>
                {isBot ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
              </div>

              {/* Speech bubble */}
              <div className={`rounded-2xl p-4 text-xs shadow-3xs leading-relaxed ${
                isBot 
                  ? "bg-white border border-slate-100 text-slate-800" 
                  : "bg-indigo-600 text-white font-medium"
              }`}>
                {isBot ? (
                  <div className="markdown-body space-y-2">
                    <ReactMarkdown>{m.content}</ReactMarkdown>
                  </div>
                ) : (
                  <p className="whitespace-pre-wrap">{m.content}</p>
                )}
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-start gap-3 mr-auto">
            <div className="p-2.5 bg-indigo-600 text-white rounded-xl shrink-0 animate-pulse">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-white border border-slate-100 rounded-2xl px-4 py-3 text-xs text-slate-400 flex items-center gap-2 shadow-3xs">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-500" />
              <span>MerchantBot is compiling accounts data...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggestion Chips and Send Message Row */}
      <div className="border-t border-slate-100 p-4 bg-white space-y-3 shrink-0">
        {/* Suggestion chips */}
        {messages.length === 1 && !isLoading && (
          <div className="flex flex-wrap gap-2">
            {SUGGESTION_CHIPS.map((chip, i) => {
              const Icon = chip.icon;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleSendMessage(chip.prompt)}
                  className="flex items-center gap-1.5 bg-slate-50 border border-slate-100 hover:bg-slate-100 text-slate-600 font-semibold px-3 py-1.5 rounded-full text-[10px] transition-colors cursor-pointer text-left"
                >
                  <Icon className="w-3 h-3 text-indigo-500 shrink-0" />
                  {chip.label}
                </button>
              );
            })}
          </div>
        )}

        {/* Text Input Row */}
        <form 
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex gap-2"
        >
          <input 
            type="text" 
            placeholder="Ask MerchantBot about stock optimization, pricing takeways or dynamic deals..."
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            disabled={isLoading}
            className="flex-1 border border-slate-200 rounded-xl px-4 py-2.5 text-xs focus:outline-hidden focus:border-indigo-500 disabled:bg-slate-50 disabled:text-slate-400"
          />
          <button
            type="submit"
            disabled={!userInput.trim() || isLoading}
            className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-100 disabled:text-slate-400 text-white p-2.5 rounded-xl transition-colors cursor-pointer shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
