import React, { useMemo } from "react";
import { Shop, Product, Transaction } from "../types";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip,
  BarChart,
  Bar,
  Cell
} from "recharts";
import { 
  Store, 
  TrendingUp, 
  ShoppingCart, 
  Package, 
  AlertTriangle, 
  DollarSign, 
  ArrowRightLeft,
  Percent,
  TrendingDown
} from "lucide-react";

interface DashboardProps {
  shops: Shop[];
  products: Product[];
  transactions: Transaction[];
  activeShopId: string;
  onNavigate: (tab: string) => void;
}

export default function Dashboard({ 
  shops, 
  products, 
  transactions, 
  activeShopId, 
  onNavigate 
}: DashboardProps) {
  
  // Filter state based on active shop
  const activeShop = useMemo(() => {
    return shops.find(s => s.id === activeShopId);
  }, [shops, activeShopId]);

  const filteredTransactions = useMemo(() => {
    if (activeShopId === "all") return transactions;
    return transactions.filter(t => t.shopId === activeShopId);
  }, [transactions, activeShopId]);

  const filteredProducts = useMemo(() => {
    if (activeShopId === "all") return products;
    return products.filter(p => p.shopId === activeShopId);
  }, [products, activeShopId]);

  // Compute key stats
  const stats = useMemo(() => {
    let revenue = 0;
    let cost = 0;
    let salesCount = filteredTransactions.length;
    let itemsCount = 0;

    filteredTransactions.forEach(t => {
      revenue += t.total;
      itemsCount += t.items.reduce((acc, item) => acc + item.quantity, 0);
      t.items.forEach(item => {
        cost += (item.cost * item.quantity);
      });
    });

    const netProfit = revenue - cost;
    const grossMargin = revenue > 0 ? (netProfit / revenue) * 100 : 0;
    const avgOrderValue = salesCount > 0 ? revenue / salesCount : 0;

    // Out of stock & Low stock alert counts
    let outOfStock = 0;
    let lowStock = 0;
    filteredProducts.forEach(p => {
      if (p.stockQuantity <= 0) {
        outOfStock++;
      } else if (p.stockQuantity <= p.lowStockThreshold) {
        lowStock++;
      }
    });

    return {
      revenue,
      netProfit,
      grossMargin,
      avgOrderValue,
      salesCount,
      outOfStock,
      lowStock
    };
  }, [filteredTransactions, filteredProducts]);

  // Chart data: Sales by date (last 7 days)
  const chartData = useMemo(() => {
    const datesMap: { [dateStr: string]: { date: string, revenue: number, profit: number } } = {};
    
    // Seed last 7 days
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
      datesMap[dateStr] = { date: dateStr, revenue: 0, profit: 0 };
    }

    // Populate
    filteredTransactions.forEach(t => {
      const txDate = new Date(t.date);
      const dateStr = txDate.toLocaleDateString(undefined, { month: "short", day: "numeric" });
      if (datesMap[dateStr]) {
        datesMap[dateStr].revenue += t.total;
        datesMap[dateStr].profit += t.profit;
      }
    });

    return Object.values(datesMap);
  }, [filteredTransactions]);

  // Revenue by shop data
  const shopRevenueData = useMemo(() => {
    const dataMap: { [shopName: string]: { name: string, value: number, color: string } } = {};
    
    shops.forEach(s => {
      dataMap[s.id] = { name: s.name, value: 0, color: s.color };
    });

    transactions.forEach(t => {
      if (dataMap[t.shopId]) {
        dataMap[t.shopId].value += t.total;
      }
    });

    return Object.values(dataMap).filter(item => item.value > 0);
  }, [shops, transactions]);

  // Top products
  const topProducts = useMemo(() => {
    const productSalesMap: { [prodId: string]: { name: string, sku: string, quantity: number, revenue: number } } = {};
    
    filteredTransactions.forEach(t => {
      t.items.forEach(item => {
        if (!productSalesMap[item.productId]) {
          productSalesMap[item.productId] = {
            name: item.productName,
            sku: item.sku,
            quantity: 0,
            revenue: 0
          };
        }
        productSalesMap[item.productId].quantity += item.quantity;
        productSalesMap[item.productId].revenue += item.subtotal;
      });
    });

    return Object.values(productSalesMap)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  }, [filteredTransactions]);

  const currencySymbol = activeShop ? activeShop.currency : "$";

  return (
    <div className="space-y-8" id="dashboard-tab">
      {/* Welcome header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-white font-sans">
            {activeShopId === "all" ? "Enterprise Dashboard" : activeShop?.name}
          </h1>
          <p className="text-dark-muted text-sm mt-1">
            Real-time shop operations, metrics, checkout statistics, and inventory alerts.
          </p>
        </div>
        <button 
          onClick={() => onNavigate("pos")}
          className="flex items-center gap-2 bg-gold hover:bg-gold-hover text-dark-bg font-bold px-5 py-2.5 rounded-lg shadow-md transition-colors text-sm cursor-pointer"
          id="btn-quick-pos"
        >
          <ShoppingCart className="w-4 h-4" />
          Open Register (POS)
        </button>
      </div>

      {/* Metrics bento grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Card 1: Revenue */}
        <div className="bg-dark-card border border-dark-border rounded-xl p-5 shadow-xs flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-dark-muted uppercase tracking-wider">Gross Revenue</span>
            <h3 className="text-2xl font-bold text-white tracking-tight font-mono">
              {currencySymbol}{stats.revenue.toFixed(2)}
            </h3>
            <div className="flex items-center gap-1 text-emerald-400 text-xs font-medium">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>+12.4% vs last week</span>
            </div>
          </div>
          <div className="p-3 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-lg">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>

        {/* Card 2: Net Profit */}
        <div className="bg-dark-card border border-dark-border rounded-xl p-5 shadow-xs flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-dark-muted uppercase tracking-wider">Net Profit</span>
            <h3 className="text-2xl font-bold text-white tracking-tight font-mono">
              {currencySymbol}{stats.netProfit.toFixed(2)}
            </h3>
            <div className="flex items-center gap-1 text-emerald-400 text-xs font-medium">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>+8.2% vs last week</span>
            </div>
          </div>
          <div className="p-3 bg-gold/10 text-gold border border-gold/20 rounded-lg">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Card 3: Avg Margin */}
        <div className="bg-dark-card border border-dark-border rounded-xl p-5 shadow-xs flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-dark-muted uppercase tracking-wider">Profit Margin</span>
            <h3 className="text-2xl font-bold text-white tracking-tight font-mono">
              {stats.grossMargin.toFixed(1)}%
            </h3>
            <div className="flex items-center gap-1 text-dark-muted text-xs">
              <Percent className="w-3.5 h-3.5" />
              <span>Healthy profit levels</span>
            </div>
          </div>
          <div className="p-3 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-lg">
            <Percent className="w-5 h-5" />
          </div>
        </div>

        {/* Card 4: Avg Order */}
        <div className="bg-dark-card border border-dark-border rounded-xl p-5 shadow-xs flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-xs font-semibold text-dark-muted uppercase tracking-wider">Avg Order Value</span>
            <h3 className="text-2xl font-bold text-white tracking-tight font-mono">
              {currencySymbol}{stats.avgOrderValue.toFixed(2)}
            </h3>
            <div className="flex items-center gap-1 text-dark-muted text-xs">
              <ArrowRightLeft className="w-3.5 h-3.5" />
              <span>Based on {stats.salesCount} tickets</span>
            </div>
          </div>
          <div className="p-3 bg-teal-500/10 text-teal-400 border border-teal-500/20 rounded-lg">
            <ShoppingCart className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Danger Stock Alert Banner if any */}
      {(stats.outOfStock > 0 || stats.lowStock > 0) && (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-amber-950/20 border border-amber-500/30 p-4 rounded-xl text-amber-200">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-900/30 text-amber-400 border border-amber-500/20 rounded-lg shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-semibold text-sm">Critical Inventory Attention Required</h4>
              <p className="text-xs text-amber-300 mt-0.5">
                There are <strong className="font-bold">{stats.outOfStock}</strong> out-of-stock items and <strong className="font-bold">{stats.lowStock}</strong> low-stock products currently on shelves.
              </p>
            </div>
          </div>
          <button 
            onClick={() => onNavigate("inventory")}
            className="text-xs font-bold bg-gold hover:bg-gold-hover text-dark-bg px-3.5 py-1.5 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
          >
            Manage Restocks
          </button>
        </div>
      )}

      {/* Charts & Top-selling items section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue trend area chart */}
        <div className="bg-dark-card border border-dark-border p-5 rounded-2xl shadow-xs lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-bold text-white text-base">Weekly Revenue & Profit Flow</h3>
              <p className="text-xs text-dark-muted mt-0.5">Rolling 7-day snapshot of daily transaction totals.</p>
            </div>
            <span className="text-xs text-gold bg-gold/10 border border-gold/20 font-medium px-2.5 py-1 rounded-full">
              Live Feed
            </span>
          </div>

          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#C5A059" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#C5A059" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1F1F1F" />
                <XAxis 
                  dataKey="date" 
                  tickLine={false} 
                  axisLine={false}
                  tick={{ fill: "#888888", fontSize: 11, fontFamily: "monospace" }} 
                />
                <YAxis 
                  tickLine={false} 
                  axisLine={false}
                  tickFormatter={(val) => `${currencySymbol}${val}`}
                  tick={{ fill: "#888888", fontSize: 11, fontFamily: "monospace" }} 
                />
                <Tooltip 
                  formatter={(val: number) => [`${currencySymbol}${val.toFixed(2)}`]}
                  contentStyle={{ backgroundColor: "#0F0F0F", borderRadius: "12px", border: "1px solid #1F1F1F", color: "#E0E0E0" }}
                  labelStyle={{ fontWeight: "bold", fontSize: "12px", color: "#888888", fontFamily: "monospace" }}
                />
                <Area 
                  name="Revenue"
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#C5A059" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#revenueGrad)" 
                />
                <Area 
                  name="Net Profit"
                  type="monotone" 
                  dataKey="profit" 
                  stroke="#10B981" 
                  strokeWidth={2}
                  fillOpacity={1} 
                  fill="url(#profitGrad)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Enterprise breakdown or Top categories */}
        <div className="bg-dark-card border border-dark-border p-5 rounded-2xl shadow-xs space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-white text-base">
              {activeShopId === "all" ? "Revenue Share by Shop" : "Store Distribution"}
            </h3>
            <p className="text-xs text-dark-muted mt-0.5">
              {activeShopId === "all" ? "Comparing sales volume across active locations." : `Performance allocation for ${activeShop?.name}.`}
            </p>
          </div>

          {activeShopId === "all" && shopRevenueData.length > 0 ? (
            <div className="h-56 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={shopRevenueData} layout="vertical" margin={{ top: 5, right: 10, left: 10, bottom: 5 }}>
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" tickLine={false} axisLine={false} tick={{ fill: "#888888", fontSize: 11 }} width={110} />
                  <Tooltip 
                    formatter={(val: number) => [`${currencySymbol}${val.toFixed(2)}`]}
                    contentStyle={{ backgroundColor: "#0F0F0F", borderRadius: "8px", border: "1px solid #1F1F1F", color: "#E0E0E0" }}
                  />
                  <Bar dataKey="value" barSize={12} radius={[0, 4, 4, 0]}>
                    {shopRevenueData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-56 flex flex-col items-center justify-center text-dark-muted text-center px-4">
              <Store className="w-10 h-10 stroke-1 text-dark-dim mb-2" />
              <p className="text-xs font-semibold text-dark-muted">
                {activeShopId === "all" ? "No Store Revenue Logged" : `${activeShop?.type} Location Active`}
              </p>
              <p className="text-[10px] text-dark-dim mt-1 max-w-xs">
                {activeShopId === "all" 
                  ? "Ring up sales in the register to see revenue comparisons here." 
                  : `This shop operates on a flat ${activeShop?.taxRate}% tax rate. Change active shop from the top manager to view comparative graphs.`}
              </p>
            </div>
          )}

          {/* Mini info badge */}
          <div className="bg-dark-input p-3 rounded-xl border border-dark-border">
            <div className="flex justify-between items-center text-xs font-semibold text-dark-muted">
              <span>Managed Stores</span>
              <span className="font-mono text-gold">{shops.length} Active</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Row: Top products table & Recent transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top selling products */}
        <div className="bg-dark-card border border-dark-border p-5 rounded-2xl shadow-xs space-y-4">
          <div>
            <h3 className="font-bold text-white text-base">Top Performing Products</h3>
            <p className="text-xs text-dark-muted mt-0.5">High margin items driving checkout volume.</p>
          </div>

          {topProducts.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-dark-border text-dark-muted font-medium pb-2">
                    <th className="py-2.5">Product</th>
                    <th className="py-2.5 text-right">Units Sold</th>
                    <th className="py-2.5 text-right">Revenue</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-dark-border/40">
                  {topProducts.map((p, idx) => (
                    <tr key={idx} className="hover:bg-dark-input/30 transition-colors">
                      <td className="py-3">
                        <span className="font-semibold text-white block">{p.name}</span>
                        <span className="text-[10px] text-dark-muted font-mono mt-0.5 block">{p.sku}</span>
                      </td>
                      <td className="py-3 text-right font-semibold text-dark-muted">{p.quantity}</td>
                      <td className="py-3 text-right font-mono font-bold text-gold">
                        {currencySymbol}{p.revenue.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-12 text-center text-dark-muted text-xs">
              No sales logged yet. Go to the POS Register to sell items!
            </div>
          )}
        </div>

        {/* Recent sales ledger snapshot */}
        <div className="bg-dark-card border border-dark-border p-5 rounded-2xl shadow-xs space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-bold text-white text-base">Recent Checkouts</h3>
              <p className="text-xs text-dark-muted mt-0.5">Latest transactions processed at registers.</p>
            </div>
            <button 
              onClick={() => onNavigate("ledger")}
              className="text-xs font-semibold text-gold hover:text-gold-hover cursor-pointer"
            >
              View Ledger
            </button>
          </div>

          {filteredTransactions.length > 0 ? (
            <div className="space-y-3">
              {filteredTransactions.slice(-4).reverse().map((tx) => {
                const shop = shops.find(s => s.id === tx.shopId);
                return (
                  <div 
                    key={tx.id} 
                    className="flex items-center justify-between p-3 bg-dark-input rounded-xl hover:bg-dark-card transition-colors border border-dark-border"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-gold/10 text-gold border border-gold/20 rounded-lg shrink-0">
                        <Package className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white block">{tx.invoiceNumber}</span>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[10px] px-1.5 py-0.5 rounded-xs font-medium" style={{ backgroundColor: `${shop?.color}15`, color: shop?.color }}>
                            {shop?.name || "Shop"}
                          </span>
                          <span className="text-[10px] text-dark-muted font-mono">
                            {new Date(tx.date).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-bold text-white block font-mono">
                        {shop?.currency || "$"}{tx.total.toFixed(2)}
                      </span>
                      <span className="text-[10px] text-dark-muted block mt-0.5">
                        {tx.paymentMethod}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-12 text-center text-dark-muted text-xs">
              No transactions found. Begin processing orders to build history!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
