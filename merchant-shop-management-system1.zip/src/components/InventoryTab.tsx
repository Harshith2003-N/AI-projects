import React, { useState, useMemo } from "react";
import { Product, Shop, Supplier, StockLog } from "../types";
import ReactMarkdown from "react-markdown";
import { 
  Package, 
  AlertTriangle, 
  Plus, 
  Minus, 
  Search, 
  Sparkles, 
  Loader2, 
  Activity, 
  Calendar, 
  Info,
  CheckCircle2,
  ListRestart
} from "lucide-react";

interface InventoryTabProps {
  products: Product[];
  shops: Shop[];
  suppliers: Supplier[];
  stockLogs: StockLog[];
  activeShopId: string;
  onUpdateProductStock: (id: string, qty: number, logType: StockLog["type"], note: string) => void;
}

export default function InventoryTab({
  products,
  shops,
  suppliers,
  stockLogs,
  activeShopId,
  onUpdateProductStock
}: InventoryTabProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [stockFilter, setStockFilter] = useState<"all" | "low" | "out">("all");
  
  // Stock adjustment form state
  const [selectedProductId, setSelectedProductId] = useState("");
  const [adjustmentQty, setAdjustmentQty] = useState<number>(0);
  const [adjustmentType, setAdjustmentType] = useState<StockLog["type"]>("Restock");
  const [adjustmentNote, setAdjustmentNote] = useState("");

  // AI procurement advice state
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Filter products by shop and category/stock
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      // Shop filter
      if (activeShopId !== "all" && p.shopId !== activeShopId) return false;

      // Stock filter
      if (stockFilter === "out" && p.stockQuantity > 0) return false;
      if (stockFilter === "low" && p.stockQuantity > p.lowStockThreshold) return false;

      // Search
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return p.name.toLowerCase().includes(query) || p.sku.toLowerCase().includes(query);
      }

      return true;
    });
  }, [products, activeShopId, stockFilter, searchQuery]);

  // Handle direct Quick-Restock buttons
  const handleQuickRestock = (p: Product, amount: number) => {
    onUpdateProductStock(
      p.id,
      amount,
      "Restock",
      `Quick restock +${amount} units from active inventory shelf.`
    );
  };

  // Submit manual adjustments
  const handleManualAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId) return alert("Please select a product first.");
    if (adjustmentQty === 0) return alert("Adjustment quantity cannot be zero.");

    const product = products.find(p => p.id === selectedProductId);
    if (!product) return;

    // Guard negative stock quantities
    if (product.stockQuantity + adjustmentQty < 0) {
      return alert(`Cannot adjust stock down by ${Math.abs(adjustmentQty)}. Shelf only contains ${product.stockQuantity} units.`);
    }

    onUpdateProductStock(
      selectedProductId,
      adjustmentQty,
      adjustmentType,
      adjustmentNote.trim() || `Manual stock adjustment: ${adjustmentType}`
    );

    // Reset Form
    setAdjustmentQty(0);
    setAdjustmentNote("");
  };

  // Trigger Gemini AI restock forecast
  const handleFetchAiProcurement = async () => {
    setIsAiLoading(true);
    setAiReport(null);
    try {
      const activeShop = shops.find(s => s.id === activeShopId);
      const response = await fetch("/api/ai/forecast-inventory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          products: products.filter(p => activeShopId === "all" || p.shopId === activeShopId),
          activeShop: activeShop || { name: "All Stores" }
        })
      });
      const data = await response.json();
      if (data.forecast) {
        setAiReport(data.forecast);
      } else if (data.error) {
        alert("AI Advisor Error: " + data.error);
      }
    } catch (e) {
      console.error(e);
      alert("Failed to analyze procurement. Check network connections.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const activeShop = shops.find(s => s.id === activeShopId);
  const currencySymbol = activeShop?.currency || "$";

  return (
    <div className="space-y-6" id="inventory-tab">
      {/* Header and top metrics */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Inventory Management & Audit</h2>
          <p className="text-xs text-slate-500">Track shelf quantities, log write-offs, and generate AI-driven supplier orders.</p>
        </div>
        
        {/* Trigger AI Procurement Advice button */}
        <button
          onClick={handleFetchAiProcurement}
          disabled={isAiLoading}
          className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-200 disabled:text-slate-400 text-white font-semibold px-4 py-2 rounded-lg text-xs transition-colors shadow-xs"
        >
          {isAiLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              Analyzing Shells...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-amber-400" />
              AI Restock Intelligence
            </>
          )}
        </button>
      </div>

      {/* AI Procurement Advice Card Panel */}
      {aiReport && (
        <div className="bg-indigo-900 text-slate-100 p-6 rounded-2xl border border-indigo-950 shadow-md space-y-4 animate-in slide-in-from-top-4 duration-200">
          <div className="flex justify-between items-center border-b border-indigo-800 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-300" />
              <h3 className="font-extrabold text-sm text-white tracking-wide">AI Procurement Advisory report</h3>
            </div>
            <button 
              onClick={() => setAiReport(null)}
              className="text-indigo-300 hover:text-white text-xs font-semibold"
            >
              Dismiss
            </button>
          </div>
          
          <div className="markdown-body text-xs leading-relaxed space-y-2 text-indigo-100 max-h-72 overflow-y-auto pr-2">
            <ReactMarkdown>{aiReport}</ReactMarkdown>
          </div>
          
          <p className="text-[10px] text-indigo-300 italic">
            Procurement forecast computed using live shelf volumes and cost pricing variables.
          </p>
        </div>
      )}

      {/* Grid: Shelf inventory & manual control card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Product Shelf tracking table */}
        <div className="lg:col-span-8 space-y-4">
          <div className="bg-white border border-slate-100 p-4 rounded-xl shadow-3xs flex flex-col sm:flex-row gap-3 items-center justify-between">
            {/* Search Input */}
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input 
                type="text" 
                placeholder="Search stock sheets by SKU, name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            {/* Quick Filter tabs */}
            <div className="flex gap-1 shrink-0 w-full sm:w-auto">
              {[
                { label: "All Items", val: "all" },
                { label: "Low Stock", val: "low" },
                { label: "Sold Out", val: "out" }
              ].map(tab => (
                <button
                  key={tab.val}
                  onClick={() => setStockFilter(tab.val as typeof stockFilter)}
                  className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap border transition-colors ${
                    stockFilter === tab.val
                      ? "bg-indigo-50 border-indigo-200 text-indigo-700"
                      : "bg-white hover:bg-slate-50 text-slate-500 border-slate-200/50"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Table Container */}
          <div className="bg-white border border-slate-100 rounded-xl overflow-hidden shadow-3xs">
            {filteredProducts.length > 0 ? (
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 font-semibold uppercase tracking-wider">
                    <th className="p-4">SKU & Product Description</th>
                    <th className="p-4 text-center">Shelf Stock</th>
                    <th className="p-4 text-center">Alert Limit</th>
                    <th className="p-4 text-center">Supplier Partner</th>
                    <th className="p-4 text-right">Quick Refills</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredProducts.map(p => {
                    const isOutOfStock = p.stockQuantity <= 0;
                    const isLowStock = p.stockQuantity <= p.lowStockThreshold;
                    const sup = suppliers.find(s => s.id === p.supplierId);

                    return (
                      <tr key={p.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="p-4">
                          <div>
                            <span className="font-bold text-slate-800 text-sm block">{p.name}</span>
                            <span className="text-[10px] text-slate-400 font-mono tracking-wide mt-0.5 block">{p.sku}</span>
                          </div>
                        </td>

                        <td className="p-4 text-center">
                          <span className={`inline-flex font-extrabold font-mono px-2 py-0.5 rounded text-xs ${
                            isOutOfStock 
                              ? "bg-red-50 text-red-700" 
                              : isLowStock 
                                ? "bg-amber-50 text-amber-700" 
                                : "bg-emerald-50 text-emerald-700"
                          }`}>
                            {p.stockQuantity} units
                          </span>
                        </td>

                        <td className="p-4 text-center font-mono font-medium text-slate-500">
                          {p.lowStockThreshold} units
                        </td>

                        <td className="p-4 text-center">
                          <span className="text-[11px] font-semibold text-slate-600 block">
                            {sup?.name || "Global Partner"}
                          </span>
                          <span className="text-[10px] text-slate-400 block mt-0.5">
                            {sup?.contactPerson || "In-house procurement"}
                          </span>
                        </td>

                        {/* Quick Refills */}
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => handleQuickRestock(p, 5)}
                              className="px-2 py-1 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded text-[10px] font-bold tracking-wide cursor-pointer transition-all active:scale-95"
                              title="Add 5 units"
                            >
                              +5
                            </button>
                            <button
                              onClick={() => handleQuickRestock(p, 25)}
                              className="px-2 py-1 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded text-[10px] font-bold tracking-wide cursor-pointer transition-all active:scale-95"
                              title="Add 25 units"
                            >
                              +25
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            ) : (
              <div className="py-16 text-center text-slate-400">
                No items matching filters are currently listed.
              </div>
            )}
          </div>
        </div>

        {/* Right: Stock adjustment form panel */}
        <div className="lg:col-span-4 space-y-6">
          {/* Manual Adjustment Card */}
          <div className="bg-white border border-slate-100 p-5 rounded-xl shadow-xs space-y-4">
            <div>
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-indigo-600" />
                Audit / Log Adjustment
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">Increment or write-off stock quantities manually.</p>
            </div>

            <form onSubmit={handleManualAdjustment} className="space-y-3.5">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Select Product *
                </label>
                <select
                  value={selectedProductId}
                  onChange={(e) => setSelectedProductId(e.target.value)}
                  required
                  className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                >
                  <option value="">-- Choose shelf item --</option>
                  {products
                    .filter(p => activeShopId === "all" || p.shopId === activeShopId)
                    .map(p => (
                      <option key={p.id} value={p.id}>{p.name} ({p.sku})</option>
                    ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                    Difference Qty *
                  </label>
                  <input
                    type="number"
                    value={adjustmentQty}
                    onChange={(e) => setAdjustmentQty(Number(e.target.value))}
                    required
                    placeholder="e.g. -5, 10"
                    className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-mono focus:outline-hidden focus:border-indigo-500"
                  />
                  <span className="text-[9px] text-slate-400 block mt-1">Use negative for loss/waste.</span>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                    Adjustment Type
                  </label>
                  <select
                    value={adjustmentType}
                    onChange={(e) => setAdjustmentType(e.target.value as StockLog["type"])}
                    className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
                  >
                    <option value="Restock">Restock</option>
                    <option value="Adjustment">Adjustment</option>
                    <option value="Wastage">Wastage / Scrap</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                  Reasoning Note *
                </label>
                <input
                  type="text"
                  value={adjustmentNote}
                  onChange={(e) => setAdjustmentNote(e.target.value)}
                  placeholder="e.g. Expired product lot / stock audit"
                  required
                  className="w-full border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2 px-3 rounded-lg text-xs transition-colors cursor-pointer text-center"
              >
                Log Adjustment Entry
              </button>
            </form>
          </div>

          {/* Stock Log History panel */}
          <div className="bg-white border border-slate-100 p-5 rounded-xl shadow-xs space-y-4">
            <div>
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                <ListRestart className="w-4 h-4 text-indigo-600" />
                Historic Log Ledger
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">Most recent inventory log sheets filed.</p>
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
              {stockLogs.slice().reverse().map((log) => {
                const isLoss = log.quantity < 0;
                return (
                  <div key={log.id} className="p-2.5 bg-slate-50 rounded-lg border border-slate-100/50 text-left text-[11px]">
                    <div className="flex justify-between items-start">
                      <span className="font-bold text-slate-800 line-clamp-1 max-w-[150px]">
                        {log.productName}
                      </span>
                      <span className={`font-mono font-bold shrink-0 ml-1 ${isLoss ? "text-red-600" : "text-emerald-600"}`}>
                        {log.quantity > 0 ? `+${log.quantity}` : log.quantity}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 mt-1.5 text-[9px] text-slate-400">
                      <span className="bg-slate-200 text-slate-700 px-1 py-0.5 rounded font-bold uppercase tracking-wider">
                        {log.type}
                      </span>
                      <span className="flex items-center gap-1 font-mono">
                        <Calendar className="w-3 h-3 shrink-0" />
                        {new Date(log.date).toLocaleDateString()}
                      </span>
                    </div>

                    <p className="text-slate-500 mt-1 italic leading-tight text-[10px]">
                      "{log.note}"
                    </p>
                  </div>
                );
              })}

              {stockLogs.length === 0 && (
                <div className="text-center text-slate-400 py-10">
                  No adjustments filed yet.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
