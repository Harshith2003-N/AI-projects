import React, { useState, useMemo } from "react";
import { Transaction, Shop, Product } from "../types";
import ReactMarkdown from "react-markdown";
import { 
  FileText, 
  Search, 
  TrendingUp, 
  Percent, 
  DollarSign, 
  Sparkles, 
  Loader2, 
  CheckCircle2, 
  Calendar, 
  ShoppingCart,
  Printer
} from "lucide-react";

interface LedgerTabProps {
  transactions: Transaction[];
  shops: Shop[];
  products: Product[];
  activeShopId: string;
}

export default function LedgerTab({
  transactions,
  shops,
  products,
  activeShopId
}: LedgerTabProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPayment, setSelectedPayment] = useState("all");
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);

  // AI sales advisor state
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Filter transactions based on shop context and inputs
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      // Shop context filter
      if (activeShopId !== "all" && t.shopId !== activeShopId) return false;

      // Payment method filter
      if (selectedPayment !== "all" && t.paymentMethod !== selectedPayment) return false;

      // Invoice / Customer search
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return (
          t.invoiceNumber.toLowerCase().includes(query) ||
          (t.customerName && t.customerName.toLowerCase().includes(query))
        );
      }

      return true;
    });
  }, [transactions, activeShopId, selectedPayment, searchQuery]);

  // Aggregate stats on filtered subset
  const aggregates = useMemo(() => {
    let revenue = 0;
    let profit = 0;
    let count = filteredTransactions.length;

    filteredTransactions.forEach(t => {
      revenue += t.total;
      profit += t.profit;
    });

    return {
      revenue,
      profit,
      count
    };
  }, [filteredTransactions]);

  // Fetch AI Strategic Advice
  const handleFetchAiAudit = async () => {
    setIsAiLoading(true);
    setAiAnalysis(null);
    try {
      const activeShop = shops.find(s => s.id === activeShopId);
      const response = await fetch("/api/ai/analyze-sales", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sales: filteredTransactions,
          products: products.filter(p => activeShopId === "all" || p.shopId === activeShopId),
          activeShop: activeShop || { name: "All Stores" }
        })
      });
      const data = await response.json();
      if (data.analysis) {
        setAiAnalysis(data.analysis);
      } else if (data.error) {
        alert("AI Analyst Error: " + data.error);
      }
    } catch (e) {
      console.error(e);
      alert("Failed to analyze sales ledger. Check server configuration.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const activeShop = shops.find(s => s.id === activeShopId);
  const currencySymbol = activeShop?.currency || "$";

  return (
    <div className="space-y-6" id="ledger-tab">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Historic Sales Ledger</h2>
          <p className="text-xs text-slate-500">Audit daily checkouts, track margins, and run AI financial strategy audits on-the-fly.</p>
        </div>

        {/* AI Financial Strategy button */}
        <button
          onClick={handleFetchAiAudit}
          disabled={isAiLoading}
          className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-200 disabled:text-slate-400 text-white font-semibold px-4 py-2 rounded-lg text-xs transition-colors shadow-xs"
        >
          {isAiLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              Auditing Accounts...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-amber-400" />
              Run AI Store Audit
            </>
          )}
        </button>
      </div>

      {/* AI Sales Audit Card Panel */}
      {aiAnalysis && (
        <div className="bg-slate-900 text-slate-100 p-6 rounded-2xl border border-slate-950 shadow-md space-y-4 animate-in slide-in-from-top-4 duration-200">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-300" />
              <h3 className="font-extrabold text-sm text-white tracking-wide">AI Store Performance report</h3>
            </div>
            <button 
              onClick={() => setAiAnalysis(null)}
              className="text-slate-400 hover:text-white text-xs font-semibold"
            >
              Dismiss
            </button>
          </div>
          
          <div className="markdown-body text-xs leading-relaxed space-y-2 text-slate-200 max-h-72 overflow-y-auto pr-2">
            <ReactMarkdown>{aiAnalysis}</ReactMarkdown>
          </div>
          
          <p className="text-[10px] text-slate-400 italic">
            Computed by Gemini AI using historic transaction logs. recommendations represent pricing insights.
          </p>
        </div>
      )}

      {/* Grid: Stats aggregates */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-100 p-4 rounded-xl shadow-3xs">
          <span className="text-[10px] font-semibold text-slate-400 uppercase">Selected Transactions</span>
          <h3 className="text-xl font-bold text-slate-700 font-mono mt-0.5">{aggregates.count} tickets</h3>
        </div>
        <div className="bg-white border border-slate-100 p-4 rounded-xl shadow-3xs">
          <span className="text-[10px] font-semibold text-slate-400 uppercase">Selected Sales Total</span>
          <h3 className="text-xl font-bold text-slate-800 font-mono mt-0.5">{currencySymbol}{aggregates.revenue.toFixed(2)}</h3>
        </div>
        <div className="bg-white border border-slate-100 p-4 rounded-xl shadow-3xs">
          <span className="text-[10px] font-semibold text-slate-400 uppercase">Selected net profit</span>
          <h3 className="text-xl font-bold text-emerald-600 font-mono mt-0.5">{currencySymbol}{aggregates.profit.toFixed(2)}</h3>
        </div>
      </div>

      {/* Filter and Table section */}
      <div className="space-y-4">
        {/* Filter bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white p-4 rounded-xl border border-slate-100 shadow-2xs">
          <div className="relative col-span-1 sm:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input 
              type="text" 
              placeholder="Search invoices by ticket code or customer name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-xs focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          <div>
            <select
              value={selectedPayment}
              onChange={(e) => setSelectedPayment(e.target.value)}
              className="w-full border border-slate-200 rounded-lg px-3 py-2 text-xs focus:outline-hidden focus:border-indigo-500 bg-white"
            >
              <option value="all">All Payment Methods</option>
              <option value="Cash">Cash Only</option>
              <option value="Card">Card Only</option>
              <option value="Mobile Pay">Mobile Pay Only</option>
            </select>
          </div>
        </div>

        {/* Ledger Invoices Table */}
        <div className="bg-white border border-slate-100 rounded-xl shadow-3xs overflow-hidden">
          {filteredTransactions.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 font-semibold uppercase tracking-wider">
                    <th className="p-4">Invoice No</th>
                    <th className="p-4">Timestamp</th>
                    <th className="p-4">Client</th>
                    <th className="p-4">Items count</th>
                    <th className="p-4 text-center">Receipt store</th>
                    <th className="p-4 text-right">Tax Paid</th>
                    <th className="p-4 text-right">Sales Net</th>
                    <th className="p-4 text-right">Gross Profit</th>
                    <th className="p-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredTransactions.slice().reverse().map((tx) => {
                    const shop = shops.find(s => s.id === tx.shopId);
                    const itemsSum = tx.items.reduce((sum, item) => sum + item.quantity, 0);

                    return (
                      <tr key={tx.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="p-4 font-bold text-slate-800 font-mono text-sm">
                          {tx.invoiceNumber}
                        </td>

                        <td className="p-4 whitespace-nowrap text-slate-400 font-mono">
                          {new Date(tx.date).toLocaleDateString()} {new Date(tx.date).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })}
                        </td>

                        <td className="p-4 text-slate-600 font-semibold whitespace-nowrap">
                          {tx.customerName || "Walk-in Buyer"}
                        </td>

                        <td className="p-4 text-center font-mono font-bold text-slate-600">
                          {itemsSum} items
                        </td>

                        <td className="p-4 text-center">
                          <span 
                            className="inline-flex text-[9px] font-bold px-2 py-0.5 rounded-full"
                            style={{ backgroundColor: `${shop?.color}15`, color: shop?.color }}
                          >
                            {shop?.name || "Shop location"}
                          </span>
                        </td>

                        <td className="p-4 text-right font-mono text-slate-400">
                          {shop?.currency || "$"}{tx.tax.toFixed(2)}
                        </td>

                        <td className="p-4 text-right font-mono font-bold text-slate-800 text-sm">
                          {shop?.currency || "$"}{tx.total.toFixed(2)}
                        </td>

                        <td className="p-4 text-right font-mono font-bold text-emerald-600">
                          {shop?.currency || "$"}{tx.profit.toFixed(2)}
                        </td>

                        <td className="p-4 text-right whitespace-nowrap">
                          <button
                            onClick={() => setSelectedTx(tx)}
                            className="inline-flex items-center gap-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-2.5 py-1.5 rounded-lg text-[10px] transition-colors"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            Ticket details
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-20 text-center text-slate-400">
              <FileText className="w-12 h-12 stroke-1 mx-auto text-slate-300 mb-3" />
              <h3 className="font-bold text-slate-600 text-sm">No Invoice Records Filed</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                No historic sales match your current search queries. Checkout items in the POS terminal.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Invoice Detail Modal Sheet */}
      {selectedTx && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-sm border border-slate-100 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="flex justify-between items-center px-6 py-4 border-b border-slate-100">
              <h3 className="font-bold text-slate-800 text-base">Sales Ticket Audit</h3>
              <button 
                onClick={() => setSelectedTx(null)}
                className="p-1 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Receipt layout */}
            <div className="p-6 space-y-4 max-h-[400px] overflow-y-auto">
              {/* Header */}
              <div className="text-center space-y-1">
                <h4 className="font-bold text-slate-800 text-sm">
                  {shops.find(s => s.id === selectedTx.shopId)?.name}
                </h4>
                <p className="text-[10px] text-slate-400 font-medium">
                  {shops.find(s => s.id === selectedTx.shopId)?.location}
                </p>
              </div>

              {/* Meta details */}
              <div className="border-t border-b border-dashed border-slate-200 py-3 text-[10px] font-mono text-slate-500 space-y-1">
                <div className="flex justify-between">
                  <span>INVOICE ID:</span>
                  <span className="font-bold text-slate-800">{selectedTx.invoiceNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span>DATE RECORDED:</span>
                  <span>{new Date(selectedTx.date).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>PAYMENT TYPE:</span>
                  <span>{selectedTx.paymentMethod}</span>
                </div>
                {selectedTx.customerName && (
                  <div className="flex justify-between">
                    <span>CUSTOMER:</span>
                    <span>{selectedTx.customerName}</span>
                  </div>
                )}
              </div>

              {/* Items details table */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Receipt Items</span>
                <div className="space-y-1.5 text-xs text-slate-600">
                  {selectedTx.items.map((item, index) => (
                    <div key={index} className="flex justify-between items-start">
                      <div>
                        <span className="font-semibold text-slate-800 block">{item.productName}</span>
                        <span className="text-[10px] text-slate-400 block font-mono mt-0.5">
                          {item.quantity} x {currencySymbol}{item.price.toFixed(2)}
                        </span>
                      </div>
                      <span className="font-mono text-slate-700 font-semibold">
                        {currencySymbol}{item.subtotal.toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Totals table */}
              <div className="border-t border-dashed border-slate-200 pt-3 text-xs space-y-1.5 font-semibold text-slate-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-mono">{currencySymbol}{selectedTx.subtotal.toFixed(2)}</span>
                </div>
                {selectedTx.discount > 0 && (
                  <div className="flex justify-between text-emerald-600">
                    <span>Discount applied ({selectedTx.discount}%)</span>
                    <span className="font-mono">-{currencySymbol}{(selectedTx.subtotal * (selectedTx.discount / 100)).toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-400">
                  <span>VAT / Sales Tax</span>
                  <span className="font-mono">+{currencySymbol}{selectedTx.tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-800 text-sm font-extrabold border-t border-slate-100 pt-2">
                  <span>Invoice Total</span>
                  <span className="font-mono text-slate-900">{currencySymbol}{selectedTx.total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-emerald-700 text-xs font-semibold">
                  <span>Net profit generated</span>
                  <span className="font-mono">+{currencySymbol}{selectedTx.profit.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Receipt Actions */}
            <div className="bg-slate-50 p-4 border-t border-slate-100 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="flex-1 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-bold py-2 rounded-xl text-xs transition-colors text-center cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                Print Invoice
              </button>
              <button
                type="button"
                onClick={() => setSelectedTx(null)}
                className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold py-2 rounded-xl text-xs transition-colors text-center cursor-pointer"
              >
                Close Audit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Simple X icon replacement since we use custom X
const X = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
);
