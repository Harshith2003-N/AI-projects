import React, { useState, useMemo } from "react";
import { Product, Shop, Transaction, TransactionItem } from "../types";
import { Search, ShoppingCart, Trash2, Plus, Minus, CreditCard, DollarSign, Smartphone, Tag, User, Receipt, X, CheckCircle2 } from "lucide-react";

interface POSTabProps {
  products: Product[];
  shops: Shop[];
  activeShopId: string;
  onProcessTransaction: (transaction: Omit<Transaction, "id" | "invoiceNumber" | "date">) => void;
  lastProcessedTransaction: Transaction | null;
  clearLastProcessed: () => void;
}

export default function POSTab({
  products,
  shops,
  activeShopId,
  onProcessTransaction,
  lastProcessedTransaction,
  clearLastProcessed
}: POSTabProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  
  // Checkout details
  const [discount, setDiscount] = useState<number>(0); // discount percent
  const [paymentMethod, setPaymentMethod] = useState<Transaction["paymentMethod"]>("Cash");
  const [customerName, setCustomerName] = useState("");

  // Select active shop for POS. POS cannot operate on "all" shops synchronously!
  const [posShopId, setPosShopId] = useState(() => {
    return activeShopId === "all" ? (shops[0]?.id || "") : activeShopId;
  });

  // Keep POS shop updated if the global context changes (unless it is "all")
  React.useEffect(() => {
    if (activeShopId !== "all") {
      setPosShopId(activeShopId);
      setCart([]); // Clear cart when switching shop
    }
  }, [activeShopId]);

  const activeShop = useMemo(() => {
    return shops.find(s => s.id === posShopId);
  }, [shops, posShopId]);

  // Available products for the selected POS store
  const availableProducts = useMemo(() => {
    return products.filter(p => p.shopId === posShopId && p.status === "Active");
  }, [products, posShopId]);

  // Categories for the active POS store
  const categories = useMemo(() => {
    const set = new Set(availableProducts.map(p => p.category));
    return Array.from(set);
  }, [availableProducts]);

  // Filter products by search and category
  const filteredProducts = useMemo(() => {
    return availableProducts.filter(p => {
      if (selectedCategory !== "all" && p.category !== selectedCategory) return false;
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return p.name.toLowerCase().includes(query) || p.sku.toLowerCase().includes(query);
      }
      return true;
    });
  }, [availableProducts, selectedCategory, searchQuery]);

  // Cart operations
  const addToCart = (product: Product) => {
    if (product.stockQuantity <= 0) return; // cannot add out of stock
    
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        // limit by physical stock quantity
        if (existing.quantity >= product.stockQuantity) {
          alert(`Cannot add more. Only ${product.stockQuantity} units available in stock.`);
          return prev;
        }
        return prev.map(item => 
          item.product.id === product.id 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          const target = item.quantity + delta;
          if (target <= 0) return null;
          if (target > item.product.stockQuantity) {
            alert(`Only ${item.product.stockQuantity} units of this item exist in stock.`);
            return item;
          }
          return { ...item, quantity: target };
        }
        return item;
      }).filter(Boolean) as typeof prev;
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  // Pricing calculations
  const cartTotals = useMemo(() => {
    let subtotal = 0;
    let costTotal = 0;

    cart.forEach(item => {
      subtotal += item.product.sellingPrice * item.quantity;
      costTotal += item.product.costPrice * item.quantity;
    });

    const discountAmount = subtotal * (discount / 100);
    const discountedSubtotal = subtotal - discountAmount;
    
    const taxRate = activeShop?.taxRate || 0;
    const taxAmount = discountedSubtotal * (taxRate / 100);
    
    const total = discountedSubtotal + taxAmount;
    const profit = total - costTotal;

    return {
      subtotal,
      discountAmount,
      taxAmount,
      total,
      profit
    };
  }, [cart, discount, activeShop]);

  // Checkout process
  const handleCheckout = () => {
    if (cart.length === 0) return;
    
    const items: TransactionItem[] = cart.map(item => ({
      productId: item.product.id,
      productName: item.product.name,
      sku: item.product.sku,
      price: item.product.sellingPrice,
      cost: item.product.costPrice,
      quantity: item.quantity,
      subtotal: item.product.sellingPrice * item.quantity
    }));

    onProcessTransaction({
      shopId: posShopId,
      items,
      subtotal: cartTotals.subtotal,
      discount,
      tax: cartTotals.taxAmount,
      total: cartTotals.total,
      profit: cartTotals.profit,
      paymentMethod,
      customerName: customerName.trim() || undefined
    });

    // Clear cart and checkout input fields
    setCart([]);
    setDiscount(0);
    setCustomerName("");
  };

  const currencySymbol = activeShop?.currency || "$";

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="pos-tab">
      {/* Products Shelves (Left Column) */}
      <div className="lg:col-span-7 xl:col-span-8 space-y-4">
        {/* Top store selector & search filters */}
        <div className="bg-dark-card border border-dark-border p-4 rounded-xl shadow-xs space-y-3.5">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Receipt className="w-5 h-5 text-gold animate-pulse" />
                Active Terminal: <span className="text-gold font-bold">{activeShop?.name}</span>
              </h2>
            </div>

            {/* Shop context selector only if global is set to "all" */}
            {activeShopId === "all" && (
              <div className="flex items-center gap-1.5 w-full sm:w-auto shrink-0">
                <span className="text-[10px] font-semibold text-dark-muted uppercase">POS Store:</span>
                <select 
                  value={posShopId}
                  onChange={(e) => {
                    setPosShopId(e.target.value);
                    setCart([]); // Clear cart since product SKUs belong to specific store catalog
                  }}
                  className="bg-dark-input border border-dark-border text-white rounded-lg px-2.5 py-1 text-xs focus:outline-hidden focus:border-gold cursor-pointer"
                >
                  {shops.map(s => (
                    <option key={s.id} value={s.id} className="bg-dark-card">{s.name}</option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-dark-muted absolute left-3 top-2.5" />
              <input 
                type="text" 
                placeholder="Lookup item name or scan product barcode SKU..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-dark-input border border-dark-border rounded-lg text-xs text-white placeholder-dark-muted focus:outline-hidden focus:border-gold"
              />
            </div>

            {/* Category selection bar */}
            <div className="flex gap-1 overflow-x-auto pb-1 max-w-full sm:max-w-xs shrink-0 scrollbar-none">
              <button
                onClick={() => setSelectedCategory("all")}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors border cursor-pointer ${
                  selectedCategory === "all"
                    ? "bg-gold border-gold text-dark-bg font-bold"
                    : "bg-dark-input hover:bg-dark-input/80 text-dark-muted border-dark-border"
                }`}
              >
                All
              </button>
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors border cursor-pointer ${
                    selectedCategory === cat
                      ? "bg-gold border-gold text-dark-bg font-bold"
                      : "bg-dark-input hover:bg-dark-input/80 text-dark-muted border-dark-border"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Shelf items grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredProducts.map((p) => {
            const isOutOfStock = p.stockQuantity <= 0;
            const isLowStock = p.stockQuantity <= p.lowStockThreshold;

            return (
              <button
                key={p.id}
                onClick={() => addToCart(p)}
                disabled={isOutOfStock}
                className={`bg-dark-card border text-left p-4 rounded-xl shadow-xs flex flex-col justify-between h-40 transition-all cursor-pointer relative overflow-hidden active:scale-97 select-none ${
                  isOutOfStock 
                    ? "opacity-40 border-dark-border cursor-not-allowed bg-dark-input/50" 
                    : "hover:shadow-md hover:border-gold border-dark-border"
                }`}
              >
                {/* Out of stock tag overlay */}
                {isOutOfStock && (
                  <div className="absolute top-2 right-2 bg-red-600/90 text-white font-extrabold text-[8px] uppercase px-1.5 py-0.5 rounded">
                    Sold Out
                  </div>
                )}
                {!isOutOfStock && isLowStock && (
                  <div className="absolute top-2 right-2 bg-amber-500/95 text-dark-bg font-extrabold text-[8px] uppercase px-1.5 py-0.5 rounded">
                    Low Stock: {p.stockQuantity}
                  </div>
                )}

                <div className="space-y-1 w-full">
                  <span className="text-[9px] text-gold font-mono block uppercase tracking-wider">{p.category}</span>
                  <h3 className="font-bold text-white text-xs line-clamp-2 pr-4">{p.name}</h3>
                </div>

                <div className="flex justify-between items-baseline mt-4 w-full border-t border-dark-border/40 pt-3">
                  <span className="text-[10px] text-dark-muted font-mono shrink-0">SKU: {p.sku.slice(-4)}</span>
                  <span className="font-extrabold text-sm text-gold font-mono">
                    {currencySymbol}{p.sellingPrice.toFixed(2)}
                  </span>
                </div>
              </button>
            );
          })}

          {filteredProducts.length === 0 && (
            <div className="col-span-full py-16 bg-dark-card border border-dark-border rounded-xl text-center text-dark-muted text-xs">
              No product items configured or active for this store category.
            </div>
          )}
        </div>
      </div>

      {/* Shopping Cart Drawer (Right Column) */}
      <div className="lg:col-span-5 xl:col-span-4 flex flex-col h-[calc(100vh-140px)] min-h-[480px] bg-dark-card border border-dark-border rounded-xl shadow-xs overflow-hidden text-white">
        {/* Drawer Header */}
        <div className="bg-dark-input border-b border-dark-border p-4 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-gold" />
            <h3 className="font-bold text-sm">Register Ticket</h3>
          </div>
          <span className="text-xs font-semibold bg-dark-card text-gold border border-gold/20 px-2.5 py-1 rounded-full font-mono">
            {cart.reduce((acc, item) => acc + item.quantity, 0)} items
          </span>
        </div>

        {/* Cart Itemized List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.map((item) => (
            <div 
              key={item.product.id}
              className="flex items-center justify-between p-2.5 rounded-lg border border-dark-border/40 hover:bg-dark-input/50 transition-colors"
            >
              <div className="space-y-0.5 max-w-[150px] sm:max-w-[200px]">
                <h4 className="font-bold text-white text-xs truncate">{item.product.name}</h4>
                <span className="text-[10px] text-dark-muted font-mono block">
                  {currencySymbol}{item.product.sellingPrice.toFixed(2)} each
                </span>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                {/* Qty controls */}
                <div className="flex items-center gap-1.5 border border-dark-border rounded-lg p-0.5 bg-dark-input">
                  <button 
                    onClick={() => updateQuantity(item.product.id, -1)}
                    className="p-1 hover:bg-dark-card rounded text-dark-muted hover:text-white transition-colors cursor-pointer"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="text-xs font-extrabold font-mono text-white px-1 w-5 text-center">
                    {item.quantity}
                  </span>
                  <button 
                    onClick={() => updateQuantity(item.product.id, 1)}
                    className="p-1 hover:bg-dark-card rounded text-dark-muted hover:text-white transition-colors cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>

                <button 
                  onClick={() => removeFromCart(item.product.id)}
                  className="p-1.5 hover:bg-red-950/30 text-dark-muted hover:text-red-400 rounded-md transition-colors cursor-pointer"
                  title="Remove Item"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}

          {cart.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-dark-muted text-center py-20 px-6">
              <ShoppingCart className="w-12 h-12 stroke-1 text-dark-dim mb-3 animate-pulse" />
              <h4 className="font-semibold text-white text-sm">Register Ticket Empty</h4>
              <p className="text-[10px] text-dark-muted mt-1 max-w-[200px]">
                Click on the store items listed on the left to ring them up at the counter.
              </p>
            </div>
          )}
        </div>

        {/* Checkout Inputs & Config (Fixed bottom panel) */}
        <div className="border-t border-dark-border bg-dark-input p-4 space-y-3 shrink-0">
          {/* Customer & Discount Fields */}
          <div className="grid grid-cols-2 gap-2">
            {/* Customer input */}
            <div className="relative">
              <User className="w-3.5 h-3.5 text-dark-muted absolute left-2.5 top-2.5" />
              <input 
                type="text" 
                placeholder="Walk-in Customer"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full pl-8 pr-2.5 py-1.5 bg-dark-card border border-dark-border rounded-lg text-xs text-white focus:outline-hidden focus:border-gold"
              />
            </div>

            {/* Discount field */}
            <div className="relative">
              <Tag className="w-3.5 h-3.5 text-dark-muted absolute left-2.5 top-2.5" />
              <select
                value={discount}
                onChange={(e) => setDiscount(Number(e.target.value))}
                className="w-full pl-8 pr-2 py-1.5 bg-dark-card border border-dark-border rounded-lg text-xs text-white focus:outline-hidden focus:border-gold cursor-pointer"
              >
                <option value={0} className="bg-dark-card">No Discount (0%)</option>
                <option value={5} className="bg-dark-card">Discount - 5%</option>
                <option value={10} className="bg-dark-card">Discount - 10%</option>
                <option value={15} className="bg-dark-card">Discount - 15%</option>
                <option value={20} className="bg-dark-card">Discount - 20%</option>
                <option value={50} className="bg-dark-card">Discount - 50% (Staff)</option>
              </select>
            </div>
          </div>

          {/* Payment selector */}
          <div className="space-y-1">
            <span className="text-[10px] font-semibold text-dark-muted uppercase tracking-wider block">Payment Method</span>
            <div className="grid grid-cols-3 gap-1">
              {[
                { name: "Cash", icon: DollarSign },
                { name: "Card", icon: CreditCard },
                { name: "Mobile Pay", icon: Smartphone }
              ].map((p) => {
                const Icon = p.icon;
                const isSelected = paymentMethod === p.name;
                return (
                  <button
                    key={p.name}
                    type="button"
                    onClick={() => setPaymentMethod(p.name as typeof paymentMethod)}
                    className={`flex flex-col items-center gap-1 p-2 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                      isSelected 
                        ? "bg-gold border-gold text-dark-bg font-extrabold shadow-sm" 
                        : "bg-dark-card border-dark-border text-dark-muted hover:bg-dark-input hover:text-white"
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    {p.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Invoice pricing breakdown */}
          <div className="space-y-1.5 text-xs text-dark-muted border-t border-b border-dark-border/40 py-3 font-medium">
            <div className="flex justify-between items-center text-dark-muted">
              <span>Cart Subtotal</span>
              <span className="font-mono text-white">{currencySymbol}{cartTotals.subtotal.toFixed(2)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between items-center text-emerald-400">
                <span>Markdown Savings ({discount}%)</span>
                <span className="font-mono">-{currencySymbol}{cartTotals.discountAmount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between items-center text-dark-dim">
              <span>Sales VAT ({activeShop?.taxRate || 0}%)</span>
              <span className="font-mono text-white">+{currencySymbol}{cartTotals.taxAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center text-white text-sm font-extrabold border-t border-dark-border/40 pt-2">
              <span>Grand Total</span>
              <span className="font-mono text-gold text-base">{currencySymbol}{cartTotals.total.toFixed(2)}</span>
            </div>
          </div>

          {/* Action trigger checkout */}
          <button
            type="button"
            onClick={handleCheckout}
            disabled={cart.length === 0}
            className="w-full bg-gold hover:bg-gold-hover disabled:bg-dark-input disabled:text-dark-dim text-dark-bg font-extrabold py-3 px-4 rounded-xl text-sm transition-colors text-center shadow-md cursor-pointer"
          >
            Finalize Payment checkout
          </button>
        </div>
      </div>

      {/* Successful Receipt Dialog Popup */}
      {lastProcessedTransaction && (
        <div className="fixed inset-0 bg-[#000000]/75 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-dark-card rounded-2xl w-full max-w-sm border border-dark-border shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 text-white">
            {/* Top confirmation banner */}
            <div className="bg-emerald-950/60 border-b border-dark-border text-center p-6">
              <CheckCircle2 className="w-12 h-12 mx-auto mb-2 text-emerald-400" />
              <h3 className="font-extrabold text-emerald-400 text-base">Checkout Successful</h3>
              <p className="text-[11px] text-dark-muted mt-0.5">Inventory levels modified successfully.</p>
            </div>

            {/* Receipt layout */}
            <div className="p-6 space-y-4 max-h-[350px] overflow-y-auto">
              {/* Header */}
              <div className="text-center space-y-1">
                <h4 className="font-bold text-white text-sm">{activeShop?.name}</h4>
                <p className="text-[10px] text-dark-muted font-medium">{activeShop?.location}</p>
                <p className="text-[10px] text-dark-muted font-mono">TEL: {activeShop?.phone}</p>
              </div>

              {/* Meta details */}
              <div className="border-t border-b border-dashed border-dark-border/60 py-3 text-[10px] font-mono text-dark-muted space-y-1">
                <div className="flex justify-between">
                  <span>INVOICE NO:</span>
                  <span className="font-bold text-white">{lastProcessedTransaction.invoiceNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span>DATE/TIME:</span>
                  <span>{new Date(lastProcessedTransaction.date).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>PAYMENT TYPE:</span>
                  <span>{lastProcessedTransaction.paymentMethod}</span>
                </div>
                {lastProcessedTransaction.customerName && (
                  <div className="flex justify-between">
                    <span>CUSTOMER:</span>
                    <span>{lastProcessedTransaction.customerName}</span>
                  </div>
                )}
              </div>

              {/* Items details table */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-gold uppercase tracking-wider block">Itemized Receipt</span>
                <div className="space-y-1.5 text-xs text-dark-muted">
                  {lastProcessedTransaction.items.map((item, index) => (
                    <div key={index} className="flex justify-between items-start">
                      <div>
                        <span className="font-semibold text-white block">{item.productName}</span>
                        <span className="text-[10px] text-dark-muted block font-mono mt-0.5">
                          {item.quantity} x {currencySymbol}{item.price.toFixed(2)}
                        </span>
                      </div>
                      <span className="font-mono text-white font-semibold">
                        {currencySymbol}{item.subtotal.toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Totals table */}
              <div className="border-t border-dashed border-dark-border/60 pt-3 text-xs space-y-1.5 font-semibold text-dark-muted">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-mono text-white">{currencySymbol}{lastProcessedTransaction.subtotal.toFixed(2)}</span>
                </div>
                {lastProcessedTransaction.discount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount Savings ({lastProcessedTransaction.discount}%)</span>
                    <span className="font-mono">-{currencySymbol}{(lastProcessedTransaction.subtotal * (lastProcessedTransaction.discount / 100)).toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-dark-dim">
                  <span>Sales VAT</span>
                  <span className="font-mono text-white">+{currencySymbol}{lastProcessedTransaction.tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-white text-sm font-extrabold border-t border-dark-border/60 pt-2">
                  <span>Grand Total</span>
                  <span className="font-mono text-gold text-base">{currencySymbol}{lastProcessedTransaction.total.toFixed(2)}</span>
                </div>
              </div>

              {/* Receipt Footer Msg */}
              <p className="text-[9px] text-dark-muted text-center font-medium italic pt-2">
                Thank you for shopping at {activeShop?.name}! Please retain this invoice for your records.
              </p>
            </div>

            {/* Receipt Actions */}
            <div className="bg-dark-input p-4 border-t border-dark-border flex gap-2">
              <button
                type="button"
                onClick={() => {
                  window.print();
                }}
                className="flex-1 bg-dark-card hover:bg-dark-card/80 border border-dark-border text-dark-muted font-bold py-2 rounded-xl text-xs transition-colors text-center cursor-pointer"
              >
                Print Ticket
              </button>
              <button
                type="button"
                onClick={clearLastProcessed}
                className="flex-1 bg-gold hover:bg-gold-hover text-dark-bg font-extrabold py-2 rounded-xl text-xs transition-colors text-center cursor-pointer"
              >
                Close Ticket
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
