import React, { useState } from "react";
import { Shop } from "../types";
import { Plus, Store, Trash2, Edit2, Check, MapPin, Phone, DollarSign, X } from "lucide-react";

interface ShopsTabProps {
  shops: Shop[];
  onAddShop: (shop: Omit<Shop, "id" | "isActive">) => void;
  onUpdateShop: (shop: Shop) => void;
  onDeleteShop: (id: string) => void;
}

const COLORS = [
  { name: "Emerald Green", hex: "#059669" },
  { name: "Indigo Blue", hex: "#4f46e5" },
  { name: "Amber Orange", hex: "#d97706" },
  { name: "Crimson Red", hex: "#dc2626" },
  { name: "Teal", hex: "#0d9488" },
  { name: "Rose Pink", hex: "#e11d48" },
  { name: "Charcoal Black", hex: "#334155" }
];

export default function ShopsTab({ 
  shops, 
  onAddShop, 
  onUpdateShop, 
  onDeleteShop 
}: ShopsTabProps) {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingShop, setEditingShop] = useState<Shop | null>(null);

  // Form states
  const [name, setName] = useState("");
  const [type, setType] = useState<Shop["type"]>("Grocery");
  const [location, setLocation] = useState("");
  const [phone, setPhone] = useState("");
  const [taxRate, setTaxRate] = useState(8.25);
  const [currency, setCurrency] = useState("$");
  const [color, setColor] = useState("#059669");

  const openAddForm = () => {
    setEditingShop(null);
    setName("");
    setType("Grocery");
    setLocation("");
    setPhone("");
    setTaxRate(8.25);
    setCurrency("$");
    setColor("#059669");
    setIsFormOpen(true);
  };

  const openEditForm = (shop: Shop) => {
    setEditingShop(shop);
    setName(shop.name);
    setType(shop.type);
    setLocation(shop.location);
    setPhone(shop.phone);
    setTaxRate(shop.taxRate);
    setCurrency(shop.currency);
    setColor(shop.color);
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const payload = {
      name: name.trim(),
      type,
      location: location.trim(),
      phone: phone.trim(),
      taxRate: Number(taxRate),
      currency,
      color,
    };

    if (editingShop) {
      onUpdateShop({
        ...editingShop,
        ...payload,
      });
    } else {
      onAddShop(payload);
    }

    setIsFormOpen(false);
  };

  return (
    <div className="space-y-6" id="shops-tab">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Shops & Locations</h2>
          <p className="text-xs text-slate-500">Configure separate retail outlets, tax rules, and local currency rules.</p>
        </div>
        <button 
          onClick={openAddForm}
          className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2 rounded-lg text-xs transition-colors"
          id="btn-add-shop"
        >
          <Plus className="w-4 h-4" />
          Add Store
        </button>
      </div>

      {/* Main Stores Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {shops.map((shop) => (
          <div 
            key={shop.id}
            className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-slate-200/50 transition-all duration-200"
          >
            {/* Header / Brand info */}
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div 
                    className="p-3 rounded-xl text-white shrink-0"
                    style={{ backgroundColor: shop.color }}
                  >
                    <Store className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-base">{shop.name}</h3>
                    <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider">
                      {shop.type} OUTLET
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => openEditForm(shop)}
                    className="p-1.5 hover:bg-slate-50 text-slate-400 hover:text-slate-600 rounded-lg transition-colors"
                    title="Edit Store"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  {shops.length > 1 && (
                    <button 
                      onClick={() => onDeleteShop(shop.id)}
                      className="p-1.5 hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-lg transition-colors"
                      title="Delete Store"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Details List */}
              <div className="space-y-2.5 text-xs text-slate-600 border-t border-b border-slate-50 py-3.5">
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{shop.location || "No address specified"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span>{shop.phone || "No phone contact"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                  <span>Currency: <strong className="font-semibold text-slate-700">{shop.currency}</strong></span>
                </div>
              </div>
            </div>

            {/* Tax Settings Footer */}
            <div className="flex justify-between items-center mt-4 pt-1 text-xs">
              <span className="text-slate-400">VAT / Sales Tax Rate</span>
              <span className="font-semibold text-slate-800 bg-slate-50 border border-slate-100 px-2 py-1 rounded font-mono">
                {shop.taxRate}%
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Create / Edit Shop Sliding Modal or Dialog Overlay */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md border border-slate-100 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="flex justify-between items-center px-6 py-4 border-b border-slate-100">
              <h3 className="font-bold text-slate-800 text-base">
                {editingShop ? "Modify Store Details" : "Configure New Store"}
              </h3>
              <button 
                onClick={() => setIsFormOpen(false)}
                className="p-1 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                  Store Name *
                </label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Cornerstone Groceries"
                  required
                  className="w-full border border-slate-200 rounded-lg px-3.5 py-2 text-sm focus:outline-hidden focus:border-indigo-500 font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                    Store Type
                  </label>
                  <select 
                    value={type}
                    onChange={(e) => setType(e.target.value as Shop["type"])}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-hidden focus:border-indigo-500 bg-white"
                  >
                    <option value="Grocery">Grocery</option>
                    <option value="Apparel">Apparel</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Bookstore">Bookstore</option>
                    <option value="Cafe">Cafe</option>
                    <option value="Pharmacy">Pharmacy</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                    Store Currency
                  </label>
                  <select 
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-hidden focus:border-indigo-500 bg-white"
                  >
                    <option value="$">USD ($)</option>
                    <option value="€">EUR (€)</option>
                    <option value="£">GBP (£)</option>
                    <option value="₹">INR (₹)</option>
                    <option value="¥">JPY/CNY (¥)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                  Sales Tax Rate (%)
                </label>
                <input 
                  type="number" 
                  step="0.001"
                  value={taxRate}
                  onChange={(e) => setTaxRate(Number(e.target.value))}
                  required
                  className="w-full border border-slate-200 rounded-lg px-3.5 py-2 text-sm focus:outline-hidden focus:border-indigo-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                  Address Location
                </label>
                <input 
                  type="text" 
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. 452 Pine Blvd, New York, NY"
                  className="w-full border border-slate-200 rounded-lg px-3.5 py-2 text-sm focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                  Contact Phone
                </label>
                <input 
                  type="text" 
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. 212-555-0199"
                  className="w-full border border-slate-200 rounded-lg px-3.5 py-2 text-sm focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              {/* Color swatch picker */}
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
                  Brand Theme Color
                </label>
                <div className="flex flex-wrap gap-2.5">
                  {COLORS.map((c) => (
                    <button
                      key={c.hex}
                      type="button"
                      onClick={() => setColor(c.hex)}
                      className="w-7 h-7 rounded-full border border-slate-200 flex items-center justify-center transition-transform hover:scale-110 active:scale-95"
                      style={{ backgroundColor: c.hex }}
                      title={c.name}
                    >
                      {color === c.hex && (
                        <Check className="w-3.5 h-3.5 text-white" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="flex-1 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 font-semibold px-4 py-2 rounded-lg text-xs transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2 rounded-lg text-xs transition-colors"
                >
                  {editingShop ? "Apply Changes" : "Create Store"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
