import React, { useState } from "react";
import { Supplier } from "../types";
import { Plus, Users, Mail, Phone, MapPin, Trash2, Edit2, X, FileText } from "lucide-react";

interface SuppliersTabProps {
  suppliers: Supplier[];
  onAddSupplier: (supplier: Omit<Supplier, "id">) => void;
  onUpdateSupplier: (supplier: Supplier) => void;
  onDeleteSupplier: (id: string) => void;
}

export default function SuppliersTab({
  suppliers,
  onAddSupplier,
  onUpdateSupplier,
  onDeleteSupplier
}: SuppliersTabProps) {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);

  // Form states
  const [name, setName] = useState("");
  const [contactPerson, setContactPerson] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  const openAddForm = () => {
    setEditingSupplier(null);
    setName("");
    setContactPerson("");
    setEmail("");
    setPhone("");
    setAddress("");
    setIsFormOpen(true);
  };

  const openEditForm = (sup: Supplier) => {
    setEditingSupplier(sup);
    setName(sup.name);
    setContactPerson(sup.contactPerson);
    setEmail(sup.email);
    setPhone(sup.phone);
    setAddress(sup.address);
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const payload = {
      name: name.trim(),
      contactPerson: contactPerson.trim(),
      email: email.trim(),
      phone: phone.trim(),
      address: address.trim(),
    };

    if (editingSupplier) {
      onUpdateSupplier({
        ...editingSupplier,
        ...payload,
      });
    } else {
      onAddSupplier(payload);
    }

    setIsFormOpen(false);
  };

  return (
    <div className="space-y-6" id="suppliers-tab">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Procurement & Suppliers</h2>
          <p className="text-xs text-slate-500">Configure logistics partners, procurement points, and supplier account directories.</p>
        </div>
        <button 
          onClick={openAddForm}
          className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2 rounded-lg text-xs transition-colors"
          id="btn-add-supplier"
        >
          <Plus className="w-4 h-4" />
          Add Supplier
        </button>
      </div>

      {/* Grid of suppliers cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {suppliers.map((sup) => (
          <div 
            key={sup.id}
            className="bg-white border border-slate-100 rounded-2xl p-5 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-slate-200/50 transition-all duration-200"
          >
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl shrink-0">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-base">{sup.name}</h3>
                    <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block">
                      Rep: {sup.contactPerson || "Primary agent"}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => openEditForm(sup)}
                    className="p-1.5 hover:bg-slate-50 text-slate-400 hover:text-slate-600 rounded-lg transition-colors"
                    title="Edit Supplier"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  {suppliers.length > 1 && (
                    <button 
                      onClick={() => onDeleteSupplier(sup.id)}
                      className="p-1.5 hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-lg transition-colors"
                      title="Delete Supplier"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Details List */}
              <div className="space-y-2.5 text-xs text-slate-600 border-t border-slate-50 py-3.5">
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span>{sup.email || "No email linked"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span>{sup.phone || "No phone linked"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-400" />
                  <span>{sup.address || "No logistics address specified"}</span>
                </div>
              </div>
            </div>

            {/* Quick status line */}
            <div className="flex justify-between items-center mt-4 pt-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
              <span>Fulfillment Status</span>
              <span className="text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-full font-sans">
                Active Supplier
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Dialog Form overlay */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md border border-slate-100 shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="flex justify-between items-center px-6 py-4 border-b border-slate-100">
              <h3 className="font-bold text-slate-800 text-base">
                {editingSupplier ? "Edit Procurement Profile" : "Register New Logistics Partner"}
              </h3>
              <button 
                onClick={() => setIsFormOpen(false)}
                className="p-1 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                  Supplier Brand Name *
                </label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Global Foods Inc."
                  required
                  className="w-full border border-slate-200 rounded-lg px-3.5 py-2 text-sm focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                  Contact Person / Representative
                </label>
                <input 
                  type="text" 
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  placeholder="e.g. Sarah Jenkins"
                  className="w-full border border-slate-200 rounded-lg px-3.5 py-2 text-sm focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                  Email Address
                </label>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. representative@globalfoods.com"
                  className="w-full border border-slate-200 rounded-lg px-3.5 py-2 text-sm focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                  Contact Phone
                </label>
                <input 
                  type="text" 
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. 800-555-1200"
                  className="w-full border border-slate-200 rounded-lg px-3.5 py-2 text-sm focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
                  Headquarters / Logistics Depot Address
                </label>
                <input 
                  type="text" 
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="e.g. 100 Logistics Way, Jersey City, NJ"
                  className="w-full border border-slate-200 rounded-lg px-3.5 py-2 text-sm focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="flex gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="flex-1 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 font-semibold px-4 py-2 rounded-lg text-xs transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2 rounded-lg text-xs transition-colors"
                >
                  {editingSupplier ? "Save Changes" : "Register Partner"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
