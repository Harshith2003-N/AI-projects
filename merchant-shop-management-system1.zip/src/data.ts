import { Shop, Product, Supplier, Transaction, StockLog } from "./types";

export const INITIAL_SHOPS: Shop[] = [
  {
    id: "shop-1",
    name: "Cornerstone Groceries",
    type: "Grocery",
    location: "452 Pine Blvd, New York, NY",
    phone: "212-555-0199",
    taxRate: 8.25,
    currency: "$",
    color: "#059669", // Emerald green
    isActive: true,
  },
  {
    id: "shop-2",
    name: "Metro Apparel",
    type: "Apparel",
    location: "Level 2, Manhattan Mall, NY",
    phone: "212-555-0245",
    taxRate: 8.875,
    currency: "$",
    color: "#4f46e5", // Indigo
    isActive: true,
  },
  {
    id: "shop-3",
    name: "Zen Cafe & Beans",
    type: "Cafe",
    location: "88 Chelsea St, New York, NY",
    phone: "212-555-0378",
    taxRate: 8.0,
    currency: "$",
    color: "#d97706", // Amber
    isActive: true,
  }
];

export const INITIAL_SUPPLIERS: Supplier[] = [
  {
    id: "sup-1",
    name: "Global Foods Inc.",
    contactPerson: "Sarah Jenkins",
    email: "sarah@globalfoods.com",
    phone: "800-555-1200",
    address: "100 Logistics Way, Jersey City, NJ",
  },
  {
    id: "sup-2",
    name: "Aura Textiles Ltd.",
    contactPerson: "Marcus Vance",
    email: "marcus@auratextiles.com",
    phone: "800-555-3490",
    address: "404 Fashion Dist, Los Angeles, CA",
  },
  {
    id: "sup-3",
    name: "Premium Roasters",
    contactPerson: "Elena Rostova",
    email: "elena@premiumroasters.co",
    phone: "800-555-9811",
    address: "15 Espresso Ave, Seattle, WA",
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  // Grocery Shop Products
  {
    id: "prod-1",
    sku: "GRO-MILK-001",
    name: "Organic Whole Milk (1 Gallon)",
    description: "Fresh pasture-raised organic whole milk, high-quality, rich in Vitamin D.",
    category: "Dairy",
    costPrice: 2.8,
    sellingPrice: 4.99,
    stockQuantity: 24,
    lowStockThreshold: 10,
    shopId: "shop-1",
    supplierId: "sup-1",
    status: "Active",
  },
  {
    id: "prod-2",
    sku: "GRO-BREAD-002",
    name: "Artisanal Sourdough Bread",
    description: "Freshly baked daily with natural yeast, crisp crust and fluffy crumb.",
    category: "Bakery",
    costPrice: 1.5,
    sellingPrice: 3.5,
    stockQuantity: 4, // Low stock on purpose
    lowStockThreshold: 8,
    shopId: "shop-1",
    supplierId: "sup-1",
    status: "Active",
  },
  {
    id: "prod-3",
    sku: "GRO-APPLE-003",
    name: "Honeycrisp Apples (1lb)",
    description: "Crispy, sweet, and juicy fresh Honeycrisp apples locally sourced.",
    category: "Produce",
    costPrice: 1.1,
    sellingPrice: 2.49,
    stockQuantity: 45,
    lowStockThreshold: 15,
    shopId: "shop-1",
    supplierId: "sup-1",
    status: "Active",
  },
  {
    id: "prod-4",
    sku: "GRO-EGGS-004",
    name: "Free-Range Large Brown Eggs (1 Dozen)",
    description: "Certified free-range large brown eggs. High protein, ethically raised.",
    category: "Dairy",
    costPrice: 1.9,
    sellingPrice: 3.99,
    stockQuantity: 18,
    lowStockThreshold: 8,
    shopId: "shop-1",
    supplierId: "sup-1",
    status: "Active",
  },

  // Apparel Shop Products
  {
    id: "prod-5",
    sku: "APP-TEE-001",
    name: "Classic Pima Cotton Tee (Black / M)",
    description: "Luxuriously soft Pima cotton crewneck tee. Highly breathable and durable.",
    category: "Apparel",
    costPrice: 8.5,
    sellingPrice: 24.99,
    stockQuantity: 30,
    lowStockThreshold: 10,
    shopId: "shop-2",
    supplierId: "sup-2",
    status: "Active",
  },
  {
    id: "prod-6",
    sku: "APP-JEAN-002",
    name: "Slim Fit Stretch Denim (Indigo / 32)",
    description: "Premium washed stretch denim jeans. Tailored fit, flexible and comfortable.",
    category: "Apparel",
    costPrice: 18.0,
    sellingPrice: 59.99,
    stockQuantity: 15,
    lowStockThreshold: 5,
    shopId: "shop-2",
    supplierId: "sup-2",
    status: "Active",
  },
  {
    id: "prod-7",
    sku: "APP-JACK-003",
    name: "Windbreaker Active Jacket (Grey / L)",
    description: "Water-resistant windbreaker jacket with fleece lining and zip pockets.",
    category: "Apparel",
    costPrice: 22.0,
    sellingPrice: 79.99,
    stockQuantity: 2, // Dangerously low stock
    lowStockThreshold: 5,
    shopId: "shop-2",
    supplierId: "sup-2",
    status: "Active",
  },

  // Cafe Products
  {
    id: "prod-8",
    sku: "CAF-ESP-001",
    name: "Signature Espresso Beans (1lb Bag)",
    description: "Dark roast artisanal blend with notes of dark chocolate and toasted hazelnuts.",
    category: "Coffee Beans",
    costPrice: 6.0,
    sellingPrice: 16.5,
    stockQuantity: 32,
    lowStockThreshold: 10,
    shopId: "shop-3",
    supplierId: "sup-3",
    status: "Active",
  },
  {
    id: "prod-9",
    sku: "CAF-LAT-002",
    name: "Vanilla Latte (Hot / Large)",
    description: "Double espresso shot with steamed organic milk and house-made vanilla bean syrup.",
    category: "Beverages",
    costPrice: 0.9,
    sellingPrice: 5.25,
    stockQuantity: 999, // Infinite virtual stock
    lowStockThreshold: 10,
    shopId: "shop-3",
    supplierId: "sup-3",
    status: "Active",
  },
  {
    id: "prod-10",
    sku: "CAF-CRO-003",
    name: "Butter Croissant (Freshly Baked)",
    description: "Flaky, multi-layered French style butter croissant, golden and light.",
    category: "Pastries",
    costPrice: 1.1,
    sellingPrice: 3.75,
    stockQuantity: 3, // Very low
    lowStockThreshold: 8,
    shopId: "shop-3",
    supplierId: "sup-3",
    status: "Active",
  }
];

// Helper to construct dates relative to today
const getDateAgo = (days: number, hoursOffset: number = 0): string => {
  const d = new Date();
  d.setDate(d.getDate() - days);
  d.setHours(d.getHours() - hoursOffset);
  return d.toISOString();
};

export const INITIAL_TRANSACTIONS: Transaction[] = [
  // Day -6 Transactions
  {
    id: "tx-1",
    invoiceNumber: "INV-2026-0001",
    date: getDateAgo(6, 4),
    shopId: "shop-1",
    items: [
      { productId: "prod-1", productName: "Organic Whole Milk (1 Gallon)", sku: "GRO-MILK-001", price: 4.99, cost: 2.8, quantity: 2, subtotal: 9.98 },
      { productId: "prod-2", productName: "Artisanal Sourdough Bread", sku: "GRO-BREAD-002", price: 3.5, cost: 1.5, quantity: 1, subtotal: 3.50 }
    ],
    subtotal: 13.48,
    discount: 0,
    tax: 1.11,
    total: 14.59,
    profit: 5.68,
    paymentMethod: "Cash",
    customerName: "Jane Doe"
  },
  {
    id: "tx-2",
    invoiceNumber: "INV-2026-0002",
    date: getDateAgo(6, 1),
    shopId: "shop-3",
    items: [
      { productId: "prod-9", productName: "Vanilla Latte (Hot / Large)", sku: "CAF-LAT-002", price: 5.25, cost: 0.9, quantity: 2, subtotal: 10.50 },
      { productId: "prod-10", productName: "Butter Croissant (Freshly Baked)", sku: "CAF-CRO-003", price: 3.75, cost: 1.1, quantity: 1, subtotal: 3.75 }
    ],
    subtotal: 14.25,
    discount: 10, // 10% discount
    tax: 1.02,
    total: 13.85,
    profit: 9.92,
    paymentMethod: "Mobile Pay",
    customerName: "Alice Smith"
  },
  
  // Day -5
  {
    id: "tx-3",
    invoiceNumber: "INV-2026-0003",
    date: getDateAgo(5, 5),
    shopId: "shop-2",
    items: [
      { productId: "prod-5", productName: "Classic Pima Cotton Tee (Black / M)", sku: "APP-TEE-001", price: 24.99, cost: 8.5, quantity: 2, subtotal: 49.98 },
      { productId: "prod-6", productName: "Slim Fit Stretch Denim (Indigo / 32)", sku: "APP-JEAN-002", price: 59.99, cost: 18.0, quantity: 1, subtotal: 59.99 }
    ],
    subtotal: 109.97,
    discount: 0,
    tax: 9.76,
    total: 119.73,
    profit: 74.97,
    paymentMethod: "Card",
    customerName: "Thomas Wright"
  },

  // Day -4
  {
    id: "tx-4",
    invoiceNumber: "INV-2026-0004",
    date: getDateAgo(4, 2),
    shopId: "shop-1",
    items: [
      { productId: "prod-3", productName: "Honeycrisp Apples (1lb)", sku: "GRO-APPLE-003", price: 2.49, cost: 1.1, quantity: 4, subtotal: 9.96 },
      { productId: "prod-4", productName: "Free-Range Large Brown Eggs (1 Dozen)", sku: "GRO-EGGS-004", price: 3.99, cost: 1.9, quantity: 1, subtotal: 3.99 }
    ],
    subtotal: 13.95,
    discount: 5,
    tax: 1.10,
    total: 14.35,
    profit: 7.05,
    paymentMethod: "Card",
  },

  // Day -3
  {
    id: "tx-5",
    invoiceNumber: "INV-2026-0005",
    date: getDateAgo(3, 7),
    shopId: "shop-3",
    items: [
      { productId: "prod-8", productName: "Signature Espresso Beans (1lb Bag)", sku: "CAF-ESP-001", price: 16.5, cost: 6.0, quantity: 1, subtotal: 16.5 },
      { productId: "prod-9", productName: "Vanilla Latte (Hot / Large)", sku: "CAF-LAT-002", price: 5.25, cost: 0.9, quantity: 1, subtotal: 5.25 }
    ],
    subtotal: 21.75,
    discount: 0,
    tax: 1.74,
    total: 23.49,
    profit: 14.85,
    paymentMethod: "Mobile Pay",
  },
  {
    id: "tx-6",
    invoiceNumber: "INV-2026-0006",
    date: getDateAgo(3, 1),
    shopId: "shop-2",
    items: [
      { productId: "prod-6", productName: "Slim Fit Stretch Denim (Indigo / 32)", sku: "APP-JEAN-002", price: 59.99, cost: 18.0, quantity: 1, subtotal: 59.99 }
    ],
    subtotal: 59.99,
    discount: 0,
    tax: 5.32,
    total: 65.31,
    profit: 41.99,
    paymentMethod: "Card",
    customerName: "David Miller"
  },

  // Day -2
  {
    id: "tx-7",
    invoiceNumber: "INV-2026-0007",
    date: getDateAgo(2, 4),
    shopId: "shop-1",
    items: [
      { productId: "prod-1", productName: "Organic Whole Milk (1 Gallon)", sku: "GRO-MILK-001", price: 4.99, cost: 2.8, quantity: 3, subtotal: 14.97 },
      { productId: "prod-3", productName: "Honeycrisp Apples (1lb)", sku: "GRO-APPLE-003", price: 2.49, cost: 1.1, quantity: 2, subtotal: 4.98 },
      { productId: "prod-4", productName: "Free-Range Large Brown Eggs (1 Dozen)", sku: "GRO-EGGS-004", price: 3.99, cost: 1.9, quantity: 2, subtotal: 7.98 }
    ],
    subtotal: 27.93,
    discount: 0,
    tax: 2.30,
    total: 30.23,
    profit: 15.73,
    paymentMethod: "Cash",
  },

  // Day -1
  {
    id: "tx-8",
    invoiceNumber: "INV-2026-0008",
    date: getDateAgo(1, 6),
    shopId: "shop-3",
    items: [
      { productId: "prod-9", productName: "Vanilla Latte (Hot / Large)", sku: "CAF-LAT-002", price: 5.25, cost: 0.9, quantity: 3, subtotal: 15.75 },
      { productId: "prod-10", productName: "Butter Croissant (Freshly Baked)", sku: "CAF-CRO-003", price: 3.75, cost: 1.1, quantity: 2, subtotal: 7.50 }
    ],
    subtotal: 23.25,
    discount: 10,
    tax: 1.67,
    total: 22.60,
    profit: 15.15,
    paymentMethod: "Card",
  },
  {
    id: "tx-9",
    invoiceNumber: "INV-2026-0009",
    date: getDateAgo(1, 2),
    shopId: "shop-2",
    items: [
      { productId: "prod-5", productName: "Classic Pima Cotton Tee (Black / M)", sku: "APP-TEE-001", price: 24.99, cost: 8.5, quantity: 1, subtotal: 24.99 },
      { productId: "prod-7", productName: "Windbreaker Active Jacket (Grey / L)", sku: "APP-JACK-003", price: 79.99, cost: 22.0, quantity: 1, subtotal: 79.99 }
    ],
    subtotal: 104.98,
    discount: 0,
    tax: 9.32,
    total: 114.30,
    profit: 74.48,
    paymentMethod: "Card",
    customerName: "Sarah Connor"
  },

  // Today
  {
    id: "tx-10",
    invoiceNumber: "INV-2026-0010",
    date: getDateAgo(0, 3), // 3 hours ago
    shopId: "shop-1",
    items: [
      { productId: "prod-1", productName: "Organic Whole Milk (1 Gallon)", sku: "GRO-MILK-001", price: 4.99, cost: 2.8, quantity: 1, subtotal: 4.99 },
      { productId: "prod-2", productName: "Artisanal Sourdough Bread", sku: "GRO-BREAD-002", price: 3.5, cost: 1.5, quantity: 2, subtotal: 7.00 },
      { productId: "prod-4", productName: "Free-Range Large Brown Eggs (1 Dozen)", sku: "GRO-EGGS-004", price: 3.99, cost: 1.9, quantity: 1, subtotal: 3.99 }
    ],
    subtotal: 15.98,
    discount: 0,
    tax: 1.32,
    total: 17.30,
    profit: 8.48,
    paymentMethod: "Mobile Pay",
    customerName: "Robert Downey"
  },
  {
    id: "tx-11",
    invoiceNumber: "INV-2026-0011",
    date: getDateAgo(0, 1), // 1 hour ago
    shopId: "shop-3",
    items: [
      { productId: "prod-9", productName: "Vanilla Latte (Hot / Large)", sku: "CAF-LAT-002", price: 5.25, cost: 0.9, quantity: 4, subtotal: 21.00 },
      { productId: "prod-10", productName: "Butter Croissant (Freshly Baked)", sku: "CAF-CRO-003", price: 3.75, cost: 1.1, quantity: 1, subtotal: 3.75 }
    ],
    subtotal: 24.75,
    discount: 0,
    tax: 1.98,
    total: 26.73,
    profit: 20.05,
    paymentMethod: "Cash",
  }
];

export const INITIAL_STOCK_LOGS: StockLog[] = [
  {
    id: "log-1",
    date: getDateAgo(5, 8),
    productId: "prod-1",
    productName: "Organic Whole Milk (1 Gallon)",
    type: "Restock",
    quantity: 30,
    note: "Received standard monthly supply shipment",
  },
  {
    id: "log-2",
    date: getDateAgo(4, 12),
    productId: "prod-2",
    productName: "Artisanal Sourdough Bread",
    type: "Adjustment",
    quantity: -1,
    note: "Wastage: Bread found stale before opening",
  }
];
