export interface Shop {
  id: string;
  name: string;
  type: "Grocery" | "Apparel" | "Electronics" | "Bookstore" | "Cafe" | "Pharmacy" | "Other";
  location: string;
  phone: string;
  taxRate: number; // percentage, e.g. 8.25
  currency: string; // e.g. $, €, £, ¥, ₹
  color: string; // Tailwind hex or class color for custom badge styling
  isActive: boolean;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  description: string;
  category: string;
  costPrice: number;
  sellingPrice: number;
  stockQuantity: number;
  lowStockThreshold: number;
  shopId: string; // associated shop
  supplierId: string; // associated supplier
  status: "Active" | "Inactive";
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
}

export interface TransactionItem {
  productId: string;
  productName: string;
  sku: string;
  price: number;
  cost: number;
  quantity: number;
  subtotal: number;
}

export interface Transaction {
  id: string;
  invoiceNumber: string;
  date: string; // ISO format
  shopId: string;
  items: TransactionItem[];
  subtotal: number;
  discount: number; // percent discount (e.g. 10)
  tax: number; // calculated tax amount
  total: number;
  profit: number; // calculated as total revenue minus total cost
  paymentMethod: "Cash" | "Card" | "Mobile Pay";
  customerName?: string;
}

export interface SupplierOrder {
  id: string;
  orderNumber: string;
  date: string;
  supplierId: string;
  items: {
    productId: string;
    name: string;
    quantity: number;
    unitCost: number;
  }[];
  total: number;
  status: "Pending" | "Received";
  receivedDate?: string;
}

export interface StockLog {
  id: string;
  date: string;
  productId: string;
  productName: string;
  type: "Restock" | "Adjustment" | "Sale" | "Wastage";
  quantity: number; // Positive for additions, negative for reductions
  note: string;
}
