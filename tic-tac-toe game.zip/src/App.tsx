/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback, useMemo } from 'react';
import { GameMode, AIDifficulty, PlayerKey, Move, GameState, Player } from './types';
import { checkWinner, getAiMove } from './utils/gameLogic';
import { SettingsPanel } from './components/SettingsPanel';
import { StatsPanel } from './components/StatsPanel';
import { GameBoard } from './components/GameBoard';
import { HistoryPanel } from './components/HistoryPanel';

export default function App() {
  // 1. Core settings state
  const [mode, setMode] = useState<GameMode>('pvp');
  const [difficulty, setDifficulty] = useState<AIDifficulty>('impossible');
  const [p1Name, setP1Name] = useState('Player X');
  const [p2Name, setP2Name] = useState('Player O');
  const [p1Symbol, setP1Symbol] = useState<'X' | 'O'>('X');

  // 2. Active game board and state
  const [board, setBoard] = useState<Array<'X' | 'O' | null>>(Array(9).fill(null));
  const [currentPlayerKey, setCurrentPlayerKey] = useState<PlayerKey>('p1');
  const [history, setHistory] = useState<Move[]>([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [winner, setWinner] = useState<PlayerKey | 'draw' | null>(null);
  const [winningLine, setWinningLine] = useState<number[] | null>(null);
  const [isAiThinking, setIsAiThinking] = useState(false);

  // 3. Stats tracking with local storage
  const [stats, setStats] = useState(() => {
    const saved = localStorage.getItem('tictactoe_stats_records_vibranth');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // Fallback
      }
    }
    return { p1Wins: 0, p2Wins: 0, draws: 0 };
  });

  // Save stats to local storage on changes
  useEffect(() => {
    localStorage.setItem('tictactoe_stats_records_vibranth', JSON.stringify(stats));
  }, [stats]);

  // Derived player symbols
  const p2Symbol = p1Symbol === 'X' ? 'O' : 'X';

  const p1: Player = useMemo(() => ({
    name: p1Name.trim() || 'Player X',
    symbol: p1Symbol,
    color: 'pink-500',
    glowColor: 'pink-500/20',
  }), [p1Name, p1Symbol]);

  const p2: Player = useMemo(() => ({
    name: mode === 'ai' ? 'Smart Computer' : (p2Name.trim() || 'Player O'),
    symbol: p2Symbol,
    color: 'cyan-400',
    glowColor: 'cyan-400/20',
  }), [mode, p2Name, p2Symbol]);

  // Unified game state object
  const gameState: GameState = useMemo(() => ({
    board,
    currentPlayerKey,
    history,
    currentStep,
    winner,
    winningLine,
    mode,
    difficulty,
    p1,
    p2,
    stats,
    isAiThinking,
  }), [board, currentPlayerKey, history, currentStep, winner, winningLine, mode, difficulty, p1, p2, stats, isAiThinking]);

  // 4. Function: Restart / Clear current match
  const handleRestartGame = useCallback(() => {
    setBoard(Array(9).fill(null));
    setCurrentPlayerKey('p1');
    setHistory([]);
    setCurrentStep(0);
    setWinner(null);
    setWinningLine(null);
    setIsAiThinking(false);
  }, []);

  // Reset match list on setup change
  useEffect(() => {
    handleRestartGame();
  }, [mode, difficulty, p1Symbol, handleRestartGame]);

  // 5. Function: Move placement logic
  const makeMove = useCallback((index: number) => {
    if (board[index] || winner) return;

    // Truncate future steps if viewing a past move
    const actualStep = currentStep;
    const truncatedHistory = history.slice(0, actualStep);

    const activeSymbol = currentPlayerKey === 'p1' ? p1.symbol : p2.symbol;
    const activeName = currentPlayerKey === 'p1' ? p1.name : p2.name;

    const nextBoard = [...board];
    nextBoard[index] = activeSymbol;

    const winResult = checkWinner(nextBoard);
    const nextStep = actualStep + 1;

    const newMove: Move = {
      step: nextStep,
      index,
      playerKey: currentPlayerKey,
      playerSymbol: activeSymbol,
      playerName: activeName,
      boardState: nextBoard,
    };

    const nextHistory = [...truncatedHistory, newMove];

    setBoard(nextBoard);
    setHistory(nextHistory);
    setCurrentStep(nextStep);

    if (winResult.winnerSymbol === 'draw') {
      setWinner('draw');
      setStats((prev) => ({ ...prev, draws: prev.draws + 1 }));
    } else if (winResult.winnerSymbol) {
      setWinner(currentPlayerKey);
      setStats((prev) => {
        if (currentPlayerKey === 'p1') {
          return { ...prev, p1Wins: prev.p1Wins + 1 };
        } else {
          return { ...prev, p2Wins: prev.p2Wins + 1 };
        }
      });
      setWinningLine(winResult.line);
    } else {
      setCurrentPlayerKey(currentPlayerKey === 'p1' ? 'p2' : 'p1');
    }
  }, [board, winner, currentStep, history, currentPlayerKey, p1, p2]);

  // Wrapper for user board cell clicks to block double clicks or clicking during AI turns
  const handleCellClick = useCallback((index: number) => {
    if (board[index] || winner) return;
    if (mode === 'ai' && currentPlayerKey === 'p2') return;
    if (isAiThinking) return;
    makeMove(index);
  }, [board, winner, mode, currentPlayerKey, isAiThinking, makeMove]);

  // 6. AI Move engine
  useEffect(() => {
    if (mode !== 'ai' || currentPlayerKey !== 'p2' || winner) return;

    // Ensure we are in the "present" step to let AI think
    if (currentStep !== history.length) return;

    setIsAiThinking(true);

    const timer = setTimeout(() => {
      const aiMove = getAiMove(board, p2.symbol, p1.symbol, difficulty);
      if (aiMove !== -1) {
        makeMove(aiMove);
      }
      setIsAiThinking(false);
    }, 600); // Snappy 600ms delay for delightful responsiveness and visual feedback

    return () => {
      clearTimeout(timer);
      setIsAiThinking(false);
    };
  }, [mode, currentPlayerKey, winner, currentStep, history.length, board, p1.symbol, p2.symbol, difficulty, makeMove]);

  // 7. Timeline Traversal functions
  const handleJumpToStep = useCallback((step: number) => {
    if (step < 0 || step > history.length) return;

    setCurrentStep(step);

    if (step === 0) {
      setBoard(Array(9).fill(null));
      setCurrentPlayerKey('p1');
      setWinner(null);
      setWinningLine(null);
    } else {
      const targetMove = history[step - 1];
      setBoard(targetMove.boardState);
      setCurrentPlayerKey(targetMove.playerKey === 'p1' ? 'p2' : 'p1');

      // Recalculate winner state for this past step
      const winResult = checkWinner(targetMove.boardState);
      if (winResult.winnerSymbol === 'draw') {
        setWinner('draw');
        setWinningLine(null);
      } else if (winResult.winnerSymbol) {
        setWinner(targetMove.playerKey);
        setWinningLine(winResult.line);
      } else {
        setWinner(null);
        setWinningLine(null);
      }
    }
  }, [history]);

  const handleUndo = useCallback(() => {
    if (currentStep > 0) {
      handleJumpToStep(currentStep - 1);
    }
  }, [currentStep, handleJumpToStep]);

  const handleRedo = useCallback(() => {
    if (currentStep < history.length) {
      handleJumpToStep(currentStep + 1);
    }
  }, [currentStep, history.length, handleJumpToStep]);

  const handleResetScores = useCallback(() => {
    if (window.confirm('Are you sure you want to clear your win/loss statistics?')) {
      setStats({ p1Wins: 0, p2Wins: 0, draws: 0 });
    }
  }, []);

  const totalMatches = stats.p1Wins + stats.p2Wins + stats.draws;

  return (
    <div className="min-h-screen bg-indigo-900 text-white font-sans flex flex-col justify-between overflow-x-hidden antialiased">
      <div className="flex-1 w-full max-w-7xl mx-auto p-4 md:p-8 flex flex-col gap-6">
        {/* Dynamic Header from Vibrant Palette */}
        <div className="flex flex-col sm:flex-row justify-between items-center sm:items-end border-b-4 border-indigo-500 pb-5 gap-4">
          <div className="text-center sm:text-left">
            <h1 className="text-4xl md:text-6xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-purple-400 to-cyan-400 leading-none">
              NEON TIC-TAC-TOE
            </h1>
            <p className="text-indigo-300 font-bold tracking-widest mt-2 uppercase text-[10px] md:text-xs">
              TOURNAMENT EDITION V2.0
            </p>
          </div>
          <div className="flex gap-4">
            <div className="bg-indigo-950/60 px-5 py-2.5 rounded-full border-2 border-indigo-500 flex items-center gap-2.5 shadow-lg shadow-indigo-950/40">
              <span className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></span>
              <span className="font-mono font-bold tracking-wider text-xs uppercase">
                {mode === 'ai' ? 'CPU MATCH ENABLED' : 'PVP ARENA ACTIVE'}
              </span>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start my-2">
          {/* Left Column: Settings and Stats (col-span-4) */}
          <div className="lg:col-span-4 space-y-6 flex flex-col">
            <SettingsPanel
              mode={mode}
              difficulty={difficulty}
              p1Name={p1Name}
              p2Name={p2Name}
              p1Symbol={p1Symbol}
              onModeChange={setMode}
              onDifficultyChange={setDifficulty}
              onP1NameChange={setP1Name}
              onP2NameChange={setP2Name}
              onP1SymbolChange={setP1Symbol}
            />

            <StatsPanel gameState={gameState} onResetScores={handleResetScores} />
          </div>

          {/* Center Column: The Neon Board (col-span-5) */}
          <div className="lg:col-span-5 flex justify-center items-center py-4">
            <GameBoard
              gameState={gameState}
              onCellClick={handleCellClick}
              onRestartGame={handleRestartGame}
            />
          </div>

          {/* Right Column: Move history with Time-Travel (col-span-3) */}
          <div className="lg:col-span-3">
            <HistoryPanel
              gameState={gameState}
              onJumpToStep={handleJumpToStep}
              onUndo={handleUndo}
              onRedo={handleRedo}
              onClearHistory={handleRestartGame}
            />
          </div>
        </div>
      </div>

      {/* Footer Status Bar from Vibrant Palette */}
      <footer className="h-14 bg-indigo-950/90 border-t border-indigo-800 flex flex-col sm:flex-row items-center justify-between px-6 md:px-12 py-3 gap-2.5 sm:gap-0 mt-6 select-none shrink-0">
        <div className="flex gap-6 md:gap-8 text-[10px] md:text-xs font-black uppercase tracking-widest text-indigo-400">
          <span>STREAK: {totalMatches > 0 ? `${totalMatches} MATCHES` : '0 MATCHES'}</span>
          <span>P1 WINS: {stats.p1Wins}</span>
          <span>P2 WINS: {stats.p2Wins}</span>
          <span>DRAWS: {stats.draws}</span>
        </div>
        <div className="text-[10px] md:text-xs font-mono font-bold text-indigo-500 uppercase tracking-wider">
          SYSTEM OK // GRAPHICS RENDER: NEON_V2 // INPUT POLLING: 60HZ
        </div>
      </footer>
    </div>
  );
}
