import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, HelpCircle, AlertCircle } from 'lucide-react';
import { GameState, PlayerKey } from '../types';

interface GameBoardProps {
  gameState: GameState;
  onCellClick: (index: number) => void;
  onRestartGame: () => void;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  gameState,
  onCellClick,
  onRestartGame,
}) => {
  const { board, currentPlayerKey, winner, winningLine, p1, p2, isAiThinking } = gameState;

  const currentPlayer = currentPlayerKey === 'p1' ? p1 : p2;
  const isGameOver = !!winner;

  // Helper to map winning line combinations to the exact screen position overlay
  const getLineOverlayClass = (line: number[]) => {
    const s = line.join(',');
    if (s === '0,1,2') return 'top-[16.6%] left-[5%] w-[90%] h-2.5 rotate-0';
    if (s === '3,4,5') return 'top-[50%] left-[5%] w-[90%] h-2.5 rotate-0 -translate-y-1/2';
    if (s === '6,7,8') return 'bottom-[16.6%] left-[5%] w-[90%] h-2.5 rotate-0';
    if (s === '0,3,6') return 'left-[16.6%] top-[5%] h-[90%] w-2.5 rotate-0';
    if (s === '1,4,7') return 'left-[50%] top-[5%] h-[90%] w-2.5 rotate-0 -translate-x-1/2';
    if (s === '2,5,8') return 'right-[16.6%] top-[5%] h-[90%] w-2.5 rotate-0';
    if (s === '0,4,8') return 'top-[50%] left-[50%] w-[116%] h-2.5 rotate-45 -translate-x-1/2 -translate-y-1/2';
    if (s === '2,4,6') return 'top-[50%] left-[50%] w-[116%] h-2.5 -rotate-45 -translate-x-1/2 -translate-y-1/2';
    return '';
  };

  return (
    <div className="flex flex-col items-center w-full">
      {/* Current Turn / Winner Banner */}
      <div className="w-full mb-6 text-center">
        {!isGameOver ? (
          <div className="inline-block transform rotate-1 transition-all duration-200">
            <div className="bg-yellow-400 text-indigo-950 font-black tracking-widest text-center uppercase py-2.5 px-6 rounded-2xl border-4 border-white shadow-xl shadow-yellow-500/10 text-xs md:text-sm flex items-center gap-2 justify-center">
              {isAiThinking ? (
                <>
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-900 animate-pulse" />
                  <span>{p2.name} is thinking...</span>
                </>
              ) : (
                <>
                  <span
                    className={`w-2.5 h-2.5 rounded-full ${
                      currentPlayer.symbol === 'X' ? 'bg-pink-600 animate-ping' : 'bg-cyan-600 animate-ping'
                    }`}
                  />
                  <span>
                    Current Turn:{' '}
                    <span className={currentPlayer.symbol === 'X' ? 'text-pink-700' : 'text-cyan-700'}>
                      {currentPlayer.name}
                    </span>{' '}
                    ({currentPlayer.symbol})
                  </span>
                </>
              )}
            </div>
          </div>
        ) : (
          <div className="inline-block transform -rotate-1 transition-all duration-200">
            <div
              className={`bg-gradient-to-r ${
                winner === 'draw'
                  ? 'from-amber-400 to-yellow-500 border-white text-indigo-950'
                  : winner === 'p1'
                  ? 'from-pink-500 to-rose-600 border-white text-white shadow-[0_0_20px_rgba(244,114,182,0.4)]'
                  : 'from-cyan-400 to-indigo-600 border-white text-white shadow-[0_0_20px_rgba(34,211,238,0.4)]'
              } font-black uppercase text-center text-xs md:text-sm py-3 px-6 rounded-2xl border-4 shadow-xl tracking-wider flex items-center justify-center gap-2`}
            >
              {winner === 'draw' ? (
                <>
                  <AlertCircle className="w-4 h-4 text-indigo-950" />
                  <span>It&apos;s a Tournament Draw!</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-yellow-300 animate-bounce" />
                  <span>
                    {winner === 'p1' ? p1.name : p2.name} Wins the Arena!
                  </span>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Grid Canvas Container with Neon Highlights */}
      <div className="relative w-full aspect-square max-w-[340px] md:max-w-[360px] bg-indigo-800/20 rounded-[32px] border-4 border-indigo-700/80 p-4 shadow-2xl grid grid-cols-3 gap-3.5">
        {board.map((cell, index) => {
          const isWinningCell = winningLine?.includes(index);
          const isEmpty = cell === null;

          return (
            <button
              key={index}
              disabled={!isEmpty || isGameOver || isAiThinking}
              onClick={() => onCellClick(index)}
              className={`relative aspect-square bg-indigo-950 border-4 border-indigo-700/70 hover:border-indigo-500 rounded-2xl flex items-center justify-center text-5xl font-black shadow-inner transition-all duration-150 cursor-pointer select-none overflow-hidden ${
                isWinningCell
                  ? 'border-white bg-indigo-800 animate-pulse'
                  : ''
              }`}
              id={`cell-${index}`}
            >
              {/* Ghost Marker on Hover */}
              {isEmpty && !isGameOver && !isAiThinking && (
                <div
                  className={`absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-20 transition-opacity duration-150 text-4xl font-extrabold ${
                    currentPlayer.symbol === 'X' ? 'text-pink-500' : 'text-cyan-400'
                  }`}
                >
                  {currentPlayer.symbol}
                </div>
              )}

              {/* Real Marker with Vibrant Colors & Animation */}
              {cell && (
                <motion.div
                  initial={{ scale: 0.3, opacity: 0, rotate: cell === 'X' ? -30 : 30 }}
                  animate={{ scale: 1, opacity: 1, rotate: 0 }}
                  transition={{ type: 'spring', stiffness: 280, damping: 18 }}
                  className="w-full h-full flex items-center justify-center"
                >
                  {cell === 'X' ? (
                    <span className="text-4xl md:text-5xl font-black tracking-tighter text-pink-500 drop-shadow-[0_0_12px_#ec4899] font-sans">
                      X
                    </span>
                  ) : (
                    <span className="text-4xl md:text-5xl font-black tracking-tighter text-cyan-400 drop-shadow-[0_0_12px_#06b6d4] font-sans">
                      O
                    </span>
                  )}
                </motion.div>
              )}
            </button>
          );
        })}

        {/* Dynamic Vector Neon Line Overlay on win */}
        {winningLine && (
          <div
            className={`absolute rounded-full pointer-events-none blur-xs bg-gradient-to-r from-pink-400 via-white to-cyan-400 shadow-[0_0_20px_#f472b6,0_0_20px_#22d3ee] ${getLineOverlayClass(
              winningLine
            )}`}
          />
        )}
      </div>

      {/* Reset/Play Again Button */}
      {isGameOver && (
        <motion.button
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={onRestartGame}
          className="mt-6 w-full max-w-[340px] md:max-w-[360px] bg-gradient-to-r from-orange-400 to-pink-500 rounded-2xl font-black uppercase text-lg shadow-lg hover:brightness-110 active:scale-95 transition-all text-white py-3.5 px-6 cursor-pointer flex items-center justify-center gap-2"
          id="play-again-btn"
        >
          Reset Arena
        </motion.button>
      )}
    </div>
  );
};
