import React from 'react';
import { History, RotateCcw, Undo2, Redo2, Eye, EyeOff } from 'lucide-react';
import { GameState } from '../types';

interface HistoryPanelProps {
  gameState: GameState;
  onJumpToStep: (step: number) => void;
  onUndo: () => void;
  onRedo: () => void;
  onClearHistory: () => void;
}

const POSITION_LABELS = [
  'Top-Left',
  'Top-Center',
  'Top-Right',
  'Middle-Left',
  'Center',
  'Middle-Right',
  'Bottom-Left',
  'Bottom-Center',
  'Bottom-Right',
];

export const HistoryPanel: React.FC<HistoryPanelProps> = ({
  gameState,
  onJumpToStep,
  onUndo,
  onRedo,
  onClearHistory,
}) => {
  const { history, currentStep } = gameState;

  const canUndo = currentStep > 0;
  const canRedo = currentStep < history.length;
  const isViewingPast = currentStep < history.length;

  return (
    <div className="w-full bg-indigo-950/50 backdrop-blur-md rounded-3xl border-4 border-indigo-500/20 p-5 shadow-xl flex flex-col h-full">
      <div className="flex justify-between items-center mb-4 border-b border-indigo-800/80 pb-3">
        <h3 className="font-sans text-sm font-black tracking-widest text-indigo-300 uppercase flex items-center gap-1.5">
          <History className="w-4 h-4 text-pink-500" /> Move History
        </h3>
        <button
          onClick={onClearHistory}
          disabled={history.length === 0}
          className="text-[10px] font-black uppercase tracking-wider text-indigo-300 hover:text-white flex items-center gap-1 bg-indigo-900/40 hover:bg-indigo-900/95 disabled:opacity-30 disabled:pointer-events-none py-1.5 px-2.5 rounded-xl border border-indigo-700/60 transition-all cursor-pointer"
          id="clear-history-btn"
        >
          <RotateCcw className="w-3.5 h-3.5" /> Restart
        </button>
      </div>

      {/* Undo/Redo Controls */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        <button
          onClick={onUndo}
          disabled={!canUndo}
          className="flex items-center justify-center gap-1.5 py-2 px-3 bg-indigo-900/60 border border-indigo-700 text-indigo-200 hover:bg-indigo-800/80 disabled:opacity-30 disabled:hover:bg-transparent rounded-xl text-xs font-bold transition-all cursor-pointer"
          title="Undo move"
          id="undo-btn"
        >
          <Undo2 className="w-4 h-4" /> Undo
        </button>
        <button
          onClick={onRedo}
          disabled={!canRedo}
          className="flex items-center justify-center gap-1.5 py-2 px-3 bg-indigo-900/60 border border-indigo-700 text-indigo-200 hover:bg-indigo-800/80 disabled:opacity-30 disabled:hover:bg-transparent rounded-xl text-xs font-bold transition-all cursor-pointer"
          title="Redo move"
          id="redo-btn"
        >
          <Redo2 className="w-4 h-4" /> Redo
        </button>
      </div>

      {/* Past View Warning Banner */}
      {isViewingPast && (
        <div className="mb-3 flex items-center gap-1.5 text-xs text-yellow-300 bg-yellow-500/10 border border-yellow-500/30 p-2.5 rounded-xl">
          <Eye className="w-4 h-4 shrink-0 text-yellow-400 animate-pulse" />
          <p className="leading-normal font-bold">
            Viewing Step {currentStep}. Placing a move now will overwrite future history.
          </p>
        </div>
      )}

      {/* Timeline List of Moves */}
      <div className="flex-1 overflow-y-auto max-h-[220px] md:max-h-[310px] space-y-2 pr-1 scrollbar-thin">
        {/* Step 0 - Initial State */}
        <button
          onClick={() => onJumpToStep(0)}
          className={`w-full flex items-center justify-between p-3 rounded-xl text-left text-xs transition-all border-l-4 cursor-pointer ${
            currentStep === 0
              ? 'bg-indigo-800/60 border-yellow-400 text-yellow-300 font-bold shadow-md shadow-yellow-500/10'
              : 'bg-indigo-900/20 border-indigo-700 text-indigo-300 hover:bg-indigo-900/50 hover:border-indigo-600'
          }`}
          id="step-0-btn"
        >
          <span className="flex items-center gap-2">
            <span className="w-5 h-5 rounded-lg bg-indigo-950 text-indigo-300 flex items-center justify-center font-mono font-bold text-[10px]">
              0
            </span>
            <span className="uppercase tracking-wider font-bold">Game Started</span>
          </span>
          <span className="text-[10px] font-mono text-indigo-400 font-bold">EMPTY BOARD</span>
        </button>

        {history.map((move) => {
          const isActive = currentStep === move.step;
          const isP1 = move.playerSymbol === 'X';
          const symbolBorder = isP1 ? 'border-pink-500' : 'border-cyan-400';
          const activeBorder = isActive ? 'border-yellow-400' : symbolBorder;

          return (
            <button
              key={move.step}
              onClick={() => onJumpToStep(move.step)}
              className={`w-full flex items-center justify-between p-3 rounded-xl text-left text-xs transition-all border-l-4 cursor-pointer ${
                isActive
                  ? 'bg-indigo-800/60 text-white font-bold shadow-md shadow-indigo-500/10'
                  : 'bg-indigo-900/20 text-indigo-200 hover:bg-indigo-900/50 hover:border-indigo-600'
              } ${activeBorder}`}
              id={`step-${move.step}-btn`}
            >
              <span className="flex items-center gap-2 truncate">
                <span
                  className={`w-5 h-5 rounded-lg flex items-center justify-center font-mono font-black text-[10px] ${
                    isP1
                      ? 'bg-pink-500/20 text-pink-400'
                      : 'bg-cyan-400/20 text-cyan-400'
                  }`}
                >
                  {move.step}
                </span>
                <span className="truncate">
                  <strong className={isP1 ? 'text-pink-400 font-black' : 'text-cyan-400 font-black'}>
                    {move.playerName}
                  </strong>{' '}
                  played{' '}
                  <strong className={isP1 ? 'text-pink-400 font-black' : 'text-cyan-400 font-black'}>
                    {move.playerSymbol}
                  </strong>
                </span>
              </span>
              <span className="text-[10px] font-black tracking-wider uppercase text-indigo-400 shrink-0">
                {POSITION_LABELS[move.index]}
              </span>
            </button>
          );
        })}

        {history.length === 0 && (
          <div className="py-8 text-center text-indigo-400 text-xs flex flex-col items-center justify-center gap-1.5 border border-dashed border-indigo-800 rounded-2xl bg-indigo-950/20">
            <History className="w-5 h-5 text-indigo-500/80 mb-1" />
            <span className="font-bold uppercase tracking-widest text-[10px] text-indigo-400">No moves placed yet</span>
          </div>
        )}
      </div>

      {isViewingPast && (
        <button
          onClick={() => onJumpToStep(history.length)}
          className="mt-3 w-full bg-gradient-to-r from-pink-500 to-indigo-600 hover:brightness-110 text-white font-black text-xs py-2.5 px-3 rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer uppercase tracking-wider border border-pink-400/30"
          id="resume-latest-btn"
        >
          <EyeOff className="w-3.5 h-3.5" /> Return to Present
        </button>
      )}
    </div>
  );
};
