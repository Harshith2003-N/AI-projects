import React from 'react';
import { Users, Cpu, Settings } from 'lucide-react';
import { GameMode, AIDifficulty } from '../types';

interface SettingsPanelProps {
  mode: GameMode;
  difficulty: AIDifficulty;
  p1Name: string;
  p2Name: string;
  p1Symbol: 'X' | 'O';
  onModeChange: (mode: GameMode) => void;
  onDifficultyChange: (difficulty: AIDifficulty) => void;
  onP1NameChange: (name: string) => void;
  onP2NameChange: (name: string) => void;
  onP1SymbolChange: (symbol: 'X' | 'O') => void;
}

export const SettingsPanel: React.FC<SettingsPanelProps> = ({
  mode,
  difficulty,
  p1Name,
  p2Name,
  p1Symbol,
  onModeChange,
  onDifficultyChange,
  onP1NameChange,
  onP2NameChange,
  onP1SymbolChange,
}) => {
  return (
    <div className="w-full bg-indigo-950/60 backdrop-blur-md rounded-3xl border-4 border-indigo-500/30 p-5 shadow-xl">
      <h3 className="font-sans text-sm font-black tracking-widest text-indigo-300 uppercase flex items-center gap-2 mb-5">
        <Settings className="w-4 h-4 text-pink-500 animate-spin-slow" /> Match Setup
      </h3>

      {/* Mode Selection */}
      <div className="mb-5">
        <label className="block text-xs font-black text-indigo-300 uppercase tracking-widest mb-2.5">
          Game Mode
        </label>
        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={() => onModeChange('pvp')}
            className={`flex items-center justify-center gap-2 py-3 px-3 rounded-2xl border font-bold text-sm transition-all cursor-pointer ${
              mode === 'pvp'
                ? 'bg-gradient-to-r from-pink-500 to-indigo-600 border-2 border-pink-400 text-white shadow-lg shadow-pink-500/20'
                : 'bg-indigo-900/60 border border-indigo-700/60 text-indigo-200 hover:bg-indigo-800/80'
            }`}
            id="mode-pvp-btn"
          >
            <Users className="w-4 h-4" />
            Pass & Play
          </button>
          <button
            onClick={() => onModeChange('ai')}
            className={`flex items-center justify-center gap-2 py-3 px-3 rounded-2xl border font-bold text-sm transition-all cursor-pointer ${
              mode === 'ai'
                ? 'bg-gradient-to-r from-pink-500 to-indigo-600 border-2 border-pink-400 text-white shadow-lg shadow-pink-500/20'
                : 'bg-indigo-900/60 border border-indigo-700/60 text-indigo-200 hover:bg-indigo-800/80'
            }`}
            id="mode-ai-btn"
          >
            <Cpu className="w-4 h-4" />
            vs Computer
          </button>
        </div>
      </div>

      {/* AI Difficulty */}
      {mode === 'ai' && (
        <div className="mb-5 bg-indigo-900/40 border border-indigo-800/80 p-3.5 rounded-2xl">
          <label className="block text-[10px] font-black text-indigo-300 uppercase tracking-widest mb-2">
            Computer Difficulty
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['easy', 'medium', 'impossible'] as AIDifficulty[]).map((diff) => (
              <button
                key={diff}
                onClick={() => onDifficultyChange(diff)}
                className={`py-1.5 px-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                  difficulty === diff
                    ? 'bg-gradient-to-r from-pink-500 to-indigo-600 border border-pink-400 text-white shadow-md'
                    : 'bg-indigo-950/80 border border-indigo-800/50 text-indigo-300 hover:bg-indigo-800/40'
                }`}
                id={`diff-${diff}-btn`}
              >
                {diff === 'impossible' ? 'Master' : diff}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Names & Customization */}
      <div className="space-y-4">
        <div>
          <label className="block text-[10px] font-black text-indigo-300 uppercase tracking-widest mb-2">
            Player 1 Name
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={p1Name}
              onChange={(e) => onP1NameChange(e.target.value.slice(0, 15))}
              className="flex-1 bg-indigo-900/60 border-2 border-indigo-700/80 rounded-2xl px-3.5 py-2.5 text-sm text-white placeholder-indigo-400/50 focus:outline-none focus:border-pink-500 transition-all font-bold"
              placeholder="Player 1"
              id="p1-name-input"
            />
            <div className="flex bg-indigo-950 border-2 border-indigo-700/80 p-1 rounded-2xl">
              <button
                onClick={() => onP1SymbolChange('X')}
                className={`w-8 h-8 flex items-center justify-center rounded-xl text-sm font-black transition-all cursor-pointer ${
                  p1Symbol === 'X'
                    ? 'bg-pink-500 text-white shadow-md shadow-pink-500/30'
                    : 'text-indigo-400 hover:text-indigo-200'
                }`}
                title="Play as X"
                id="symbol-x-btn"
              >
                X
              </button>
              <button
                onClick={() => onP1SymbolChange('O')}
                className={`w-8 h-8 flex items-center justify-center rounded-xl text-sm font-black transition-all cursor-pointer ${
                  p1Symbol === 'O'
                    ? 'bg-cyan-400 text-indigo-950 shadow-md shadow-cyan-400/30'
                    : 'text-indigo-400 hover:text-indigo-200'
                }`}
                title="Play as O"
                id="symbol-o-btn"
              >
                O
              </button>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-black text-indigo-300 uppercase tracking-widest mb-2">
            Player 2 Name
          </label>
          <input
            type="text"
            value={mode === 'ai' ? 'Smart Computer' : p2Name}
            disabled={mode === 'ai'}
            onChange={(e) => onP2NameChange(e.target.value.slice(0, 15))}
            className={`w-full border-2 rounded-2xl px-3.5 py-2.5 text-sm transition-all font-bold ${
              mode === 'ai'
                ? 'bg-indigo-950/60 border-indigo-900/50 text-indigo-500/60 cursor-not-allowed'
                : 'bg-indigo-900/60 border-indigo-700/80 text-white placeholder-indigo-400/50 focus:outline-none focus:border-cyan-400'
            }`}
            placeholder="Player 2"
            id="p2-name-input"
          />
        </div>
      </div>
    </div>
  );
};
