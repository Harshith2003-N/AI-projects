import React from 'react';
import { Trophy, RefreshCw, Sparkles } from 'lucide-react';
import { GameState } from '../types';

interface StatsPanelProps {
  gameState: GameState;
  onResetScores: () => void;
}

export const StatsPanel: React.FC<StatsPanelProps> = ({ gameState, onResetScores }) => {
  const { stats, p1, p2 } = gameState;
  const totalGames = stats.p1Wins + stats.p2Wins + stats.draws;

  const getWinRate = (wins: number) => {
    if (totalGames === 0) return 0;
    return Math.round((wins / totalGames) * 100);
  };

  const p1Rate = getWinRate(stats.p1Wins);
  const p2Rate = getWinRate(stats.p2Wins);
  const drawRate = totalGames === 0 ? 0 : Math.round((stats.draws / totalGames) * 100);

  return (
    <div className="w-full bg-indigo-950/60 backdrop-blur-md rounded-3xl border-4 border-indigo-500/30 p-5 shadow-xl">
      <div className="flex justify-between items-center mb-5 border-b border-indigo-800/80 pb-3">
        <h3 className="font-sans text-sm font-black tracking-widest text-indigo-300 uppercase flex items-center gap-1.5">
          <Trophy className="w-4 h-4 text-yellow-400" /> Matches Statistics
        </h3>
        <button
          onClick={onResetScores}
          className="text-[10px] font-black uppercase tracking-wider text-indigo-300 hover:text-white flex items-center gap-1 bg-indigo-900/60 hover:bg-indigo-900/95 py-1.5 px-3 rounded-xl border border-indigo-700/60 transition-all cursor-pointer"
          id="reset-scores-btn"
        >
          <RefreshCw className="w-3 h-3" /> Reset
        </button>
      </div>

      <div className="grid grid-cols-3 gap-3 text-center mb-4">
        {/* P1 Stats */}
        <div className="p-3.5 bg-indigo-900/40 rounded-2xl border-2 border-pink-500 flex flex-col items-center justify-between shadow-lg shadow-pink-500/5">
          <span className="text-[10px] font-black uppercase tracking-widest text-indigo-300 truncate w-full" title={p1.name}>
            {p1.name}
          </span>
          <span className="text-3xl font-black text-pink-400 mt-2">
            {stats.p1Wins}
          </span>
          <span className="text-[9px] font-bold text-indigo-300 uppercase mt-2 tracking-wider">{p1Rate}% Wins</span>
        </div>

        {/* Draws */}
        <div className="p-3.5 bg-indigo-900/40 rounded-2xl border-2 border-yellow-400 flex flex-col items-center justify-between shadow-lg shadow-yellow-500/5">
          <span className="text-[10px] font-black uppercase tracking-widest text-indigo-300 w-full">Draws</span>
          <span className="text-3xl font-black text-yellow-400 mt-2">
            {stats.draws}
          </span>
          <span className="text-[9px] font-bold text-indigo-300 uppercase mt-2 tracking-wider">{drawRate}% Draws</span>
        </div>

        {/* P2 Stats */}
        <div className="p-3.5 bg-indigo-900/40 rounded-2xl border-2 border-cyan-400 flex flex-col items-center justify-between shadow-lg shadow-cyan-500/5">
          <span className="text-[10px] font-black uppercase tracking-widest text-indigo-300 truncate w-full" title={p2.name}>
            {p2.name}
          </span>
          <span className="text-3xl font-black text-cyan-400 mt-2">
            {stats.p2Wins}
          </span>
          <span className="text-[9px] font-bold text-indigo-300 uppercase mt-2 tracking-wider">{p2Rate}% Wins</span>
        </div>
      </div>

      <div className="flex items-center gap-2.5 text-xs text-indigo-200 bg-indigo-900/30 border border-indigo-800/60 p-3 rounded-2xl mt-3">
        <Sparkles className="w-4 h-4 text-pink-400 shrink-0 animate-pulse" />
        <p className="leading-snug font-semibold text-[11px] tracking-wide uppercase">
          {totalGames === 0 ? (
            <span>Start playing to log tournament matches</span>
          ) : (
            <span>
              Matches played: <strong className="text-pink-400 font-black">{totalGames}</strong>
            </span>
          )}
        </p>
      </div>
    </div>
  );
};
