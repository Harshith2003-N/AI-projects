export type PlayerKey = 'p1' | 'p2';

export interface Player {
  name: string;
  symbol: 'X' | 'O';
  color: string;
  glowColor: string;
}

export type GameMode = 'pvp' | 'ai';

export type AIDifficulty = 'easy' | 'medium' | 'impossible';

export interface Move {
  step: number;
  index: number;
  playerKey: PlayerKey;
  playerSymbol: 'X' | 'O';
  playerName: string;
  boardState: Array<'X' | 'O' | null>;
}

export interface GameState {
  board: Array<'X' | 'O' | null>;
  currentPlayerKey: PlayerKey;
  history: Move[];
  currentStep: number;
  winner: PlayerKey | 'draw' | null;
  winningLine: number[] | null;
  mode: GameMode;
  difficulty: AIDifficulty;
  p1: Player;
  p2: Player;
  stats: {
    p1Wins: number;
    p2Wins: number;
    draws: number;
  };
  isAiThinking: boolean;
}
