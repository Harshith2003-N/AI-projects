import { AIDifficulty } from '../types';

export const WINNING_COMBINATIONS = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
  [0, 4, 8], [2, 4, 6]             // Diagonals
];

export interface WinResult {
  winnerSymbol: 'X' | 'O' | 'draw' | null;
  line: number[] | null;
}

/**
 * Checks the current board state for a win or a draw.
 */
export function checkWinner(board: Array<'X' | 'O' | null>): WinResult {
  for (const combination of WINNING_COMBINATIONS) {
    const [a, b, c] = combination;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return {
        winnerSymbol: board[a],
        line: combination,
      };
    }
  }

  // Check for draw (all squares filled)
  if (board.every((cell) => cell !== null)) {
    return {
      winnerSymbol: 'draw',
      line: null,
    };
  }

  return {
    winnerSymbol: null,
    line: null,
  };
}

/**
 * Minimax algorithm helper to find the best score.
 */
function minimax(
  board: Array<'X' | 'O' | null>,
  depth: number,
  isMaxing: boolean,
  aiSymbol: 'X' | 'O',
  playerSymbol: 'X' | 'O'
): number {
  const result = checkWinner(board);
  if (result.winnerSymbol === aiSymbol) return 10 - depth;
  if (result.winnerSymbol === playerSymbol) return depth - 10;
  if (result.winnerSymbol === 'draw') return 0;

  if (isMaxing) {
    let bestScore = -Infinity;
    for (let i = 0; i < 9; i++) {
      if (board[i] === null) {
        board[i] = aiSymbol;
        const score = minimax(board, depth + 1, false, aiSymbol, playerSymbol);
        board[i] = null;
        bestScore = Math.max(bestScore, score);
      }
    }
    return bestScore;
  } else {
    let bestScore = Infinity;
    for (let i = 0; i < 9; i++) {
      if (board[i] === null) {
        board[i] = playerSymbol;
        const score = minimax(board, depth + 1, true, aiSymbol, playerSymbol);
        board[i] = null;
        bestScore = Math.min(bestScore, score);
      }
    }
    return bestScore;
  }
}

/**
 * Selects the optimal move for the AI based on difficulty.
 */
export function getAiMove(
  board: Array<'X' | 'O' | null>,
  aiSymbol: 'X' | 'O',
  playerSymbol: 'X' | 'O',
  difficulty: AIDifficulty
): number {
  const availableMoves: number[] = [];
  for (let i = 0; i < 9; i++) {
    if (board[i] === null) {
      availableMoves.push(i);
    }
  }

  if (availableMoves.length === 0) return -1;

  // 1. Easy Mode: Pick a completely random move
  if (difficulty === 'easy') {
    const randomIndex = Math.floor(Math.random() * availableMoves.length);
    return availableMoves[randomIndex];
  }

  // 2. Medium Mode: 40% random / 60% Minimax, OR just checks immediate win/blocks
  if (difficulty === 'medium') {
    // 40% of the time, act easy/random
    if (Math.random() < 0.40) {
      const randomIndex = Math.floor(Math.random() * availableMoves.length);
      return availableMoves[randomIndex];
    }
    
    // Otherwise, check for immediate winning move first
    for (const move of availableMoves) {
      const tempBoard = [...board];
      tempBoard[move] = aiSymbol;
      if (checkWinner(tempBoard).winnerSymbol === aiSymbol) {
        return move;
      }
    }

    // Then check for immediate blocking move
    for (const move of availableMoves) {
      const tempBoard = [...board];
      tempBoard[move] = playerSymbol;
      if (checkWinner(tempBoard).winnerSymbol === playerSymbol) {
        return move;
      }
    }

    // Default to a random move if no quick wins/blocks
    const randomIndex = Math.floor(Math.random() * availableMoves.length);
    return availableMoves[randomIndex];
  }

  // 3. Impossible Mode: Always run full Minimax for perfect play
  // Optimization: If it's the very first move of the game, pick Center (4) or a random corner (0,2,6,8) instantly
  if (availableMoves.length === 9) {
    const openingMoves = [4, 0, 2, 6, 8];
    const pick = openingMoves[Math.floor(Math.random() * openingMoves.length)];
    return pick;
  }

  let bestScore = -Infinity;
  let bestMove = availableMoves[0];

  for (const move of availableMoves) {
    const tempBoard = [...board];
    tempBoard[move] = aiSymbol;
    const score = minimax(tempBoard, 0, false, aiSymbol, playerSymbol);
    if (score > bestScore) {
      bestScore = score;
      bestMove = move;
    }
  }

  return bestMove;
}
